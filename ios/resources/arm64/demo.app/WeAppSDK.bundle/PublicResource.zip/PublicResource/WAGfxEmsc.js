"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }
function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor); } }
function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == _typeof(i) ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != _typeof(t) || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != _typeof(i)) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
var __realWebAssembly = typeof window.WebAssembly !== 'undefined' ? window.WebAssembly : window.__global.WebAssembly;
window.DEVTOOL_WASM_MODULE_FACTORY = function () {
  var exports = void 0;
  var module = void 0;
  var wgfx = function wgfx() {
    (function (e, a) {
      for (var i in a) e[i] = a[i];
    })(exports, /******/function (modules) {
      // webpackBootstrap
      /******/ // The module cache
      /******/
      var installedModules = {};
      /******/
      /******/ // The require function
      /******/
      function __webpack_require__(moduleId) {
        /******/
        /******/ // Check if module is in cache
        /******/if (installedModules[moduleId]) {
          /******/return installedModules[moduleId].exports;
          /******/
        }
        /******/ // Create a new module (and put it into the cache)
        /******/
        var module = installedModules[moduleId] = {
          /******/i: moduleId,
          /******/l: false,
          /******/exports: {}
          /******/
        };
        /******/
        /******/ // Execute the module function
        /******/
        modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
        /******/
        /******/ // Flag the module as loaded
        /******/
        module.l = true;
        /******/
        /******/ // Return the exports of the module
        /******/
        return module.exports;
        /******/
      }
      /******/
      /******/
      /******/ // expose the modules object (__webpack_modules__)
      /******/
      __webpack_require__.m = modules;
      /******/
      /******/ // expose the module cache
      /******/
      __webpack_require__.c = installedModules;
      /******/
      /******/ // define getter function for harmony exports
      /******/
      __webpack_require__.d = function (exports, name, getter) {
        /******/if (!__webpack_require__.o(exports, name)) {
          /******/Object.defineProperty(exports, name, {
            enumerable: true,
            get: getter
          });
          /******/
        }
        /******/
      };
      /******/
      /******/ // define __esModule on exports
      /******/
      __webpack_require__.r = function (exports) {
        /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
          /******/Object.defineProperty(exports, Symbol.toStringTag, {
            value: 'Module'
          });
          /******/
        }
        /******/
        Object.defineProperty(exports, '__esModule', {
          value: true
        });
        /******/
      };
      /******/
      /******/ // create a fake namespace object
      /******/ // mode & 1: value is a module id, require it
      /******/ // mode & 2: merge all properties of value into the ns
      /******/ // mode & 4: return value when already ns object
      /******/ // mode & 8|1: behave like require
      /******/
      __webpack_require__.t = function (value, mode) {
        /******/if (mode & 1) value = __webpack_require__(value);
        /******/
        if (mode & 8) return value;
        /******/
        if (mode & 4 && _typeof(value) === 'object' && value && value.__esModule) return value;
        /******/
        var ns = Object.create(null);
        /******/
        __webpack_require__.r(ns);
        /******/
        Object.defineProperty(ns, 'default', {
          enumerable: true,
          value: value
        });
        /******/
        if (mode & 2 && typeof value != 'string') for (var key in value) __webpack_require__.d(ns, key, function (key) {
          return value[key];
        }.bind(null, key));
        /******/
        return ns;
        /******/
      };
      /******/
      /******/ // getDefaultExport function for compatibility with non-harmony modules
      /******/
      __webpack_require__.n = function (module) {
        /******/var getter = module && module.__esModule ? /******/function getDefault() {
          return module['default'];
        } : /******/function getModuleExports() {
          return module;
        };
        /******/
        __webpack_require__.d(getter, 'a', getter);
        /******/
        return getter;
        /******/
      };
      /******/
      /******/ // Object.prototype.hasOwnProperty.call
      /******/
      __webpack_require__.o = function (object, property) {
        return Object.prototype.hasOwnProperty.call(object, property);
      };
      /******/
      /******/ // __webpack_public_path__
      /******/
      __webpack_require__.p = "";
      /******/
      /******/
      /******/ // Load entry module and return exports
      /******/
      return __webpack_require__(__webpack_require__.s = 0);
      /******/
    }
    /************************************************************************/
    /******/([( /* 0 */
    /*!**********************************!*\
      !*** ./tasks/WAEngine.editor.js ***!
      \**********************************/
    /*! no static exports found */
    /***/function (module, exports, __webpack_require__) {
      // try {
      //     let Native;
      //     if (navigator.platform.indexOf('Win') != -1) {
      //         Native = zombierequire(process.cwd() + '/build-win/Release/cobalt.node');
      //     } else {
      //         Native = zombierequire(process.cwd() + '/build-mac/Release/cobalt.node');
      //     }
      //     Object.assign(window, Native);
      // } catch(e) {
      //     console.error(e);
      // }

      __webpack_require__( /*! ../out/wgfx/wgfx.js */1);

      /***/
    }), ( /* 1 */
    /*!**************************!*\
      !*** ./out/wgfx/wgfx.js ***!
      \**************************/
    /*! no static exports found */
    /***/function (module, exports, __webpack_require__) {
      "use strict";

      var WX_GAME_ENV = typeof wx !== 'undefined';
      var WX_GAME_PC = false;
      var SystemInfo = null;
      var Module = null;
      var getImageData = null;
      if (WX_GAME_ENV) {
        SystemInfo = wx.getSystemInfoSync();
        if (SystemInfo.platform == "devtools" || SystemInfo.platform == "windows") {
          WX_GAME_PC = true;
        }
      }
      //浏览器或开发者工具
      var USE_WASM = WX_GAME_PC || !WX_GAME_ENV && typeof document !== 'undefined' && document.body;
      if (USE_WASM) {
        Module = window.DEVTOOL_WASM_MODULE; //require('./gfx_emsc');

        // 微信环境下，必须先调用wx.createCanvas创建主屏canvas，再include该模块
        // 否则该模块创建的离屏Canvas会成为主屏canvas
        __webpack_require__( /*! ./image */2).init();
        getImageData = __webpack_require__( /*! ./image */2).getImageData;
      }
      var wgfx;
      (function (wgfx) {
        function some(opt0, opt1) {
          return opt0 != null ? opt0 : opt1;
        }
        wgfx.some = some;
        function some3(opt0, opt1, opt2) {
          return opt0 != null ? opt0 : opt1 != null ? opt1 : opt2;
        }
        wgfx.some3 = some3;
        function GfxObj(id, destroy) {
          this.id = id;
          this.destroy = destroy;
        }
        GfxObj.prototype.toJSON = function () {
          return this.id;
        };
        GfxObj.prototype.destroy = function () {
          if (this.destroy) this.destroy(this.id);
        };
        var Gfx = /*#__PURE__*/function () {
          function Gfx(canvas, options) {
            _classCallCheck(this, Gfx);
            Module['canvas'] = canvas;
            var bufferPoolSize = wgfx.some(options.bufferPoolSize, 1024);
            var shaderPoolSize = wgfx.some(options.shaderPoolSize, 512);
            var imagePoolSize = wgfx.some(options.imagePoolSize, 1024);
            var pipelinePoolSize = wgfx.some(options.pipelinePoolSize, 1024);
            var passPoolSize = wgfx.some(options.passPoolSize, 1024);
            var bufferPoolSize = wgfx.some(options.bufferPoolSize, 1024);
            var shaderPoolSize = wgfx.some(options.shaderPoolSize, 512);
            var imagePoolSize = wgfx.some(options.imagePoolSize, 1024);
            var pipelinePoolSize = wgfx.some(options.pipelinePoolSize, 1024);
            var passPoolSize = wgfx.some(options.passPoolSize, 1024);
            var setupGfx = Module.cwrap('setupGfx', null, ['number', 'number', 'number', 'number', 'number', 'number', 'number', 'number', 'number', 'number']);
            var attr = 0;
            var EMSC_ANTIALIAS = 1 << 1;
            var EMSC_ALPHA = 1 << 2;
            var EMSC_STENCIL = 1 << 3;
            if (options.antialias) {
              attr |= EMSC_ANTIALIAS;
            }
            if (options.alpha) {
              attr |= EMSC_ALPHA;
            }
            if (options.stencil) {
              attr |= EMSC_STENCIL;
            }
            var ignore_assert = false;
            if (options.ignore_assert) {
              ignore_assert = true;
            }
            var disable_log = false;
            if (options.disable_log) {
              disable_log = true;
            }
            var canvasId = Module['canvas'].id;
            // set to "#canvas" to prevent emscripten use getElementById
            Module['canvas'].id = '#canvas';
            setupGfx(canvas.width, canvas.height, bufferPoolSize, shaderPoolSize, imagePoolSize, pipelinePoolSize, passPoolSize, ignore_assert, disable_log, attr);
            Module['canvas'].id = canvasId;
            this.createNativeBufferImpl = Module.cwrap('createNativeBuffer', 'number', ['number', 'number']);
            this.deleteNativeBufferImpl = Module.cwrap('deleteNativeBuffer', null, ['number']);
            this.queryFeatureImpl = Module.cwrap('queryFeature', 'bool', ['number']);
            this.makePassImpl = Module.cwrap('makePass', 'number', ['string']);
            this.makeBufferImpl = Module.cwrap('makeBuffer', 'number', ['string']);
            this.updateBufferImpl = Module.cwrap('updateBuffer', null, ['number', 'number', 'number', 'number', 'number']);
            this.makeImageImpl = Module.cwrap('makeImage', 'number', ['string']);
            this.updateImageImpl = Module.cwrap('updateImage', null, ['number', 'string']);
            this.makeShaderImpl = Module.cwrap('makeShader', 'number', ['string']);
            this.makePipelineImpl = Module.cwrap('makePipeline', 'number', ['string']);
            this.beginPassImpl = Module.cwrap('beginPass', null, ['number', 'string']);
            this.beginDefaultPassImpl = Module.cwrap('beginDefaultPass', null, ['string', 'number', 'number']);
            this.applyPipelineImpl = Module.cwrap('applyPipeline', null, ['number']);
            this.applyBindingsImpl = Module.cwrap('applyBindings', null, ['string']);
            this.applyUniformsImpl = Module.cwrap('applyUniforms', null, ['number', 'number', 'number']);
            this.applyViewportImpl = Module.cwrap('applyViewport', null, ['number', 'number', 'number', 'number', 'bool']);
            this.applyScissorRectImpl = Module.cwrap('applyScissorRect', null, ['number', 'number', 'number', 'number', 'bool']);
            this.drawImpl = Module.cwrap('draw', null, ['number', 'number', 'number']);
            this.endPassImpl = Module.cwrap('endPass', null, []);
            this.commitImpl = Module.cwrap('commit', null, []);
            this.readPixelsImpl = Module.cwrap('readPixels', 'number', ['number', 'number', 'number', 'number', 'number', 'number']);
            this.getBufferStringImpl = Module.cwrap('getBufferString', 'string', ['number']);
            this.destroyPassImpl = Module.cwrap('destroyPass', null, ['number']);
            this.destroyBufferImpl = Module.cwrap('destroyBuffer', null, ['number']);
            this.destroyImageImpl = Module.cwrap('destroyImage', null, ['number']);
            this.destroyShaderImpl = Module.cwrap('destroyShader', null, ['number']);
            this.destroyPipelineImpl = Module.cwrap('destroyPipeline', null, ['number']);
            this.queryPassStateImpl = Module.cwrap('queryPassState', 'number', ['number']);
            this.queryBufferStateImpl = Module.cwrap('queryBufferState', 'number', ['number']);
            this.queryImageStateImpl = Module.cwrap('queryImageState', 'number', ['number']);
            this.queryShaderStateImpl = Module.cwrap('queryShaderState', 'number', ['number']);
            this.queryPipelineStateImpl = Module.cwrap('queryPipelineState', 'number', ['number']);
            wgfx.setGfxConsts(this);
          }
          return _createClass(Gfx, [{
            key: "_convertBuffer",
            value: function _convertBuffer(data) {
              var buffer = Module._malloc(data.byteLength);
              var type = Object.prototype.toString.call(data);
              // if (data instanceof Float32Array) {
              if (type == "[object Float32Array]") {
                Module.HEAPF32.set(data, buffer >> 2);
                // } else if (data instanceof Int8Array) {
              } else if (type == "[object Int8Array]") {
                Module.HEAP8.set(data, buffer);
                // } else if (data instanceof Int16Array) {
              } else if (type == "[object Int16Array]") {
                Module.HEAP16.set(data, buffer >> 1);
                // } else if (data instanceof Int32Array) {
              } else if (type == "[object Int32Array]") {
                Module.HEAP32.set(data, buffer >> 2);
                // } else if (data instanceof Uint8Array || data instanceof Uint8ClampedArray) {
              } else if (type == "[object Uint8Array]" || type == "[object Uint8ClampedArray]") {
                Module.HEAPU8.set(data, buffer);
                // } else if (data instanceof Uint16Array) {
              } else if (type == "[object Uint16Array]") {
                Module.HEAPU16.set(data, buffer >> 1);
                // } else if (data instanceof Uint32Array) {
              } else if (type == "[object Uint32Array]") {
                Module.HEAPU32.set(data, buffer >> 2);
                // } else if (data instanceof Float64Array) {
              } else if (type == "[object Float64Array]") {
                Module.HEAPF64.set(data, buffer >> 4);
              } else {
                console.log("data invalid!");
              }
              return buffer;
            }
          }, {
            key: "queryFeature",
            value: function queryFeature(feature) {
              return this.queryFeatureImpl(feature);
            }
          }, {
            key: "makePass",
            value: function makePass(o) {
              var pass_id = this.makePassImpl(JSON.stringify(o));
              return new GfxObj(pass_id, this.destroyPassImpl);
            }
          }, {
            key: "makeBuffer",
            value: function makeBuffer(o) {
              var bufferId = 0;
              var vb;
              var oldContent;
              var needDelete = false;
              if (o.content != null) {
                if (ArrayBuffer.isView(o.content)) {
                  vb = this._convertBuffer(o.content);
                  bufferId = this.createNativeBufferImpl(vb, o.content.byteLength);
                  if (o.size == null) {
                    o.size = o.content.byteLength;
                  }
                  oldContent = o.content;
                  o.content = bufferId;
                  needDelete = true;
                } else {
                  this.deleteNativeBufferImpl(o.content.id);
                  Module._free(o.content.buffer);
                  vb = this._convertBuffer(new Uint8Array(o.content.data));
                  bufferId = this.createNativeBufferImpl(vb, o.content.data.byteLength);
                  if (o.size == null) {
                    o.size = o.content.data.byteLength;
                  }
                  o.content.id = bufferId;
                  o.content.buffer = vb;
                  oldContent = o.content;
                  o.content = bufferId;
                }
              }
              var buffer = this.makeBufferImpl(JSON.stringify(o));
              if (needDelete) {
                if (bufferId > 0) {
                  this.deleteNativeBufferImpl(bufferId);
                }
                if (o.oldContent) {
                  o.content = oldContent;
                  Module._free(vb);
                }
              }
              return new GfxObj(buffer, this.destroyBufferImpl);
            }
          }, {
            key: "updateBuffer",
            value: function updateBuffer(buffer, offset, data, dataOffset, dataSize) {
              var buffer_id = buffer.id;
              var dataBufferId = -1;
              var buffer;
              var toDelete = false;
              if (ArrayBuffer.isView(data)) {
                buffer = this._convertBuffer(data);
                dataBufferId = this.createNativeBufferImpl(buffer, data.byteLength);
                toDelete = true;
                // fix  使用传入的dataOffset/dataSize
                if (!dataOffset) {
                  dataOffset = 0;
                }
                if (!dataSize) {
                  dataSize = data.byteLength - dataOffset;
                }
              } else {
                this.deleteNativeBufferImpl(data.id);
                Module._free(data.buffer);
                buffer = this._convertBuffer(new Uint8Array(data.data));
                dataBufferId = this.createNativeBufferImpl(buffer, data.data.byteLength);
                data.id = dataBufferId;
                data.buffer = buffer;
                if (!dataOffset) {
                  dataOffset = 0;
                }
                if (!dataSize) {
                  dataSize = data.data.byteLength - dataOffset;
                }
              }
              this.updateBufferImpl(buffer_id, offset === 'undefined' ? 0 : offset, dataBufferId, dataOffset, dataSize);
              if (toDelete) {
                if (dataBufferId > 0) {
                  this.deleteNativeBufferImpl(dataBufferId);
                }
                Module._free(buffer);
              }
            }
          }, {
            key: "makeShader",
            value: function makeShader(o) {
              return new GfxObj(this.makeShaderImpl(JSON.stringify(o)), this.destroyShaderImpl);
            }
          }, {
            key: "makeImage",
            value: function makeImage(o) {
              var nativeBuffers = [];
              if (o.content != null && o.content.subimage != null) {
                for (var i = 0; i < this.CUBEFACE_NUM; i++) {
                  nativeBuffers[i] = [];
                  if (o.content.subimage[i] == null) {
                    continue;
                  }
                  for (var j = 0; j < this.MAX_MIPMAPS; j++) {
                    if (o.content.subimage[i][j] == null) {
                      continue;
                    }
                    var subimage = o.content.subimage[i][j];
                    if (ArrayBuffer.isView(subimage)) {
                      var buffer = this._convertBuffer(subimage);
                      var bufferId = this.createNativeBufferImpl(buffer, subimage.byteLength);
                      nativeBuffers[i][j] = {
                        buffer: buffer,
                        bufferId: bufferId,
                        oldSubImage: subimage
                      };
                      o.content.subimage[i][j] = {
                        buffer_id: bufferId
                      };
                    } else if (subimage.buffer) {
                      this.deleteNativeBufferImpl(subimage.id);
                      Module._free(subimage.buffer);
                      var buffer = this._convertBuffer(new Uint8Array(subimage.data));
                      var bufferId = this.createNativeBufferImpl(buffer, subimage.data.byteLength);
                      subimage.id = bufferId;
                      subimage.buffer = buffer;
                      nativeBuffers[i][j] = {
                        buffer: null,
                        bufferId: 0,
                        // do not need to delete
                        oldSubImage: subimage
                      };
                      o.content.subimage[i][j] = {
                        buffer_id: bufferId
                      };
                    } else {
                      var _img = o.content.subimage[i][j];
                      var imageData = getImageData(_img);
                      var buffer = this._convertBuffer(imageData);
                      var bufferId = this.createNativeBufferImpl(buffer, imageData.byteLength);
                      nativeBuffers[i][j] = {
                        buffer: buffer,
                        bufferId: bufferId,
                        oldSubImage: o.content.subimage[i][j]
                      };
                      o.content.subimage[i][j] = {
                        buffer_id: bufferId
                      };
                      o.width = _img.width;
                      o.height = _img.height;
                    }
                  }
                }
              }
              var img = this.makeImageImpl(JSON.stringify(o));
              for (var i = 0; i < this.CUBEFACE_NUM; i++) {
                if (nativeBuffers[i] != null) {
                  for (var j = 0; j < this.MAX_MIPMAPS; j++) {
                    if (nativeBuffers[i][j] != null) {
                      if (nativeBuffers[i][j].bufferId > 0) {
                        this.deleteNativeBufferImpl(nativeBuffers[i][j].bufferId);
                        Module._free(nativeBuffers[i][j].buffer);
                      }
                      o.content.subimage[i][j] = nativeBuffers[i][j].oldSubImage;
                    }
                  }
                }
              }
              return new GfxObj(img, this.destroyImageImpl);
            }
          }, {
            key: "updateImage",
            value: function updateImage(imgobj, o) {
              var img_id = imgobj.id;
              var nativeBuffers = [];
              if (o.content != null && o.content.subimage != null) {
                for (var i = 0; i < this.CUBEFACE_NUM; i++) {
                  nativeBuffers[i] = [];
                  if (o.content.subimage[i] == null) {
                    continue;
                  }
                  for (var j = 0; j < this.MAX_MIPMAPS; j++) {
                    if (o.content.subimage[i][j] == null) {
                      continue;
                    }
                    var subimage = o.content.subimage[i][j];
                    if (ArrayBuffer.isView(subimage)) {
                      var buffer = this._convertBuffer(subimage);
                      var bufferId = this.createNativeBufferImpl(buffer, subimage.byteLength);
                      nativeBuffers[i][j] = {
                        buffer: buffer,
                        bufferId: bufferId,
                        oldSubImage: subimage
                      };
                      o.content.subimage[i][j] = {
                        buffer_id: bufferId
                      };
                    } else if (subimage.buffer) {
                      this.deleteNativeBufferImpl(subimage.id);
                      Module._free(subimage.buffer);
                      var buffer = this._convertBuffer(new Uint8Array(subimage.data));
                      var bufferId = this.createNativeBufferImpl(buffer, subimage.data.byteLength);
                      subimage.id = bufferId;
                      subimage.buffer = buffer;
                      nativeBuffers[i][j] = {
                        buffer: null,
                        bufferId: 0,
                        // do not to delete
                        oldSubImage: subimage
                      };
                      o.content.subimage[i][j] = {
                        buffer_id: bufferId
                      };
                    } else {
                      var img = o.content.subimage[i][j];
                      var imageData = getImageData(img);
                      var buffer = this._convertBuffer(imageData);
                      var bufferId = this.createNativeBufferImpl(buffer, imageData.byteLength);
                      nativeBuffers[i][j] = {
                        buffer: buffer,
                        bufferId: bufferId,
                        oldSubImage: o.content.subimage[i][j]
                      };
                      o.content.subimage[i][j] = {
                        buffer_id: bufferId
                      };
                      o.width = img.width;
                      o.height = img.height;
                    }
                  }
                }
              }
              this.updateImageImpl(img_id, JSON.stringify(o));
              for (var i = 0; i < this.CUBEFACE_NUM; i++) {
                if (nativeBuffers[i] != null) {
                  for (var j = 0; j < this.MAX_MIPMAPS; j++) {
                    if (nativeBuffers[i][j] != null) {
                      if (nativeBuffers[i][j].bufferId > 0) {
                        this.deleteNativeBufferImpl(nativeBuffers[i][j].bufferId);
                        Module._free(nativeBuffers[i][j].buffer);
                      }
                      o.content.subimage[i][j] = nativeBuffers[i][j].oldSubImage;
                    }
                  }
                }
              }
            }
          }, {
            key: "makePipeline",
            value: function makePipeline(o) {
              return new GfxObj(this.makePipelineImpl(JSON.stringify(o)), this.destroyPipelineImpl);
            }
          }, {
            key: "makePassAction",
            value: function makePassAction(desc) {
              return JSON.stringify(desc);
            }
          }, {
            key: "beginPass",
            value: function beginPass(pass, passAction) {
              this.beginPassImpl(pass.id, passAction);
            }
          }, {
            key: "beginDefaultPass",
            value: function beginDefaultPass(passAction, width, height) {
              this.beginDefaultPassImpl(passAction, width, height);
            }
          }, {
            key: "applyPipeline",
            value: function applyPipeline(pip) {
              this.applyPipelineImpl(pip.id);
            }
          }, {
            key: "applyViewport",
            value: function applyViewport(x, y, width, height, origin_top_left) {
              this.applyViewportImpl(x, y, width, height, origin_top_left);
            }
          }, {
            key: "applyScissorRect",
            value: function applyScissorRect(x, y, width, height, origin_top_left) {
              this.applyScissorRectImpl(x, y, width, height, origin_top_left);
            }
          }, {
            key: "makeBindings",
            value: function makeBindings(bind) {
              return JSON.stringify(bind);
            }
          }, {
            key: "applyBindings",
            value: function applyBindings(bind) {
              this.applyBindingsImpl(bind);
            }
          }, {
            key: "applyUniforms",
            value: function applyUniforms(shaderStage, index, data) {
              if (ArrayBuffer.isView(data)) {
                var buffer = this._convertBuffer(data);
                var bufferId = this.createNativeBufferImpl(buffer, data.byteLength);
                this.applyUniformsImpl(shaderStage, index, bufferId);
                Module._free(buffer);
                this.deleteNativeBufferImpl(bufferId);
              } else {
                this.deleteNativeBufferImpl(data.id);
                Module._free(data.buffer);
                var buffer = this._convertBuffer(new Uint8Array(data.data));
                var bufferId = this.createNativeBufferImpl(buffer, data.data.byteLength);
                this.applyUniformsImpl(shaderStage, index, bufferId);
                data.id = bufferId;
                data.buffer = buffer;
              }
            }
          }, {
            key: "draw",
            value: function draw(baseElement, numElements, numInstances) {
              this.drawImpl(baseElement, numElements, numInstances);
            }
          }, {
            key: "endPass",
            value: function endPass() {
              this.endPassImpl();
            }
          }, {
            key: "commit",
            value: function commit() {
              this.commitImpl();
            }
          }, {
            key: "getPixels",
            value: function getPixels(x, y, width, height, format, type) {
              var buffer_id = this.readPixelsImpl(x, y, width, height, format, type);
              var str2ab = function str2ab(str) {
                var binary_string = window.atob(base64);
                var len = binary_string.length;
                var bytes = new Uint8Array(len);
                for (var i = 0; i < len; i++) {
                  bytes[i] = binary_string.charCodeAt(i);
                }
                return bytes.buffer;
              };
              var base64 = this.getBufferStringImpl(buffer_id);
              this.deleteNativeBufferImpl(buffer_id);
              return str2ab(base64);
            }
          }, {
            key: "createNativeBuffer",
            value: function createNativeBuffer(data) {
              if (typeof data === 'number') {
                data = new ArrayBuffer(data);
              }
              var buffer = this._convertBuffer(new Uint8Array(data));
              var bufferId = this.createNativeBufferImpl(buffer, data.byteLength);
              return {
                id: bufferId,
                data: data,
                buffer: buffer
              };
            }
          }, {
            key: "queryPassState",
            value: function queryPassState(pass) {
              return this.queryPassStateImpl(pass.id);
            }
          }, {
            key: "queryBufferState",
            value: function queryBufferState(buf) {
              return this.queryBufferStateImpl(buf.id);
            }
          }, {
            key: "queryImageState",
            value: function queryImageState(image) {
              return this.queryImageStateImpl(image.id);
            }
          }, {
            key: "queryShaderState",
            value: function queryShaderState(shd) {
              return this.queryShaderStateImpl(shd.id);
            }
          }, {
            key: "queryPipelineState",
            value: function queryPipelineState(pip) {
              return this.queryPipelineStateImpl(pip.id);
            }
          }]);
        }();
        wgfx.Gfx = Gfx;
        if (typeof NativeGlobal !== "undefined") {
          NativeGlobal.Gfx = Gfx;
        }
        var canvasProto;
        if (typeof HTMLCanvasElement !== "undefined") {
          canvasProto = HTMLCanvasElement.prototype;
        } else {
          canvasProto = Object.getPrototypeOf(wx.createOffScreenCanvas());
        }
        var _getContext = canvasProto.getContext;
        canvasProto.getContext = function (type, attributes) {
          if (type == 'wgfx' || type == 'gfx-metal') {
            return new wgfx.Gfx(this, attributes || {});
          } else {
            return _getContext.call(this, type, attributes || {});
          }
        };
        function setGfxConsts(gfx) {
          gfx.FEATURE_INSTANCING = 0;
          gfx.FEATURE_TEXTURE_COMPRESSION_DXT = 1;
          gfx.FEATURE_TEXTURE_COMPRESSION_PVRTC = 2;
          gfx.FEATURE_TEXTURE_COMPRESSION_ATC = 3;
          gfx.FEATURE_TEXTURE_COMPRESSION_ETC2 = 4;
          gfx.FEATURE_TEXTURE_FLOAT = 5;
          gfx.FEATURE_TEXTURE_HALF_FLOAT = 6;
          gfx.FEATURE_ORIGIN_BOTTOM_LEFT = 7;
          gfx.FEATURE_ORIGIN_TOP_LEFT = 8;
          gfx.FEATURE_MSAA_RENDER_TARGETS = 9;
          gfx.FEATURE_PACKED_VERTEX_FORMAT_10_2 = 10;
          gfx.FEATURE_MULTIPLE_RENDER_TARGET = 11;
          gfx.FEATURE_IMAGETYPE_3D = 12;
          gfx.FEATURE_IMAGETYPE_ARRAY = 13;
          gfx.FEATURE_TEXTURE_COMPRESSION_ETC1 = 14;
          gfx.SG_FEATURE_TEXTURE_COMPRESSION_ASTC_8x8 = 15;
          gfx.NUM_FEATURES = 16;

          // sg_resource_state
          gfx.RESOURCESTATE_INITIAL = 0;
          gfx.RESOURCESTATE_ALLOC = 1;
          gfx.RESOURCESTATE_VALID = 2;
          gfx.RESOURCESTATE_FAILED = 3;
          gfx.RESOURCESTATE_INVALID = 4;

          // sg_usage
          gfx.USAGE_IMMUTABLE = 1;
          gfx.USAGE_DYNAMIC = 2;
          gfx.USAGE_STREAM = 3;

          // sg_buffer_type
          gfx.BUFFERTYPE_VERTEXBUFFER = 1;
          gfx.BUFFERTYPE_INDEXBUFFER = 2;

          // sg_index_type
          gfx.INDEXTYPE_NONE = 1;
          gfx.INDEXTYPE_UINT16 = 2;
          gfx.INDEXTYPE_UINT32 = 3;

          // sg_image_type
          gfx.IMAGETYPE_2D = 1;
          gfx.IMAGETYPE_CUBE = 2;
          gfx.IMAGETYPE_3D = 3;
          gfx.IMAGETYPE_ARRAY = 4;

          // sg_cube_face
          gfx.CUBEFACE_POS_X = 0;
          gfx.CUBEFACE_NEG_X = 1;
          gfx.CUBEFACE_POS_Y = 2;
          gfx.CUBEFACE_NEG_Y = 3;
          gfx.CUBEFACE_POS_Z = 4;
          gfx.CUBEFACE_NEG_Z = 5;
          gfx.CUBEFACE_NUM = 6;

          // sg_shader_stage
          gfx.SHADERSTAGE_VS = 0;
          gfx.SHADERSTAGE_FS = 1;

          // sg_pixel_format
          gfx.PIXELFORMAT_NONE = 1;
          gfx.PIXELFORMAT_RGBA8 = 2;
          gfx.PIXELFORMAT_RGB8 = 3;
          gfx.PIXELFORMAT_RGBA4 = 4;
          gfx.PIXELFORMAT_R5G6B5 = 5;
          gfx.PIXELFORMAT_R5G5B5A1 = 6;
          gfx.PIXELFORMAT_R10G10B10A2 = 7;
          gfx.PIXELFORMAT_RGBA32F = 8;
          gfx.PIXELFORMAT_RGBA16F = 9;
          gfx.PIXELFORMAT_R32F = 10;
          gfx.PIXELFORMAT_R16F = 11;
          gfx.PIXELFORMAT_L8 = 12;
          gfx.PIXELFORMAT_DXT1 = 13;
          gfx.PIXELFORMAT_DXT3 = 14;
          gfx.PIXELFORMAT_DXT5 = 15;
          gfx.PIXELFORMAT_DEPTH = 16;
          gfx.PIXELFORMAT_DEPTHSTENCIL = 17;
          gfx.PIXELFORMAT_PVRTC2_RGB = 18;
          gfx.PIXELFORMAT_PVRTC4_RGB = 19;
          gfx.PIXELFORMAT_PVRTC2_RGBA = 20;
          gfx.PIXELFORMAT_PVRTC4_RGBA = 21;
          gfx.PIXELFORMAT_ETC2_RGB8 = 22;
          gfx.PIXELFORMAT_ETC2_SRGB8 = 23;
          gfx.PIXELFORMAT_ETC1_RGB8 = 24;
          gfx.PIXELFORMAT_PVR_CCZ = 25;
          gfx.PIXELFORMAT_PVR_GZ = 26;

          // sg_primitive_type
          gfx.PRIMITIVETYPE_POINTS = 1;
          gfx.PRIMITIVETYPE_LINES = 2;
          gfx.PRIMITIVETYPE_LINE_STRIP = 3;
          gfx.PRIMITIVETYPE_TRIANGLES = 4;
          gfx.PRIMITIVETYPE_TRIANGLE_STRIP = 5;

          // sg_filter
          gfx.FILTER_NEAREST = 1;
          gfx.FILTER_LINEAR = 2;
          gfx.FILTER_NEAREST_MIPMAP_NEAREST = 3;
          gfx.FILTER_NEAREST_MIPMAP_LINEAR = 4;
          gfx.FILTER_LINEAR_MIPMAP_NEAREST = 5;
          gfx.FILTER_LINEAR_MIPMAP_LINEAR = 6;

          // sg_wrap
          gfx.WRAP_REPEAT = 1;
          gfx.WRAP_CLAMP_TO_EDGE = 2;
          gfx.WRAP_MIRRORED_REPEAT = 3;

          // sg_vertex_format
          gfx.VERTEXFORMAT_INVALID = 0;
          gfx.VERTEXFORMAT_FLOAT = 1;
          gfx.VERTEXFORMAT_FLOAT2 = 2;
          gfx.VERTEXFORMAT_FLOAT3 = 3;
          gfx.VERTEXFORMAT_FLOAT4 = 4;
          gfx.VERTEXFORMAT_BYTE4 = 5;
          gfx.VERTEXFORMAT_BYTE4N = 6;
          gfx.VERTEXFORMAT_UBYTE4 = 7;
          gfx.VERTEXFORMAT_UBYTE4N = 8;
          gfx.VERTEXFORMAT_SHORT2 = 9;
          gfx.VERTEXFORMAT_SHORT2N = 10;
          gfx.VERTEXFORMAT_SHORT4 = 11;
          gfx.VERTEXFORMAT_SHORT4N = 12;
          gfx.VERTEXFORMAT_UINT10_N2 = 13;

          // sg_vertex_step
          gfx.VERTEXSTEP_PER_VERTEX = 1;
          gfx.VERTEXSTEP_PER_INSTANCE = 2;

          // sg_uniform_type
          gfx.UNIFORMTYPE_INVALID = 0;
          gfx.UNIFORMTYPE_FLOAT = 1;
          gfx.UNIFORMTYPE_FLOAT2 = 2;
          gfx.UNIFORMTYPE_FLOAT3 = 3;
          gfx.UNIFORMTYPE_FLOAT4 = 4;
          gfx.UNIFORMTYPE_MAT4 = 5;

          // sg_cull_mode
          gfx.CULLMODE_NONE = 1;
          gfx.CULLMODE_FRONT = 2;
          gfx.CULLMODE_BACK = 3;

          // sg_face_winding
          gfx.FACEWINDING_CCW = 1;
          gfx.FACEWINDING_CW = 2;

          // sg_compare_func
          gfx.COMPAREFUNC_NEVER = 1;
          gfx.COMPAREFUNC_LESS = 2;
          gfx.COMPAREFUNC_EQUAL = 3;
          gfx.COMPAREFUNC_LESS_EQUAL = 4;
          gfx.COMPAREFUNC_GREATER = 5;
          gfx.COMPAREFUNC_NOT_EQUAL = 6;
          gfx.COMPAREFUNC_GREATER_EQUAL = 7;
          gfx.COMPAREFUNC_ALWAYS = 8;

          // sg_stencil_op
          gfx.STENCILOP_KEEP = 1;
          gfx.STENCILOP_ZERO = 2;
          gfx.STENCILOP_REPLACE = 3;
          gfx.STENCILOP_INCR_CLAMP = 4;
          gfx.STENCILOP_DECR_CLAMP = 5;
          gfx.STENCILOP_INVERT = 6;
          gfx.STENCILOP_INCR_WRAP = 7;
          gfx.STENCILOP_DECR_WRAP = 8;

          // sg_blend_factor
          gfx.BLENDFACTOR_ZERO = 1;
          gfx.BLENDFACTOR_ONE = 2;
          gfx.BLENDFACTOR_SRC_COLOR = 3;
          gfx.BLENDFACTOR_ONE_MINUS_SRC_COLOR = 4;
          gfx.BLENDFACTOR_SRC_ALPHA = 5;
          gfx.BLENDFACTOR_ONE_MINUS_SRC_ALPHA = 6;
          gfx.BLENDFACTOR_DST_COLOR = 7;
          gfx.BLENDFACTOR_ONE_MINUS_DST_COLOR = 8;
          gfx.BLENDFACTOR_DST_ALPHA = 9;
          gfx.BLENDFACTOR_ONE_MINUS_DST_ALPHA = 10;
          gfx.BLENDFACTOR_SRC_ALPHA_SATURATED = 11;
          gfx.BLENDFACTOR_BLEND_COLOR = 12;
          gfx.BLENDFACTOR_ONE_MINUS_BLEND_COLOR = 13;
          gfx.BLENDFACTOR_BLEND_ALPHA = 14;
          gfx.BLENDFACTOR_ONE_MINUS_BLEND_ALPHA = 15;

          // sg_blend_op
          gfx.BLENDOP_ADD = 1;
          gfx.BLENDOP_SUBTRACT = 2;
          gfx.BLENDOP_REVERSE_SUBTRACT = 3;

          // sg_color_mask
          gfx.COLORMASK_NONE = 0x10; /* special value for 'all channels disabled */
          gfx.COLORMASK_R = 1 << 0;
          gfx.COLORMASK_G = 1 << 1;
          gfx.COLORMASK_B = 1 << 2;
          gfx.COLORMASK_A = 1 << 3;
          gfx.COLORMASK_RGB = 0x7;
          gfx.COLORMASK_RGBA = 0xF;

          // sg_action
          gfx.ACTION_CLEAR = 1;
          gfx.ACTION_LOAD = 2;
          gfx.ACTION_DONTCARE = 3;

          // constants
          gfx.INVALID_ID = 0;
          gfx.NUM_SHADER_STAGES = 2;
          gfx.NUM_INFLIGHT_FRAMES = 2;
          gfx.MAX_COLOR_ATTACHMENTS = 4;
          gfx.MAX_SHADERSTAGE_BUFFERS = 4;
          gfx.MAX_SHADERSTAGE_IMAGES = 12;
          gfx.MAX_SHADERSTAGE_UBS = 4;
          gfx.MAX_UB_MEMBERS = 16;
          gfx.MAX_VERTEX_ATTRIBUTES = 16;
          gfx.MAX_MIPMAPS = 16;
          gfx.MAX_TEXTUREARRAY_LAYERS = 128;

          //PixelType
          gfx.UNSIGNED_BYTE = 0x1401;
          gfx.FLOAT = 0x1406;
          gfx.UNSIGNED_SHORT_5_6_5 = 0x8363;
          gfx.UNSIGNED_SHORT_4_4_4_4 = 0x8033;
          gfx.UNSIGNED_SHORT_5_5_5_1 = 0x8034;
        }
        wgfx.setGfxConsts = setGfxConsts;
      })(wgfx || (wgfx = {}));

      /***/
    }), ( /* 2 */
    /*!***************************!*\
      !*** ./out/wgfx/image.js ***!
      \***************************/
    /*! exports provided: init, getImageData */
    /***/function (module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */
      __webpack_require__.d(__webpack_exports__, "init", function () {
        return init;
      });
      /* harmony export (binding) */
      __webpack_require__.d(__webpack_exports__, "getImageData", function () {
        return getImageData;
      });
      var gl;
      var fb;
      var texture;
      var initialized = false;
      function init() {
        if (initialized) return;
        var canvas = null;
        if (typeof wx !== "undefined") {
          if (wx.createOffScreenCanvas) {
            canvas = wx.createOffScreenCanvas();
          } else {
            canvas = wx.createCanvas();
          }
        } else {
          canvas = document ? document.createElement("canvas") : __global.document.createElement("canvas");
        }
        canvas.height = 2048;
        canvas.width = 2048;
        gl = canvas.getContext("webgl");
        fb = gl.createFramebuffer();
        texture = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
        initialized = true;
      }
      function getImageData(image) {
        if (!initialized) {
          initialized = true;
          init();
        }
        gl.bindTexture(gl.TEXTURE_2D, texture);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
        gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
        gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
        var canRead = gl.checkFramebufferStatus(gl.FRAMEBUFFER) === gl.FRAMEBUFFER_COMPLETE;
        if (canRead) {
          var pixels = new Uint8Array(image.width * image.height * 4);
          gl.readPixels(0, 0, image.width, image.height, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
          gl.bindFramebuffer(gl.FRAMEBUFFER, null);
          return pixels;
        } else {
          return new Uint8Array([255, 0, 0, 255, 255]);
        }
      }

      /***/
    }
    /******/)]));
  };

  // 下面这行注释不要删
  //
  var Module = function () {
    var _scriptDir = typeof document !== 'undefined' && document.currentScript ? document.currentScript.src : undefined;
    return function (Module) {
      Module = Module || {};
      var Module = typeof Module !== "undefined" ? Module : {};
      var moduleOverrides = {};
      var key;
      for (key in Module) {
        if (Module.hasOwnProperty(key)) {
          moduleOverrides[key] = Module[key];
        }
      }
      Module["arguments"] = [];
      Module["thisProgram"] = "./this.program";
      Module["quit"] = function (status, toThrow) {
        throw toThrow;
      };
      Module["preRun"] = [];
      Module["postRun"] = [];
      var ENVIRONMENT_IS_WEB = true;
      var ENVIRONMENT_IS_WORKER = false;
      var scriptDirectory = "";
      function locateFile(path) {
        if (Module["locateFile"]) {
          return Module["locateFile"](path, scriptDirectory);
        } else {
          return scriptDirectory + path;
        }
      }
      if (ENVIRONMENT_IS_WEB || ENVIRONMENT_IS_WORKER) {
        if (ENVIRONMENT_IS_WORKER) {
          scriptDirectory = self.location.href;
        } else if (document.currentScript) {
          scriptDirectory = document.currentScript.src;
        }
        if (_scriptDir) {
          scriptDirectory = _scriptDir;
        }
        if (scriptDirectory.indexOf("blob:") !== 0) {
          scriptDirectory = scriptDirectory.substr(0, scriptDirectory.lastIndexOf("/") + 1);
        } else {
          scriptDirectory = "";
        }
        Module["read"] = function shell_read(url) {
          var xhr = new XMLHttpRequest();
          xhr.open("GET", url, false);
          xhr.send(null);
          return xhr.responseText;
        };
        if (ENVIRONMENT_IS_WORKER) {
          Module["readBinary"] = function readBinary(url) {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", url, false);
            xhr.responseType = "arraybuffer";
            xhr.send(null);
            return new Uint8Array(xhr.response);
          };
        }
        Module["readAsync"] = function readAsync(url, onload, onerror) {
          var xhr = new XMLHttpRequest();
          xhr.open("GET", url, true);
          xhr.responseType = "arraybuffer";
          xhr.onload = function xhr_onload() {
            if (xhr.status == 200 || xhr.status == 0 && xhr.response) {
              onload(xhr.response);
              return;
            }
            onerror();
          };
          xhr.onerror = onerror;
          xhr.send(null);
        };
        Module["setWindowTitle"] = function (title) {
          document.title = title;
        };
      } else {}
      var out = Module["print"] || (typeof console !== "undefined" ? console.log.bind(console) : typeof print !== "undefined" ? print : null);
      var err = Module["printErr"] || (typeof printErr !== "undefined" ? printErr : typeof console !== "undefined" && console.warn.bind(console) || out);
      for (key in moduleOverrides) {
        if (moduleOverrides.hasOwnProperty(key)) {
          Module[key] = moduleOverrides[key];
        }
      }
      moduleOverrides = undefined;
      var asm2wasmImports = {
        "f64-rem": function f64Rem(x, y) {
          return x % y;
        },
        "debugger": function _debugger() {
          debugger;
        }
      };
      var functionPointers = new Array(0);
      if (_typeof(__realWebAssembly) !== "object") {
        err("no native wasm support detected");
      }
      var wasmMemory;
      var wasmTable;
      var ABORT = false;
      var EXITSTATUS = 0;
      function assert(condition, text) {
        if (!condition) {
          abort("Assertion failed: " + text);
        }
      }
      function getCFunc(ident) {
        var func = Module["_" + ident];
        assert(func, "Cannot call unknown function " + ident + ", make sure it is exported");
        return func;
      }
      function ccall(ident, returnType, argTypes, args, opts) {
        var toC = {
          "string": function string(str) {
            var ret = 0;
            if (str !== null && str !== undefined && str !== 0) {
              var len = (str.length << 2) + 1;
              ret = stackAlloc(len);
              stringToUTF8(str, ret, len);
            }
            return ret;
          },
          "array": function array(arr) {
            var ret = stackAlloc(arr.length);
            writeArrayToMemory(arr, ret);
            return ret;
          }
        };
        function convertReturnValue(ret) {
          if (returnType === "string") return UTF8ToString(ret);
          if (returnType === "boolean") return Boolean(ret);
          return ret;
        }
        var func = getCFunc(ident);
        var cArgs = [];
        var stack = 0;
        if (args) {
          for (var i = 0; i < args.length; i++) {
            var converter = toC[argTypes[i]];
            if (converter) {
              if (stack === 0) stack = stackSave();
              cArgs[i] = converter(args[i]);
            } else {
              cArgs[i] = args[i];
            }
          }
        }
        var ret = func.apply(null, cArgs);
        ret = convertReturnValue(ret);
        if (stack !== 0) stackRestore(stack);
        return ret;
      }
      function cwrap(ident, returnType, argTypes, opts) {
        argTypes = argTypes || [];
        var numericArgs = argTypes.every(function (type) {
          return type === "number";
        });
        var numericRet = returnType !== "string";
        if (numericRet && numericArgs && !opts) {
          return getCFunc(ident);
        }
        return function () {
          return ccall(ident, returnType, argTypes, arguments, opts);
        };
      }
      var UTF8Decoder = typeof TextDecoder !== "undefined" ? new TextDecoder("utf8") : undefined;
      function UTF8ArrayToString(u8Array, idx, maxBytesToRead) {
        var endIdx = idx + maxBytesToRead;
        var endPtr = idx;
        while (u8Array[endPtr] && !(endPtr >= endIdx)) ++endPtr;
        if (endPtr - idx > 16 && u8Array.subarray && UTF8Decoder) {
          return UTF8Decoder.decode(u8Array.subarray(idx, endPtr));
        } else {
          var str = "";
          while (idx < endPtr) {
            var u0 = u8Array[idx++];
            if (!(u0 & 128)) {
              str += String.fromCharCode(u0);
              continue;
            }
            var u1 = u8Array[idx++] & 63;
            if ((u0 & 224) == 192) {
              str += String.fromCharCode((u0 & 31) << 6 | u1);
              continue;
            }
            var u2 = u8Array[idx++] & 63;
            if ((u0 & 240) == 224) {
              u0 = (u0 & 15) << 12 | u1 << 6 | u2;
            } else {
              u0 = (u0 & 7) << 18 | u1 << 12 | u2 << 6 | u8Array[idx++] & 63;
            }
            if (u0 < 65536) {
              str += String.fromCharCode(u0);
            } else {
              var ch = u0 - 65536;
              str += String.fromCharCode(55296 | ch >> 10, 56320 | ch & 1023);
            }
          }
        }
        return str;
      }
      function UTF8ToString(ptr, maxBytesToRead) {
        return ptr ? UTF8ArrayToString(HEAPU8, ptr, maxBytesToRead) : "";
      }
      function stringToUTF8Array(str, outU8Array, outIdx, maxBytesToWrite) {
        if (!(maxBytesToWrite > 0)) return 0;
        var startIdx = outIdx;
        var endIdx = outIdx + maxBytesToWrite - 1;
        for (var i = 0; i < str.length; ++i) {
          var u = str.charCodeAt(i);
          if (u >= 55296 && u <= 57343) {
            var u1 = str.charCodeAt(++i);
            u = 65536 + ((u & 1023) << 10) | u1 & 1023;
          }
          if (u <= 127) {
            if (outIdx >= endIdx) break;
            outU8Array[outIdx++] = u;
          } else if (u <= 2047) {
            if (outIdx + 1 >= endIdx) break;
            outU8Array[outIdx++] = 192 | u >> 6;
            outU8Array[outIdx++] = 128 | u & 63;
          } else if (u <= 65535) {
            if (outIdx + 2 >= endIdx) break;
            outU8Array[outIdx++] = 224 | u >> 12;
            outU8Array[outIdx++] = 128 | u >> 6 & 63;
            outU8Array[outIdx++] = 128 | u & 63;
          } else {
            if (outIdx + 3 >= endIdx) break;
            outU8Array[outIdx++] = 240 | u >> 18;
            outU8Array[outIdx++] = 128 | u >> 12 & 63;
            outU8Array[outIdx++] = 128 | u >> 6 & 63;
            outU8Array[outIdx++] = 128 | u & 63;
          }
        }
        outU8Array[outIdx] = 0;
        return outIdx - startIdx;
      }
      function stringToUTF8(str, outPtr, maxBytesToWrite) {
        return stringToUTF8Array(str, HEAPU8, outPtr, maxBytesToWrite);
      }
      function lengthBytesUTF8(str) {
        var len = 0;
        for (var i = 0; i < str.length; ++i) {
          var u = str.charCodeAt(i);
          if (u >= 55296 && u <= 57343) u = 65536 + ((u & 1023) << 10) | str.charCodeAt(++i) & 1023;
          if (u <= 127) ++len;else if (u <= 2047) len += 2;else if (u <= 65535) len += 3;else len += 4;
        }
        return len;
      }
      var UTF16Decoder = typeof TextDecoder !== "undefined" ? new TextDecoder("utf-16le") : undefined;
      function allocateUTF8OnStack(str) {
        var size = lengthBytesUTF8(str) + 1;
        var ret = stackAlloc(size);
        stringToUTF8Array(str, HEAP8, ret, size);
        return ret;
      }
      function writeArrayToMemory(array, buffer) {
        HEAP8.set(array, buffer);
      }
      var WASM_PAGE_SIZE = 65536;
      function alignUp(x, multiple) {
        if (x % multiple > 0) {
          x += multiple - x % multiple;
        }
        return x;
      }
      var buffer, HEAP8, HEAPU8, HEAP16, HEAPU16, HEAP32, HEAPU32, HEAPF32, HEAPF64;
      function updateGlobalBufferViews() {
        Module["HEAP8"] = HEAP8 = new Int8Array(buffer);
        Module["HEAP16"] = HEAP16 = new Int16Array(buffer);
        Module["HEAP32"] = HEAP32 = new Int32Array(buffer);
        Module["HEAPU8"] = HEAPU8 = new Uint8Array(buffer);
        Module["HEAPU16"] = HEAPU16 = new Uint16Array(buffer);
        Module["HEAPU32"] = HEAPU32 = new Uint32Array(buffer);
        Module["HEAPF32"] = HEAPF32 = new Float32Array(buffer);
        Module["HEAPF64"] = HEAPF64 = new Float64Array(buffer);
      }
      var DYNAMIC_BASE = 5254976,
        DYNAMICTOP_PTR = 11840;
      var TOTAL_STACK = 5242880;
      var INITIAL_TOTAL_MEMORY = Module["TOTAL_MEMORY"] || 16777216;
      if (INITIAL_TOTAL_MEMORY < TOTAL_STACK) err("TOTAL_MEMORY should be larger than TOTAL_STACK, was " + INITIAL_TOTAL_MEMORY + "! (TOTAL_STACK=" + TOTAL_STACK + ")");
      if (Module["buffer"]) {
        buffer = Module["buffer"];
      } else {
        if (_typeof(__realWebAssembly) === "object" && typeof __realWebAssembly.Memory === "function") {
          wasmMemory = new __realWebAssembly.Memory({
            "initial": INITIAL_TOTAL_MEMORY / WASM_PAGE_SIZE
          });
          buffer = wasmMemory.buffer;
        } else {
          buffer = new ArrayBuffer(INITIAL_TOTAL_MEMORY);
        }
      }
      updateGlobalBufferViews();
      HEAP32[DYNAMICTOP_PTR >> 2] = DYNAMIC_BASE;
      function callRuntimeCallbacks(callbacks) {
        while (callbacks.length > 0) {
          var callback = callbacks.shift();
          if (typeof callback == "function") {
            callback();
            continue;
          }
          var func = callback.func;
          if (typeof func === "number") {
            if (callback.arg === undefined) {
              Module["dynCall_v"](func);
            } else {
              Module["dynCall_vi"](func, callback.arg);
            }
          } else {
            func(callback.arg === undefined ? null : callback.arg);
          }
        }
      }
      var __ATPRERUN__ = [];
      var __ATINIT__ = [];
      var __ATMAIN__ = [];
      var __ATEXIT__ = [];
      var __ATPOSTRUN__ = [];
      var runtimeInitialized = false;
      var runtimeExited = false;
      function preRun() {
        if (Module["preRun"]) {
          if (typeof Module["preRun"] == "function") Module["preRun"] = [Module["preRun"]];
          while (Module["preRun"].length) {
            addOnPreRun(Module["preRun"].shift());
          }
        }
        callRuntimeCallbacks(__ATPRERUN__);
      }
      function ensureInitRuntime() {
        if (runtimeInitialized) return;
        runtimeInitialized = true;
        callRuntimeCallbacks(__ATINIT__);
      }
      function preMain() {
        callRuntimeCallbacks(__ATMAIN__);
      }
      function exitRuntime() {
        runtimeExited = true;
      }
      function postRun() {
        if (Module["postRun"]) {
          if (typeof Module["postRun"] == "function") Module["postRun"] = [Module["postRun"]];
          while (Module["postRun"].length) {
            addOnPostRun(Module["postRun"].shift());
          }
        }
        callRuntimeCallbacks(__ATPOSTRUN__);
      }
      function addOnPreRun(cb) {
        __ATPRERUN__.unshift(cb);
      }
      function addOnPostRun(cb) {
        __ATPOSTRUN__.unshift(cb);
      }
      var Math_abs = Math.abs;
      var Math_ceil = Math.ceil;
      var Math_floor = Math.floor;
      var Math_min = Math.min;
      var runDependencies = 0;
      var runDependencyWatcher = null;
      var dependenciesFulfilled = null;
      function addRunDependency(id) {
        runDependencies++;
        if (Module["monitorRunDependencies"]) {
          Module["monitorRunDependencies"](runDependencies);
        }
      }
      function removeRunDependency(id) {
        runDependencies--;
        if (Module["monitorRunDependencies"]) {
          Module["monitorRunDependencies"](runDependencies);
        }
        if (runDependencies == 0) {
          if (runDependencyWatcher !== null) {
            clearInterval(runDependencyWatcher);
            runDependencyWatcher = null;
          }
          if (dependenciesFulfilled) {
            var callback = dependenciesFulfilled;
            dependenciesFulfilled = null;
            callback();
          }
        }
      }
      Module["preloadedImages"] = {};
      Module["preloadedAudios"] = {};
      var dataURIPrefix = "data:application/octet-stream;base64,";
      function isDataURI(filename) {
        return String.prototype.startsWith ? filename.startsWith(dataURIPrefix) : filename.indexOf(dataURIPrefix) === 0;
      }
      var wasmBinaryFile = window.DEVTOOL_WASM_MODULE_PATH;
      if (!isDataURI(wasmBinaryFile)) {
        wasmBinaryFile = locateFile(wasmBinaryFile);
      }
      function getBinary() {
        try {
          if (Module["wasmBinary"]) {
            return new Uint8Array(Module["wasmBinary"]);
          }
          if (Module["readBinary"]) {
            return Module["readBinary"](wasmBinaryFile);
          } else {
            return wx.getFileSystemManager().readFileSync(wasmBinaryFile);
          }
        } catch (err) {
          abort(err);
        }
      }
      function getBinaryPromise() {
        if (typeof wx !== "undefined") {
          return new Promise(function (resolve, reject) {
            if (wasmBinaryFile.indexOf('http') == -1) {
              wx.getFileSystemManager().readFile({
                filePath: wasmBinaryFile,
                success: function success(res) {
                  resolve(res.data);
                },
                fail: function fail(e) {
                  reject("failed to load wasm binary file at '" + wasmBinaryFile + "'");
                }
              });
            } else {
              wx.request({
                url: wasmBinaryFile,
                success: function success(res) {
                  if (res.statusCode == 200) {
                    resolve(res.data);
                  } else {
                    reject("failed to load wasm binary file at '" + wasmBinaryFile + "'");
                  }
                },
                fail: function fail(e) {
                  reject("failed to load wasm binary file at '" + wasmBinaryFile + "'");
                },
                responseType: 'arraybuffer'
              });
            }
          });
        } else if (typeof __global.fetch !== "undefined") {
          // 工具IDE的环境下，会把fetch隐藏在这里
          return __global.fetch(wasmBinaryFile).then(function (response) {
            return response.arrayBuffer();
          });
        } else {
          return fetch(wasmBinaryFile).then(function (response) {
            return response.arrayBuffer();
          });
        }
      }
      function createWasm(env) {
        var info = {
          "env": env,
          "global": {
            "NaN": NaN,
            Infinity: Infinity
          },
          "global.Math": Math,
          "asm2wasm": asm2wasmImports
        };
        function receiveInstance(instance, module) {
          var exports = instance.exports;
          Module["asm"] = exports;
          removeRunDependency("wasm-instantiate");
        }
        addRunDependency("wasm-instantiate");
        if (Module["instantiateWasm"]) {
          try {
            return Module["instantiateWasm"](info, receiveInstance);
          } catch (e) {
            err("Module.instantiateWasm callback failed with error: " + e);
            return false;
          }
        }
        function receiveInstantiatedSource(output) {
          receiveInstance(output["instance"]);
        }
        function instantiateArrayBuffer(receiver) {
          getBinaryPromise().then(function (binary) {
            return __realWebAssembly.instantiate(binary, info);
          }).then(receiver, function (reason) {
            err("failed to asynchronously prepare wasm: " + reason);
            abort(reason);
          });
        }
        if (!Module["wasmBinary"] && typeof __realWebAssembly.instantiateStreaming === "function" && !isDataURI(wasmBinaryFile) && typeof fetch === "function") {
          __realWebAssembly.instantiateStreaming(fetch(wasmBinaryFile, {
            credentials: "same-origin"
          }), info).then(receiveInstantiatedSource, function (reason) {
            err("wasm streaming compile failed: " + reason);
            err("falling back to ArrayBuffer instantiation");
            instantiateArrayBuffer(receiveInstantiatedSource);
          });
        } else {
          instantiateArrayBuffer(receiveInstantiatedSource);
        }
        return {};
      }
      Module["asm"] = function (global, env, providedBuffer) {
        env["memory"] = wasmMemory;
        env["table"] = wasmTable = new __realWebAssembly.Table({
          "initial": 59,
          "maximum": 59,
          "element": "anyfunc"
        });
        env["__memory_base"] = 1024;
        env["__table_base"] = 0;
        var exports = createWasm(env);
        return exports;
      };
      __ATINIT__.push({
        func: function func() {
          __GLOBAL__sub_I_gfx_emsc_cc();
        }
      });
      function ___cxa_allocate_exception(size) {
        return _malloc(size);
      }
      function __ZSt18uncaught_exceptionv() {
        return !!__ZSt18uncaught_exceptionv.uncaught_exception;
      }
      function ___cxa_free_exception(ptr) {
        try {
          return _free(ptr);
        } catch (e) {}
      }
      var EXCEPTIONS = {
        last: 0,
        caught: [],
        infos: {},
        deAdjust: function deAdjust(adjusted) {
          if (!adjusted || EXCEPTIONS.infos[adjusted]) return adjusted;
          for (var key in EXCEPTIONS.infos) {
            var ptr = +key;
            var adj = EXCEPTIONS.infos[ptr].adjusted;
            var len = adj.length;
            for (var i = 0; i < len; i++) {
              if (adj[i] === adjusted) {
                return ptr;
              }
            }
          }
          return adjusted;
        },
        addRef: function addRef(ptr) {
          if (!ptr) return;
          var info = EXCEPTIONS.infos[ptr];
          info.refcount++;
        },
        decRef: function decRef(ptr) {
          if (!ptr) return;
          var info = EXCEPTIONS.infos[ptr];
          assert(info.refcount > 0);
          info.refcount--;
          if (info.refcount === 0 && !info.rethrown) {
            if (info.destructor) {
              Module["dynCall_vi"](info.destructor, ptr);
            }
            delete EXCEPTIONS.infos[ptr];
            ___cxa_free_exception(ptr);
          }
        },
        clearRef: function clearRef(ptr) {
          if (!ptr) return;
          var info = EXCEPTIONS.infos[ptr];
          info.refcount = 0;
        }
      };
      function ___cxa_throw(ptr, type, destructor) {
        EXCEPTIONS.infos[ptr] = {
          ptr: ptr,
          adjusted: [ptr],
          type: type,
          destructor: destructor,
          refcount: 0,
          caught: false,
          rethrown: false
        };
        EXCEPTIONS.last = ptr;
        if (!("uncaught_exception" in __ZSt18uncaught_exceptionv)) {
          __ZSt18uncaught_exceptionv.uncaught_exception = 1;
        } else {
          __ZSt18uncaught_exceptionv.uncaught_exception++;
        }
        throw ptr;
      }
      var SYSCALLS = {
        buffers: [null, [], []],
        printChar: function printChar(stream, curr) {
          var buffer = SYSCALLS.buffers[stream];
          if (curr === 0 || curr === 10) {
            (stream === 1 ? out : err)(UTF8ArrayToString(buffer, 0));
            buffer.length = 0;
          } else {
            buffer.push(curr);
          }
        },
        varargs: 0,
        get: function get(varargs) {
          SYSCALLS.varargs += 4;
          var ret = HEAP32[SYSCALLS.varargs - 4 >> 2];
          return ret;
        },
        getStr: function getStr() {
          var ret = UTF8ToString(SYSCALLS.get());
          return ret;
        },
        get64: function get64() {
          var low = SYSCALLS.get(),
            high = SYSCALLS.get();
          return low;
        },
        getZero: function getZero() {
          SYSCALLS.get();
        }
      };
      function ___syscall140(which, varargs) {
        SYSCALLS.varargs = varargs;
        try {
          var stream = SYSCALLS.getStreamFromFD(),
            offset_high = SYSCALLS.get(),
            offset_low = SYSCALLS.get(),
            result = SYSCALLS.get(),
            whence = SYSCALLS.get();
          var offset = offset_low;
          FS.llseek(stream, offset, whence);
          HEAP32[result >> 2] = stream.position;
          if (stream.getdents && offset === 0 && whence === 0) stream.getdents = null;
          return 0;
        } catch (e) {
          if (typeof FS === "undefined" || !(e instanceof FS.ErrnoError)) abort(e);
          return -e.errno;
        }
      }
      function ___syscall146(which, varargs) {
        SYSCALLS.varargs = varargs;
        try {
          var stream = SYSCALLS.get(),
            iov = SYSCALLS.get(),
            iovcnt = SYSCALLS.get();
          var ret = 0;
          for (var i = 0; i < iovcnt; i++) {
            var ptr = HEAP32[iov + i * 8 >> 2];
            var len = HEAP32[iov + (i * 8 + 4) >> 2];
            for (var j = 0; j < len; j++) {
              SYSCALLS.printChar(stream, HEAPU8[ptr + j]);
            }
            ret += len;
          }
          return ret;
        } catch (e) {
          if (typeof FS === "undefined" || !(e instanceof FS.ErrnoError)) abort(e);
          return -e.errno;
        }
      }
      function ___syscall54(which, varargs) {
        SYSCALLS.varargs = varargs;
        try {
          return 0;
        } catch (e) {
          if (typeof FS === "undefined" || !(e instanceof FS.ErrnoError)) abort(e);
          return -e.errno;
        }
      }
      function ___syscall6(which, varargs) {
        SYSCALLS.varargs = varargs;
        try {
          var stream = SYSCALLS.getStreamFromFD();
          FS.close(stream);
          return 0;
        } catch (e) {
          if (typeof FS === "undefined" || !(e instanceof FS.ErrnoError)) abort(e);
          return -e.errno;
        }
      }
      function _abort() {
        Module["abort"]();
      }
      function _emscripten_get_heap_size() {
        return HEAP8.length;
      }
      function abortOnCannotGrowMemory(requestedSize) {
        abort("OOM");
      }
      function emscripten_realloc_buffer(size) {
        var PAGE_MULTIPLE = 65536;
        size = alignUp(size, PAGE_MULTIPLE);
        var oldSize = buffer.byteLength;
        try {
          var result = wasmMemory.grow((size - oldSize) / 65536);
          if (result !== (-1 | 0)) {
            return buffer = wasmMemory.buffer;
          } else {
            return null;
          }
        } catch (e) {
          return null;
        }
      }
      function _emscripten_resize_heap(requestedSize) {
        var oldSize = _emscripten_get_heap_size();
        var PAGE_MULTIPLE = 65536;
        var LIMIT = 2147483648 - PAGE_MULTIPLE;
        if (requestedSize > LIMIT) {
          return false;
        }
        var MIN_TOTAL_MEMORY = 16777216;
        var newSize = Math.max(oldSize, MIN_TOTAL_MEMORY);
        while (newSize < requestedSize) {
          if (newSize <= 536870912) {
            newSize = alignUp(2 * newSize, PAGE_MULTIPLE);
          } else {
            newSize = Math.min(alignUp((3 * newSize + 2147483648) / 4, PAGE_MULTIPLE), LIMIT);
          }
        }
        var replacement = emscripten_realloc_buffer(newSize);
        if (!replacement || replacement.byteLength != newSize) {
          return false;
        }
        updateGlobalBufferViews();
        return true;
      }
      var GL = {
        counter: 1,
        lastError: 0,
        buffers: [],
        mappedBuffers: {},
        programs: [],
        framebuffers: [],
        renderbuffers: [],
        textures: [],
        uniforms: [],
        shaders: [],
        vaos: [],
        contexts: {},
        currentContext: null,
        offscreenCanvases: {},
        timerQueriesEXT: [],
        queries: [],
        samplers: [],
        transformFeedbacks: [],
        syncs: [],
        programInfos: {},
        stringCache: {},
        stringiCache: {},
        unpackAlignment: 4,
        init: function init() {
          GL.miniTempBuffer = new Float32Array(GL.MINI_TEMP_BUFFER_SIZE);
          for (var i = 0; i < GL.MINI_TEMP_BUFFER_SIZE; i++) {
            GL.miniTempBufferViews[i] = GL.miniTempBuffer.subarray(0, i + 1);
          }
        },
        recordError: function recordError(errorCode) {
          if (!GL.lastError) {
            GL.lastError = errorCode;
          }
        },
        getNewId: function getNewId(table) {
          var ret = GL.counter++;
          for (var i = table.length; i < ret; i++) {
            table[i] = null;
          }
          return ret;
        },
        MINI_TEMP_BUFFER_SIZE: 256,
        miniTempBuffer: null,
        miniTempBufferViews: [0],
        getSource: function getSource(shader, count, string, length) {
          var source = "";
          for (var i = 0; i < count; ++i) {
            var len = length ? HEAP32[length + i * 4 >> 2] : -1;
            source += UTF8ToString(HEAP32[string + i * 4 >> 2], len < 0 ? undefined : len);
          }
          return source;
        },
        createContext: function createContext(canvas, webGLContextAttributes) {
          var ctx = webGLContextAttributes.majorVersion > 1 ? canvas.getContext("webgl2", webGLContextAttributes) : canvas.getContext("webgl", webGLContextAttributes) || canvas.getContext("experimental-webgl", webGLContextAttributes);
          return ctx && GL.registerContext(ctx, webGLContextAttributes);
        },
        registerContext: function registerContext(ctx, webGLContextAttributes) {
          var handle = _malloc(8);
          var context = {
            handle: handle,
            attributes: webGLContextAttributes,
            version: webGLContextAttributes.majorVersion,
            GLctx: ctx
          };
          function getChromeVersion() {
            var raw = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);
            return raw ? parseInt(raw[2], 10) : false;
          }
          context.supportsWebGL2EntryPoints = context.version >= 2 && (getChromeVersion() === false || getChromeVersion() >= 58);
          if (ctx.canvas) ctx.canvas.GLctxObject = context;
          GL.contexts[handle] = context;
          if (typeof webGLContextAttributes.enableExtensionsByDefault === "undefined" || webGLContextAttributes.enableExtensionsByDefault) {
            GL.initExtensions(context);
          }
          return handle;
        },
        makeContextCurrent: function makeContextCurrent(contextHandle) {
          GL.currentContext = GL.contexts[contextHandle];
          Module.ctx = GLctx = GL.currentContext && GL.currentContext.GLctx;
          return !(contextHandle && !GLctx);
        },
        getContext: function getContext(contextHandle) {
          return GL.contexts[contextHandle];
        },
        deleteContext: function deleteContext(contextHandle) {
          if (GL.currentContext === GL.contexts[contextHandle]) GL.currentContext = null;
          if (_typeof(JSEvents) === "object") JSEvents.removeAllHandlersOnTarget(GL.contexts[contextHandle].GLctx.canvas);
          if (GL.contexts[contextHandle] && GL.contexts[contextHandle].GLctx.canvas) GL.contexts[contextHandle].GLctx.canvas.GLctxObject = undefined;
          _free(GL.contexts[contextHandle]);
          GL.contexts[contextHandle] = null;
        },
        initExtensions: function initExtensions(context) {
          if (!context) context = GL.currentContext;
          if (context.initExtensionsDone) return;
          context.initExtensionsDone = true;
          var GLctx = context.GLctx;
          if (context.version < 2) {
            var instancedArraysExt = GLctx.getExtension("ANGLE_instanced_arrays");
            if (instancedArraysExt) {
              GLctx["vertexAttribDivisor"] = function (index, divisor) {
                instancedArraysExt["vertexAttribDivisorANGLE"](index, divisor);
              };
              GLctx["drawArraysInstanced"] = function (mode, first, count, primcount) {
                instancedArraysExt["drawArraysInstancedANGLE"](mode, first, count, primcount);
              };
              GLctx["drawElementsInstanced"] = function (mode, count, type, indices, primcount) {
                instancedArraysExt["drawElementsInstancedANGLE"](mode, count, type, indices, primcount);
              };
            }
            var vaoExt = GLctx.getExtension("OES_vertex_array_object");
            if (vaoExt) {
              GLctx["createVertexArray"] = function () {
                return vaoExt["createVertexArrayOES"]();
              };
              GLctx["deleteVertexArray"] = function (vao) {
                vaoExt["deleteVertexArrayOES"](vao);
              };
              GLctx["bindVertexArray"] = function (vao) {
                vaoExt["bindVertexArrayOES"](vao);
              };
              GLctx["isVertexArray"] = function (vao) {
                return vaoExt["isVertexArrayOES"](vao);
              };
            }
            var drawBuffersExt = GLctx.getExtension("WEBGL_draw_buffers");
            if (drawBuffersExt) {
              GLctx["drawBuffers"] = function (n, bufs) {
                drawBuffersExt["drawBuffersWEBGL"](n, bufs);
              };
            }
          }
          GLctx.disjointTimerQueryExt = GLctx.getExtension("EXT_disjoint_timer_query");
          var automaticallyEnabledExtensions = ["OES_texture_float", "OES_texture_half_float", "OES_standard_derivatives", "OES_vertex_array_object", "WEBGL_compressed_texture_s3tc", "WEBGL_depth_texture", "OES_element_index_uint", "EXT_texture_filter_anisotropic", "EXT_frag_depth", "WEBGL_draw_buffers", "ANGLE_instanced_arrays", "OES_texture_float_linear", "OES_texture_half_float_linear", "EXT_blend_minmax", "EXT_shader_texture_lod", "WEBGL_compressed_texture_pvrtc", "EXT_color_buffer_half_float", "WEBGL_color_buffer_float", "EXT_sRGB", "WEBGL_compressed_texture_etc1", "EXT_disjoint_timer_query", "WEBGL_compressed_texture_etc", "WEBGL_compressed_texture_astc", "EXT_color_buffer_float", "WEBGL_compressed_texture_s3tc_srgb", "EXT_disjoint_timer_query_webgl2"];
          var exts = GLctx.getSupportedExtensions();
          if (exts && exts.length > 0) {
            GLctx.getSupportedExtensions().forEach(function (ext) {
              if (automaticallyEnabledExtensions.indexOf(ext) != -1) {
                GLctx.getExtension(ext);
              }
            });
          }
        },
        populateUniformTable: function populateUniformTable(program) {
          var p = GL.programs[program];
          var ptable = GL.programInfos[program] = {
            uniforms: {},
            maxUniformLength: 0,
            maxAttributeLength: -1,
            maxUniformBlockNameLength: -1
          };
          var utable = ptable.uniforms;
          var numUniforms = GLctx.getProgramParameter(p, 35718);
          for (var i = 0; i < numUniforms; ++i) {
            var u = GLctx.getActiveUniform(p, i);
            var name = u.name;
            ptable.maxUniformLength = Math.max(ptable.maxUniformLength, name.length + 1);
            if (name.slice(-1) == "]") {
              name = name.slice(0, name.lastIndexOf("["));
            }
            var loc = GLctx.getUniformLocation(p, name);
            if (loc) {
              var id = GL.getNewId(GL.uniforms);
              utable[name] = [u.size, id];
              GL.uniforms[id] = loc;
              for (var j = 1; j < u.size; ++j) {
                var n = name + "[" + j + "]";
                loc = GLctx.getUniformLocation(p, n);
                id = GL.getNewId(GL.uniforms);
                GL.uniforms[id] = loc;
              }
            }
          }
        }
      };
      var JSEvents = {
        keyEvent: 0,
        mouseEvent: 0,
        wheelEvent: 0,
        uiEvent: 0,
        focusEvent: 0,
        deviceOrientationEvent: 0,
        deviceMotionEvent: 0,
        fullscreenChangeEvent: 0,
        pointerlockChangeEvent: 0,
        visibilityChangeEvent: 0,
        touchEvent: 0,
        previousFullscreenElement: null,
        previousScreenX: null,
        previousScreenY: null,
        removeEventListenersRegistered: false,
        removeAllEventListeners: function removeAllEventListeners() {
          for (var i = JSEvents.eventHandlers.length - 1; i >= 0; --i) {
            JSEvents._removeHandler(i);
          }
          JSEvents.eventHandlers = [];
          JSEvents.deferredCalls = [];
        },
        registerRemoveEventListeners: function registerRemoveEventListeners() {
          if (!JSEvents.removeEventListenersRegistered) {
            __ATEXIT__.push(JSEvents.removeAllEventListeners);
            JSEvents.removeEventListenersRegistered = true;
          }
        },
        deferredCalls: [],
        deferCall: function deferCall(targetFunction, precedence, argsList) {
          function arraysHaveEqualContent(arrA, arrB) {
            if (arrA.length != arrB.length) return false;
            for (var i in arrA) {
              if (arrA[i] != arrB[i]) return false;
            }
            return true;
          }
          for (var i in JSEvents.deferredCalls) {
            var call = JSEvents.deferredCalls[i];
            if (call.targetFunction == targetFunction && arraysHaveEqualContent(call.argsList, argsList)) {
              return;
            }
          }
          JSEvents.deferredCalls.push({
            targetFunction: targetFunction,
            precedence: precedence,
            argsList: argsList
          });
          JSEvents.deferredCalls.sort(function (x, y) {
            return x.precedence < y.precedence;
          });
        },
        removeDeferredCalls: function removeDeferredCalls(targetFunction) {
          for (var i = 0; i < JSEvents.deferredCalls.length; ++i) {
            if (JSEvents.deferredCalls[i].targetFunction == targetFunction) {
              JSEvents.deferredCalls.splice(i, 1);
              --i;
            }
          }
        },
        canPerformEventHandlerRequests: function canPerformEventHandlerRequests() {
          return JSEvents.inEventHandler && JSEvents.currentEventHandler.allowsDeferredCalls;
        },
        runDeferredCalls: function runDeferredCalls() {
          if (!JSEvents.canPerformEventHandlerRequests()) {
            return;
          }
          for (var i = 0; i < JSEvents.deferredCalls.length; ++i) {
            var call = JSEvents.deferredCalls[i];
            JSEvents.deferredCalls.splice(i, 1);
            --i;
            call.targetFunction.apply(this, call.argsList);
          }
        },
        inEventHandler: 0,
        currentEventHandler: null,
        eventHandlers: [],
        isInternetExplorer: function isInternetExplorer() {
          return navigator.userAgent.indexOf("MSIE") !== -1 || navigator.appVersion.indexOf("Trident/") > 0;
        },
        removeAllHandlersOnTarget: function removeAllHandlersOnTarget(target, eventTypeString) {
          for (var i = 0; i < JSEvents.eventHandlers.length; ++i) {
            if (JSEvents.eventHandlers[i].target == target && (!eventTypeString || eventTypeString == JSEvents.eventHandlers[i].eventTypeString)) {
              JSEvents._removeHandler(i--);
            }
          }
        },
        _removeHandler: function _removeHandler(i) {
          var h = JSEvents.eventHandlers[i];
          h.target.removeEventListener(h.eventTypeString, h.eventListenerFunc, h.useCapture);
          JSEvents.eventHandlers.splice(i, 1);
        },
        registerOrRemoveHandler: function registerOrRemoveHandler(eventHandler) {
          var jsEventHandler = function jsEventHandler(event) {
            ++JSEvents.inEventHandler;
            JSEvents.currentEventHandler = eventHandler;
            JSEvents.runDeferredCalls();
            eventHandler.handlerFunc(event);
            JSEvents.runDeferredCalls();
            --JSEvents.inEventHandler;
          };
          if (eventHandler.callbackfunc) {
            eventHandler.eventListenerFunc = jsEventHandler;
            eventHandler.target.addEventListener(eventHandler.eventTypeString, jsEventHandler, eventHandler.useCapture);
            JSEvents.eventHandlers.push(eventHandler);
            JSEvents.registerRemoveEventListeners();
          } else {
            for (var i = 0; i < JSEvents.eventHandlers.length; ++i) {
              if (JSEvents.eventHandlers[i].target == eventHandler.target && JSEvents.eventHandlers[i].eventTypeString == eventHandler.eventTypeString) {
                JSEvents._removeHandler(i--);
              }
            }
          }
        },
        getBoundingClientRectOrZeros: function getBoundingClientRectOrZeros(target) {
          return target.getBoundingClientRect ? target.getBoundingClientRect() : {
            left: 0,
            top: 0
          };
        },
        pageScrollPos: function pageScrollPos() {
          if (window.pageXOffset > 0 || window.pageYOffset > 0) {
            return [window.pageXOffset, window.pageYOffset];
          }
          if (typeof document.documentElement.scrollLeft !== "undefined" || typeof document.documentElement.scrollTop !== "undefined") {
            return [document.documentElement.scrollLeft, document.documentElement.scrollTop];
          }
          return [document.body.scrollLeft | 0, document.body.scrollTop | 0];
        },
        getNodeNameForTarget: function getNodeNameForTarget(target) {
          if (!target) return "";
          if (target == window) return "#window";
          if (target == screen) return "#screen";
          return target && target.nodeName ? target.nodeName : "";
        },
        tick: function tick() {
          if (window["performance"] && window["performance"]["now"]) return window["performance"]["now"]();else return Date.now();
        },
        fullscreenEnabled: function fullscreenEnabled() {
          return document.fullscreenEnabled || document.mozFullScreenEnabled || document.webkitFullscreenEnabled || document.msFullscreenEnabled;
        }
      };
      var __emscripten_webgl_power_preferences = ["default", "low-power", "high-performance"];
      var __specialEventTargets = [0, document, window];
      function __findEventTarget(target) {
        try {
          if (!target) return window;
          if (typeof target === "number") target = __specialEventTargets[target] || UTF8ToString(target);
          if (target === "#window") return window;else if (target === "#document") return document;else if (target === "#screen") return screen;else if (target === "#canvas") return Module["canvas"];
          return typeof target === "string" ? document.getElementById(target) : target;
        } catch (e) {
          return null;
        }
      }
      function __findCanvasEventTarget(target) {
        if (typeof target === "number") target = UTF8ToString(target);
        if (!target || target === "#canvas") {
          if (typeof GL !== "undefined" && GL.offscreenCanvases["canvas"]) return GL.offscreenCanvases["canvas"];
          return Module["canvas"];
        }
        if (typeof GL !== "undefined" && GL.offscreenCanvases[target]) return GL.offscreenCanvases[target];
        return __findEventTarget(target);
      }
      function _emscripten_webgl_do_create_context(target, attributes) {
        var contextAttributes = {};
        var a = attributes >> 2;
        contextAttributes["alpha"] = !!HEAP32[a + (0 >> 2)];
        contextAttributes["depth"] = !!HEAP32[a + (4 >> 2)];
        contextAttributes["stencil"] = !!HEAP32[a + (8 >> 2)];
        contextAttributes["antialias"] = !!HEAP32[a + (12 >> 2)];
        contextAttributes["premultipliedAlpha"] = !!HEAP32[a + (16 >> 2)];
        contextAttributes["preserveDrawingBuffer"] = !!HEAP32[a + (20 >> 2)];
        var powerPreference = HEAP32[a + (24 >> 2)];
        contextAttributes["powerPreference"] = __emscripten_webgl_power_preferences[powerPreference];
        contextAttributes["failIfMajorPerformanceCaveat"] = !!HEAP32[a + (28 >> 2)];
        contextAttributes.majorVersion = HEAP32[a + (32 >> 2)];
        contextAttributes.minorVersion = HEAP32[a + (36 >> 2)];
        contextAttributes.enableExtensionsByDefault = HEAP32[a + (40 >> 2)];
        contextAttributes.explicitSwapControl = HEAP32[a + (44 >> 2)];
        contextAttributes.proxyContextToMainThread = HEAP32[a + (48 >> 2)];
        contextAttributes.renderViaOffscreenBackBuffer = HEAP32[a + (52 >> 2)];
        var canvas = __findCanvasEventTarget(target);
        if (!canvas) {
          return 0;
        }
        if (contextAttributes.explicitSwapControl) {
          return 0;
        }
        var contextHandle = GL.createContext(canvas, contextAttributes);
        return contextHandle;
      }
      function _emscripten_webgl_create_context(a0, a1) {
        return _emscripten_webgl_do_create_context(a0, a1);
      }
      function _emscripten_webgl_init_context_attributes(attributes) {
        var a = attributes >> 2;
        for (var i = 0; i < 56 >> 2; ++i) {
          HEAP32[a + i] = 0;
        }
        HEAP32[a + (0 >> 2)] = HEAP32[a + (4 >> 2)] = HEAP32[a + (12 >> 2)] = HEAP32[a + (16 >> 2)] = HEAP32[a + (32 >> 2)] = HEAP32[a + (40 >> 2)] = 1;
      }
      function _emscripten_webgl_make_context_current(contextHandle) {
        var success = GL.makeContextCurrent(contextHandle);
        return success ? 0 : -5;
      }
      function _glActiveTexture(x0) {
        GLctx["activeTexture"](x0);
      }
      function _glAttachShader(program, shader) {
        GLctx.attachShader(GL.programs[program], GL.shaders[shader]);
      }
      function _glBindBuffer(target, buffer) {
        if (target == 35051) {
          GLctx.currentPixelPackBufferBinding = buffer;
        } else if (target == 35052) {
          GLctx.currentPixelUnpackBufferBinding = buffer;
        }
        GLctx.bindBuffer(target, GL.buffers[buffer]);
      }
      function _glBindBufferBase(target, index, buffer) {
        GLctx["bindBufferBase"](target, index, GL.buffers[buffer]);
      }
      function _glBindFramebuffer(target, framebuffer) {
        GLctx.bindFramebuffer(target, GL.framebuffers[framebuffer]);
      }
      function _glBindRenderbuffer(target, renderbuffer) {
        GLctx.bindRenderbuffer(target, GL.renderbuffers[renderbuffer]);
      }
      function _glBindTexture(target, texture) {
        GLctx.bindTexture(target, GL.textures[texture]);
      }
      function _glBindVertexArray(vao) {
        GLctx["bindVertexArray"](GL.vaos[vao]);
      }
      function _glBlendColor(x0, x1, x2, x3) {
        GLctx["blendColor"](x0, x1, x2, x3);
      }
      function _glBlendEquationSeparate(x0, x1) {
        GLctx["blendEquationSeparate"](x0, x1);
      }
      function _glBlendFuncSeparate(x0, x1, x2, x3) {
        GLctx["blendFuncSeparate"](x0, x1, x2, x3);
      }
      function _glBlitFramebuffer(x0, x1, x2, x3, x4, x5, x6, x7, x8, x9) {
        GLctx["blitFramebuffer"](x0, x1, x2, x3, x4, x5, x6, x7, x8, x9);
      }
      function _glBufferData(target, size, data, usage) {
        if (GL.currentContext.supportsWebGL2EntryPoints) {
          if (data) {
            GLctx.bufferData(target, HEAPU8, usage, data, size);
          } else {
            GLctx.bufferData(target, size, usage);
          }
        } else {
          GLctx.bufferData(target, data ? HEAPU8.subarray(data, data + size) : size, usage);
        }
      }
      function _glBufferSubData(target, offset, size, data) {
        if (GL.currentContext.supportsWebGL2EntryPoints) {
          GLctx.bufferSubData(target, offset, HEAPU8, data, size);
          return;
        }
        GLctx.bufferSubData(target, offset, HEAPU8.subarray(data, data + size));
      }
      function _glCheckFramebufferStatus(x0) {
        return GLctx["checkFramebufferStatus"](x0);
      }
      function _glClear(x0) {
        GLctx["clear"](x0);
      }
      function _glClearBufferfi(x0, x1, x2, x3) {
        GLctx["clearBufferfi"](x0, x1, x2, x3);
      }
      function _glClearBufferfv(buffer, drawbuffer, value) {
        GLctx["clearBufferfv"](buffer, drawbuffer, HEAPF32, value >> 2);
      }
      function _glClearBufferuiv(buffer, drawbuffer, value) {
        GLctx["clearBufferuiv"](buffer, drawbuffer, HEAPU32, value >> 2);
      }
      function _glClearColor(x0, x1, x2, x3) {
        GLctx["clearColor"](x0, x1, x2, x3);
      }
      function _glClearDepthf(x0) {
        GLctx["clearDepth"](x0);
      }
      function _glClearStencil(x0) {
        GLctx["clearStencil"](x0);
      }
      function _glColorMask(red, green, blue, alpha) {
        GLctx.colorMask(!!red, !!green, !!blue, !!alpha);
      }
      function _glCompileShader(shader) {
        GLctx.compileShader(GL.shaders[shader]);
      }
      function _glCompressedTexImage2D(target, level, internalFormat, width, height, border, imageSize, data) {
        if (GL.currentContext.supportsWebGL2EntryPoints) {
          if (GLctx.currentPixelUnpackBufferBinding) {
            GLctx["compressedTexImage2D"](target, level, internalFormat, width, height, border, imageSize, data);
          } else {
            GLctx["compressedTexImage2D"](target, level, internalFormat, width, height, border, HEAPU8, data, imageSize);
          }
          return;
        }
        GLctx["compressedTexImage2D"](target, level, internalFormat, width, height, border, data ? HEAPU8.subarray(data, data + imageSize) : null);
      }
      function _glCompressedTexImage3D(target, level, internalFormat, width, height, depth, border, imageSize, data) {
        if (GL.currentContext.supportsWebGL2EntryPoints) {
          if (GLctx.currentPixelUnpackBufferBinding) {
            GLctx["compressedTexImage3D"](target, level, internalFormat, width, height, depth, border, imageSize, data);
          } else {
            GLctx["compressedTexImage3D"](target, level, internalFormat, width, height, depth, border, HEAPU8, data, imageSize);
          }
        } else {
          GLctx["compressedTexImage3D"](target, level, internalFormat, width, height, depth, border, data ? HEAPU8.subarray(data, data + imageSize) : null);
        }
      }
      function _glCreateProgram() {
        var id = GL.getNewId(GL.programs);
        var program = GLctx.createProgram();
        program.name = id;
        GL.programs[id] = program;
        return id;
      }
      function _glCreateShader(shaderType) {
        var id = GL.getNewId(GL.shaders);
        GL.shaders[id] = GLctx.createShader(shaderType);
        return id;
      }
      function _glCullFace(x0) {
        GLctx["cullFace"](x0);
      }
      function _glDeleteBuffers(n, buffers) {
        for (var i = 0; i < n; i++) {
          var id = HEAP32[buffers + i * 4 >> 2];
          var buffer = GL.buffers[id];
          if (!buffer) continue;
          GLctx.deleteBuffer(buffer);
          buffer.name = 0;
          GL.buffers[id] = null;
          if (id == GL.currArrayBuffer) GL.currArrayBuffer = 0;
          if (id == GL.currElementArrayBuffer) GL.currElementArrayBuffer = 0;
          if (id == GLctx.currentPixelPackBufferBinding) GLctx.currentPixelPackBufferBinding = 0;
          if (id == GLctx.currentPixelUnpackBufferBinding) GLctx.currentPixelUnpackBufferBinding = 0;
        }
      }
      function _glDeleteFramebuffers(n, framebuffers) {
        for (var i = 0; i < n; ++i) {
          var id = HEAP32[framebuffers + i * 4 >> 2];
          var framebuffer = GL.framebuffers[id];
          if (!framebuffer) continue;
          GLctx.deleteFramebuffer(framebuffer);
          framebuffer.name = 0;
          GL.framebuffers[id] = null;
        }
      }
      function _glDeleteProgram(id) {
        if (!id) return;
        var program = GL.programs[id];
        if (!program) {
          GL.recordError(1281);
          return;
        }
        GLctx.deleteProgram(program);
        program.name = 0;
        GL.programs[id] = null;
        GL.programInfos[id] = null;
      }
      function _glDeleteRenderbuffers(n, renderbuffers) {
        for (var i = 0; i < n; i++) {
          var id = HEAP32[renderbuffers + i * 4 >> 2];
          var renderbuffer = GL.renderbuffers[id];
          if (!renderbuffer) continue;
          GLctx.deleteRenderbuffer(renderbuffer);
          renderbuffer.name = 0;
          GL.renderbuffers[id] = null;
        }
      }
      function _glDeleteShader(id) {
        if (!id) return;
        var shader = GL.shaders[id];
        if (!shader) {
          GL.recordError(1281);
          return;
        }
        GLctx.deleteShader(shader);
        GL.shaders[id] = null;
      }
      function _glDeleteTextures(n, textures) {
        for (var i = 0; i < n; i++) {
          var id = HEAP32[textures + i * 4 >> 2];
          var texture = GL.textures[id];
          if (!texture) continue;
          GLctx.deleteTexture(texture);
          texture.name = 0;
          GL.textures[id] = null;
        }
      }
      function _glDepthFunc(x0) {
        GLctx["depthFunc"](x0);
      }
      function _glDepthMask(flag) {
        GLctx.depthMask(!!flag);
      }
      function _glDisable(x0) {
        GLctx["disable"](x0);
      }
      function _glDisableVertexAttribArray(index) {
        GLctx.disableVertexAttribArray(index);
      }
      function _glDrawArrays(mode, first, count) {
        GLctx.drawArrays(mode, first, count);
      }
      function _glDrawArraysInstanced(mode, first, count, primcount) {
        GLctx["drawArraysInstanced"](mode, first, count, primcount);
      }
      var __tempFixedLengthArray = [];
      function _glDrawBuffers(n, bufs) {
        var bufArray = __tempFixedLengthArray[n];
        for (var i = 0; i < n; i++) {
          bufArray[i] = HEAP32[bufs + i * 4 >> 2];
        }
        GLctx["drawBuffers"](bufArray);
      }
      function _glDrawElements(mode, count, type, indices) {
        GLctx.drawElements(mode, count, type, indices);
      }
      function _glDrawElementsInstanced(mode, count, type, indices, primcount) {
        GLctx["drawElementsInstanced"](mode, count, type, indices, primcount);
      }
      function _glEnable(x0) {
        GLctx["enable"](x0);
      }
      function _glEnableVertexAttribArray(index) {
        GLctx.enableVertexAttribArray(index);
      }
      function _glFramebufferRenderbuffer(target, attachment, renderbuffertarget, renderbuffer) {
        GLctx.framebufferRenderbuffer(target, attachment, renderbuffertarget, GL.renderbuffers[renderbuffer]);
      }
      function _glFramebufferTexture2D(target, attachment, textarget, texture, level) {
        GLctx.framebufferTexture2D(target, attachment, textarget, GL.textures[texture], level);
      }
      function _glFramebufferTextureLayer(target, attachment, texture, level, layer) {
        GLctx.framebufferTextureLayer(target, attachment, GL.textures[texture], level, layer);
      }
      function _glFrontFace(x0) {
        GLctx["frontFace"](x0);
      }
      function __glGenObject(n, buffers, createFunction, objectTable) {
        for (var i = 0; i < n; i++) {
          var buffer = GLctx[createFunction]();
          var id = buffer && GL.getNewId(objectTable);
          if (buffer) {
            buffer.name = id;
            objectTable[id] = buffer;
          } else {
            GL.recordError(1282);
          }
          HEAP32[buffers + i * 4 >> 2] = id;
        }
      }
      function _glGenBuffers(n, buffers) {
        __glGenObject(n, buffers, "createBuffer", GL.buffers);
      }
      function _glGenFramebuffers(n, ids) {
        __glGenObject(n, ids, "createFramebuffer", GL.framebuffers);
      }
      function _glGenRenderbuffers(n, renderbuffers) {
        __glGenObject(n, renderbuffers, "createRenderbuffer", GL.renderbuffers);
      }
      function _glGenTextures(n, textures) {
        __glGenObject(n, textures, "createTexture", GL.textures);
      }
      function _glGenVertexArrays(n, arrays) {
        __glGenObject(n, arrays, "createVertexArray", GL.vaos);
      }
      function _glGenerateMipmap(x0) {
        GLctx["generateMipmap"](x0);
      }
      function _glGetAttribLocation(program, name) {
        return GLctx.getAttribLocation(GL.programs[program], UTF8ToString(name));
      }
      function emscriptenWebGLGet(name_, p, type) {
        if (!p) {
          GL.recordError(1281);
          return;
        }
        var ret = undefined;
        switch (name_) {
          case 36346:
            ret = 1;
            break;
          case 36344:
            if (type !== "Integer" && type !== "Integer64") {
              GL.recordError(1280);
            }
            return;
          case 34814:
          case 36345:
            ret = 0;
            break;
          case 34466:
            var formats = GLctx.getParameter(34467);
            ret = formats ? formats.length : 0;
            break;
          case 33309:
            if (GL.currentContext.version < 2) {
              GL.recordError(1282);
              return;
            }
            var exts = GLctx.getSupportedExtensions();
            ret = 2 * exts.length;
            break;
          case 33307:
          case 33308:
            if (GL.currentContext.version < 2) {
              GL.recordError(1280);
              return;
            }
            ret = name_ == 33307 ? 3 : 0;
            break;
        }
        if (ret === undefined) {
          var result = GLctx.getParameter(name_);
          switch (_typeof(result)) {
            case "number":
              ret = result;
              break;
            case "boolean":
              ret = result ? 1 : 0;
              break;
            case "string":
              GL.recordError(1280);
              return;
            case "object":
              if (result === null) {
                switch (name_) {
                  case 34964:
                  case 35725:
                  case 34965:
                  case 36006:
                  case 36007:
                  case 32873:
                  case 34229:
                  case 35097:
                  case 36389:
                  case 34068:
                    {
                      ret = 0;
                      break;
                    }
                  default:
                    {
                      GL.recordError(1280);
                      return;
                    }
                }
              } else if (result instanceof Float32Array || result instanceof Uint32Array || result instanceof Int32Array || result instanceof Array) {
                for (var i = 0; i < result.length; ++i) {
                  switch (type) {
                    case "Integer":
                      HEAP32[p + i * 4 >> 2] = result[i];
                      break;
                    case "Float":
                      HEAPF32[p + i * 4 >> 2] = result[i];
                      break;
                    case "Boolean":
                      HEAP8[p + i >> 0] = result[i] ? 1 : 0;
                      break;
                    default:
                      throw "internal glGet error, bad type: " + type;
                  }
                }
                return;
              } else {
                try {
                  ret = result.name | 0;
                } catch (e) {
                  GL.recordError(1280);
                  err("GL_INVALID_ENUM in glGet" + type + "v: Unknown object returned from WebGL getParameter(" + name_ + ")! (error: " + e + ")");
                  return;
                }
              }
              break;
            default:
              GL.recordError(1280);
              return;
          }
        }
        switch (type) {
          case "Integer64":
            tempI64 = [ret >>> 0, (tempDouble = ret, +Math_abs(tempDouble) >= 1 ? tempDouble > 0 ? (Math_min(+Math_floor(tempDouble / 4294967296), 4294967295) | 0) >>> 0 : ~~+Math_ceil((tempDouble - +(~~tempDouble >>> 0)) / 4294967296) >>> 0 : 0)], HEAP32[p >> 2] = tempI64[0], HEAP32[p + 4 >> 2] = tempI64[1];
            break;
          case "Integer":
            HEAP32[p >> 2] = ret;
            break;
          case "Float":
            HEAPF32[p >> 2] = ret;
            break;
          case "Boolean":
            HEAP8[p >> 0] = ret ? 1 : 0;
            break;
          default:
            throw "internal glGet error, bad type: " + type;
        }
      }
      function _glGetIntegerv(name_, p) {
        emscriptenWebGLGet(name_, p, "Integer");
      }
      function _glGetProgramBinary(program, bufSize, length, binaryFormat, binary) {
        GL.recordError(1282);
      }
      function _glGetProgramInfoLog(program, maxLength, length, infoLog) {
        var log = GLctx.getProgramInfoLog(GL.programs[program]);
        if (log === null) log = "(unknown error)";
        if (maxLength > 0 && infoLog) {
          var numBytesWrittenExclNull = stringToUTF8(log, infoLog, maxLength);
          if (length) HEAP32[length >> 2] = numBytesWrittenExclNull;
        } else {
          if (length) HEAP32[length >> 2] = 0;
        }
      }
      function _glGetProgramiv(program, pname, p) {
        if (!p) {
          GL.recordError(1281);
          return;
        }
        if (program >= GL.counter) {
          GL.recordError(1281);
          return;
        }
        var ptable = GL.programInfos[program];
        if (!ptable) {
          GL.recordError(1282);
          return;
        }
        if (pname == 35716) {
          var log = GLctx.getProgramInfoLog(GL.programs[program]);
          if (log === null) log = "(unknown error)";
          HEAP32[p >> 2] = log.length + 1;
        } else if (pname == 35719) {
          HEAP32[p >> 2] = ptable.maxUniformLength;
        } else if (pname == 35722) {
          if (ptable.maxAttributeLength == -1) {
            program = GL.programs[program];
            var numAttribs = GLctx.getProgramParameter(program, 35721);
            ptable.maxAttributeLength = 0;
            for (var i = 0; i < numAttribs; ++i) {
              var activeAttrib = GLctx.getActiveAttrib(program, i);
              ptable.maxAttributeLength = Math.max(ptable.maxAttributeLength, activeAttrib.name.length + 1);
            }
          }
          HEAP32[p >> 2] = ptable.maxAttributeLength;
        } else if (pname == 35381) {
          if (ptable.maxUniformBlockNameLength == -1) {
            program = GL.programs[program];
            var numBlocks = GLctx.getProgramParameter(program, 35382);
            ptable.maxUniformBlockNameLength = 0;
            for (var i = 0; i < numBlocks; ++i) {
              var activeBlockName = GLctx.getActiveUniformBlockName(program, i);
              ptable.maxUniformBlockNameLength = Math.max(ptable.maxUniformBlockNameLength, activeBlockName.length + 1);
            }
          }
          HEAP32[p >> 2] = ptable.maxUniformBlockNameLength;
        } else {
          HEAP32[p >> 2] = GLctx.getProgramParameter(GL.programs[program], pname);
        }
      }
      function _glGetShaderInfoLog(shader, maxLength, length, infoLog) {
        var log = GLctx.getShaderInfoLog(GL.shaders[shader]);
        if (log === null) log = "(unknown error)";
        if (maxLength > 0 && infoLog) {
          var numBytesWrittenExclNull = stringToUTF8(log, infoLog, maxLength);
          if (length) HEAP32[length >> 2] = numBytesWrittenExclNull;
        } else {
          if (length) HEAP32[length >> 2] = 0;
        }
      }
      function _glGetShaderiv(shader, pname, p) {
        if (!p) {
          GL.recordError(1281);
          return;
        }
        if (pname == 35716) {
          var log = GLctx.getShaderInfoLog(GL.shaders[shader]);
          if (log === null) log = "(unknown error)";
          HEAP32[p >> 2] = log.length + 1;
        } else if (pname == 35720) {
          var source = GLctx.getShaderSource(GL.shaders[shader]);
          var sourceLength = source === null || source.length == 0 ? 0 : source.length + 1;
          HEAP32[p >> 2] = sourceLength;
        } else {
          HEAP32[p >> 2] = GLctx.getShaderParameter(GL.shaders[shader], pname);
        }
      }
      function stringToNewUTF8(jsString) {
        var length = lengthBytesUTF8(jsString) + 1;
        var cString = _malloc(length);
        stringToUTF8(jsString, cString, length);
        return cString;
      }
      function _glGetString(name_) {
        if (GL.stringCache[name_]) return GL.stringCache[name_];
        var ret;
        switch (name_) {
          case 7939:
            var exts = GLctx.getSupportedExtensions();
            var gl_exts = [];
            for (var i = 0; i < exts.length; ++i) {
              gl_exts.push(exts[i]);
              gl_exts.push("GL_" + exts[i]);
            }
            ret = stringToNewUTF8(gl_exts.join(" "));
            break;
          case 7936:
          case 7937:
          case 37445:
          case 37446:
            var s = GLctx.getParameter(name_);
            if (!s) {
              GL.recordError(1280);
            }
            ret = stringToNewUTF8(s);
            break;
          case 7938:
            var glVersion = GLctx.getParameter(GLctx.VERSION);
            if (GL.currentContext.version >= 2) glVersion = "OpenGL ES 3.0 (" + glVersion + ")";else {
              glVersion = "OpenGL ES 2.0 (" + glVersion + ")";
            }
            ret = stringToNewUTF8(glVersion);
            break;
          case 35724:
            var glslVersion = GLctx.getParameter(GLctx.SHADING_LANGUAGE_VERSION);
            var ver_re = /^WebGL GLSL ES ([0-9]\.[0-9][0-9]?)(?:$| .*)/;
            var ver_num = glslVersion.match(ver_re);
            if (ver_num !== null) {
              if (ver_num[1].length == 3) ver_num[1] = ver_num[1] + "0";
              glslVersion = "OpenGL ES GLSL ES " + ver_num[1] + " (" + glslVersion + ")";
            }
            ret = stringToNewUTF8(glslVersion);
            break;
          default:
            GL.recordError(1280);
            return 0;
        }
        GL.stringCache[name_] = ret;
        return ret;
      }
      function _glGetUniformBlockIndex(program, uniformBlockName) {
        return GLctx["getUniformBlockIndex"](GL.programs[program], UTF8ToString(uniformBlockName));
      }
      function _glGetUniformLocation(program, name) {
        name = UTF8ToString(name);
        var arrayIndex = 0;
        if (name[name.length - 1] == "]") {
          var leftBrace = name.lastIndexOf("[");
          arrayIndex = name[leftBrace + 1] != "]" ? parseInt(name.slice(leftBrace + 1)) : 0;
          name = name.slice(0, leftBrace);
        }
        var uniformInfo = GL.programInfos[program] && GL.programInfos[program].uniforms[name];
        if (uniformInfo && arrayIndex >= 0 && arrayIndex < uniformInfo[0]) {
          return uniformInfo[1] + arrayIndex;
        } else {
          return -1;
        }
      }
      function _glLinkProgram(program) {
        GLctx.linkProgram(GL.programs[program]);
        GL.populateUniformTable(program);
      }
      function _glPolygonOffset(x0, x1) {
        GLctx["polygonOffset"](x0, x1);
      }
      function _glProgramBinary(program, binaryFormat, binary, length) {
        GL.recordError(1280);
      }
      function _glReadBuffer(x0) {
        GLctx["readBuffer"](x0);
      }
      function __computeUnpackAlignedImageSize(width, height, sizePerPixel, alignment) {
        function roundedToNextMultipleOf(x, y) {
          return x + y - 1 & -y;
        }
        var plainRowSize = width * sizePerPixel;
        var alignedRowSize = roundedToNextMultipleOf(plainRowSize, alignment);
        return height * alignedRowSize;
      }
      var __colorChannelsInGlTextureFormat = {
        6402: 1,
        6403: 1,
        6406: 1,
        6407: 3,
        6408: 4,
        6409: 1,
        6410: 2,
        33319: 2,
        33320: 2,
        35904: 3,
        35906: 4,
        36244: 1,
        36248: 3,
        36249: 4
      };
      var __sizeOfGlTextureElementType = {
        5120: 1,
        5121: 1,
        5122: 2,
        5123: 2,
        5124: 4,
        5125: 4,
        5126: 4,
        5131: 2,
        32819: 2,
        32820: 2,
        33635: 2,
        33640: 4,
        34042: 4,
        35899: 4,
        35902: 4,
        36193: 2
      };
      function emscriptenWebGLGetTexPixelData(type, format, width, height, pixels, internalFormat) {
        var sizePerPixel = __colorChannelsInGlTextureFormat[format] * __sizeOfGlTextureElementType[type];
        if (!sizePerPixel) {
          GL.recordError(1280);
          return;
        }
        var bytes = __computeUnpackAlignedImageSize(width, height, sizePerPixel, GL.unpackAlignment);
        var end = pixels + bytes;
        switch (type) {
          case 5120:
            return HEAP8.subarray(pixels, end);
          case 5121:
            return HEAPU8.subarray(pixels, end);
          case 5122:
            return HEAP16.subarray(pixels >> 1, end >> 1);
          case 5124:
            return HEAP32.subarray(pixels >> 2, end >> 2);
          case 5126:
            return HEAPF32.subarray(pixels >> 2, end >> 2);
          case 5125:
          case 34042:
          case 35902:
          case 33640:
          case 35899:
          case 34042:
            return HEAPU32.subarray(pixels >> 2, end >> 2);
          case 5123:
          case 33635:
          case 32819:
          case 32820:
          case 36193:
          case 5131:
            return HEAPU16.subarray(pixels >> 1, end >> 1);
          default:
            GL.recordError(1280);
        }
      }
      function __heapObjectForWebGLType(type) {
        switch (type) {
          case 5120:
            return HEAP8;
          case 5121:
            return HEAPU8;
          case 5122:
            return HEAP16;
          case 5123:
          case 33635:
          case 32819:
          case 32820:
          case 36193:
          case 5131:
            return HEAPU16;
          case 5124:
            return HEAP32;
          case 5125:
          case 34042:
          case 35902:
          case 33640:
          case 35899:
          case 34042:
            return HEAPU32;
          case 5126:
            return HEAPF32;
        }
      }
      var __heapAccessShiftForWebGLType = {
        5122: 1,
        5123: 1,
        5124: 2,
        5125: 2,
        5126: 2,
        5131: 1,
        32819: 1,
        32820: 1,
        33635: 1,
        33640: 2,
        34042: 2,
        35899: 2,
        35902: 2,
        36193: 1
      };
      function _glReadPixels(x, y, width, height, format, type, pixels) {
        if (GL.currentContext.supportsWebGL2EntryPoints) {
          if (GLctx.currentPixelPackBufferBinding) {
            GLctx.readPixels(x, y, width, height, format, type, pixels);
          } else {
            GLctx.readPixels(x, y, width, height, format, type, __heapObjectForWebGLType(type), pixels >> (__heapAccessShiftForWebGLType[type] | 0));
          }
          return;
        }
        var pixelData = emscriptenWebGLGetTexPixelData(type, format, width, height, pixels, format);
        if (!pixelData) {
          GL.recordError(1280);
          return;
        }
        GLctx.readPixels(x, y, width, height, format, type, pixelData);
      }
      function _glRenderbufferStorage(x0, x1, x2, x3) {
        GLctx["renderbufferStorage"](x0, x1, x2, x3);
      }
      function _glRenderbufferStorageMultisample(x0, x1, x2, x3, x4) {
        GLctx["renderbufferStorageMultisample"](x0, x1, x2, x3, x4);
      }
      function _glScissor(x0, x1, x2, x3) {
        GLctx["scissor"](x0, x1, x2, x3);
      }
      function _glShaderSource(shader, count, string, length) {
        var source = GL.getSource(shader, count, string, length);
        GLctx.shaderSource(GL.shaders[shader], source);
      }
      function _glStencilFunc(x0, x1, x2) {
        GLctx["stencilFunc"](x0, x1, x2);
      }
      function _glStencilFuncSeparate(x0, x1, x2, x3) {
        GLctx["stencilFuncSeparate"](x0, x1, x2, x3);
      }
      function _glStencilMask(x0) {
        GLctx["stencilMask"](x0);
      }
      function _glStencilOp(x0, x1, x2) {
        GLctx["stencilOp"](x0, x1, x2);
      }
      function _glStencilOpSeparate(x0, x1, x2, x3) {
        GLctx["stencilOpSeparate"](x0, x1, x2, x3);
      }
      function _glTexImage2D(target, level, internalFormat, width, height, border, format, type, pixels) {
        if (GL.currentContext.supportsWebGL2EntryPoints) {
          if (GLctx.currentPixelUnpackBufferBinding) {
            GLctx.texImage2D(target, level, internalFormat, width, height, border, format, type, pixels);
          } else if (pixels != 0) {
            GLctx.texImage2D(target, level, internalFormat, width, height, border, format, type, __heapObjectForWebGLType(type), pixels >> (__heapAccessShiftForWebGLType[type] | 0));
          } else {
            GLctx.texImage2D(target, level, internalFormat, width, height, border, format, type, null);
          }
          return;
        }
        GLctx.texImage2D(target, level, internalFormat, width, height, border, format, type, pixels ? emscriptenWebGLGetTexPixelData(type, format, width, height, pixels, internalFormat) : null);
      }
      function _glTexImage3D(target, level, internalFormat, width, height, depth, border, format, type, pixels) {
        if (GLctx.currentPixelUnpackBufferBinding) {
          GLctx["texImage3D"](target, level, internalFormat, width, height, depth, border, format, type, pixels);
        } else if (pixels != 0) {
          GLctx["texImage3D"](target, level, internalFormat, width, height, depth, border, format, type, __heapObjectForWebGLType(type), pixels >> (__heapAccessShiftForWebGLType[type] | 0));
        } else {
          GLctx["texImage3D"](target, level, internalFormat, width, height, depth, border, format, type, null);
        }
      }
      function _glTexParameterf(x0, x1, x2) {
        GLctx["texParameterf"](x0, x1, x2);
      }
      function _glTexParameteri(x0, x1, x2) {
        GLctx["texParameteri"](x0, x1, x2);
      }
      function _glTexSubImage2D(target, level, xoffset, yoffset, width, height, format, type, pixels) {
        if (GL.currentContext.supportsWebGL2EntryPoints) {
          if (GLctx.currentPixelUnpackBufferBinding) {
            GLctx.texSubImage2D(target, level, xoffset, yoffset, width, height, format, type, pixels);
          } else if (pixels != 0) {
            GLctx.texSubImage2D(target, level, xoffset, yoffset, width, height, format, type, __heapObjectForWebGLType(type), pixels >> (__heapAccessShiftForWebGLType[type] | 0));
          } else {
            GLctx.texSubImage2D(target, level, xoffset, yoffset, width, height, format, type, null);
          }
          return;
        }
        var pixelData = null;
        if (pixels) pixelData = emscriptenWebGLGetTexPixelData(type, format, width, height, pixels, 0);
        GLctx.texSubImage2D(target, level, xoffset, yoffset, width, height, format, type, pixelData);
      }
      function _glTexSubImage3D(target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, pixels) {
        if (GLctx.currentPixelUnpackBufferBinding) {
          GLctx["texSubImage3D"](target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, pixels);
        } else if (pixels != 0) {
          GLctx["texSubImage3D"](target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, __heapObjectForWebGLType(type), pixels >> (__heapAccessShiftForWebGLType[type] | 0));
        } else {
          GLctx["texSubImage3D"](target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, null);
        }
      }
      function _glUniform1fv(location, count, value) {
        if (GL.currentContext.supportsWebGL2EntryPoints) {
          GLctx.uniform1fv(GL.uniforms[location], HEAPF32, value >> 2, count);
          return;
        }
        if (count <= GL.MINI_TEMP_BUFFER_SIZE) {
          var view = GL.miniTempBufferViews[count - 1];
          for (var i = 0; i < count; ++i) {
            view[i] = HEAPF32[value + 4 * i >> 2];
          }
        } else {
          var view = HEAPF32.subarray(value >> 2, value + count * 4 >> 2);
        }
        GLctx.uniform1fv(GL.uniforms[location], view);
      }
      function _glUniform1i(location, v0) {
        GLctx.uniform1i(GL.uniforms[location], v0);
      }
      function _glUniform2fv(location, count, value) {
        if (GL.currentContext.supportsWebGL2EntryPoints) {
          GLctx.uniform2fv(GL.uniforms[location], HEAPF32, value >> 2, count * 2);
          return;
        }
        if (2 * count <= GL.MINI_TEMP_BUFFER_SIZE) {
          var view = GL.miniTempBufferViews[2 * count - 1];
          for (var i = 0; i < 2 * count; i += 2) {
            view[i] = HEAPF32[value + 4 * i >> 2];
            view[i + 1] = HEAPF32[value + (4 * i + 4) >> 2];
          }
        } else {
          var view = HEAPF32.subarray(value >> 2, value + count * 8 >> 2);
        }
        GLctx.uniform2fv(GL.uniforms[location], view);
      }
      function _glUniform3fv(location, count, value) {
        if (GL.currentContext.supportsWebGL2EntryPoints) {
          GLctx.uniform3fv(GL.uniforms[location], HEAPF32, value >> 2, count * 3);
          return;
        }
        if (3 * count <= GL.MINI_TEMP_BUFFER_SIZE) {
          var view = GL.miniTempBufferViews[3 * count - 1];
          for (var i = 0; i < 3 * count; i += 3) {
            view[i] = HEAPF32[value + 4 * i >> 2];
            view[i + 1] = HEAPF32[value + (4 * i + 4) >> 2];
            view[i + 2] = HEAPF32[value + (4 * i + 8) >> 2];
          }
        } else {
          var view = HEAPF32.subarray(value >> 2, value + count * 12 >> 2);
        }
        GLctx.uniform3fv(GL.uniforms[location], view);
      }
      function _glUniform4fv(location, count, value) {
        if (GL.currentContext.supportsWebGL2EntryPoints) {
          GLctx.uniform4fv(GL.uniforms[location], HEAPF32, value >> 2, count * 4);
          return;
        }
        if (4 * count <= GL.MINI_TEMP_BUFFER_SIZE) {
          var view = GL.miniTempBufferViews[4 * count - 1];
          for (var i = 0; i < 4 * count; i += 4) {
            view[i] = HEAPF32[value + 4 * i >> 2];
            view[i + 1] = HEAPF32[value + (4 * i + 4) >> 2];
            view[i + 2] = HEAPF32[value + (4 * i + 8) >> 2];
            view[i + 3] = HEAPF32[value + (4 * i + 12) >> 2];
          }
        } else {
          var view = HEAPF32.subarray(value >> 2, value + count * 16 >> 2);
        }
        GLctx.uniform4fv(GL.uniforms[location], view);
      }
      function _glUniformBlockBinding(program, uniformBlockIndex, uniformBlockBinding) {
        program = GL.programs[program];
        GLctx["uniformBlockBinding"](program, uniformBlockIndex, uniformBlockBinding);
      }
      function _glUniformMatrix4fv(location, count, transpose, value) {
        if (GL.currentContext.supportsWebGL2EntryPoints) {
          GLctx.uniformMatrix4fv(GL.uniforms[location], !!transpose, HEAPF32, value >> 2, count * 16);
          return;
        }
        if (16 * count <= GL.MINI_TEMP_BUFFER_SIZE) {
          var view = GL.miniTempBufferViews[16 * count - 1];
          for (var i = 0; i < 16 * count; i += 16) {
            view[i] = HEAPF32[value + 4 * i >> 2];
            view[i + 1] = HEAPF32[value + (4 * i + 4) >> 2];
            view[i + 2] = HEAPF32[value + (4 * i + 8) >> 2];
            view[i + 3] = HEAPF32[value + (4 * i + 12) >> 2];
            view[i + 4] = HEAPF32[value + (4 * i + 16) >> 2];
            view[i + 5] = HEAPF32[value + (4 * i + 20) >> 2];
            view[i + 6] = HEAPF32[value + (4 * i + 24) >> 2];
            view[i + 7] = HEAPF32[value + (4 * i + 28) >> 2];
            view[i + 8] = HEAPF32[value + (4 * i + 32) >> 2];
            view[i + 9] = HEAPF32[value + (4 * i + 36) >> 2];
            view[i + 10] = HEAPF32[value + (4 * i + 40) >> 2];
            view[i + 11] = HEAPF32[value + (4 * i + 44) >> 2];
            view[i + 12] = HEAPF32[value + (4 * i + 48) >> 2];
            view[i + 13] = HEAPF32[value + (4 * i + 52) >> 2];
            view[i + 14] = HEAPF32[value + (4 * i + 56) >> 2];
            view[i + 15] = HEAPF32[value + (4 * i + 60) >> 2];
          }
        } else {
          var view = HEAPF32.subarray(value >> 2, value + count * 64 >> 2);
        }
        GLctx.uniformMatrix4fv(GL.uniforms[location], !!transpose, view);
      }
      function _glUseProgram(program) {
        GLctx.useProgram(GL.programs[program]);
      }
      function _glVertexAttribDivisor(index, divisor) {
        GLctx["vertexAttribDivisor"](index, divisor);
      }
      function _glVertexAttribPointer(index, size, type, normalized, stride, ptr) {
        GLctx.vertexAttribPointer(index, size, type, !!normalized, stride, ptr);
      }
      function _glViewport(x0, x1, x2, x3) {
        GLctx["viewport"](x0, x1, x2, x3);
      }
      function _emscripten_memcpy_big(dest, src, num) {
        HEAPU8.set(HEAPU8.subarray(src, src + num), dest);
      }
      function _pthread_cond_wait() {
        return 0;
      }
      function ___setErrNo(value) {
        if (Module["___errno_location"]) HEAP32[Module["___errno_location"]() >> 2] = value;
        return value;
      }
      var GLctx;
      GL.init();
      for (var i = 0; i < 32; i++) __tempFixedLengthArray.push(new Array(i));
      var asmGlobalArg = {};
      var asmLibraryArg = {
        "i": abort,
        "gb": ___cxa_allocate_exception,
        "Sa": ___cxa_throw,
        "U": ___setErrNo,
        "Ja": ___syscall140,
        "Q": ___syscall146,
        "za": ___syscall54,
        "va": ___syscall6,
        "oa": _abort,
        "ia": _emscripten_get_heap_size,
        "fb": _emscripten_memcpy_big,
        "Za": _emscripten_resize_heap,
        "C": _emscripten_webgl_create_context,
        "Va": _emscripten_webgl_init_context_attributes,
        "Ua": _emscripten_webgl_make_context_current,
        "e": _glActiveTexture,
        "$": _glAttachShader,
        "h": _glBindBuffer,
        "Ta": _glBindBufferBase,
        "f": _glBindFramebuffer,
        "_": _glBindRenderbuffer,
        "d": _glBindTexture,
        "Z": _glBindVertexArray,
        "Y": _glBlendColor,
        "X": _glBlendEquationSeparate,
        "W": _glBlendFuncSeparate,
        "u": _glBlitFramebuffer,
        "V": _glBufferData,
        "B": _glBufferSubData,
        "r": _glCheckFramebufferStatus,
        "Ra": _glClear,
        "Qa": _glClearBufferfi,
        "q": _glClearBufferfv,
        "Pa": _glClearBufferuiv,
        "Oa": _glClearColor,
        "Na": _glClearDepthf,
        "Ma": _glClearStencil,
        "A": _glColorMask,
        "La": _glCompileShader,
        "Ka": _glCompressedTexImage2D,
        "Ia": _glCompressedTexImage3D,
        "Ha": _glCreateProgram,
        "Ga": _glCreateShader,
        "T": _glCullFace,
        "Fa": _glDeleteBuffers,
        "n": _glDeleteFramebuffers,
        "S": _glDeleteProgram,
        "R": _glDeleteRenderbuffers,
        "z": _glDeleteShader,
        "Ea": _glDeleteTextures,
        "y": _glDepthFunc,
        "x": _glDepthMask,
        "g": _glDisable,
        "b": _glDisableVertexAttribArray,
        "Da": _glDrawArrays,
        "Ca": _glDrawArraysInstanced,
        "p": _glDrawBuffers,
        "Ba": _glDrawElements,
        "Aa": _glDrawElementsInstanced,
        "l": _glEnable,
        "ya": _glEnableVertexAttribArray,
        "m": _glFramebufferRenderbuffer,
        "c": _glFramebufferTexture2D,
        "k": _glFramebufferTextureLayer,
        "P": _glFrontFace,
        "O": _glGenBuffers,
        "o": _glGenFramebuffers,
        "N": _glGenRenderbuffers,
        "xa": _glGenTextures,
        "wa": _glGenVertexArrays,
        "ua": _glGenerateMipmap,
        "ta": _glGetAttribLocation,
        "M": _glGetIntegerv,
        "sa": _glGetProgramBinary,
        "ra": _glGetProgramInfoLog,
        "w": _glGetProgramiv,
        "qa": _glGetShaderInfoLog,
        "L": _glGetShaderiv,
        "pa": _glGetString,
        "K": _glGetUniformBlockIndex,
        "t": _glGetUniformLocation,
        "na": _glLinkProgram,
        "J": _glPolygonOffset,
        "ma": _glProgramBinary,
        "s": _glReadBuffer,
        "la": _glReadPixels,
        "ka": _glRenderbufferStorage,
        "I": _glRenderbufferStorageMultisample,
        "H": _glScissor,
        "ja": _glShaderSource,
        "ha": _glStencilFunc,
        "G": _glStencilFuncSeparate,
        "v": _glStencilMask,
        "ga": _glStencilOp,
        "F": _glStencilOpSeparate,
        "fa": _glTexImage2D,
        "ea": _glTexImage3D,
        "E": _glTexParameterf,
        "j": _glTexParameteri,
        "D": _glTexSubImage2D,
        "da": _glTexSubImage3D,
        "eb": _glUniform1fv,
        "ca": _glUniform1i,
        "db": _glUniform2fv,
        "cb": _glUniform3fv,
        "bb": _glUniform4fv,
        "ba": _glUniformBlockBinding,
        "ab": _glUniformMatrix4fv,
        "$a": _glUseProgram,
        "_a": _glVertexAttribDivisor,
        "Ya": _glVertexAttribPointer,
        "aa": _glViewport,
        "Xa": _pthread_cond_wait,
        "Wa": abortOnCannotGrowMemory,
        "a": DYNAMICTOP_PTR
      };
      var asm = Module["asm"](asmGlobalArg, asmLibraryArg, buffer);
      Module["asm"] = asm;
      var __GLOBAL__sub_I_gfx_emsc_cc = Module["__GLOBAL__sub_I_gfx_emsc_cc"] = function () {
        return Module["asm"]["hb"].apply(null, arguments);
      };
      var ___errno_location = Module["___errno_location"] = function () {
        return Module["asm"]["ib"].apply(null, arguments);
      };
      var _applyBindings = Module["_applyBindings"] = function () {
        return Module["asm"]["jb"].apply(null, arguments);
      };
      var _applyPipeline = Module["_applyPipeline"] = function () {
        return Module["asm"]["kb"].apply(null, arguments);
      };
      var _applyScissorRect = Module["_applyScissorRect"] = function () {
        return Module["asm"]["lb"].apply(null, arguments);
      };
      var _applyUniformBlock = Module["_applyUniformBlock"] = function () {
        return Module["asm"]["mb"].apply(null, arguments);
      };
      var _applyUniforms = Module["_applyUniforms"] = function () {
        return Module["asm"]["nb"].apply(null, arguments);
      };
      var _applyViewport = Module["_applyViewport"] = function () {
        return Module["asm"]["ob"].apply(null, arguments);
      };
      var _beginDefaultPass = Module["_beginDefaultPass"] = function () {
        return Module["asm"]["pb"].apply(null, arguments);
      };
      var _beginPass = Module["_beginPass"] = function () {
        return Module["asm"]["qb"].apply(null, arguments);
      };
      var _commit = Module["_commit"] = function () {
        return Module["asm"]["rb"].apply(null, arguments);
      };
      var _createNativeBuffer = Module["_createNativeBuffer"] = function () {
        return Module["asm"]["sb"].apply(null, arguments);
      };
      var _deleteNativeBuffer = Module["_deleteNativeBuffer"] = function () {
        return Module["asm"]["tb"].apply(null, arguments);
      };
      var _destroyBuffer = Module["_destroyBuffer"] = function () {
        return Module["asm"]["ub"].apply(null, arguments);
      };
      var _destroyImage = Module["_destroyImage"] = function () {
        return Module["asm"]["vb"].apply(null, arguments);
      };
      var _destroyPass = Module["_destroyPass"] = function () {
        return Module["asm"]["wb"].apply(null, arguments);
      };
      var _destroyPipeline = Module["_destroyPipeline"] = function () {
        return Module["asm"]["xb"].apply(null, arguments);
      };
      var _destroyShader = Module["_destroyShader"] = function () {
        return Module["asm"]["yb"].apply(null, arguments);
      };
      var _draw = Module["_draw"] = function () {
        return Module["asm"]["zb"].apply(null, arguments);
      };
      var _endPass = Module["_endPass"] = function () {
        return Module["asm"]["Ab"].apply(null, arguments);
      };
      var _free = Module["_free"] = function () {
        return Module["asm"]["Bb"].apply(null, arguments);
      };
      var _getBufferString = Module["_getBufferString"] = function () {
        return Module["asm"]["Cb"].apply(null, arguments);
      };
      var _main = Module["_main"] = function () {
        return Module["asm"]["Db"].apply(null, arguments);
      };
      var _makeBuffer = Module["_makeBuffer"] = function () {
        return Module["asm"]["Eb"].apply(null, arguments);
      };
      var _makeImage = Module["_makeImage"] = function () {
        return Module["asm"]["Fb"].apply(null, arguments);
      };
      var _makePass = Module["_makePass"] = function () {
        return Module["asm"]["Gb"].apply(null, arguments);
      };
      var _makePipeline = Module["_makePipeline"] = function () {
        return Module["asm"]["Hb"].apply(null, arguments);
      };
      var _makeShader = Module["_makeShader"] = function () {
        return Module["asm"]["Ib"].apply(null, arguments);
      };
      var _malloc = Module["_malloc"] = function () {
        return Module["asm"]["Jb"].apply(null, arguments);
      };
      var _queryBackend = Module["_queryBackend"] = function () {
        return Module["asm"]["Kb"].apply(null, arguments);
      };
      var _queryBufferState = Module["_queryBufferState"] = function () {
        return Module["asm"]["Lb"].apply(null, arguments);
      };
      var _queryFeature = Module["_queryFeature"] = function () {
        return Module["asm"]["Mb"].apply(null, arguments);
      };
      var _queryImageState = Module["_queryImageState"] = function () {
        return Module["asm"]["Nb"].apply(null, arguments);
      };
      var _queryPassState = Module["_queryPassState"] = function () {
        return Module["asm"]["Ob"].apply(null, arguments);
      };
      var _queryPipelineState = Module["_queryPipelineState"] = function () {
        return Module["asm"]["Pb"].apply(null, arguments);
      };
      var _queryShaderBinary = Module["_queryShaderBinary"] = function () {
        return Module["asm"]["Qb"].apply(null, arguments);
      };
      var _queryShaderState = Module["_queryShaderState"] = function () {
        return Module["asm"]["Rb"].apply(null, arguments);
      };
      var _readPixels = Module["_readPixels"] = function () {
        return Module["asm"]["Sb"].apply(null, arguments);
      };
      var _setupGfx = Module["_setupGfx"] = function () {
        return Module["asm"]["Tb"].apply(null, arguments);
      };
      var _updateBuffer = Module["_updateBuffer"] = function () {
        return Module["asm"]["Ub"].apply(null, arguments);
      };
      var _updateImage = Module["_updateImage"] = function () {
        return Module["asm"]["Vb"].apply(null, arguments);
      };
      var stackAlloc = Module["stackAlloc"] = function () {
        return Module["asm"]["Yb"].apply(null, arguments);
      };
      var stackRestore = Module["stackRestore"] = function () {
        return Module["asm"]["Zb"].apply(null, arguments);
      };
      var stackSave = Module["stackSave"] = function () {
        return Module["asm"]["_b"].apply(null, arguments);
      };
      var dynCall_v = Module["dynCall_v"] = function () {
        return Module["asm"]["Wb"].apply(null, arguments);
      };
      var dynCall_vi = Module["dynCall_vi"] = function () {
        return Module["asm"]["Xb"].apply(null, arguments);
      };
      Module["asm"] = asm;
      Module["ccall"] = ccall;
      Module["cwrap"] = cwrap;
      Module["then"] = function (func) {
        if (Module["calledRun"]) {
          func(Module);
        } else {
          var old = Module["onRuntimeInitialized"];
          Module["onRuntimeInitialized"] = function () {
            if (old) old();
            func(Module);
          };
        }
        return Module;
      };
      function ExitStatus(status) {
        this.name = "ExitStatus";
        this.message = "Program terminated with exit(" + status + ")";
        this.status = status;
      }
      ExitStatus.prototype = new Error();
      ExitStatus.prototype.constructor = ExitStatus;
      var calledMain = false;
      dependenciesFulfilled = function runCaller() {
        if (!Module["calledRun"]) run();
        if (!Module["calledRun"]) dependenciesFulfilled = runCaller;
      };
      Module["callMain"] = function callMain(args) {
        args = args || [];
        ensureInitRuntime();
        var argc = args.length + 1;
        var argv = stackAlloc((argc + 1) * 4);
        HEAP32[argv >> 2] = allocateUTF8OnStack(Module["thisProgram"]);
        for (var i = 1; i < argc; i++) {
          HEAP32[(argv >> 2) + i] = allocateUTF8OnStack(args[i - 1]);
        }
        HEAP32[(argv >> 2) + argc] = 0;
        try {
          var ret = Module["_main"](argc, argv, 0);
          exit(ret, true);
        } catch (e) {
          if (e instanceof ExitStatus) {
            return;
          } else if (e == "SimulateInfiniteLoop") {
            Module["noExitRuntime"] = true;
            return;
          } else {
            var toLog = e;
            if (e && _typeof(e) === "object" && e.stack) {
              toLog = [e, e.stack];
            }
            err("exception thrown: " + toLog);
            Module["quit"](1, e);
          }
        } finally {
          calledMain = true;
        }
      };
      function run(args) {
        args = args || Module["arguments"];
        if (runDependencies > 0) {
          return;
        }
        preRun();
        if (runDependencies > 0) return;
        if (Module["calledRun"]) return;
        function doRun() {
          if (Module["calledRun"]) return;
          Module["calledRun"] = true;
          if (ABORT) return;
          ensureInitRuntime();
          preMain();
          if (Module["onRuntimeInitialized"]) Module["onRuntimeInitialized"]();
          if (Module["_main"] && shouldRunNow) Module["callMain"](args);
          postRun();
        }
        if (Module["setStatus"]) {
          Module["setStatus"]("Running...");
          setTimeout(function () {
            setTimeout(function () {
              Module["setStatus"]("");
            }, 1);
            doRun();
          }, 1);
        } else {
          doRun();
        }
      }
      Module["run"] = run;
      function exit(status, implicit) {
        if (implicit && Module["noExitRuntime"] && status === 0) {
          return;
        }
        if (Module["noExitRuntime"]) {} else {
          ABORT = true;
          EXITSTATUS = status;
          exitRuntime();
          if (Module["onExit"]) Module["onExit"](status);
        }
        Module["quit"](status, new ExitStatus(status));
      }
      function abort(what) {
        if (Module["onAbort"]) {
          Module["onAbort"](what);
        }
        if (what !== undefined) {
          out(what);
          err(what);
          what = JSON.stringify(what);
        } else {
          what = "";
        }
        ABORT = true;
        EXITSTATUS = 1;
        throw "abort(" + what + "). Build with -s ASSERTIONS=1 for more info.";
      }
      Module["abort"] = abort;
      if (Module["preInit"]) {
        if (typeof Module["preInit"] == "function") Module["preInit"] = [Module["preInit"]];
        while (Module["preInit"].length > 0) {
          Module["preInit"].pop()();
        }
      }
      var shouldRunNow = true;
      if (Module["noInitialRun"]) {
        shouldRunNow = false;
      }
      Module["noExitRuntime"] = true;
      run();
      return Module;
    };
  }();
  if (_typeof(exports) === 'object' && _typeof(module) === 'object') module.exports = Module;else if (typeof define === 'function' && define['amd']) define([], function () {
    return Module;
  });else if (_typeof(exports) === 'object') exports["Module"] = Module;
  return function () {
    return Module().then(function (mod) {
      window.DEVTOOL_WASM_MODULE = mod;
      wgfx();
      return mod;
    });
  };
}();