
;try {

;(function () { /* LIBRARY_CLOSURE_START () */


            let getGlobalVar = "getWxGAGlobalVar"
            let sdkSubpakcageGlobalVarGetter
            if(globalThis[getGlobalVar]) {
              sdkSubpakcageGlobalVarGetter = globalThis[getGlobalVar]
            } else if(typeof globalThis.WeixinJSBridge !== "undefined" && globalThis.WeixinJSBridge[getGlobalVar]){
              sdkSubpakcageGlobalVarGetter = globalThis.WeixinJSBridge[getGlobalVar]
            }
            var {wxConsole,wxNativeConsole} = sdkSubpakcageGlobalVarGetter();
          

var wgfx =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var wgfx = tslib_1.__importStar(__webpack_require__(2));
exports.default = wgfx;


/***/ }),
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__extends", function() { return __extends; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__assign", function() { return __assign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__rest", function() { return __rest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__decorate", function() { return __decorate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__param", function() { return __param; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__metadata", function() { return __metadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__awaiter", function() { return __awaiter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__generator", function() { return __generator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__createBinding", function() { return __createBinding; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__exportStar", function() { return __exportStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__values", function() { return __values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__read", function() { return __read; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spread", function() { return __spread; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArrays", function() { return __spreadArrays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArray", function() { return __spreadArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__await", function() { return __await; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function() { return __asyncGenerator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function() { return __asyncDelegator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncValues", function() { return __asyncValues; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function() { return __makeTemplateObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importStar", function() { return __importStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importDefault", function() { return __importDefault; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldGet", function() { return __classPrivateFieldGet; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldSet", function() { return __classPrivateFieldSet; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldIn", function() { return __classPrivateFieldIn; });
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    if (typeof b !== "function" && b !== null)
        throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

var __createBinding = Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});

function __exportStar(m, o) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
}

function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

/** @deprecated */
function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

/** @deprecated */
function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
}

function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
}

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

var __setModuleDefault = Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}

function __classPrivateFieldGet(receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}

function __classPrivateFieldSet(receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
}

function __classPrivateFieldIn(state, receiver) {
    if (receiver === null || (typeof receiver !== "object" && typeof receiver !== "function")) throw new TypeError("Cannot use 'in' operator on non-object");
    return typeof state === "function" ? receiver === state : state.has(receiver);
}


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/*
 * @Author: bluecatliao
 * @Date: 2018-10-31 22:21:20
 * @Last Modified by: bluecatliao
 * @Last Modified time: 2019-03-29 06:06:19
 * GFX常量、枚举值配置
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnumPixelType = exports.EnumAction = exports.EnumColorMask = exports.EnumBlendOp = exports.EnumBlendFactor = exports.EnumStencilOp = exports.EnumCompareFunc = exports.EnumFaceWinding = exports.EnumCullMode = exports.EnumUniformType = exports.EnumVertexStep = exports.EnumVertexFormat = exports.EnumWrap = exports.EnumFilter = exports.EnumPrimitiveType = exports.EnumPixelFormat = exports.EnumShaderStage = exports.EnumCubeFace = exports.EnumImageType = exports.EnumIndexType = exports.EnumBufferType = exports.EnumUsage = exports.EnumFeature = void 0;
var EnumFeature;
(function (EnumFeature) {
    EnumFeature[EnumFeature["INSTANCING"] = 0] = "INSTANCING";
    EnumFeature[EnumFeature["TEXTURE_COMPRESSION_DXT"] = 1] = "TEXTURE_COMPRESSION_DXT";
    EnumFeature[EnumFeature["TEXTURE_COMPRESSION_PVRTC"] = 2] = "TEXTURE_COMPRESSION_PVRTC";
    EnumFeature[EnumFeature["TEXTURE_COMPRESSION_ATC"] = 3] = "TEXTURE_COMPRESSION_ATC";
    EnumFeature[EnumFeature["TEXTURE_COMPRESSION_ETC2"] = 4] = "TEXTURE_COMPRESSION_ETC2";
    EnumFeature[EnumFeature["TEXTURE_FLOAT"] = 5] = "TEXTURE_FLOAT";
    EnumFeature[EnumFeature["TEXTURE_HALF_FLOAT"] = 6] = "TEXTURE_HALF_FLOAT";
    EnumFeature[EnumFeature["ORIGIN_BOTTOM_LEFT"] = 7] = "ORIGIN_BOTTOM_LEFT";
    EnumFeature[EnumFeature["ORIGIN_TOP_LEFT"] = 8] = "ORIGIN_TOP_LEFT";
    EnumFeature[EnumFeature["MSAA_RENDER_TARGETS"] = 9] = "MSAA_RENDER_TARGETS";
    EnumFeature[EnumFeature["PACKED_VERTEX_FORMAT_10_2"] = 10] = "PACKED_VERTEX_FORMAT_10_2";
    EnumFeature[EnumFeature["MULTIPLE_RENDER_TARGET"] = 11] = "MULTIPLE_RENDER_TARGET";
    EnumFeature[EnumFeature["IMAGETYPE_3D"] = 12] = "IMAGETYPE_3D";
    EnumFeature[EnumFeature["IMAGETYPE_ARRAY"] = 13] = "IMAGETYPE_ARRAY";
})(EnumFeature = exports.EnumFeature || (exports.EnumFeature = {}));
// sg_usage
var EnumUsage;
(function (EnumUsage) {
    EnumUsage[EnumUsage["IMMUTABLE"] = 1] = "IMMUTABLE";
    EnumUsage[EnumUsage["DYNAMIC"] = 2] = "DYNAMIC";
    EnumUsage[EnumUsage["STREAM"] = 3] = "STREAM";
})(EnumUsage = exports.EnumUsage || (exports.EnumUsage = {}));
// sg_buffer_type
var EnumBufferType;
(function (EnumBufferType) {
    EnumBufferType[EnumBufferType["VERTEXBUFFER"] = 1] = "VERTEXBUFFER";
    EnumBufferType[EnumBufferType["INDEXBUFFER"] = 2] = "INDEXBUFFER";
})(EnumBufferType = exports.EnumBufferType || (exports.EnumBufferType = {}));
// sg_index_type
var EnumIndexType;
(function (EnumIndexType) {
    EnumIndexType[EnumIndexType["NONE"] = 1] = "NONE";
    EnumIndexType[EnumIndexType["UINT16"] = 2] = "UINT16";
    EnumIndexType[EnumIndexType["UINT32"] = 3] = "UINT32";
})(EnumIndexType = exports.EnumIndexType || (exports.EnumIndexType = {}));
// sg_image_type
var EnumImageType;
(function (EnumImageType) {
    EnumImageType[EnumImageType["IMAGETYPE_2D"] = 1] = "IMAGETYPE_2D";
    EnumImageType[EnumImageType["IMAGETYPE_CUBE"] = 2] = "IMAGETYPE_CUBE";
    EnumImageType[EnumImageType["IMAGETYPE_3D"] = 3] = "IMAGETYPE_3D";
    EnumImageType[EnumImageType["IMAGETYPE_ARRAY"] = 4] = "IMAGETYPE_ARRAY";
})(EnumImageType = exports.EnumImageType || (exports.EnumImageType = {}));
// sg_cube_face
var EnumCubeFace;
(function (EnumCubeFace) {
    EnumCubeFace[EnumCubeFace["POS_X"] = 0] = "POS_X";
    EnumCubeFace[EnumCubeFace["NEG_X"] = 1] = "NEG_X";
    EnumCubeFace[EnumCubeFace["POS_Y"] = 2] = "POS_Y";
    EnumCubeFace[EnumCubeFace["NEG_Y"] = 3] = "NEG_Y";
    EnumCubeFace[EnumCubeFace["POS_Z"] = 4] = "POS_Z";
    EnumCubeFace[EnumCubeFace["NEG_Z"] = 5] = "NEG_Z";
    EnumCubeFace[EnumCubeFace["NUM"] = 6] = "NUM";
})(EnumCubeFace = exports.EnumCubeFace || (exports.EnumCubeFace = {}));
// sg_shader_stage
var EnumShaderStage;
(function (EnumShaderStage) {
    EnumShaderStage[EnumShaderStage["VS"] = 0] = "VS";
    EnumShaderStage[EnumShaderStage["FS"] = 1] = "FS";
})(EnumShaderStage = exports.EnumShaderStage || (exports.EnumShaderStage = {}));
// sg_pixel_format
var EnumPixelFormat;
(function (EnumPixelFormat) {
    EnumPixelFormat[EnumPixelFormat["NONE"] = 1] = "NONE";
    EnumPixelFormat[EnumPixelFormat["RGBA8"] = 2] = "RGBA8";
    EnumPixelFormat[EnumPixelFormat["RGB8"] = 3] = "RGB8";
    EnumPixelFormat[EnumPixelFormat["RGBA4"] = 4] = "RGBA4";
    EnumPixelFormat[EnumPixelFormat["R5G6B5"] = 5] = "R5G6B5";
    EnumPixelFormat[EnumPixelFormat["R5G5B5A1"] = 6] = "R5G5B5A1";
    EnumPixelFormat[EnumPixelFormat["R10G10B10A2"] = 7] = "R10G10B10A2";
    EnumPixelFormat[EnumPixelFormat["RGBA32F"] = 8] = "RGBA32F";
    EnumPixelFormat[EnumPixelFormat["RGBA16F"] = 9] = "RGBA16F";
    EnumPixelFormat[EnumPixelFormat["R32F"] = 10] = "R32F";
    EnumPixelFormat[EnumPixelFormat["R16F"] = 11] = "R16F";
    EnumPixelFormat[EnumPixelFormat["L8"] = 12] = "L8";
    EnumPixelFormat[EnumPixelFormat["DXT1"] = 13] = "DXT1";
    EnumPixelFormat[EnumPixelFormat["DXT3"] = 14] = "DXT3";
    EnumPixelFormat[EnumPixelFormat["DXT5"] = 15] = "DXT5";
    EnumPixelFormat[EnumPixelFormat["DEPTH"] = 16] = "DEPTH";
    EnumPixelFormat[EnumPixelFormat["DEPTHSTENCIL"] = 17] = "DEPTHSTENCIL";
    EnumPixelFormat[EnumPixelFormat["PVRTC2_RGB"] = 18] = "PVRTC2_RGB";
    EnumPixelFormat[EnumPixelFormat["PVRTC4_RGB"] = 19] = "PVRTC4_RGB";
    EnumPixelFormat[EnumPixelFormat["PVRTC2_RGBA"] = 20] = "PVRTC2_RGBA";
    EnumPixelFormat[EnumPixelFormat["PVRTC4_RGBA"] = 21] = "PVRTC4_RGBA";
    EnumPixelFormat[EnumPixelFormat["ETC2_RGB8"] = 22] = "ETC2_RGB8";
    EnumPixelFormat[EnumPixelFormat["ETC2_SRGB8"] = 23] = "ETC2_SRGB8";
    EnumPixelFormat[EnumPixelFormat["ETC1_RGB8"] = 24] = "ETC1_RGB8";
    EnumPixelFormat[EnumPixelFormat["PIXELFORMAT_PVR_CCZ"] = 25] = "PIXELFORMAT_PVR_CCZ";
    EnumPixelFormat[EnumPixelFormat["PIXELFORMAT_PVR_GZ"] = 26] = "PIXELFORMAT_PVR_GZ";
    EnumPixelFormat[EnumPixelFormat["PIXELFORMAT_ETC2_RGBA8"] = 27] = "PIXELFORMAT_ETC2_RGBA8";
    EnumPixelFormat[EnumPixelFormat["ASTC"] = 28] = "ASTC";
})(EnumPixelFormat = exports.EnumPixelFormat || (exports.EnumPixelFormat = {}));
// sg_primitive_type
var EnumPrimitiveType;
(function (EnumPrimitiveType) {
    EnumPrimitiveType[EnumPrimitiveType["POINTS"] = 1] = "POINTS";
    EnumPrimitiveType[EnumPrimitiveType["LINES"] = 2] = "LINES";
    EnumPrimitiveType[EnumPrimitiveType["LINE_STRIP"] = 3] = "LINE_STRIP";
    EnumPrimitiveType[EnumPrimitiveType["TRIANGLES"] = 4] = "TRIANGLES";
    EnumPrimitiveType[EnumPrimitiveType["TRIANGLE_STRIP"] = 5] = "TRIANGLE_STRIP";
})(EnumPrimitiveType = exports.EnumPrimitiveType || (exports.EnumPrimitiveType = {}));
// sg_filter
var EnumFilter;
(function (EnumFilter) {
    EnumFilter[EnumFilter["NEAREST"] = 1] = "NEAREST";
    EnumFilter[EnumFilter["LINEAR"] = 2] = "LINEAR";
    EnumFilter[EnumFilter["NEAREST_MIPMAP_NEAREST"] = 3] = "NEAREST_MIPMAP_NEAREST";
    EnumFilter[EnumFilter["NEAREST_MIPMAP_LINEAR"] = 4] = "NEAREST_MIPMAP_LINEAR";
    EnumFilter[EnumFilter["LINEAR_MIPMAP_NEAREST"] = 5] = "LINEAR_MIPMAP_NEAREST";
    EnumFilter[EnumFilter["LINEAR_MIPMAP_LINEAR"] = 6] = "LINEAR_MIPMAP_LINEAR";
})(EnumFilter = exports.EnumFilter || (exports.EnumFilter = {}));
// sg_wrap
var EnumWrap;
(function (EnumWrap) {
    EnumWrap[EnumWrap["REPEAT"] = 1] = "REPEAT";
    EnumWrap[EnumWrap["CLAMP_TO_EDGE"] = 2] = "CLAMP_TO_EDGE";
    EnumWrap[EnumWrap["MIRRORED_REPEAT"] = 3] = "MIRRORED_REPEAT";
})(EnumWrap = exports.EnumWrap || (exports.EnumWrap = {}));
// sg_vertex_format
var EnumVertexFormat;
(function (EnumVertexFormat) {
    EnumVertexFormat[EnumVertexFormat["INVALID"] = 0] = "INVALID";
    EnumVertexFormat[EnumVertexFormat["FLOAT"] = 1] = "FLOAT";
    EnumVertexFormat[EnumVertexFormat["FLOAT2"] = 2] = "FLOAT2";
    EnumVertexFormat[EnumVertexFormat["FLOAT3"] = 3] = "FLOAT3";
    EnumVertexFormat[EnumVertexFormat["FLOAT4"] = 4] = "FLOAT4";
    EnumVertexFormat[EnumVertexFormat["BYTE4"] = 5] = "BYTE4";
    EnumVertexFormat[EnumVertexFormat["BYTE4N"] = 6] = "BYTE4N";
    EnumVertexFormat[EnumVertexFormat["UBYTE4"] = 7] = "UBYTE4";
    EnumVertexFormat[EnumVertexFormat["UBYTE4N"] = 8] = "UBYTE4N";
    EnumVertexFormat[EnumVertexFormat["SHORT2"] = 9] = "SHORT2";
    EnumVertexFormat[EnumVertexFormat["SHORT2N"] = 10] = "SHORT2N";
    EnumVertexFormat[EnumVertexFormat["SHORT4"] = 11] = "SHORT4";
    EnumVertexFormat[EnumVertexFormat["SHORT4N"] = 12] = "SHORT4N";
    EnumVertexFormat[EnumVertexFormat["UINT10_N2"] = 13] = "UINT10_N2";
})(EnumVertexFormat = exports.EnumVertexFormat || (exports.EnumVertexFormat = {}));
// sg_vertex_step
var EnumVertexStep;
(function (EnumVertexStep) {
    EnumVertexStep[EnumVertexStep["PER_VERTEX"] = 1] = "PER_VERTEX";
    EnumVertexStep[EnumVertexStep["PER_INSTANCE"] = 2] = "PER_INSTANCE";
})(EnumVertexStep = exports.EnumVertexStep || (exports.EnumVertexStep = {}));
// sg_uniform_type
var EnumUniformType;
(function (EnumUniformType) {
    EnumUniformType[EnumUniformType["INVALID"] = 0] = "INVALID";
    EnumUniformType[EnumUniformType["FLOAT"] = 1] = "FLOAT";
    EnumUniformType[EnumUniformType["FLOAT2"] = 2] = "FLOAT2";
    EnumUniformType[EnumUniformType["FLOAT3"] = 3] = "FLOAT3";
    EnumUniformType[EnumUniformType["FLOAT4"] = 4] = "FLOAT4";
    EnumUniformType[EnumUniformType["MAT4"] = 5] = "MAT4";
})(EnumUniformType = exports.EnumUniformType || (exports.EnumUniformType = {}));
// sg_cull_mode
var EnumCullMode;
(function (EnumCullMode) {
    EnumCullMode[EnumCullMode["NONE"] = 1] = "NONE";
    EnumCullMode[EnumCullMode["FRONT"] = 2] = "FRONT";
    EnumCullMode[EnumCullMode["BACK"] = 3] = "BACK";
})(EnumCullMode = exports.EnumCullMode || (exports.EnumCullMode = {}));
// sg_face_winding
var EnumFaceWinding;
(function (EnumFaceWinding) {
    EnumFaceWinding[EnumFaceWinding["CCW"] = 1] = "CCW";
    EnumFaceWinding[EnumFaceWinding["CW"] = 2] = "CW";
})(EnumFaceWinding = exports.EnumFaceWinding || (exports.EnumFaceWinding = {}));
// sg_compare_func
var EnumCompareFunc;
(function (EnumCompareFunc) {
    EnumCompareFunc[EnumCompareFunc["NEVER"] = 1] = "NEVER";
    EnumCompareFunc[EnumCompareFunc["LESS"] = 2] = "LESS";
    EnumCompareFunc[EnumCompareFunc["EQUAL"] = 3] = "EQUAL";
    EnumCompareFunc[EnumCompareFunc["LESS_EQUAL"] = 4] = "LESS_EQUAL";
    EnumCompareFunc[EnumCompareFunc["GREATER"] = 5] = "GREATER";
    EnumCompareFunc[EnumCompareFunc["NOT_EQUAL"] = 6] = "NOT_EQUAL";
    EnumCompareFunc[EnumCompareFunc["GREATER_EQUAL"] = 7] = "GREATER_EQUAL";
    EnumCompareFunc[EnumCompareFunc["ALWAYS"] = 8] = "ALWAYS";
})(EnumCompareFunc = exports.EnumCompareFunc || (exports.EnumCompareFunc = {}));
// sg_stencil_op
var EnumStencilOp;
(function (EnumStencilOp) {
    EnumStencilOp[EnumStencilOp["KEEP"] = 1] = "KEEP";
    EnumStencilOp[EnumStencilOp["ZERO"] = 2] = "ZERO";
    EnumStencilOp[EnumStencilOp["REPLACE"] = 3] = "REPLACE";
    EnumStencilOp[EnumStencilOp["INCR_CLAMP"] = 4] = "INCR_CLAMP";
    EnumStencilOp[EnumStencilOp["DECR_CLAMP"] = 5] = "DECR_CLAMP";
    EnumStencilOp[EnumStencilOp["INVERT"] = 6] = "INVERT";
    EnumStencilOp[EnumStencilOp["INCR_WRAP"] = 7] = "INCR_WRAP";
    EnumStencilOp[EnumStencilOp["DECR_WRAP"] = 8] = "DECR_WRAP";
})(EnumStencilOp = exports.EnumStencilOp || (exports.EnumStencilOp = {}));
// sg_blend_factor
var EnumBlendFactor;
(function (EnumBlendFactor) {
    EnumBlendFactor[EnumBlendFactor["ZERO"] = 1] = "ZERO";
    EnumBlendFactor[EnumBlendFactor["ONE"] = 2] = "ONE";
    EnumBlendFactor[EnumBlendFactor["SRC_COLOR"] = 3] = "SRC_COLOR";
    EnumBlendFactor[EnumBlendFactor["ONE_MINUS_SRC_COLOR"] = 4] = "ONE_MINUS_SRC_COLOR";
    EnumBlendFactor[EnumBlendFactor["SRC_ALPHA"] = 5] = "SRC_ALPHA";
    EnumBlendFactor[EnumBlendFactor["ONE_MINUS_SRC_ALPHA"] = 6] = "ONE_MINUS_SRC_ALPHA";
    EnumBlendFactor[EnumBlendFactor["DST_COLOR"] = 7] = "DST_COLOR";
    EnumBlendFactor[EnumBlendFactor["ONE_MINUS_DST_COLOR"] = 8] = "ONE_MINUS_DST_COLOR";
    EnumBlendFactor[EnumBlendFactor["DST_ALPHA"] = 9] = "DST_ALPHA";
    EnumBlendFactor[EnumBlendFactor["ONE_MINUS_DST_ALPHA"] = 10] = "ONE_MINUS_DST_ALPHA";
    EnumBlendFactor[EnumBlendFactor["SRC_ALPHA_SATURATED"] = 11] = "SRC_ALPHA_SATURATED";
    EnumBlendFactor[EnumBlendFactor["BLEND_COLOR"] = 12] = "BLEND_COLOR";
    EnumBlendFactor[EnumBlendFactor["ONE_MINUS_BLEND_COLOR"] = 13] = "ONE_MINUS_BLEND_COLOR";
    EnumBlendFactor[EnumBlendFactor["BLEND_ALPHA"] = 14] = "BLEND_ALPHA";
    EnumBlendFactor[EnumBlendFactor["ONE_MINUS_BLEND_ALPHA"] = 15] = "ONE_MINUS_BLEND_ALPHA";
})(EnumBlendFactor = exports.EnumBlendFactor || (exports.EnumBlendFactor = {}));
// sg_blend_op
var EnumBlendOp;
(function (EnumBlendOp) {
    EnumBlendOp[EnumBlendOp["ADD"] = 1] = "ADD";
    EnumBlendOp[EnumBlendOp["SUBTRACT"] = 2] = "SUBTRACT";
    EnumBlendOp[EnumBlendOp["REVERSE_SUBTRACT"] = 3] = "REVERSE_SUBTRACT";
})(EnumBlendOp = exports.EnumBlendOp || (exports.EnumBlendOp = {}));
// sg_color_mask
var EnumColorMask;
(function (EnumColorMask) {
    EnumColorMask[EnumColorMask["NONE"] = 16] = "NONE";
    EnumColorMask[EnumColorMask["R"] = 1] = "R";
    EnumColorMask[EnumColorMask["G"] = 2] = "G";
    EnumColorMask[EnumColorMask["B"] = 4] = "B";
    EnumColorMask[EnumColorMask["A"] = 8] = "A";
    EnumColorMask[EnumColorMask["RGB"] = 7] = "RGB";
    EnumColorMask[EnumColorMask["RGBA"] = 15] = "RGBA";
})(EnumColorMask = exports.EnumColorMask || (exports.EnumColorMask = {}));
// sg_action
var EnumAction;
(function (EnumAction) {
    EnumAction[EnumAction["CLEAR"] = 1] = "CLEAR";
    EnumAction[EnumAction["LOAD"] = 2] = "LOAD";
    EnumAction[EnumAction["DONTCARE"] = 3] = "DONTCARE";
})(EnumAction = exports.EnumAction || (exports.EnumAction = {}));
var EnumPixelType;
(function (EnumPixelType) {
    EnumPixelType[EnumPixelType["UNSIGNED_BYTE"] = 5121] = "UNSIGNED_BYTE";
    EnumPixelType[EnumPixelType["FLOAT"] = 5126] = "FLOAT";
    EnumPixelType[EnumPixelType["UNSIGNED_SHORT_5_6_5"] = 33635] = "UNSIGNED_SHORT_5_6_5";
    EnumPixelType[EnumPixelType["UNSIGNED_SHORT_4_4_4_4"] = 32819] = "UNSIGNED_SHORT_4_4_4_4";
    EnumPixelType[EnumPixelType["UNSIGNED_SHORT_5_5_5_1"] = 32820] = "UNSIGNED_SHORT_5_5_5_1";
})(EnumPixelType = exports.EnumPixelType || (exports.EnumPixelType = {}));


/***/ })
/******/ ])["default"];
var wxGA =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 3);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */,
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__extends", function() { return __extends; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__assign", function() { return __assign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__rest", function() { return __rest; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__decorate", function() { return __decorate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__param", function() { return __param; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__metadata", function() { return __metadata; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__awaiter", function() { return __awaiter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__generator", function() { return __generator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__createBinding", function() { return __createBinding; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__exportStar", function() { return __exportStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__values", function() { return __values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__read", function() { return __read; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spread", function() { return __spread; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArrays", function() { return __spreadArrays; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__spreadArray", function() { return __spreadArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__await", function() { return __await; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function() { return __asyncGenerator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function() { return __asyncDelegator; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__asyncValues", function() { return __asyncValues; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function() { return __makeTemplateObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importStar", function() { return __importStar; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__importDefault", function() { return __importDefault; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldGet", function() { return __classPrivateFieldGet; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldSet", function() { return __classPrivateFieldSet; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "__classPrivateFieldIn", function() { return __classPrivateFieldIn; });
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = function(d, b) {
    extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
    return extendStatics(d, b);
};

function __extends(d, b) {
    if (typeof b !== "function" && b !== null)
        throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = function() {
    __assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
        return t;
    }
    return __assign.apply(this, arguments);
}

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
            if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                t[p[i]] = s[p[i]];
        }
    return t;
}

function __decorate(decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
}

function __param(paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
}

function __metadata(metadataKey, metadataValue) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
}

function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
}

function __generator(thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
}

var __createBinding = Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
});

function __exportStar(m, o) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p)) __createBinding(o, m, p);
}

function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
        next: function () {
            if (o && i >= o.length) o = void 0;
            return { value: o && o[i++], done: !o };
        }
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}

function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

/** @deprecated */
function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

/** @deprecated */
function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
    for (var r = Array(s), k = 0, i = 0; i < il; i++)
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
            r[k] = a[j];
    return r;
}

function __spreadArray(to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
}

function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
}

function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
    function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
    function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
    function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
    function fulfill(value) { resume("next", value); }
    function reject(value) { resume("throw", value); }
    function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
}

function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
    function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
}

function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
    function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
    function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
}

function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
    return cooked;
};

var __setModuleDefault = Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
};

function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
}

function __importDefault(mod) {
    return (mod && mod.__esModule) ? mod : { default: mod };
}

function __classPrivateFieldGet(receiver, state, kind, f) {
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
    return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}

function __classPrivateFieldSet(receiver, state, value, kind, f) {
    if (kind === "m") throw new TypeError("Private method is not writable");
    if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
    if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
    return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
}

function __classPrivateFieldIn(state, receiver) {
    if (receiver === null || (typeof receiver !== "object" && typeof receiver !== "function")) throw new TypeError("Cannot use 'in' operator on non-object");
    return typeof state === "function" ? receiver === state : state.has(receiver);
}


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/*
 * @Author: bluecatliao
 * @Date: 2018-10-31 22:21:20
 * @Last Modified by: bluecatliao
 * @Last Modified time: 2019-03-29 06:06:19
 * GFX常量、枚举值配置
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnumPixelType = exports.EnumAction = exports.EnumColorMask = exports.EnumBlendOp = exports.EnumBlendFactor = exports.EnumStencilOp = exports.EnumCompareFunc = exports.EnumFaceWinding = exports.EnumCullMode = exports.EnumUniformType = exports.EnumVertexStep = exports.EnumVertexFormat = exports.EnumWrap = exports.EnumFilter = exports.EnumPrimitiveType = exports.EnumPixelFormat = exports.EnumShaderStage = exports.EnumCubeFace = exports.EnumImageType = exports.EnumIndexType = exports.EnumBufferType = exports.EnumUsage = exports.EnumFeature = void 0;
var EnumFeature;
(function (EnumFeature) {
    EnumFeature[EnumFeature["INSTANCING"] = 0] = "INSTANCING";
    EnumFeature[EnumFeature["TEXTURE_COMPRESSION_DXT"] = 1] = "TEXTURE_COMPRESSION_DXT";
    EnumFeature[EnumFeature["TEXTURE_COMPRESSION_PVRTC"] = 2] = "TEXTURE_COMPRESSION_PVRTC";
    EnumFeature[EnumFeature["TEXTURE_COMPRESSION_ATC"] = 3] = "TEXTURE_COMPRESSION_ATC";
    EnumFeature[EnumFeature["TEXTURE_COMPRESSION_ETC2"] = 4] = "TEXTURE_COMPRESSION_ETC2";
    EnumFeature[EnumFeature["TEXTURE_FLOAT"] = 5] = "TEXTURE_FLOAT";
    EnumFeature[EnumFeature["TEXTURE_HALF_FLOAT"] = 6] = "TEXTURE_HALF_FLOAT";
    EnumFeature[EnumFeature["ORIGIN_BOTTOM_LEFT"] = 7] = "ORIGIN_BOTTOM_LEFT";
    EnumFeature[EnumFeature["ORIGIN_TOP_LEFT"] = 8] = "ORIGIN_TOP_LEFT";
    EnumFeature[EnumFeature["MSAA_RENDER_TARGETS"] = 9] = "MSAA_RENDER_TARGETS";
    EnumFeature[EnumFeature["PACKED_VERTEX_FORMAT_10_2"] = 10] = "PACKED_VERTEX_FORMAT_10_2";
    EnumFeature[EnumFeature["MULTIPLE_RENDER_TARGET"] = 11] = "MULTIPLE_RENDER_TARGET";
    EnumFeature[EnumFeature["IMAGETYPE_3D"] = 12] = "IMAGETYPE_3D";
    EnumFeature[EnumFeature["IMAGETYPE_ARRAY"] = 13] = "IMAGETYPE_ARRAY";
})(EnumFeature = exports.EnumFeature || (exports.EnumFeature = {}));
// sg_usage
var EnumUsage;
(function (EnumUsage) {
    EnumUsage[EnumUsage["IMMUTABLE"] = 1] = "IMMUTABLE";
    EnumUsage[EnumUsage["DYNAMIC"] = 2] = "DYNAMIC";
    EnumUsage[EnumUsage["STREAM"] = 3] = "STREAM";
})(EnumUsage = exports.EnumUsage || (exports.EnumUsage = {}));
// sg_buffer_type
var EnumBufferType;
(function (EnumBufferType) {
    EnumBufferType[EnumBufferType["VERTEXBUFFER"] = 1] = "VERTEXBUFFER";
    EnumBufferType[EnumBufferType["INDEXBUFFER"] = 2] = "INDEXBUFFER";
})(EnumBufferType = exports.EnumBufferType || (exports.EnumBufferType = {}));
// sg_index_type
var EnumIndexType;
(function (EnumIndexType) {
    EnumIndexType[EnumIndexType["NONE"] = 1] = "NONE";
    EnumIndexType[EnumIndexType["UINT16"] = 2] = "UINT16";
    EnumIndexType[EnumIndexType["UINT32"] = 3] = "UINT32";
})(EnumIndexType = exports.EnumIndexType || (exports.EnumIndexType = {}));
// sg_image_type
var EnumImageType;
(function (EnumImageType) {
    EnumImageType[EnumImageType["IMAGETYPE_2D"] = 1] = "IMAGETYPE_2D";
    EnumImageType[EnumImageType["IMAGETYPE_CUBE"] = 2] = "IMAGETYPE_CUBE";
    EnumImageType[EnumImageType["IMAGETYPE_3D"] = 3] = "IMAGETYPE_3D";
    EnumImageType[EnumImageType["IMAGETYPE_ARRAY"] = 4] = "IMAGETYPE_ARRAY";
})(EnumImageType = exports.EnumImageType || (exports.EnumImageType = {}));
// sg_cube_face
var EnumCubeFace;
(function (EnumCubeFace) {
    EnumCubeFace[EnumCubeFace["POS_X"] = 0] = "POS_X";
    EnumCubeFace[EnumCubeFace["NEG_X"] = 1] = "NEG_X";
    EnumCubeFace[EnumCubeFace["POS_Y"] = 2] = "POS_Y";
    EnumCubeFace[EnumCubeFace["NEG_Y"] = 3] = "NEG_Y";
    EnumCubeFace[EnumCubeFace["POS_Z"] = 4] = "POS_Z";
    EnumCubeFace[EnumCubeFace["NEG_Z"] = 5] = "NEG_Z";
    EnumCubeFace[EnumCubeFace["NUM"] = 6] = "NUM";
})(EnumCubeFace = exports.EnumCubeFace || (exports.EnumCubeFace = {}));
// sg_shader_stage
var EnumShaderStage;
(function (EnumShaderStage) {
    EnumShaderStage[EnumShaderStage["VS"] = 0] = "VS";
    EnumShaderStage[EnumShaderStage["FS"] = 1] = "FS";
})(EnumShaderStage = exports.EnumShaderStage || (exports.EnumShaderStage = {}));
// sg_pixel_format
var EnumPixelFormat;
(function (EnumPixelFormat) {
    EnumPixelFormat[EnumPixelFormat["NONE"] = 1] = "NONE";
    EnumPixelFormat[EnumPixelFormat["RGBA8"] = 2] = "RGBA8";
    EnumPixelFormat[EnumPixelFormat["RGB8"] = 3] = "RGB8";
    EnumPixelFormat[EnumPixelFormat["RGBA4"] = 4] = "RGBA4";
    EnumPixelFormat[EnumPixelFormat["R5G6B5"] = 5] = "R5G6B5";
    EnumPixelFormat[EnumPixelFormat["R5G5B5A1"] = 6] = "R5G5B5A1";
    EnumPixelFormat[EnumPixelFormat["R10G10B10A2"] = 7] = "R10G10B10A2";
    EnumPixelFormat[EnumPixelFormat["RGBA32F"] = 8] = "RGBA32F";
    EnumPixelFormat[EnumPixelFormat["RGBA16F"] = 9] = "RGBA16F";
    EnumPixelFormat[EnumPixelFormat["R32F"] = 10] = "R32F";
    EnumPixelFormat[EnumPixelFormat["R16F"] = 11] = "R16F";
    EnumPixelFormat[EnumPixelFormat["L8"] = 12] = "L8";
    EnumPixelFormat[EnumPixelFormat["DXT1"] = 13] = "DXT1";
    EnumPixelFormat[EnumPixelFormat["DXT3"] = 14] = "DXT3";
    EnumPixelFormat[EnumPixelFormat["DXT5"] = 15] = "DXT5";
    EnumPixelFormat[EnumPixelFormat["DEPTH"] = 16] = "DEPTH";
    EnumPixelFormat[EnumPixelFormat["DEPTHSTENCIL"] = 17] = "DEPTHSTENCIL";
    EnumPixelFormat[EnumPixelFormat["PVRTC2_RGB"] = 18] = "PVRTC2_RGB";
    EnumPixelFormat[EnumPixelFormat["PVRTC4_RGB"] = 19] = "PVRTC4_RGB";
    EnumPixelFormat[EnumPixelFormat["PVRTC2_RGBA"] = 20] = "PVRTC2_RGBA";
    EnumPixelFormat[EnumPixelFormat["PVRTC4_RGBA"] = 21] = "PVRTC4_RGBA";
    EnumPixelFormat[EnumPixelFormat["ETC2_RGB8"] = 22] = "ETC2_RGB8";
    EnumPixelFormat[EnumPixelFormat["ETC2_SRGB8"] = 23] = "ETC2_SRGB8";
    EnumPixelFormat[EnumPixelFormat["ETC1_RGB8"] = 24] = "ETC1_RGB8";
    EnumPixelFormat[EnumPixelFormat["PIXELFORMAT_PVR_CCZ"] = 25] = "PIXELFORMAT_PVR_CCZ";
    EnumPixelFormat[EnumPixelFormat["PIXELFORMAT_PVR_GZ"] = 26] = "PIXELFORMAT_PVR_GZ";
    EnumPixelFormat[EnumPixelFormat["PIXELFORMAT_ETC2_RGBA8"] = 27] = "PIXELFORMAT_ETC2_RGBA8";
    EnumPixelFormat[EnumPixelFormat["ASTC"] = 28] = "ASTC";
})(EnumPixelFormat = exports.EnumPixelFormat || (exports.EnumPixelFormat = {}));
// sg_primitive_type
var EnumPrimitiveType;
(function (EnumPrimitiveType) {
    EnumPrimitiveType[EnumPrimitiveType["POINTS"] = 1] = "POINTS";
    EnumPrimitiveType[EnumPrimitiveType["LINES"] = 2] = "LINES";
    EnumPrimitiveType[EnumPrimitiveType["LINE_STRIP"] = 3] = "LINE_STRIP";
    EnumPrimitiveType[EnumPrimitiveType["TRIANGLES"] = 4] = "TRIANGLES";
    EnumPrimitiveType[EnumPrimitiveType["TRIANGLE_STRIP"] = 5] = "TRIANGLE_STRIP";
})(EnumPrimitiveType = exports.EnumPrimitiveType || (exports.EnumPrimitiveType = {}));
// sg_filter
var EnumFilter;
(function (EnumFilter) {
    EnumFilter[EnumFilter["NEAREST"] = 1] = "NEAREST";
    EnumFilter[EnumFilter["LINEAR"] = 2] = "LINEAR";
    EnumFilter[EnumFilter["NEAREST_MIPMAP_NEAREST"] = 3] = "NEAREST_MIPMAP_NEAREST";
    EnumFilter[EnumFilter["NEAREST_MIPMAP_LINEAR"] = 4] = "NEAREST_MIPMAP_LINEAR";
    EnumFilter[EnumFilter["LINEAR_MIPMAP_NEAREST"] = 5] = "LINEAR_MIPMAP_NEAREST";
    EnumFilter[EnumFilter["LINEAR_MIPMAP_LINEAR"] = 6] = "LINEAR_MIPMAP_LINEAR";
})(EnumFilter = exports.EnumFilter || (exports.EnumFilter = {}));
// sg_wrap
var EnumWrap;
(function (EnumWrap) {
    EnumWrap[EnumWrap["REPEAT"] = 1] = "REPEAT";
    EnumWrap[EnumWrap["CLAMP_TO_EDGE"] = 2] = "CLAMP_TO_EDGE";
    EnumWrap[EnumWrap["MIRRORED_REPEAT"] = 3] = "MIRRORED_REPEAT";
})(EnumWrap = exports.EnumWrap || (exports.EnumWrap = {}));
// sg_vertex_format
var EnumVertexFormat;
(function (EnumVertexFormat) {
    EnumVertexFormat[EnumVertexFormat["INVALID"] = 0] = "INVALID";
    EnumVertexFormat[EnumVertexFormat["FLOAT"] = 1] = "FLOAT";
    EnumVertexFormat[EnumVertexFormat["FLOAT2"] = 2] = "FLOAT2";
    EnumVertexFormat[EnumVertexFormat["FLOAT3"] = 3] = "FLOAT3";
    EnumVertexFormat[EnumVertexFormat["FLOAT4"] = 4] = "FLOAT4";
    EnumVertexFormat[EnumVertexFormat["BYTE4"] = 5] = "BYTE4";
    EnumVertexFormat[EnumVertexFormat["BYTE4N"] = 6] = "BYTE4N";
    EnumVertexFormat[EnumVertexFormat["UBYTE4"] = 7] = "UBYTE4";
    EnumVertexFormat[EnumVertexFormat["UBYTE4N"] = 8] = "UBYTE4N";
    EnumVertexFormat[EnumVertexFormat["SHORT2"] = 9] = "SHORT2";
    EnumVertexFormat[EnumVertexFormat["SHORT2N"] = 10] = "SHORT2N";
    EnumVertexFormat[EnumVertexFormat["SHORT4"] = 11] = "SHORT4";
    EnumVertexFormat[EnumVertexFormat["SHORT4N"] = 12] = "SHORT4N";
    EnumVertexFormat[EnumVertexFormat["UINT10_N2"] = 13] = "UINT10_N2";
})(EnumVertexFormat = exports.EnumVertexFormat || (exports.EnumVertexFormat = {}));
// sg_vertex_step
var EnumVertexStep;
(function (EnumVertexStep) {
    EnumVertexStep[EnumVertexStep["PER_VERTEX"] = 1] = "PER_VERTEX";
    EnumVertexStep[EnumVertexStep["PER_INSTANCE"] = 2] = "PER_INSTANCE";
})(EnumVertexStep = exports.EnumVertexStep || (exports.EnumVertexStep = {}));
// sg_uniform_type
var EnumUniformType;
(function (EnumUniformType) {
    EnumUniformType[EnumUniformType["INVALID"] = 0] = "INVALID";
    EnumUniformType[EnumUniformType["FLOAT"] = 1] = "FLOAT";
    EnumUniformType[EnumUniformType["FLOAT2"] = 2] = "FLOAT2";
    EnumUniformType[EnumUniformType["FLOAT3"] = 3] = "FLOAT3";
    EnumUniformType[EnumUniformType["FLOAT4"] = 4] = "FLOAT4";
    EnumUniformType[EnumUniformType["MAT4"] = 5] = "MAT4";
})(EnumUniformType = exports.EnumUniformType || (exports.EnumUniformType = {}));
// sg_cull_mode
var EnumCullMode;
(function (EnumCullMode) {
    EnumCullMode[EnumCullMode["NONE"] = 1] = "NONE";
    EnumCullMode[EnumCullMode["FRONT"] = 2] = "FRONT";
    EnumCullMode[EnumCullMode["BACK"] = 3] = "BACK";
})(EnumCullMode = exports.EnumCullMode || (exports.EnumCullMode = {}));
// sg_face_winding
var EnumFaceWinding;
(function (EnumFaceWinding) {
    EnumFaceWinding[EnumFaceWinding["CCW"] = 1] = "CCW";
    EnumFaceWinding[EnumFaceWinding["CW"] = 2] = "CW";
})(EnumFaceWinding = exports.EnumFaceWinding || (exports.EnumFaceWinding = {}));
// sg_compare_func
var EnumCompareFunc;
(function (EnumCompareFunc) {
    EnumCompareFunc[EnumCompareFunc["NEVER"] = 1] = "NEVER";
    EnumCompareFunc[EnumCompareFunc["LESS"] = 2] = "LESS";
    EnumCompareFunc[EnumCompareFunc["EQUAL"] = 3] = "EQUAL";
    EnumCompareFunc[EnumCompareFunc["LESS_EQUAL"] = 4] = "LESS_EQUAL";
    EnumCompareFunc[EnumCompareFunc["GREATER"] = 5] = "GREATER";
    EnumCompareFunc[EnumCompareFunc["NOT_EQUAL"] = 6] = "NOT_EQUAL";
    EnumCompareFunc[EnumCompareFunc["GREATER_EQUAL"] = 7] = "GREATER_EQUAL";
    EnumCompareFunc[EnumCompareFunc["ALWAYS"] = 8] = "ALWAYS";
})(EnumCompareFunc = exports.EnumCompareFunc || (exports.EnumCompareFunc = {}));
// sg_stencil_op
var EnumStencilOp;
(function (EnumStencilOp) {
    EnumStencilOp[EnumStencilOp["KEEP"] = 1] = "KEEP";
    EnumStencilOp[EnumStencilOp["ZERO"] = 2] = "ZERO";
    EnumStencilOp[EnumStencilOp["REPLACE"] = 3] = "REPLACE";
    EnumStencilOp[EnumStencilOp["INCR_CLAMP"] = 4] = "INCR_CLAMP";
    EnumStencilOp[EnumStencilOp["DECR_CLAMP"] = 5] = "DECR_CLAMP";
    EnumStencilOp[EnumStencilOp["INVERT"] = 6] = "INVERT";
    EnumStencilOp[EnumStencilOp["INCR_WRAP"] = 7] = "INCR_WRAP";
    EnumStencilOp[EnumStencilOp["DECR_WRAP"] = 8] = "DECR_WRAP";
})(EnumStencilOp = exports.EnumStencilOp || (exports.EnumStencilOp = {}));
// sg_blend_factor
var EnumBlendFactor;
(function (EnumBlendFactor) {
    EnumBlendFactor[EnumBlendFactor["ZERO"] = 1] = "ZERO";
    EnumBlendFactor[EnumBlendFactor["ONE"] = 2] = "ONE";
    EnumBlendFactor[EnumBlendFactor["SRC_COLOR"] = 3] = "SRC_COLOR";
    EnumBlendFactor[EnumBlendFactor["ONE_MINUS_SRC_COLOR"] = 4] = "ONE_MINUS_SRC_COLOR";
    EnumBlendFactor[EnumBlendFactor["SRC_ALPHA"] = 5] = "SRC_ALPHA";
    EnumBlendFactor[EnumBlendFactor["ONE_MINUS_SRC_ALPHA"] = 6] = "ONE_MINUS_SRC_ALPHA";
    EnumBlendFactor[EnumBlendFactor["DST_COLOR"] = 7] = "DST_COLOR";
    EnumBlendFactor[EnumBlendFactor["ONE_MINUS_DST_COLOR"] = 8] = "ONE_MINUS_DST_COLOR";
    EnumBlendFactor[EnumBlendFactor["DST_ALPHA"] = 9] = "DST_ALPHA";
    EnumBlendFactor[EnumBlendFactor["ONE_MINUS_DST_ALPHA"] = 10] = "ONE_MINUS_DST_ALPHA";
    EnumBlendFactor[EnumBlendFactor["SRC_ALPHA_SATURATED"] = 11] = "SRC_ALPHA_SATURATED";
    EnumBlendFactor[EnumBlendFactor["BLEND_COLOR"] = 12] = "BLEND_COLOR";
    EnumBlendFactor[EnumBlendFactor["ONE_MINUS_BLEND_COLOR"] = 13] = "ONE_MINUS_BLEND_COLOR";
    EnumBlendFactor[EnumBlendFactor["BLEND_ALPHA"] = 14] = "BLEND_ALPHA";
    EnumBlendFactor[EnumBlendFactor["ONE_MINUS_BLEND_ALPHA"] = 15] = "ONE_MINUS_BLEND_ALPHA";
})(EnumBlendFactor = exports.EnumBlendFactor || (exports.EnumBlendFactor = {}));
// sg_blend_op
var EnumBlendOp;
(function (EnumBlendOp) {
    EnumBlendOp[EnumBlendOp["ADD"] = 1] = "ADD";
    EnumBlendOp[EnumBlendOp["SUBTRACT"] = 2] = "SUBTRACT";
    EnumBlendOp[EnumBlendOp["REVERSE_SUBTRACT"] = 3] = "REVERSE_SUBTRACT";
})(EnumBlendOp = exports.EnumBlendOp || (exports.EnumBlendOp = {}));
// sg_color_mask
var EnumColorMask;
(function (EnumColorMask) {
    EnumColorMask[EnumColorMask["NONE"] = 16] = "NONE";
    EnumColorMask[EnumColorMask["R"] = 1] = "R";
    EnumColorMask[EnumColorMask["G"] = 2] = "G";
    EnumColorMask[EnumColorMask["B"] = 4] = "B";
    EnumColorMask[EnumColorMask["A"] = 8] = "A";
    EnumColorMask[EnumColorMask["RGB"] = 7] = "RGB";
    EnumColorMask[EnumColorMask["RGBA"] = 15] = "RGBA";
})(EnumColorMask = exports.EnumColorMask || (exports.EnumColorMask = {}));
// sg_action
var EnumAction;
(function (EnumAction) {
    EnumAction[EnumAction["CLEAR"] = 1] = "CLEAR";
    EnumAction[EnumAction["LOAD"] = 2] = "LOAD";
    EnumAction[EnumAction["DONTCARE"] = 3] = "DONTCARE";
})(EnumAction = exports.EnumAction || (exports.EnumAction = {}));
var EnumPixelType;
(function (EnumPixelType) {
    EnumPixelType[EnumPixelType["UNSIGNED_BYTE"] = 5121] = "UNSIGNED_BYTE";
    EnumPixelType[EnumPixelType["FLOAT"] = 5126] = "FLOAT";
    EnumPixelType[EnumPixelType["UNSIGNED_SHORT_5_6_5"] = 33635] = "UNSIGNED_SHORT_5_6_5";
    EnumPixelType[EnumPixelType["UNSIGNED_SHORT_4_4_4_4"] = 32819] = "UNSIGNED_SHORT_4_4_4_4";
    EnumPixelType[EnumPixelType["UNSIGNED_SHORT_5_5_5_1"] = 32820] = "UNSIGNED_SHORT_5_5_5_1";
})(EnumPixelType = exports.EnumPixelType || (exports.EnumPixelType = {}));


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
/*
 * @Author: bluecatliao
 * @Date: 2019-03-27 22:32:55
 * @Last Modified by: roamye
 * @Last Modified time: 2020-11-25 14:58:46
 * 这里作为公共库的封装，对上层游戏引擎将客户端提供的接口隐藏，目前来说是直接调用客户端提供的接口
 */
var index_1 = __webpack_require__(4);
var def_1 = __webpack_require__(6);
var index_2 = tslib_1.__importDefault(__webpack_require__(30));
var nativeValue_1 = tslib_1.__importDefault(__webpack_require__(79));
var renderer_1 = tslib_1.__importDefault(__webpack_require__(80));
var nodeRequire_1 = tslib_1.__importStar(__webpack_require__(78));
var WXGameAccelerator = /** @class */ (function () {
    function WXGameAccelerator() {
        this.enumComponentType = def_1.enumComponentType;
        this.enumModelType = def_1.enumModelType;
        this.isNativeValueNative = false;
        this.isEngineNative = false;
        this.isPhysicsNative = false;
        this.isWeakRefNative = false;
        this.isCreateNativeUUMap = false;
        this.isCreateNativeSUMap = false;
        this.isCreateNativeULUMap = false;
        this.hasNewWeakRef = false;
        // 2021/04/25 引擎放开限帧 （兼容老引擎限帧逻辑）
        this.heatProtect = 60;
        this._inited = false;
    }
    ;
    WXGameAccelerator.prototype.heatProtectPromiseFactory = function () {
        return new Promise(function (resolve) {
            // 2021/04/25 引擎放开限帧 （新引擎限帧）
            resolve(60);
            // if (wx.getSystemInfoSync().platform === 'ios') {
            //   wx.checkIsSupportMidasFriendPayment({
            //     success: (res) => {
            //       // 如果允许代付，那么也允许放开限帧
            //       if (res && !res.blocked) {
            //         //@ts-ignore
            //         this.heatProtect = 60
            //       } else {
            //         //@ts-ignore
            //         this.heatProtect = 30
            //       }
            //       //@ts-ignore
            //       resolve(this.heatProtect);
            //     },
            //     fail: (res) => {
            //       //@ts-ignore
            //       this.heatProtect = 30;
            //       //@ts-ignore
            //       resolve(this.heatProtect);
            //     },
            //   })
            // } else {
            //   resolve(60);
            // }
        });
    };
    WXGameAccelerator.prototype.init = function () {
        var _this = this;
        if (this._inited)
            return;
        if (typeof NativeGlobal !== "undefined" && NativeGlobal.GameAccelerator) {
            this.worker = new NativeGlobal.GameAccelerator();
            this.isEngineNative = !!this.worker.getEngine;
            this.isPhysicsNative = !!NativeGlobal.Phys3D;
            this.isRenderNative = !!this.worker.getRenderer;
            // this.isPhysicsNative = !!NativeGlobal.Phys3D;
            this.isNativeValueNative = !!this.worker.createNativeValue;
            this.isWeakRefNative = !!this.worker.createWeakRef;
            this.hasNewWeakRef = !!this.worker.createNewWeakRef;
            this.gaVersion = this.worker.getVersion ? this.worker.getVersion() : { version: '0' };
            this.isCreateNativeUUMap = !!this.worker.createNativeUUMap;
            this.isCreateNativeSUMap = !!this.worker.createNativeSUMap;
            this.isCreateNativeULUMap = !!this.worker.createNativeULUMap;
        }
        else {
            this.worker = index_1.wxMockGA;
            this.isEngineNative = this.isPhysicsNative = this.isRenderNative = false;
            try {
                var ga_1 = nodeRequire_1.default("ga-logic");
                if (ga_1 && typeof ga_1.getEngine === "function" && typeof ga_1.getVersion === "function") {
                    console.log("ga-logic process id:" + nodeRequire_1.pid);
                    this.worker.getEngine = function getEngine() {
                        return ga_1.getEngine();
                    };
                    this.worker.getVersion = function getVersion() {
                        return ga_1.getVersion();
                    };
                    this.isEngineNative = true;
                }
            }
            catch (e) { }
            this.gaVersion = this.worker.getVersion();
        }
        var versionNumberInt = parseInt(this.gaVersion.version);
        var versionNumber = versionNumberInt === NaN || versionNumberInt < 100 ? 0 : versionNumberInt;
        // 写入verionNumber
        this.gaVersion.versionNumber = versionNumber;
        // 全局配置
        this.config = {
            isNativeValueNative: this.isNativeValueNative,
            isEngineNative: this.isEngineNative,
            isPhysicsNative: this.isPhysicsNative,
            isRenderNative: this.isRenderNative,
            isWeakRefNative: this.isWeakRefNative,
            gaVersion: this.gaVersion
        };
        // 延时打log适配公共库
        setTimeout(function () {
            if (typeof NativeGlobal !== "undefined" && NativeGlobal.GameAccelerator) {
                wxConsole.log("native WXGameAccelerator");
            }
            else {
                wxConsole.log("mock WXGameAccelerator");
            }
            if (_this.isRenderNative) {
                wxConsole.log("native WXGame Render Accelerator");
            }
            else {
                wxConsole.log("mock WXGame Render Accelerator");
            }
            if (_this.isEngineNative) {
                wxConsole.log("native WXGame Logic Accelerator");
                wxConsole.log('WXGameAccelerator version ' + _this.config.gaVersion.versionNumber);
            }
            else {
                wxConsole.log("mock WXGame Logic Accelerator");
            }
            if (_this.isNativeValueNative) {
                wxConsole.log("native WXGame Native Value");
            }
            else {
                wxConsole.log("mock WXGame Native Value");
            }
        }, 100);
        this._inited = true;
    };
    // 创建弱引用，见tc-39标准
    WXGameAccelerator.prototype.createWeakRef = function (wrapper) {
        var ga = this.isWeakRefNative ? this.worker : index_1.wxMockGA;
        var weakRef = ga.createWeakRef(wrapper);
        return weakRef;
    };
    // IOS下我们实现的WeakRef有bug，因此改用AutoRef
    WXGameAccelerator.prototype.createAutoRef = function (wrapper) {
        var ga = this.isWeakRefNative ? this.worker : index_1.wxMockGA;
        var weakRef = ga.createAutoRef(wrapper);
        return weakRef;
    };
    // AutoRef方案有缺陷
    WXGameAccelerator.prototype.createNewWeakRef = function (wrapper) {
        if (!wrapper._wr_entry_) {
            throw new Error('createNewWeakRef Error: is not a WeakRefSentry');
        }
        var ga = this.isWeakRefNative ? this.worker : index_1.wxMockGA;
        var weakRef = ga.createNewWeakRef(wrapper);
        return weakRef;
    };
    // IOS下我们实现的WeakRef有bug，因此改用AutoRef
    WXGameAccelerator.prototype.createNewWeakRefSentry = function () {
        var ga = this.isWeakRefNative ? this.worker : index_1.wxMockGA;
        var weakRefSentry = ga.createNewWeakRefSentry();
        weakRefSentry._wr_entry_ = true;
        return weakRefSentry;
    };
    /**
     * 对NativeGlobal接口的包装
     */
    WXGameAccelerator.prototype.NativeGlobalStartProfile = function () {
        return NativeGlobal.startProfile();
    };
    /**
     * 对NativeGlobal接口的包装
     */
    WXGameAccelerator.prototype.NativeGlobalStopProfile = function () {
        return NativeGlobal.stopProfile();
    };
    /**
     * 对NativeGlobal接口的包装
     */
    WXGameAccelerator.prototype.getNativeGlobalProfileResult = function () {
        return NativeGlobal.getProfileResult();
    };
    /**
     * 对NativeGlobal接口的包装
     */
    WXGameAccelerator.prototype.LogicAcceleratorStartProfile = function () {
        return this.worker.startProfile();
    };
    /**
     * 对NativeGlobal接口的包装
     */
    WXGameAccelerator.prototype.LogicAcceleratorStopProfile = function () {
        return this.worker.stopProfile();
    };
    /**
     * 对NativeGlobal接口的包装
     */
    WXGameAccelerator.prototype.getLogicAcceleratorProfileResult = function () {
        return this.worker.getProfileResult();
    };
    WXGameAccelerator.prototype.createNativeValue = function (byteSize) {
        var ga = this.isNativeValueNative ? this.worker : index_1.wxMockGA;
        var native = ga.createNativeValue(byteSize);
        return new nativeValue_1.default(native);
    };
    WXGameAccelerator.prototype.getRenderer = function (context) {
        var ga = this.isRenderNative ? this.worker : index_1.wxMockGA;
        var gfxContext = this.isRenderNative ? context.gfx : context;
        var native = ga.getRenderer(gfxContext);
        return new renderer_1.default(native, this.config);
    };
    WXGameAccelerator.prototype.getEngine = function () {
        var ga = this.isEngineNative ? this.worker : index_1.wxMockGA;
        var native = ga.getEngine();
        return new index_2.default(native, this.config);
    };
    // public getPhysics() {
    //   if (this.isPhysicsNative) {
    //     return new PhysicsManager(NativeGlobal.Phys3D, this.isPhysicsNative);
    //   }
    //   // return __global.require("physicsEngine");
    //   if (PHYSX) {
    //     return new PhysicsManager(PHYSX.getPhysicsEngine().Phys3D, this.isPhysicsNative);
    //   } else {
    //     console.error("no physics engine found.");
    //     return null;
    //   }
    // }
    /**
     * 返回逻辑加速层版本
     */
    WXGameAccelerator.prototype.getGAVersion = function () {
        return this.gaVersion;
    };
    /**
     * uint to uint map
     */
    WXGameAccelerator.prototype.createNativeUUMap = function () {
        var ga = this.isCreateNativeUUMap ? this.worker : index_1.wxMockGA;
        return ga.createNativeUUMap();
    };
    /**
     * string to uint map
     */
    WXGameAccelerator.prototype.createNativeSUMap = function () {
        var ga = this.isCreateNativeSUMap ? this.worker : index_1.wxMockGA;
        return ga.createNativeSUMap();
    };
    /**
     * uint to long uint map
     */
    WXGameAccelerator.prototype.createNativeULUMap = function () {
        var ga = this.isCreateNativeULUMap ? this.worker : index_1.wxMockGA;
        return ga.createNativeULUMap();
    };
    return WXGameAccelerator;
}());
// 2021/04/26 wxGA改为仅当判断引擎游戏时wxGA初始化，减少普通小游戏内存占用
// 2021/09/22 wxGA改为一个函数，由基础库调用，按需创建
var _wxGA;
Object.defineProperty(globalThis, 'wxGA', {
    get: function () {
        if (!_wxGA) {
            var wxGA = new WXGameAccelerator();
            if (__wxConfig.engine === true) {
                wxGA.init();
            }
            _wxGA = wxGA;
        }
        return _wxGA;
    }
});
wxNativeConsole.warn('inject wxga success.');


/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.wxMockGA = void 0;
var tslib_1 = __webpack_require__(1);
/*
 * @Author: bluecatliao
 * @Date: 2018-10-29 21:21:01
 * @Last Modified by: roamye
 * @Last Modified time: 2019-12-16 21:44:51
 * 模拟客户端提供的jsBinding层，浏览器环境下的兼容方案
 */
var mockLogicAcceleratorWorker_1 = tslib_1.__importDefault(__webpack_require__(5));
var nativeValue_1 = __webpack_require__(13);
var renderer_1 = tslib_1.__importDefault(__webpack_require__(14));
var LongIntToIntMap = /** @class */ (function () {
    function LongIntToIntMap() {
        // 我没有办法
        this.key1toKey2 = new Map();
        this.key2toValue = new Map();
    }
    LongIntToIntMap.prototype.set = function (key1, key2, value) {
        this.key1toKey2.set(key1, key2);
        this.key2toValue.set(key2, value);
    };
    LongIntToIntMap.prototype.get = function (key1, key2) {
        if (this.key1toKey2.get(key1) === key2) {
            return this.key2toValue.get(key2);
        }
    };
    LongIntToIntMap.prototype.del = function (key1, key2) {
        this.key1toKey2.delete(key1);
        this.key2toValue.delete(key2);
    };
    return LongIntToIntMap;
}());
var NativeMap = /** @class */ (function () {
    function NativeMap() {
        this.map = new Map();
    }
    NativeMap.prototype.set = function (key, value) {
        this.map.set(key, value);
    };
    NativeMap.prototype.get = function (key) {
        return this.map.get(key);
    };
    NativeMap.prototype.del = function (key) {
        this.map.delete(key);
    };
    return NativeMap;
}());
var MockGameAccelerator = /** @class */ (function () {
    function MockGameAccelerator() {
    }
    MockGameAccelerator.prototype.createNativeValue = function (byteSize) {
        return new nativeValue_1.NativeValueNative(this._gfx, byteSize);
    };
    MockGameAccelerator.prototype.getRenderer = function (context) {
        this._gfx = context;
        return new renderer_1.default(context);
    };
    MockGameAccelerator.prototype.getEngine = function () {
        return new mockLogicAcceleratorWorker_1.default();
    };
    MockGameAccelerator.prototype.getVersion = function () {
        return {
            version: 'mock'
        };
    };
    MockGameAccelerator.prototype.createWeakRef = function (wrapper) {
        if (typeof WeakRef === "function") {
            return new WeakRef(wrapper);
        }
        else {
            return {
                deref: function () { return wrapper; }
            };
        }
    };
    MockGameAccelerator.prototype.createAutoRef = function (wrapper) {
        if (typeof WeakRef === "function") {
            var weakRef = new WeakRef(wrapper);
        }
        return {
            makeRef: function () {
                if (typeof WeakRef === "function") {
                    return weakRef.deref();
                }
                else {
                    return wrapper;
                }
            }
        };
    };
    MockGameAccelerator.prototype.createNewWeakRef = function (wrapper) {
        if (typeof WeakRef === "function") {
            return new WeakRef(wrapper);
        }
        else {
            return {
                deref: function () { return wrapper; }
            };
        }
    };
    MockGameAccelerator.prototype.createNewWeakRefSentry = function () {
        return {
            __mockGA__: true
        };
    };
    MockGameAccelerator.prototype.createNativeUUMap = function () {
        return new NativeMap();
    };
    MockGameAccelerator.prototype.createNativeSUMap = function () {
        return new NativeMap();
    };
    MockGameAccelerator.prototype.createNativeULUMap = function () {
        return new LongIntToIntMap();
    };
    MockGameAccelerator.prototype.startProfile = function () { };
    MockGameAccelerator.prototype.stopProfile = function () { };
    MockGameAccelerator.prototype.getProfileResult = function () {
        return {};
    };
    return MockGameAccelerator;
}());
var wxMockGA = new MockGameAccelerator();
exports.wxMockGA = wxMockGA;
exports.default = MockGameAccelerator;


/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var def_1 = __webpack_require__(6);
var component_1 = tslib_1.__importDefault(__webpack_require__(7));
var dataBuffer_1 = tslib_1.__importDefault(__webpack_require__(9));
var dataModel_1 = tslib_1.__importDefault(__webpack_require__(10));
var entity_1 = tslib_1.__importDefault(__webpack_require__(11));
var pool_1 = tslib_1.__importDefault(__webpack_require__(12));
var util_1 = __webpack_require__(8);
var DEAFAULT_BUFFER_SIZE = 1024;
var MockAcceleratorWorker = /** @class */ (function () {
    function MockAcceleratorWorker() {
        this.dirtyEntities = new ArrayBuffer(DEAFAULT_BUFFER_SIZE);
        this.entityCommands = new ArrayBuffer(DEAFAULT_BUFFER_SIZE);
        this.cullingResult = new ArrayBuffer(DEAFAULT_BUFFER_SIZE);
    }
    MockAcceleratorWorker.prototype.createEntity = function (type, length) {
        if (length && length > 0) {
            var poolSize = 0;
            if (type === def_1.enumEntityType.Entity3D) {
                poolSize = def_1.ENTITY3D_SIZE * 4;
            }
            else {
                poolSize = def_1.ENTITY2D_SIZE * 4;
            }
            return new pool_1.default(poolSize, length);
        }
        else {
            return new entity_1.default(type);
        }
    };
    MockAcceleratorWorker.prototype.createComponent = function (type, parm1, parm2) {
        if (type === def_1.enumComponentType.Cullable && parm1 && parm1 > 0) {
            var poolSize = def_1.CULLABLECOMPONENT_SIZE * 4;
            return new pool_1.default(poolSize, parm1);
        }
        else {
            return new component_1.default(type, parm1, parm2);
        }
    };
    MockAcceleratorWorker.prototype.createDataModel = function (type, content) {
        return new dataModel_1.default(type, content);
    };
    MockAcceleratorWorker.prototype.createDataBuffer = function (bufferSize) {
        return new dataBuffer_1.default(bufferSize);
    };
    MockAcceleratorWorker.prototype.createAnimatorControllerStateModel = function (clipCount) {
        return {
            id: util_1.requestAccelerateObjectID(),
            buffer: new ArrayBuffer(clipCount * 5 * 4 + 3 * 4),
        };
    };
    MockAcceleratorWorker.prototype.refreshWorldTransform = function () { };
    MockAcceleratorWorker.prototype.frustumCulling = function (cullMask, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ, fovy, aspect, zNear, zFar) {
        return { hash: 0, objects: new ArrayBuffer(0), distances: new ArrayBuffer(0) };
    };
    MockAcceleratorWorker.prototype.orthoCulling = function (cullMask, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ, xwMin, xwMax, ywMin, ywMax, zNear, zFar) {
        return { hash: 0, objects: new ArrayBuffer(0), distances: new ArrayBuffer(0) };
    };
    MockAcceleratorWorker.prototype.addDirtyEntity = function () { };
    MockAcceleratorWorker.prototype.frameStart = function () { };
    ;
    return MockAcceleratorWorker;
}());
exports.default = MockAcceleratorWorker;


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.CULLABLECOMPONENT_SIZE = exports.CULLABLECOMPONENT_OFFSET = exports.ENTITY3D_SIZE = exports.ENTITY3D_OFFSET = exports.ENTITY2D_SIZE = exports.ENTITY2D_OFFSET = exports.POOLINDEX_AND = exports.POOLID_AND = exports.componentType2SharedBufferSize = exports.enumEntityType = exports.enumEntityCommandType = exports.enumModelType = exports.enumComponentType = void 0;
/*
 * @Author: bluecatliao
 * @Date: 2019-01-09 16:48:09
 * @Last Modified by: roamye
 * @Last Modified time: 2020-05-07 14:27:32
 * 这个文件会被accelerator模块和其worker都依赖，主要存放一些公共定义
 */
var enumComponentType;
(function (enumComponentType) {
    enumComponentType[enumComponentType["Undefined"] = 0] = "Undefined";
    /*
    PhysicalRigidBody = 10,
  
    PhysicalCollider, // Internal
    PhysicalBoxCollider,
    PhysicalCircleCollider,
    PhysicalChainCollider,
    PhysicalPolygonCollider,
  
    PhysicalJoint = 20, // Internal
    PhysicalDistanceJoint,
    PhysicalMotorJoint,
    PhysicalMouseJoint,
    PhysicalPrismaticJoint,
    PhysicalRevoluteJoint,
    PhysicalRopeJoint,
    PhysicalWheelJoint,
    PhysicalWeldJoint,
    PhysicalGearJoint,
  
  */
    enumComponentType[enumComponentType["Cullable"] = 1] = "Cullable";
    enumComponentType[enumComponentType["Animator"] = 2] = "Animator";
    enumComponentType[enumComponentType["SkinnedSkeleton"] = 3] = "SkinnedSkeleton";
})(enumComponentType = exports.enumComponentType || (exports.enumComponentType = {}));
var enumModelType;
(function (enumModelType) {
    enumModelType[enumModelType["Undefined"] = 0] = "Undefined";
    enumModelType[enumModelType["AnimationClipModel"] = 1] = "AnimationClipModel";
    enumModelType[enumModelType["SkeletonBoneInverseModel"] = 2] = "SkeletonBoneInverseModel";
})(enumModelType = exports.enumModelType || (exports.enumModelType = {}));
var enumEntityCommandType;
(function (enumEntityCommandType) {
    enumEntityCommandType[enumEntityCommandType["SetRootEntity"] = 1] = "SetRootEntity";
    enumEntityCommandType[enumEntityCommandType["AddChild"] = 2] = "AddChild";
    enumEntityCommandType[enumEntityCommandType["AddChildAtIndex"] = 3] = "AddChildAtIndex";
    enumEntityCommandType[enumEntityCommandType["RemoveFromParent"] = 4] = "RemoveFromParent";
    enumEntityCommandType[enumEntityCommandType["DisperseSubTree"] = 5] = "DisperseSubTree";
    enumEntityCommandType[enumEntityCommandType["BindToBone"] = 6] = "BindToBone";
    enumEntityCommandType[enumEntityCommandType["BindToBones"] = 7] = "BindToBones";
    enumEntityCommandType[enumEntityCommandType["UnBindFromBone"] = 8] = "UnBindFromBone";
    enumEntityCommandType[enumEntityCommandType["UnBindFromBones"] = 9] = "UnBindFromBones";
    enumEntityCommandType[enumEntityCommandType["EntityCommandActive"] = 10] = "EntityCommandActive";
    enumEntityCommandType[enumEntityCommandType["EntityCommandInActive"] = 11] = "EntityCommandInActive";
})(enumEntityCommandType = exports.enumEntityCommandType || (exports.enumEntityCommandType = {}));
/**
 * Entity数据类型
 */
var enumEntityType;
(function (enumEntityType) {
    enumEntityType[enumEntityType["Entity2D"] = 0] = "Entity2D";
    enumEntityType[enumEntityType["Entity3D"] = 1] = "Entity3D";
})(enumEntityType = exports.enumEntityType || (exports.enumEntityType = {}));
// componentType2SizeNative
exports.componentType2SharedBufferSize = {};
exports.componentType2SharedBufferSize[enumComponentType.Cullable] = 6 * 4;
exports.componentType2SharedBufferSize[enumComponentType.Animator] = 4;
exports.componentType2SharedBufferSize[enumComponentType.SkinnedSkeleton] = 18 * 4;
// 节点共享内存数据
// 池子偏移量
exports.POOLID_AND = 0xFFFFF000;
exports.POOLINDEX_AND = 0xFFF;
// 2D节点
exports.ENTITY2D_OFFSET = {};
exports.ENTITY2D_OFFSET.OFFSET_ROTATION = 0;
exports.ENTITY2D_OFFSET.OFFSET_POSITION = 1;
exports.ENTITY2D_OFFSET.OFFSET_SCALE = 3;
exports.ENTITY2D_OFFSET.OFFSET_WORLDMATRIX = 5; /* 5-13 */
exports.ENTITY2D_SIZE = 14;
// 3D节点
exports.ENTITY3D_OFFSET = {};
exports.ENTITY3D_OFFSET.DF_ROTATIONTYPE = 1; // 第一位类型位运算布尔值位置
// 偏移量
exports.ENTITY3D_OFFSET.OFFSET_ROTATIONTYPE = 0;
exports.ENTITY3D_OFFSET.OFFSET_ROTATION = 1;
exports.ENTITY3D_OFFSET.OFFSET_POSITION = 5;
exports.ENTITY3D_OFFSET.OFFSET_SCALE = 8;
exports.ENTITY3D_OFFSET.OFFSET_WORLDMATRIX = 11; /* 11-26 */
exports.ENTITY3D_SIZE = 27;
// 剔除组件
exports.CULLABLECOMPONENT_OFFSET = {};
exports.CULLABLECOMPONENT_OFFSET.DF_ACTIVE = 1; // 第一位类型位运算布尔值位置
// 偏移量
exports.CULLABLECOMPONENT_OFFSET.OFFSET_ACTIVE = 0;
exports.CULLABLECOMPONENT_OFFSET.OFFSET_CULLMASK = 1;
exports.CULLABLECOMPONENT_OFFSET.OFFSET_BOUDINGBALL_CENTER = 2;
exports.CULLABLECOMPONENT_OFFSET.OFFSET_BOUDINGBALL_RADIUS = 5;
exports.CULLABLECOMPONENT_OFFSET.OFFSET_ENTITYID = 6;
exports.CULLABLECOMPONENT_SIZE = 7;


/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/*
 * @Author: bluecatliao
 * @Date: 2018-11-20 19:42:17
 * @Last Modified by: bluecatliao
 * @Last Modified time: 2019-03-30 21:53:18
 * 这个为暴露给JSAccelerator侧的Component对象，实际上只是个壳，为了让JS侧能使用new的形式。
 * 此对象的ID与Worker中实际对象的ID一致
 */
var def_1 = __webpack_require__(6);
var util_1 = __webpack_require__(8);
var ComponentNative = /** @class */ (function () {
    function ComponentNative(typeID, parm1, parm2) {
        this.size = 0;
        this.id = util_1.requestAccelerateObjectID();
        switch (typeID) {
            case def_1.enumComponentType.Cullable:
                this.size = def_1.componentType2SharedBufferSize[typeID];
                break;
            case def_1.enumComponentType.Animator:
                this.size = def_1.componentType2SharedBufferSize[typeID] * parm1 * parm2;
                break;
            case def_1.enumComponentType.SkinnedSkeleton:
                this.size = def_1.componentType2SharedBufferSize[typeID] * parm1;
                break;
        }
        this.buffer = new ArrayBuffer(this.size);
    }
    return ComponentNative;
}());
exports.default = ComponentNative;


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.applyMixins = exports.requestAcceleratePoolID = exports.requestAccelerateObjectID = void 0;
var IDCounter = 0;
function requestAccelerateObjectID() {
    return IDCounter++;
}
exports.requestAccelerateObjectID = requestAccelerateObjectID;
var PoolIDCounter = 0x00001000;
function requestAcceleratePoolID() {
    var beforeID = PoolIDCounter;
    PoolIDCounter += 0x00001000;
    return beforeID;
}
exports.requestAcceleratePoolID = requestAcceleratePoolID;
function applyMixins(derivedCtor, baseCtors) {
    baseCtors.forEach(function (baseCtor) {
        Object.getOwnPropertyNames(baseCtor.prototype).forEach(function (name) {
            Object.defineProperty(derivedCtor.prototype, name, Object.getOwnPropertyDescriptor(baseCtor.prototype, name));
        });
    });
}
exports.applyMixins = applyMixins;


/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var DataBufferNativeFake = /** @class */ (function () {
    function DataBufferNativeFake(bufferSize) {
    }
    return DataBufferNativeFake;
}());
exports.default = DataBufferNativeFake;


/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var DataModelNative = /** @class */ (function () {
    function DataModelNative(type, content) {
    }
    return DataModelNative;
}());
exports.default = DataModelNative;


/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/*
 * @Author: bluecatliao
 * @Date: 2018-11-20 19:42:17
 * @Last Modified by: bluecatliao
 * @Last Modified time: 2018-11-20 22:51:58
 * 这个为暴露给JSAccelerator侧的Component对象，实际上只是个壳，为了让JS侧能使用new的形式。
 *
 */
var def_1 = __webpack_require__(6);
var util_1 = __webpack_require__(8);
var ENTITY3D_BUFFER_LENGTH = 27 * 4;
var ENTITY2D_BUFFER_LENGTH = 14 * 4;
var EntityNative = /** @class */ (function () {
    function EntityNative(type) {
        this.id = util_1.requestAccelerateObjectID();
        // tslint:disable-next-line: prefer-conditional-expression
        if (type === def_1.enumEntityType.Entity3D) {
            this.size = ENTITY3D_BUFFER_LENGTH;
        }
        else {
            this.size = ENTITY2D_BUFFER_LENGTH;
        }
        this.buffer = new ArrayBuffer(this.size);
    }
    return EntityNative;
}());
exports.default = EntityNative;


/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var util_1 = __webpack_require__(8);
var PoolNative = /** @class */ (function () {
    function PoolNative(size, length) {
        this.id = util_1.requestAcceleratePoolID();
        this.size = size * length;
        this.buffer = new ArrayBuffer(this.size);
    }
    return PoolNative;
}());
exports.default = PoolNative;


/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.NativeValueNative = void 0;
var jitMode = false;
if (typeof __wxConfig !== "undefined" && __wxConfig.jitMode) {
    jitMode = true;
}
var NativeValueNative = /** @class */ (function () {
    function NativeValueNative(context, byteSize) {
        if (!jitMode) {
            this.nativeBuffer = context.createNativeBuffer(byteSize);
            this.data = this.nativeBuffer.data;
        }
        else {
            /*for wk*/
            this.nativeBuffer = new Float32Array(byteSize / 4);
            this.data = this.nativeBuffer.buffer;
        }
        this._f32View = new Float32Array(this.data);
    }
    return NativeValueNative;
}());
exports.NativeValueNative = NativeValueNative;


/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var commandBuffer_1 = tslib_1.__importDefault(__webpack_require__(15));
var gfxCommandExecutor_1 = tslib_1.__importDefault(__webpack_require__(16));
var rect_1 = __webpack_require__(25);
var renderCommandDecoder_1 = tslib_1.__importDefault(__webpack_require__(26));
var renderDraw_1 = __webpack_require__(17);
var renderView_1 = __webpack_require__(27);
var vertexLayout_1 = __webpack_require__(23);
var batchableVertexBuffer_1 = __webpack_require__(28);
var batchableIndexBuffer_1 = __webpack_require__(29);
var RendererNative = /** @class */ (function () {
    function RendererNative(gfx) {
        this._decoder = new renderCommandDecoder_1.default();
        var gfxCommandExecutor = new gfxCommandExecutor_1.default(gfx);
        this._executor = gfxCommandExecutor;
        this._decoder._setCommandExecutor(gfxCommandExecutor);
        this._gfx = gfx;
    }
    RendererNative.prototype.createCommandBuffer = function (bytesLen) {
        return new commandBuffer_1.default(this);
    };
    RendererNative.prototype.createRect = function (x, y, width, height) {
        return new rect_1.RectNative(x, y, width, height);
    };
    RendererNative.prototype.createRenderDraw = function () {
        return new renderDraw_1.RenderDrawNative();
    };
    RendererNative.prototype.createVertexLayout = function (configstr) {
        var config = JSON.parse(configstr);
        return new vertexLayout_1.VertexLayoutNative(config, this._gfx);
    };
    RendererNative.prototype.createView = function (pass, passAction, viewport, scissor) {
        return new renderView_1.RenderViewNative(pass, passAction, viewport, scissor);
    };
    RendererNative.prototype._executeCommandBuffer = function (commandBuffer) {
        this._decoder.decodeAndExecCommandBuffer(commandBuffer);
        this._executor.endFrame();
    };
    RendererNative.prototype.executeCommandBuffer = function (id) {
    };
    RendererNative.prototype.createBatchableVertexBuffer = function (count, vertexLayout) {
        return new batchableVertexBuffer_1.BatchableVertexBufferNative(count, vertexLayout);
    };
    RendererNative.prototype.createBatchableIndexBuffer = function (count) {
        return new batchableIndexBuffer_1.BatchableIndexBufferNative(count);
    };
    return RendererNative;
}());
exports.default = RendererNative;


/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var CommandBufferNative = /** @class */ (function () {
    function CommandBufferNative(renderer, bytesLen) {
        this._array = [];
        this._renderer = renderer;
    }
    CommandBufferNative.prototype.extend = function (commandSize) {
        return new CommandBufferNative(this._renderer);
    };
    CommandBufferNative.prototype.putRenderDraw = function (renderDraw) {
        this._array.push(renderDraw);
    };
    CommandBufferNative.prototype.batchPutRenderDraw = function (renderDraws) {
        this._array = this._array.concat(renderDraws);
    };
    CommandBufferNative.prototype.putSubCommandBuffer = function (commandBuffer) {
        this._array.push(commandBuffer);
    };
    CommandBufferNative.prototype.reset = function () {
        this._array.length = 0;
    };
    CommandBufferNative.prototype.execute = function () {
        this._renderer._executeCommandBuffer(this);
    };
    return CommandBufferNative;
}());
exports.default = CommandBufferNative;


/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var renderDraw_1 = __webpack_require__(17);
var vertexLayout_1 = __webpack_require__(23);
var GFXCommandExcutor = /** @class */ (function () {
    function GFXCommandExcutor(gfx /*GFXRenderingContext*/) {
        this.renderDraw2Bindings = new WeakMap();
        this.pipelineMap = {};
        this._renderDrawList = [];
        this._batchedRenderDrawList = [];
        this.gfx = gfx;
    }
    // 这里只是把renderDraw推到队列里，一帧结束时统一执行
    GFXCommandExcutor.prototype.drawRenderDraw = function (renderDraw) {
        this._renderDrawList.push(renderDraw);
    };
    GFXCommandExcutor.prototype.endFrame = function () {
        // 1.处理renderDraw合批
        for (var _i = 0, createdVertexLayout_1 = vertexLayout_1.createdVertexLayout; _i < createdVertexLayout_1.length; _i++) {
            var layout = createdVertexLayout_1[_i];
            layout._getBatcher().reset();
        }
        // 执行合批
        for (var _a = 0, _b = this._renderDrawList; _a < _b.length; _a++) {
            var renderDraw = _b[_a];
            this.doRenderDrawBatch(renderDraw);
        }
        this._flushRenderDrawBatch();
        // 提交合批后的gfxBuffer
        for (var _c = 0, createdVertexLayout_2 = vertexLayout_1.createdVertexLayout; _c < createdVertexLayout_2.length; _c++) {
            var layout = createdVertexLayout_2[_c];
            layout._getBatcher().uploadBuffer();
        }
        // 2.执行真正的renderDraw
        for (var _d = 0, _e = this._batchedRenderDrawList; _d < _e.length; _d++) {
            var renderDraw = _e[_d];
            this.doDrawRenderDraw(renderDraw);
        }
        // 3. 提交gfx
        if (this.lastView) {
            this.gfx.endPass();
            this.lastView = null;
        }
        this.gfx.commit();
        // clear
        this._renderDrawList.length = 0;
        this._batchedRenderDrawList.length = 0;
    };
    //private _startVBOffset:number;
    GFXCommandExcutor.prototype.doRenderDrawBatch = function (renderDraw) {
        // 1.非batchable的renderDraw将中断合批
        if (!renderDraw.batchable) {
            this._flushRenderDrawBatch();
            this._batchedRenderDrawList.push(renderDraw);
            return;
        }
        // 当前render和startRenderDraw不一致时，中断合批
        if (this._startBatchedRenderDraw && !this._compareMaterial(this._startBatchedRenderDraw, renderDraw)) {
            this._flushRenderDrawBatch();
        }
        // 2.更新renderDraw的BatchBuffer
        var vb = renderDraw.vertexBuffers[0];
        var ib = renderDraw.indexBuffer;
        // worldMatrix或vertexBuffer有修改时，需要将renderDataDirty置为true
        if (renderDraw.renderDataDirty) {
            vb._cloneBuffer();
            var _positionViews = vb._positionViews;
            var _worldPositionViews = vb._worldPositionViews;
            var wt = renderDraw._worldTransformMatrix;
            for (var i = 0; i < _positionViews.length; i++) {
                var oriPos = _positionViews[i];
                var worldPos = _worldPositionViews[i];
                wt.transformPoint(oriPos, worldPos);
            }
        }
        // 3.将当前renderDraw加入batch
        var batcher = renderDraw.vertexLayout._getBatcher();
        var ibCount = batcher._ibCount;
        //const vbOffset = batcher._vbOffset;
        if (!this._startBatchedRenderDraw) {
            // 当前是第一个batchRenderDraw，只记录start i和v
            this._startBatchedRenderDraw = renderDraw;
            this._vertexBatcher = batcher;
            this._startIBCount = ibCount;
            //this._startVBOffset = vbOffset;
        }
        batcher.batchMesh(vb, ib, renderDraw.baseElement, renderDraw.numElements);
    };
    GFXCommandExcutor.prototype._flushRenderDrawBatch = function () {
        if (!this._startBatchedRenderDraw) {
            return;
        }
        var newRenderDraw = new renderDraw_1.RenderDrawNative();
        Object.assign(newRenderDraw, this._startBatchedRenderDraw);
        newRenderDraw.indexBuffer = this._vertexBatcher._indexBuffer;
        newRenderDraw.vertexBuffers = [this._vertexBatcher._vertexBuffer];
        newRenderDraw.batchable = false;
        newRenderDraw.baseElement = this._startIBCount;
        newRenderDraw.numElements = this._vertexBatcher._ibCount - this._startIBCount;
        this._batchedRenderDrawList.push(newRenderDraw);
        this._startBatchedRenderDraw = null;
        this._vertexBatcher = null;
    };
    GFXCommandExcutor.prototype._compareMaterial = function (a, b) {
        var equal = (a.raster === b.raster) && (a.rgba === b.rgba) && (a.shader === b.shader) && (a.vertexLayout === b.vertexLayout) &&
            (a.view === b.view) && (a.stencilDepth === b.stencilDepth) && (a.stencilOpTest === b.stencilOpTest) && (a.blend === b.blend);
        var imageLength = a.images.length;
        var nativeValueLength = a.nativeValues.length;
        equal = equal && (imageLength == b.images.length) && (nativeValueLength == b.nativeValues.length);
        if (!equal) {
            return equal;
        }
        for (var i = 0; i < imageLength; i++) {
            equal = equal && (a.images[i] === b.images[i]);
        }
        for (var i = 0; i < nativeValueLength; i++) {
            equal = equal && (a.nativeValues[i] === b.nativeValues[i]);
        }
        return equal;
    };
    GFXCommandExcutor.prototype.doDrawRenderDraw = function (renderDraw) {
        var renderView = renderDraw.view;
        if (this.lastView !== renderView) {
            // switch gfx pass
            if (this.lastView) {
                this.gfx.endPass();
            }
            if (renderView._isDefaultView) {
                // @ts-ignore
                if (typeof __IDE === "undefined") {
                    // 只判断__IDE比较快
                    this.gfx.beginDefaultPass(renderView._passAction, renderView._viewport._width, renderView._viewport._height);
                    // @ts-ignore
                }
                else if (typeof __gameContextWindow !== "undefined" && typeof __gameContextWindow.__IDE !== "undefined" && typeof __gameContextWindow.__IDE.realCanvas !== "undefined") {
                    // @ts-ignore
                    this.gfx.beginDefaultPass(renderView._passAction, __gameContextWindow.__IDE.realCanvas.width, __gameContextWindow.__IDE.realCanvas.height);
                }
                else {
                    // 如果最后判断有问题，还是兜底走这个逻辑
                    this.gfx.beginDefaultPass(renderView._passAction, renderView._viewport._width, renderView._viewport._height);
                }
            }
            else {
                this.gfx.beginPass(renderView._pass, renderView._passAction);
            }
            this.gfx.applyViewport(renderView._viewport._x, renderView._viewport._y, renderView._viewport._width, renderView._viewport._height, false);
            this.gfx.applyScissorRect(renderView._scissor._x, renderView._scissor._y, renderView._scissor._width, renderView._scissor._height, false);
            this.lastView = renderDraw.view;
        }
        // gfx绘制主流程
        this.gfx.applyPipeline(this.getPipeline(renderDraw));
        this.gfx.applyBindings(this.getBindings(renderDraw));
        for (var i = 0; i < renderDraw.nativeValues.length; i++) {
            var value = renderDraw.nativeValues[i].nativeBuffer;
            // gl环境下只需设置VSUniform
            this.gfx.applyUniforms(wgfx.EnumShaderStage.VS, i, value);
        }
        this.gfx.draw(renderDraw.baseElement, renderDraw.numElements, 1 /*instance_num*/);
    };
    GFXCommandExcutor.prototype.getBindings = function (renderDraw) {
        // if (!this.renderDraw2Bindings.has(renderDraw)) {
        var binding = this.gfx.makeBindings({
            vertex_buffers: renderDraw.vertexBuffers,
            index_buffer: renderDraw.indexBuffer,
            vs_images: renderDraw.images,
        });
        return binding;
        //   this.renderDraw2Bindings.set(renderDraw, binding);
        // } else {
        //   // 这里要做hash，有可能更改
        // }
        // return this.renderDraw2Bindings.get(renderDraw);
    };
    GFXCommandExcutor.prototype.getPipeline = function (renderDraw) {
        var hash = renderDraw._hashForPipeline;
        if (!this.pipelineMap[hash]) {
            var pipeline = this.gfx.makePipeline({
                layout: renderDraw.vertexLayout._config.layout,
                shader: renderDraw.shader,
                index_type: renderDraw._getIndexType(),
                primitive_type: renderDraw._getPrimitiveType(),
                depth_stencil: {
                    stencil_front: {
                        fail_op: renderDraw._getStencilFrontFailOp(),
                        depth_fail_op: renderDraw._getStencilFrontDepthFailOp(),
                        pass_op: renderDraw._getStencilFrontPassOp(),
                        compare_func: renderDraw._getStencilFrontCompareFunc(),
                    },
                    stencil_back: {
                        fail_op: renderDraw._getStencilBackFailOp(),
                        depth_fail_op: renderDraw._getStencilBackDepthFailOp(),
                        pass_op: renderDraw._getStencilBackPassOp(),
                        compare_func: renderDraw._getStencilBackCompareFunc(),
                    },
                    depth_compare_func: renderDraw._getDepthCompareFunc(),
                    depth_write_enabled: renderDraw._getDepthWriteEnable(),
                    stencil_enabled: renderDraw._getStencilEnable(),
                    stencil_read_mask: renderDraw._getStencilRead(),
                    stencil_write_mask: renderDraw._getStencilWrite(),
                    stencil_ref: renderDraw._getStencilRef(),
                },
                blend: {
                    enabled: renderDraw._getBlendEnable(),
                    src_factor_rgb: renderDraw._getBlendSrcFactorRGB(),
                    dst_factor_rgb: renderDraw._getBlendDstFactorRGB(),
                    op_rgb: renderDraw._getBlendOpRGB(),
                    src_factor_alpha: renderDraw._getBlendSrcFactorAlpha(),
                    dst_factor_alpha: renderDraw._getBlendDstFactorAlpha(),
                    op_alpha: renderDraw._getBlendOpAlpha(),
                    color_write_mask: renderDraw._getBlendColorMask(),
                    // color_attachment_count: renderDraw._getColorAttachCount(),
                    color_format: renderDraw._getColorFormat(),
                    depth_format: renderDraw._getDepthFormat(),
                },
                rasterizer: {
                    // alpha_to_coverage_enabled: renderDraw._getAlphaToCoverageEnable(),
                    cull_mode: renderDraw._getCullMode(),
                    face_winding: renderDraw._getFaceWinding(),
                },
            });
            this.pipelineMap[hash] = pipeline;
        }
        return this.pipelineMap[hash];
    };
    return GFXCommandExcutor;
}());
exports.default = GFXCommandExcutor;


/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.RenderDrawNative = void 0;
var tslib_1 = __webpack_require__(1);
var renderDrawEncodeDefines_1 = tslib_1.__importDefault(__webpack_require__(18));
var color_1 = tslib_1.__importDefault(__webpack_require__(19));
var matrix3_1 = tslib_1.__importDefault(__webpack_require__(21));
function arrayToHashTime33(arr) {
    var hash = 0;
    for (var i = 0, len = arr.length; i < len; i++) {
        hash = (hash * 33 + arr[i]) % 1000000007;
    }
    return hash;
}
var RENDERDRAW_DATALENGTH = 50 * 4;
var RenderDrawNative = /** @class */ (function () {
    function RenderDrawNative() {
        this.blend = 0;
        this.rgba = 0;
        this.stencilOpTest = 0;
        this.stencilDepth = 0;
        this.raster = 0;
        this._hashForPipeline = '';
    }
    RenderDrawNative.prototype.applyUpdate = function () {
        var arr = [this.blend, this.rgba, this.stencilDepth, this.stencilOpTest, this.raster, this.vertexLayout._id, this.shader.id];
        // PC小游戏上高频出现hash冲突，换成字符串key
        this._hashForPipeline = arr.join('_'); //arrayToHashTime33(arr);
        if (this.worldTransform && this.batchable) {
            this._worldTransformMatrix = new matrix3_1.default(this.worldTransform._f32View);
        }
    };
    /*
      blend
    */
    RenderDrawNative.prototype._getBlendEnable = function () {
        return !!renderDrawEncodeDefines_1.default.WRITE_GET(this.blend, renderDrawEncodeDefines_1.default.BLEND_ENABLE_MASK, renderDrawEncodeDefines_1.default.BLEND_ENABLE_SHIFT);
    };
    RenderDrawNative.prototype._getBlendOpAlpha = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.blend, renderDrawEncodeDefines_1.default.BLEND_OP_ALPHA_MASK, renderDrawEncodeDefines_1.default.BLEND_OP_ALPHA_SHIFT);
    };
    RenderDrawNative.prototype._getBlendDstFactorAlpha = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.blend, renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_ALPHA_MASK, renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_ALPHA_SHIFT);
    };
    RenderDrawNative.prototype._getBlendSrcFactorAlpha = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.blend, renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_ALPHA_MASK, renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_ALPHA_SHIFT);
    };
    RenderDrawNative.prototype._getBlendOpRGB = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.blend, renderDrawEncodeDefines_1.default.BLEND_OP_RGB_MASK, renderDrawEncodeDefines_1.default.BLEND_OP_RGB_SHIFT);
    };
    RenderDrawNative.prototype._getBlendDstFactorRGB = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.blend, renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_RGB_MASK, renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_RGB_SHIFT);
    };
    RenderDrawNative.prototype._getBlendSrcFactorRGB = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.blend, renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_RGB_MASK, renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_RGB_SHIFT);
    };
    RenderDrawNative.prototype._getBlendColorMask = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.blend, renderDrawEncodeDefines_1.default.COLOR_WRITE_MASK, renderDrawEncodeDefines_1.default.COLOR_WRITE_SHIFT);
    };
    /*
      blend rgba
    */
    RenderDrawNative.prototype._getBlendRGBA = function () {
        var color = color_1.default.fromHex(this.rgba);
        return [color.r / 255.0, color.g / 255.0, color.b / 255.0, color.a / 255.0];
    };
    /*
      stencilOpTest
     */
    RenderDrawNative.prototype._getStencilFrontFailOp = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.stencilOpTest, renderDrawEncodeDefines_1.default.STENCIL_FRONT_FAIL_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_FAIL_OP_SHIFT);
    };
    RenderDrawNative.prototype._getStencilFrontDepthFailOp = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.stencilOpTest, renderDrawEncodeDefines_1.default.STENCIL_FRONT_DEPTH_FAIL_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_DEPTH_FAIL_OP_SHIFT);
    };
    RenderDrawNative.prototype._getStencilFrontPassOp = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.stencilOpTest, renderDrawEncodeDefines_1.default.STENCIL_FRONT_PASS_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_PASS_OP_SHIFT);
    };
    RenderDrawNative.prototype._getStencilFrontCompareFunc = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.stencilOpTest, renderDrawEncodeDefines_1.default.STENCIL_FRONT_COMPARE_FUN_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_COMPARE_FUN_SHIFT);
    };
    RenderDrawNative.prototype._getStencilBackFailOp = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.stencilOpTest, renderDrawEncodeDefines_1.default.STENCIL_BACK_FAIL_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_BACK_FAIL_OP_SHIFT);
    };
    RenderDrawNative.prototype._getStencilBackDepthFailOp = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.stencilOpTest, renderDrawEncodeDefines_1.default.STENCIL_BACK_DEPTH_FAIL_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_BACK_DEPTH_FAIL_OP_SHIFT);
    };
    RenderDrawNative.prototype._getStencilBackPassOp = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.stencilOpTest, renderDrawEncodeDefines_1.default.STENCIL_BACK_PASS_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_BACK_PASS_OP_SHIFT);
    };
    RenderDrawNative.prototype._getStencilBackCompareFunc = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.stencilOpTest, renderDrawEncodeDefines_1.default.STENCIL_BACK_COMPARE_FUN_MASK, renderDrawEncodeDefines_1.default.STENCIL_BACK_COMPARE_FUN_SHIFT);
    };
    /*
      stencilDepth
    */
    RenderDrawNative.prototype._getStencilRef = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.stencilDepth, renderDrawEncodeDefines_1.default.STENCIL_REF_MASK, renderDrawEncodeDefines_1.default.STENCIL_REF_SHIFT);
    };
    RenderDrawNative.prototype._getStencilWrite = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.stencilDepth, renderDrawEncodeDefines_1.default.STENCIL_WRITE_MASK, renderDrawEncodeDefines_1.default.STENCIL_WRITE_SHIFT);
    };
    RenderDrawNative.prototype._getStencilRead = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.stencilDepth, renderDrawEncodeDefines_1.default.STENCIL_READ_MASK, renderDrawEncodeDefines_1.default.STENCIL_READ_SHIFT);
    };
    RenderDrawNative.prototype._getDepthCompareFunc = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.stencilDepth, renderDrawEncodeDefines_1.default.DEPTH_COMPARE_FUNC_MASK, renderDrawEncodeDefines_1.default.DEPTH_COMPARE_FUNC_SHIFT);
    };
    RenderDrawNative.prototype._getDepthWriteEnable = function () {
        return !!renderDrawEncodeDefines_1.default.WRITE_GET(this.stencilDepth, renderDrawEncodeDefines_1.default.DEPTH_WRITE_ENABLE_FUNC_MASK, renderDrawEncodeDefines_1.default.DEPTH_WRITE_ENABLE_FUNC_SHIFT);
    };
    RenderDrawNative.prototype._getStencilEnable = function () {
        return !!renderDrawEncodeDefines_1.default.WRITE_GET(this.stencilDepth, renderDrawEncodeDefines_1.default.STENCIL_ENABLE_FUNC_MASK, renderDrawEncodeDefines_1.default.STENCIL_ENABLE_FUNC_SHIFT);
    };
    RenderDrawNative.prototype._getColorAttachCount = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.raster, renderDrawEncodeDefines_1.default.COLOR_ATTACHMENT_COUNT_MASK, renderDrawEncodeDefines_1.default.COLOR_ATTACHMENT_COUNT_SHIFT);
    };
    RenderDrawNative.prototype._getColorFormat = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.raster, renderDrawEncodeDefines_1.default.COLOR_FORMAT_MASK, renderDrawEncodeDefines_1.default.COLOR_FORMAT_SHIFT);
    };
    RenderDrawNative.prototype._getDepthFormat = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.raster, renderDrawEncodeDefines_1.default.DEPTH_FORMAT_MASK, renderDrawEncodeDefines_1.default.DEPTH_FORMAT_SHIFT);
    };
    RenderDrawNative.prototype._getCullMode = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.raster, renderDrawEncodeDefines_1.default.CULL_MODE_MASK, renderDrawEncodeDefines_1.default.CULL_MODE_SHIFT);
    };
    RenderDrawNative.prototype._getFaceWinding = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.raster, renderDrawEncodeDefines_1.default.FACE_WINDING_MASK, renderDrawEncodeDefines_1.default.FACE_WINDING_SHIFT);
    };
    RenderDrawNative.prototype._getSampleCount = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.raster, renderDrawEncodeDefines_1.default.SAMPLE_COUNT_MASK, renderDrawEncodeDefines_1.default.SAMPLE_COUNT_SHIFT);
    };
    RenderDrawNative.prototype._getPrimitiveType = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.raster, renderDrawEncodeDefines_1.default.PRIMITIVE_TYPE_MASK, renderDrawEncodeDefines_1.default.PRIMITIVE_TYPE_SHIFT);
    };
    RenderDrawNative.prototype._getIndexType = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.raster, renderDrawEncodeDefines_1.default.INDEX_TYPE_MASK, renderDrawEncodeDefines_1.default.INDEX_TYPE_SHIFT);
    };
    RenderDrawNative.prototype._getAlphaToCoverageEnable = function () {
        return renderDrawEncodeDefines_1.default.WRITE_GET(this.raster, renderDrawEncodeDefines_1.default.ALPHA_TO_COVERAGE_ENABLE_MASK, renderDrawEncodeDefines_1.default.ALPHA_TO_COVERAGE_ENABLE_SHIFT);
    };
    return RenderDrawNative;
}());
exports.RenderDrawNative = RenderDrawNative;


/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/*
 * @Author: bluecatliao
 * @Date: 2019-03-18 20:14:16
 * @Last Modified by: roamye
 * @Last Modified time: 2020-11-24 21:11:49
 * renderDraw中的一些编码位
 */
var GA_RD = {
    WRITE_GET: function (value, writeMask, writeShift) {
        return (value & writeMask) >> writeShift;
    },
    WRITE_SET: function (value, writeMask, writeShift) {
        return (value << writeShift) & writeMask;
    },
    WRITE_SET_SAFE: function (value, writeMask, writeShift) {
        return (value << writeShift >>> 0) & writeMask;
    },
    // RenderState::blend -> sg_blend_state
    // 32 bits:
    //
    //                            │ op_rgb
    //                            │    │ dst_factor_rgb
    //        │ enable            │    │    │ src_factor_rgb
    //        0000 0000 0000 0000 0000 0000 0000 0000
    //             │    │    │ src_factor_alpha  │ color_write_mask
    //             │    │ dst_factor_alpha
    //             │ op_alpha
    //
    COLOR_WRITE_SHIFT: 0,
    COLOR_WRITE_MASK: 0x0000000f,
    BLEND_SRC_FACTOR_RGB_SHIFT: 4,
    BLEND_SRC_FACTOR_RGB_MASK: 0x000000f0,
    BLEND_DST_FACTOR_RGB_SHIFT: 8,
    BLEND_DST_FACTOR_RGB_MASK: 0x00000f00,
    BLEND_OP_RGB_SHIFT: 12,
    BLEND_OP_RGB_MASK: 0x0000f000,
    BLEND_SRC_FACTOR_ALPHA_SHIFT: 16,
    BLEND_SRC_FACTOR_ALPHA_MASK: 0x000f0000,
    BLEND_DST_FACTOR_ALPHA_SHIFT: 20,
    BLEND_DST_FACTOR_ALPHA_MASK: 0x00f00000,
    BLEND_OP_ALPHA_SHIFT: 24,
    BLEND_OP_ALPHA_MASK: 0x0f000000,
    BLEND_ENABLE_SHIFT: 28,
    BLEND_ENABLE_MASK: 0xf0000000,
    // RenderState::rgba -> sg_blend_state::blend_color
    // 32 bits:
    //
    //        │ a       │ b       │ g       │ r
    //        0000 0000 0000 0000 0000 0000 0000 0000
    //
    BLEND_RGBA_R_SHIFT: 0,
    BLEND_RGBA_R_MASK: 0x000000ff,
    BLEND_RGBA_G_SHIFT: 8,
    BLEND_RGBA_G_MASK: 0x0000ff00,
    BLEND_RGBA_B_SHIFT: 16,
    BLEND_RGBA_B_MASK: 0x00ff0000,
    BLEND_RGBA_A_SHIFT: 24,
    BLEND_RGBA_A_MASK: 0xff000000,
    // RenderState::stencil_op_test -> sg_depth_stencil_state::[stencil_back | stencil_front]
    // 32 bits:
    //
    //                            │ compare_func
    //                            │    │ pass_op
    //                            │    │    │ depth_fail_op
    //                            │    │    │    │ fail_op
    //        0000 0000 0000 0000 0000 0000 0000 0000
    //        │    │    │    │ fail_op
    //        │    │    │ depth_fail_op
    //        │    │ pass_op
    //        │ compare_func
    //
    STENCIL_FRONT_FAIL_OP_SHIFT: 0,
    STENCIL_FRONT_FAIL_OP_MASK: 0x0000000f,
    STENCIL_FRONT_DEPTH_FAIL_OP_SHIFT: 4,
    STENCIL_FRONT_DEPTH_FAIL_OP_MASK: 0x000000f0,
    STENCIL_FRONT_PASS_OP_SHIFT: 8,
    STENCIL_FRONT_PASS_OP_MASK: 0x00000f00,
    STENCIL_FRONT_COMPARE_FUN_SHIFT: 12,
    STENCIL_FRONT_COMPARE_FUN_MASK: 0x0000f000,
    STENCIL_BACK_FAIL_OP_SHIFT: 16,
    STENCIL_BACK_FAIL_OP_MASK: 0x000f0000,
    STENCIL_BACK_DEPTH_FAIL_OP_SHIFT: 20,
    STENCIL_BACK_DEPTH_FAIL_OP_MASK: 0x00f00000,
    STENCIL_BACK_PASS_OP_SHIFT: 24,
    STENCIL_BACK_PASS_OP_MASK: 0x0f000000,
    STENCIL_BACK_COMPARE_FUN_SHIFT: 28,
    STENCIL_BACK_COMPARE_FUN_MASK: 0xf0000000,
    // RenderState::stencil_depth -> sg_depth_stencil_state::[stencil_back | stencil_front]
    // 32 bits:
    //
    //                   │ stencil_read
    //                   │         │ stencil_write
    //                   │         │         │ stencil_ref
    //        00 00 0000 0000 0000 0000 0000 0000 0000
    //        │  │  │ depth_compare_func
    //        │  │ depth_write_enable
    //        │ stencil_enable
    STENCIL_REF_SHIFT: 0,
    STENCIL_REF_MASK: 0x000000ff,
    STENCIL_WRITE_SHIFT: 8,
    STENCIL_WRITE_MASK: 0x0000ff00,
    STENCIL_READ_SHIFT: 16,
    STENCIL_READ_MASK: 0x00ff0000,
    DEPTH_COMPARE_FUNC_SHIFT: 24,
    DEPTH_COMPARE_FUNC_MASK: 0x0f000000,
    DEPTH_WRITE_ENABLE_FUNC_SHIFT: 28,
    DEPTH_WRITE_ENABLE_FUNC_MASK: 0x30000000,
    STENCIL_ENABLE_FUNC_SHIFT: 30,
    STENCIL_ENABLE_FUNC_MASK: 0xc0000000,
    // RenderState::raster -> sg_blend_state | sg_rasterizer_state
    // 32 bits:
    //
    //                              │ depth_format
    //        │ alpha_to_coverage_e │      │ color_format
    //        │  │ index_type       │      │      │ color_attachment_count
    //        00 000 000 0000 00 00 000000 000000 0000
    //               │   │    │  │ cull_mode
    //               │   │    │ face_winding
    //               │   │ sample_count
    //               │ primitive_type
    COLOR_ATTACHMENT_COUNT_SHIFT: 0,
    COLOR_ATTACHMENT_COUNT_MASK: 0x0000000f,
    COLOR_FORMAT_SHIFT: 4,
    COLOR_FORMAT_MASK: 0x000003f0,
    DEPTH_FORMAT_SHIFT: 10,
    DEPTH_FORMAT_MASK: 0x0000fc00,
    BLEND_PART_MASK: 0x0000ffff,
    CULL_MODE_SHIFT: 16,
    CULL_MODE_MASK: 0x00030000,
    FACE_WINDING_SHIFT: 18,
    FACE_WINDING_MASK: 0x000c0000,
    SAMPLE_COUNT_SHIFT: 20,
    SAMPLE_COUNT_MASK: 0x00f00000,
    PRIMITIVE_TYPE_SHIFT: 24,
    PRIMITIVE_TYPE_MASK: 0x07000000,
    INDEX_TYPE_SHIFT: 27,
    INDEX_TYPE_MASK: 0x38000000,
    ALPHA_TO_COVERAGE_ENABLE_SHIFT: 30,
    ALPHA_TO_COVERAGE_ENABLE_MASK: 0xc0000000,
    RASTER_PART_MASK: 0xffff0000,
};
exports.default = GA_RD;


/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.BlendType = void 0;
var utils_1 = __webpack_require__(20);
/*
 * @Author: bluecatliao
 * @Date: 2018-09-25 17:00:06
 * @Last Modified by: roamye
 * @Last Modified time: 2020-05-06 16:36:24
 * Color defined by RGBA8888
 */
var BlendType;
(function (BlendType) {
    BlendType[BlendType["Alpha"] = 0] = "Alpha";
    BlendType[BlendType["RGB"] = 1] = "RGB";
    BlendType[BlendType["RGBA"] = 2] = "RGBA";
    BlendType[BlendType["None"] = 3] = "None";
})(BlendType = exports.BlendType || (exports.BlendType = {}));
/**
 * @public
 */
var Color = /** @class */ (function () {
    function Color(r, g, b, a) {
        r = r || 0;
        g = g || 0;
        b = b || 0;
        a = typeof a === "number" ? a : 255;
        this._value32 = ((a << 24) >>> 0) + (b << 16) + (g << 8) + r;
    }
    Object.defineProperty(Color.prototype, "r", {
        get: function () {
            return this._value32 & 0x000000ff;
        },
        set: function (val) {
            val = utils_1.mathClamp(val, 0, 255);
            this._value32 = ((this._value32 & 0xffffff00) | val) >>> 0;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Color.prototype, "g", {
        get: function () {
            return (this._value32 & 0x0000ff00) >>> 8;
        },
        set: function (val) {
            val = utils_1.mathClamp(val, 0, 255) << 8;
            this._value32 = ((this._value32 & 0xffff00ff) | val) >>> 0;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Color.prototype, "b", {
        get: function () {
            return (this._value32 & 0x00ff0000) >>> 16;
        },
        set: function (val) {
            val = utils_1.mathClamp(val, 0, 255) << 16;
            this._value32 = ((this._value32 & 0xff00ffff) | val) >>> 0;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Color.prototype, "a", {
        get: function () {
            return (this._value32 & 0xff000000) >>> 24;
        },
        set: function (val) {
            val = utils_1.mathClamp(val, 0, 255) << 24;
            this._value32 = ((this._value32 & 0x00ffffff) | val) >>> 0;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Color, "WHITE", {
        get: function () {
            return new Color(255, 255, 255, 255);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Color, "BLACK", {
        get: function () {
            return new Color(0, 0, 0, 255);
        },
        enumerable: false,
        configurable: true
    });
    Color.fromHex = function (hex) {
        var color = new Color(0, 0, 0, 0);
        color._value32 = hex;
        return color;
    };
    Color.fromFloatArray = function (arr) {
        var r = Math.ceil((arr[0] || 0) * 255);
        var g = Math.ceil((arr[1] || 0) * 255);
        var b = Math.ceil((arr[2] || 0) * 255);
        var a = arr.length >= 4 ? Math.ceil((arr[3] || 0) * 255) : 255;
        var color = new Color(r, g, b, a);
        return color;
    };
    Color.prototype.clone = function () {
        var color = new Color(0, 0, 0, 0);
        color._value32 = this._value32;
        return color;
    };
    Color.prototype.equals = function (target) {
        return target._value32 === this._value32;
    };
    Color.prototype.set = function (val) {
        this._value32 = val._value32;
    };
    Color.prototype.setRGBA = function (r, g, b, a) {
        this._value32 = ((a << 24) >>> 0) + (b << 16) + (g << 8) + r;
    };
    Color.prototype.setValue32 = function (v32) {
        this._value32 = v32;
    };
    Color.prototype.toNormalizedArray = function () {
        return [this.r / 255.0, this.g / 255.0, this.b / 255.0, this.a / 255.0];
    };
    Color.prototype.toRGBAString = function () {
        return "rgba(" + this.r + ", " + this.g + ", " + this.b + ", " + this.a / 255.0 + ")";
    };
    Color.prototype.mix = function (color, dst) {
        if (dst) {
            dst.r = (this.r * color.r) / 255;
            dst.g = (this.g * color.g) / 255;
            dst.b = (this.b * color.b) / 255;
            dst.a = (this.a * color.a) / 255;
            return dst;
        }
        else {
            return new Color((this.r * color.r) / 255, (this.g * color.g) / 255, (this.b * color.b) / 255, (this.a * color.a) / 255);
        }
    };
    Color.blendColorHex = function (colorHexA, colorHexB, type) {
        if (type === void 0) { type = BlendType.None; }
        var blendedColor;
        switch (type) {
            case BlendType.Alpha:
                // blendedColor = new Color(colorA.r, colorA.g, colorA.b, (colorA.a * colorB.a) / 255);
                var alpha_a = (((colorHexA & 0xff000000) >>> 24) * ((colorHexB & 0xff000000) >>> 24)) / 255;
                blendedColor = ((alpha_a << 24) >>> 0) + (colorHexA & 0x00ffffff);
                break;
            case BlendType.RGB:
                // blendedColor = new Color((colorA.r * colorB.r) / 255, (colorA.g * colorB.g) / 255, (colorA.b * colorB.b) / 255, colorA.a);
                var rgb_r = ((colorHexA & 0x000000ff) * (colorHexB & 0x000000ff)) / 255;
                var rgb_g = (((colorHexA & 0x0000ff00) >>> 8) * ((colorHexB & 0x0000ff00) >>> 8)) / 255;
                var rgb_b = (((colorHexA & 0x00ff0000) >>> 16) * ((colorHexB & 0x00ff0000) >>> 16)) / 255;
                blendedColor = (colorHexA & 0xff000000) + (rgb_b << 16) + (rgb_g << 8) + rgb_r;
                break;
            case BlendType.RGBA:
                // blendedColor = new Color((colorA.r * colorB.r) / 255, (colorA.g * colorB.g) / 255, (colorA.b * colorB.b) / 255, (colorA.a * colorB.a) / 255);
                var rgba_r = ((colorHexA & 0x000000ff) * (colorHexB & 0x000000ff)) / 255;
                var rgba_g = (((colorHexA & 0x0000ff00) >>> 8) * ((colorHexB & 0x0000ff00) >>> 8)) / 255;
                var rgba_b = (((colorHexA & 0x00ff0000) >>> 16) * ((colorHexB & 0x00ff0000) >>> 16)) / 255;
                var rgba_a = (((colorHexA & 0xff000000) >>> 24) * ((colorHexB & 0xff000000) >>> 24)) / 255;
                blendedColor = ((rgba_a << 24) >>> 0) + (rgba_b << 16) + (rgba_g << 8) + rgba_r;
                break;
            case BlendType.None:
                blendedColor = colorHexA;
                break;
            default:
                blendedColor = colorHexA;
                break;
        }
        return blendedColor;
    };
    Color.getValue32FromRGBA = function (r, g, b, a) {
        return ((a << 24) >>> 0) + (b << 16) + (g << 8) + r;
    };
    Color.randomMix = function (colorHexA, colorHexB) {
        var AColor_r = colorHexA & 0x000000ff;
        var AColor_g = (colorHexA & 0x0000ff00) >>> 8;
        var AColor_b = (colorHexA & 0x00ff0000) >>> 16;
        var AColor_a = (colorHexA & 0xff000000) >>> 24;
        var BColor_r = colorHexB & 0x000000ff;
        var BColor_g = (colorHexB & 0x0000ff00) >>> 8;
        var BColor_b = (colorHexB & 0x00ff0000) >>> 16;
        var BColor_a = (colorHexB & 0xff000000) >>> 24;
        var random = Math.random();
        var r = Math.abs(AColor_r - BColor_r) * random + Math.min(AColor_r, BColor_r);
        var g = Math.abs(AColor_g - BColor_g) * random + Math.min(AColor_g, BColor_g);
        var b = Math.abs(AColor_b - BColor_b) * random + Math.min(AColor_b, BColor_b);
        var a = Math.abs(AColor_a - BColor_a) * random + Math.min(AColor_a, BColor_a);
        return this.getValue32FromRGBA(r, g, b, a);
    };
    Color.BlendType = BlendType;
    return Color;
}());
exports.default = Color;


/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.m4Helper = exports.m3Helper = exports.quatHelper = exports.v4Helper = exports.v3Helper = exports.v2Helper = exports.mathHelper = exports.mathClamp = exports.nearEqual = exports.isPowOf2 = exports.arcTanAngle = void 0;
function arcTanAngle(x, y) {
    if (x === 0) {
        if (y === 1) {
            return Math.PI / 2;
        }
        return -Math.PI / 2;
    }
    if (x > 0) {
        return Math.atan(y / x);
    }
    if (x < 0) {
        if (y > 0) {
            return Math.atan(y / x) + Math.PI;
        }
        return Math.atan(y / x) - Math.PI;
    }
    return 0;
}
exports.arcTanAngle = arcTanAngle;
function isPowOf2(num) {
    return !(num & (num - 1));
}
exports.isPowOf2 = isPowOf2;
function nearEqual(a, b) {
    return Math.abs(a - b) < 1e-6;
}
exports.nearEqual = nearEqual;
function mathClamp(val, min, max) {
    val = val > min ? val : min;
    return val < max ? val : max;
}
exports.mathClamp = mathClamp;
exports.mathHelper = {
    arcTanAngle: arcTanAngle,
    isPowOf2: isPowOf2,
    nearEqual: nearEqual,
    mathClamp: mathClamp,
};
exports.v2Helper = {
    equal: function (a, ao, b, bo) {
        return nearEqual(a[ao], b[bo]) && nearEqual(a[ao + 1], b[bo + 1]);
    },
    add: function (a, ao, b, bo, dst, dsto) {
        dst[dsto] = a[ao] + b[bo];
        dst[dsto + 1] = a[ao + 1] + b[bo + 1];
    },
    sub: function (a, ao, b, bo, dst, dsto) {
        dst[dsto] = a[ao] - b[bo];
        dst[dsto + 1] = a[ao + 1] - b[bo + 1];
    },
    length: function (a, ao) {
        var x = a[ao];
        var y = a[ao + 1];
        return Math.sqrt(x * x + y * y);
    },
    normalize: function (a, ao, dst, dsto) {
        var norm = exports.v2Helper.length(a, ao);
        if (norm === 0) {
            dst[dsto] = 0;
            dst[dsto + 1] = 0;
        }
        else {
            dst[dsto] = a[ao] / norm;
            dst[dsto + 1] = a[ao + 1] / norm;
        }
    },
    scale: function (a, ao, f, dst, dsto) {
        dst[dsto] = a[ao] * f;
        dst[dsto + 1] = a[ao + 1] * f;
    },
    lerp: function (a, ao, b, bo, f, dst, dsto) {
        var fp = 1 - f;
        dst[dsto] = a[ao] * fp + b[bo] * f;
        dst[dsto + 1] = a[ao + 1] * fp + b[bo + 1] * f;
    },
    dot: function (a, ao, b, bo) {
        return a[ao] * b[bo] + a[ao + 1] * b[bo + 1];
    },
    isZero: function (a, ao) {
        return nearEqual(a[ao], 0) && nearEqual(a[ao + 1], 0);
    },
    getAngle: function (a, ao) {
        var angle = Math.atan2(a[ao + 1], a[ao]);
        var degrees = (180 * angle) / Math.PI;
        return (360 + Math.round(degrees)) % 360;
    },
    distance: function (a, ao, b, bo) {
        var dx = a[ao] - b[bo];
        var dy = a[ao + 1] - b[bo + 1];
        return Math.sqrt(dx * dx + dy * dy);
    },
    copy: function (v, vo, dst, dsto) {
        dst[dsto + 0] = v[vo + 0];
        dst[dsto + 1] = v[vo + 1];
    },
};
exports.v3Helper = {
    equal: function (a, ao, b, bo) {
        return nearEqual(a[ao], b[bo]) && nearEqual(a[ao + 1], b[bo + 1]) && nearEqual(a[ao + 2], b[bo + 2]);
    },
    add: function (a, ao, b, bo, dst, dsto) {
        dst[dsto] = a[ao] + b[bo];
        dst[dsto + 1] = a[ao + 1] + b[bo + 1];
        dst[dsto + 2] = a[ao + 2] + b[bo + 2];
    },
    sub: function (a, ao, b, bo, dst, dsto) {
        dst[dsto] = a[ao] - b[bo];
        dst[dsto + 1] = a[ao + 1] - b[bo + 1];
        dst[dsto + 2] = a[ao + 2] - b[bo + 2];
    },
    length: function (a, ao) {
        var x = a[ao];
        var y = a[ao + 1];
        var z = a[ao + 2];
        return Math.sqrt(x * x + y * y + z * z);
    },
    normalize: function (a, ao, dst, dsto) {
        var norm = exports.v3Helper.length(a, ao);
        if (norm === 0) {
            dst[dsto] = 0;
            dst[dsto + 1] = 0;
            dst[dsto + 2] = 0;
        }
        else {
            dst[dsto] = a[ao] / norm;
            dst[dsto + 1] = a[ao + 1] / norm;
            dst[dsto + 2] = a[ao + 2] / norm;
        }
    },
    scale: function (a, ao, f, dst, dsto) {
        dst[dsto] = a[ao] * f;
        dst[dsto + 1] = a[ao + 1] * f;
        dst[dsto + 2] = a[ao + 2] * f;
    },
    lerp: function (a, ao, b, bo, f, dst, dsto) {
        var fp = 1 - f;
        dst[dsto] = a[ao] * fp + b[bo] * f;
        dst[dsto + 1] = a[ao + 1] * fp + b[bo + 1] * f;
        dst[dsto + 2] = a[ao + 2] * fp + b[bo + 2] * f;
    },
    dot: function (a, ao, b, bo) {
        return a[ao] * b[bo] + a[ao + 1] * b[bo + 1] + a[ao + 2] * b[bo + 2];
    },
    isZero: function (a, ao) {
        return nearEqual(a[ao], 0) && nearEqual(a[ao + 1], 0) && nearEqual(a[ao + 2], 0);
    },
    cross: function (a, ao, b, bo, dst, dsto) {
        dst[dsto] = a[ao + 1] * b[bo + 2] - b[bo + 1] * a[ao + 2];
        dst[dsto + 1] = a[ao + 2] * b[bo] - b[bo + 2] * a[ao];
        dst[dsto + 2] = a[ao] * b[bo + 1] - b[bo] * a[ao + 1];
    },
    distance: function (a, ao, b, bo) {
        var dx = a[ao] - b[bo];
        var dy = a[ao + 1] - b[bo + 1];
        var dz = a[ao + 2] - b[bo + 2];
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    },
    angleTo: function (a, ao, b, bo, dst, dsto) {
        var dir = tempV3_1;
        exports.v3Helper.sub(b, bo, a, ao, dir, 0);
        exports.v3Helper.normalize(dir, 0, dir, 0);
        dst[dsto] = Math.asin(dir[1]);
        dst[dsto + 1] = arcTanAngle(-dir[2], -dir[0]);
        dst[dsto + 2] = 0;
    },
    copy: function (v, vo, dst, dsto) {
        dst[dsto + 0] = v[vo + 0];
        dst[dsto + 1] = v[vo + 1];
        dst[dsto + 2] = v[vo + 2];
    },
};
exports.v4Helper = {
    equal: function (a, ao, b, bo) {
        return nearEqual(a[ao], b[bo]) && nearEqual(a[ao + 1], b[bo + 1]) && nearEqual(a[ao + 2], b[bo + 2]) && nearEqual(a[ao + 3], b[bo + 3]);
    },
    add: function (a, ao, b, bo, dst, dsto) {
        dst[dsto] = a[ao] + b[bo];
        dst[dsto + 1] = a[ao + 1] + b[bo + 1];
        dst[dsto + 2] = a[ao + 2] + b[bo + 2];
        dst[dsto + 3] = a[ao + 3] + b[bo + 3];
    },
    sub: function (a, ao, b, bo, dst, dsto) {
        dst[dsto] = a[ao] - b[bo];
        dst[dsto + 1] = a[ao + 1] - b[bo + 1];
        dst[dsto + 2] = a[ao + 2] - b[bo + 2];
        dst[dsto + 3] = a[ao + 3] - b[bo + 3];
    },
    scale: function (a, ao, f, dst, dsto) {
        dst[dsto] = a[ao] * f;
        dst[dsto + 1] = a[ao + 1] * f;
        dst[dsto + 2] = a[ao + 2] * f;
        dst[dsto + 3] = a[ao + 3] * f;
    },
    lerp: function (a, ao, b, bo, f, dst, dsto) {
        var fp = 1 - f;
        dst[dsto] = a[ao] * fp + b[bo] * f;
        dst[dsto + 1] = a[ao + 1] * fp + b[bo + 1] * f;
        dst[dsto + 2] = a[ao + 2] * fp + b[bo + 2] * f;
        dst[dsto + 3] = a[ao + 3] * fp + b[bo + 3] * f;
    },
    dot: function (a, ao, b, bo) {
        return a[ao] * b[bo] + a[ao + 1] * b[bo + 1] + a[ao + 2] * b[bo + 2] + a[ao + 3] * b[bo + 3];
    },
    isZero: function (a, ao) {
        return nearEqual(a[ao], 0) && nearEqual(a[ao + 1], 0) && nearEqual(a[ao + 2], 0) && nearEqual(a[ao + 3], 0);
    },
    copy: function (v, vo, dst, dsto) {
        if (v.length === 4) {
            dst.set(v, dsto);
        }
        else {
            dst[dsto + 0] = v[vo + 0];
            dst[dsto + 1] = v[vo + 1];
            dst[dsto + 2] = v[vo + 2];
            dst[dsto + 3] = v[vo + 3];
        }
    },
};
exports.quatHelper = {
    multiply: function (l, lo, r, ro, dst, dsto) {
        var lx = l[lo + 0];
        var ly = l[lo + 1];
        var lz = l[lo + 2];
        var lw = l[lo + 3];
        var rx = r[ro + 0];
        var ry = r[ro + 1];
        var rz = r[ro + 2];
        var rw = r[ro + 3];
        var a = ly * rz - lz * ry;
        var b = lz * rx - lx * rz;
        var c = lx * ry - ly * rx;
        var d = lx * rx + ly * ry + lz * rz;
        dst[dsto] = lx * rw + rx * lw + a;
        dst[dsto + 1] = ly * rw + ry * lw + b;
        dst[dsto + 2] = lz * rw + rz * lw + c;
        dst[dsto + 3] = lw * rw - d;
    },
    invert: function (a, ao, dst, dsto) {
        var a0 = a[ao + 0];
        var a1 = a[ao + 1];
        var a2 = a[ao + 2];
        var a3 = a[ao + 3];
        var dot = a0 * a0 + a1 * a1 + a2 * a2 + a3 * a3;
        var invDot = dot ? 1.0 / dot : 0;
        dst[dsto] = -a0 * invDot;
        dst[dsto + 1] = -a1 * invDot;
        dst[dsto + 2] = -a2 * invDot;
        dst[dsto + 3] = a3 * invDot;
    },
    toMatrix4: function (quat, quato, dst, dsto) {
        var x = quat[quato];
        var y = quat[quato + 1];
        var z = quat[quato + 2];
        var w = quat[quato + 3];
        var x2 = x + x;
        var y2 = y + y;
        var z2 = z + z;
        var xx = x * x2;
        var yx = y * x2;
        var yy = y * y2;
        var zx = z * x2;
        var zy = z * y2;
        var zz = z * z2;
        var wx = w * x2;
        var wy = w * y2;
        var wz = w * z2;
        dst.set(DEFAULT_IDENTITY, dsto);
        dst[dsto] = 1 - yy - zz;
        dst[dsto + 1] = yx + wz;
        dst[dsto + 2] = zx - wy;
        dst[dsto + 4] = yx - wz;
        dst[dsto + 5] = 1 - xx - zz;
        dst[dsto + 6] = zy + wx;
        dst[dsto + 8] = zx + wy;
        dst[dsto + 9] = zy - wx;
        dst[dsto + 10] = 1 - xx - yy;
    },
    fromMatrix4: function (m, mo, dst, dsto) {
        var me = m;
        var _offsetMe = mo;
        var oe = tempV4;
        var sqrt;
        var half;
        var scale = me[_offsetMe + 0] + me[_offsetMe + 5] + me[_offsetMe + 10];
        if (scale > 0.0) {
            sqrt = Math.sqrt(scale + 1.0);
            oe[3] = sqrt * 0.5;
            sqrt = 0.5 / sqrt;
            oe[0] = (me[_offsetMe + 6] - me[_offsetMe + 9]) * sqrt;
            oe[1] = (me[_offsetMe + 8] - me[_offsetMe + 2]) * sqrt;
            oe[2] = (me[_offsetMe + 1] - me[_offsetMe + 4]) * sqrt;
        }
        else if (me[_offsetMe + 0] >= me[_offsetMe + 5] && me[_offsetMe + 0] >= me[_offsetMe + 10]) {
            sqrt = Math.sqrt(1.0 + me[_offsetMe + 0] - me[_offsetMe + 5] - me[_offsetMe + 10]);
            half = 0.5 / sqrt;
            oe[0] = 0.5 * sqrt;
            oe[1] = (me[_offsetMe + 1] + me[_offsetMe + 4]) * half;
            oe[2] = (me[_offsetMe + 2] + me[_offsetMe + 8]) * half;
            oe[3] = (me[_offsetMe + 6] - me[_offsetMe + 9]) * half;
        }
        else if (me[_offsetMe + 5] > me[_offsetMe + 10]) {
            sqrt = Math.sqrt(1.0 + me[_offsetMe + 5] - me[_offsetMe + 0] - me[_offsetMe + 10]);
            half = 0.5 / sqrt;
            oe[0] = (me[_offsetMe + 4] + me[_offsetMe + 1]) * half;
            oe[1] = 0.5 * sqrt;
            oe[2] = (me[_offsetMe + 9] + me[_offsetMe + 6]) * half;
            oe[3] = (me[_offsetMe + 8] - me[_offsetMe + 2]) * half;
        }
        else {
            sqrt = Math.sqrt(1.0 + me[_offsetMe + 10] - me[_offsetMe + 0] - me[_offsetMe + 5]);
            half = 0.5 / sqrt;
            oe[0] = (me[_offsetMe + 8] + me[_offsetMe + 2]) * half;
            oe[1] = (me[_offsetMe + 9] + me[_offsetMe + 6]) * half;
            oe[2] = 0.5 * sqrt;
            oe[3] = (me[_offsetMe + 1] - me[_offsetMe + 4]) * half;
        }
        dst.set(oe, dsto);
    },
    fromEulerAngles: function (v, vo, dst, dsto) {
        exports.quatHelper.fromYawRawPitch(v[vo + 1], v[vo], v[vo + 2], dst, dsto);
    },
    fromYawRawPitch: function (yaw, pitch, roll, dst, dsto) {
        var halfRoll = roll * 0.5;
        var halfPitch = pitch * 0.5;
        var halfYaw = yaw * 0.5;
        var sinRoll = Math.sin(halfRoll);
        var cosRoll = Math.cos(halfRoll);
        var sinPitch = Math.sin(halfPitch);
        var cosPitch = Math.cos(halfPitch);
        var sinYaw = Math.sin(halfYaw);
        var cosYaw = Math.cos(halfYaw);
        dst[dsto] = cosYaw * sinPitch * cosRoll + sinYaw * cosPitch * sinRoll;
        dst[dsto + 1] = sinYaw * cosPitch * cosRoll - cosYaw * sinPitch * sinRoll;
        dst[dsto + 2] = cosYaw * cosPitch * sinRoll - sinYaw * sinPitch * cosRoll;
        dst[dsto + 3] = cosYaw * cosPitch * cosRoll + sinYaw * sinPitch * sinRoll;
    },
    toEulerAngles: function (quat, quato, dst, dsto) {
        exports.quatHelper.toYawRawPitch(quat, quato, dst, dsto);
        // switch YawRaw
        // const temp = dst[dsto];
        // dst[dsto] = dst[dsto + 1];
        // dst[dsto + 1] = temp;
    },
    toYawRawPitch: function (quat, quato, dst, dsto) {
        exports.quatHelper.transformDirection(quat, quato, tempV3ForwardRH, 0, tempV3_1, 0);
        exports.quatHelper.transformDirection(quat, quato, tempV3Up, 0, tempV3_2, 0);
        var upr = tempV3_2;
        exports.v3Helper.angleTo(tempV3Zero, 0, tempV3_1, 0, tempV3_3, 0);
        var anglee = tempV3_3;
        if (anglee[0] === Math.PI / 2) {
            anglee[1] = arcTanAngle(upr[2], upr[0]);
            anglee[2] = 0;
        }
        else if (anglee[0] === -Math.PI / 2) {
            anglee[1] = arcTanAngle(-upr[2], -upr[0]);
            anglee[2] = 0;
        }
        else {
            exports.m4Helper.yRotation(-anglee[1], tempM4_1, 0);
            exports.m4Helper.xRotation(-anglee[0], tempM4_2, 0);
            exports.m4Helper.transformPoint(tempM4_1, 0, tempV3_2, 0, tempV3_2, 0);
            exports.m4Helper.transformPoint(tempM4_2, 0, tempV3_2, 0, tempV3_2, 0);
            anglee[2] = arcTanAngle(upr[1], -upr[0]);
        }
        if (anglee[1] <= -Math.PI) {
            anglee[1] = Math.PI;
        }
        if (anglee[2] <= -Math.PI) {
            anglee[2] = Math.PI;
        }
        if (anglee[1] >= Math.PI && anglee[2] >= Math.PI) {
            anglee[1] = 0;
            anglee[2] = 0;
            anglee[0] = Math.PI - anglee[0];
        }
        dst.set(anglee, dsto);
    },
    slerp: function (l, lo, r, ro, t, dst, dsto) {
        // tslint:disable-next-line:one-variable-per-declaration
        var ax = l[lo + 0], ay = l[lo + 1], az = l[lo + 2], aw = l[lo + 3];
        // tslint:disable-next-line:one-variable-per-declaration
        var bx = r[ro + 0], by = r[ro + 1], bz = r[ro + 2], bw = r[ro + 3];
        // tslint:disable-next-line:one-variable-per-declaration
        var omega, cosom, sinom, scale0, scale1;
        cosom = ax * bx + ay * by + az * bz + aw * bw;
        if (cosom < 0.0) {
            cosom = -cosom;
            bx = -bx;
            by = -by;
            bz = -bz;
            bw = -bw;
        }
        if (1.0 - cosom > 0.000001) {
            omega = Math.acos(cosom);
            sinom = Math.sin(omega);
            scale0 = Math.sin((1.0 - t) * omega) / sinom;
            scale1 = Math.sin(t * omega) / sinom;
        }
        else {
            scale0 = 1.0 - t;
            scale1 = t;
        }
        dst[dsto] = scale0 * ax + scale1 * bx;
        dst[dsto + 1] = scale0 * ay + scale1 * by;
        dst[dsto + 2] = scale0 * az + scale1 * bz;
        dst[dsto + 3] = scale0 * aw + scale1 * bw;
        return dst;
    },
    transformDirection: function (quat, quato, v, vo, dst, dsto) {
        // tslint:disable-next-line:one-variable-per-declaration
        var x = v[vo], y = v[vo + 1], z = v[vo + 2], qx = quat[quato], qy = quat[quato + 1], qz = quat[quato + 2], qw = quat[quato + 3], ix = qw * x + qy * z - qz * y, iy = qw * y + qz * x - qx * z, iz = qw * z + qx * y - qy * x, iw = -qx * x - qy * y - qz * z;
        dst[dsto] = ix * qw + iw * -qx + iy * -qz - iz * -qy;
        dst[dsto + 1] = iy * qw + iw * -qy + iz * -qx - ix * -qz;
        dst[dsto + 2] = iz * qw + iw * -qz + ix * -qy - iy * -qx;
    },
};
/*
  todo:

  const a = new Float32Array(16).fill(1.1111);
  const b = new Float32Array(16);
  // func1
  for(let i=0;i<1000*10000;i++){
    b.set(a);
  }
  // func2
  for(let i=0;i<1000*10000;i++){
    b[0] = a[0];
    b[1] = a[1];
    b[2] = a[2];
    b[3] = a[3];
    b[4] = a[4];
    b[5] = a[5];
    b[6] = a[6];
    b[7] = a[7];
    b[8] = a[8];
    b[9] = a[9];
    b[10] = a[10];
    b[11] = a[11];
    b[12] = a[12];
    b[13] = a[13];
    b[14] = a[14];
    b[15] = a[15];
  }

  这段代码，IOS上 func1比func2快16倍
  Android上 func1比func2 慢 30%
  所以这里后续看要不要分平台实现
*/
exports.m3Helper = {
    translate: function (m /*m3*/, mo, tx, ty, dst, dsto) {
        var m00 = m[mo + 0];
        var m01 = m[mo + 1];
        var m02 = m[mo + 2];
        var m10 = m[mo + 1 * 3 + 0];
        var m11 = m[mo + 1 * 3 + 1];
        var m12 = m[mo + 1 * 3 + 2];
        var m20 = m[mo + 2 * 3 + 0];
        var m21 = m[mo + 2 * 3 + 1];
        var m22 = m[mo + 2 * 3 + 2];
        if (m.length === 9) {
            // mo === 0, use Float32Array.set
            dst.set(m, dsto);
        }
        else if (dst !== m || dsto !== mo) {
            dst[dsto] = m00;
            dst[dsto + 1] = m01;
            dst[dsto + 2] = m02;
            dst[dsto + 3] = m10;
            dst[dsto + 4] = m11;
            dst[dsto + 5] = m12;
        }
        dst[dsto + 6] = m00 * tx + m10 * ty + m20;
        dst[dsto + 7] = m01 * tx + m11 * ty + m21;
        dst[dsto + 8] = m02 * tx + m12 * ty + m22;
    },
    scale: function (m /*m3*/, mo, sx, sy, dst, dsto) {
        dst[dsto + 0] = sx * m[mo + 0];
        dst[dsto + 1] = sx * m[mo + 1];
        dst[dsto + 3] = sy * m[mo + 3];
        dst[dsto + 4] = sy * m[mo + 4];
        if (dst !== m || dsto !== mo) {
            dst[dsto + 6] = m[mo + 6];
            dst[dsto + 7] = m[mo + 7];
            dst[dsto + 8] = m[mo + 8];
        }
    },
    rotate: function (m /*m3*/, mo, rz, dst, dsto) {
        var m00 = m[mo + 0];
        var m01 = m[mo + 1];
        var m02 = m[mo + 2];
        var m10 = m[mo + 3];
        var m11 = m[mo + 4];
        var m12 = m[mo + 5];
        var c = Math.cos(rz);
        var s = Math.sin(rz);
        dst[dsto + 0] = c * m00 - s * m10;
        dst[dsto + 1] = c * m01 - s * m11;
        dst[dsto + 2] = c * m02 - s * m12;
        dst[dsto + 3] = c * m10 + s * m00;
        dst[dsto + 4] = c * m11 + s * m01;
        dst[dsto + 5] = c * m12 + s * m02;
        if (dst !== m || dsto !== mo) {
            dst[dsto + 6] = m[mo + 6];
            dst[dsto + 7] = m[mo + 7];
            dst[dsto + 8] = m[mo + 8];
        }
    },
    inverse: function (m /*m3*/, mo, dst, dsto) {
        var m00 = m[mo + 0 * 3 + 0];
        var m01 = m[mo + 0 * 3 + 1];
        var m02 = m[mo + 0 * 3 + 2];
        var m10 = m[mo + 1 * 3 + 0];
        var m11 = m[mo + 1 * 3 + 1];
        var m12 = m[mo + 1 * 3 + 2];
        var m20 = m[mo + 2 * 3 + 0];
        var m21 = m[mo + 2 * 3 + 1];
        var m22 = m[mo + 2 * 3 + 2];
        var t00 = m11 * m22 - m12 * m21;
        var t10 = m01 * m22 - m02 * m21;
        var t20 = m01 * m12 - m02 * m11;
        var d = 1.0 / (m00 * t00 - m10 * t10 + m20 * t20);
        dst[dsto + 0] = d * t00;
        dst[dsto + 1] = -d * t10;
        dst[dsto + 2] = d * t20;
        dst[dsto + 3] = -d * (m10 * m22 - m12 * m20);
        dst[dsto + 4] = d * (m00 * m22 - m02 * m20);
        dst[dsto + 5] = -d * (m00 * m12 - m02 * m10);
        dst[dsto + 6] = d * (m10 * m21 - m11 * m20);
        dst[dsto + 7] = -d * (m00 * m21 - m01 * m20);
        dst[dsto + 8] = d * (m00 * m11 - m01 * m10);
    },
    multiply: function (mA /*m3*/, mAo, mB /*m3*/, mBo, dst, dsto) {
        var a00 = mA[mAo + 0 * 3 + 0];
        var a01 = mA[mAo + 0 * 3 + 1];
        var a02 = mA[mAo + 0 * 3 + 2];
        var a10 = mA[mAo + 1 * 3 + 0];
        var a11 = mA[mAo + 1 * 3 + 1];
        var a12 = mA[mAo + 1 * 3 + 2];
        var a20 = mA[mAo + 2 * 3 + 0];
        var a21 = mA[mAo + 2 * 3 + 1];
        var a22 = mA[mAo + 2 * 3 + 2];
        var b00 = mB[mBo + 0 * 3 + 0];
        var b01 = mB[mBo + 0 * 3 + 1];
        var b02 = mB[mBo + 0 * 3 + 2];
        var b10 = mB[mBo + 1 * 3 + 0];
        var b11 = mB[mBo + 1 * 3 + 1];
        var b12 = mB[mBo + 1 * 3 + 2];
        var b20 = mB[mBo + 2 * 3 + 0];
        var b21 = mB[mBo + 2 * 3 + 1];
        var b22 = mB[mBo + 2 * 3 + 2];
        (dst[dsto + 0] = b00 * a00 + b01 * a10 + b02 * a20),
            (dst[dsto + 1] = b00 * a01 + b01 * a11 + b02 * a21),
            (dst[dsto + 2] = b00 * a02 + b01 * a12 + b02 * a22),
            (dst[dsto + 3] = b10 * a00 + b11 * a10 + b12 * a20),
            (dst[dsto + 4] = b10 * a01 + b11 * a11 + b12 * a21),
            (dst[dsto + 5] = b10 * a02 + b11 * a12 + b12 * a22),
            (dst[dsto + 6] = b20 * a00 + b21 * a10 + b22 * a20),
            (dst[dsto + 7] = b20 * a01 + b21 * a11 + b22 * a21),
            (dst[dsto + 8] = b20 * a02 + b21 * a12 + b22 * a22);
    },
    transformPoint: function (m /*m4*/, mo, v /*v3*/, vo, dst, dsto) {
        var v0 = v[vo + 0];
        var v1 = v[vo + 1];
        var d = v0 * m[mo + 0 * 3 + 2] + v1 * m[mo + 1 * 3 + 2] + m[mo + 2 * 3 + 2];
        (dst[dsto + 0] = (v0 * m[mo + 0 * 3 + 0] + v1 * m[mo + 1 * 3 + 0] + m[mo + 2 * 3 + 0]) / d), (dst[dsto + 1] = (v0 * m[mo + 0 * 3 + 1] + v1 * m[mo + 1 * 3 + 1] + m[mo + 2 * 3 + 1]) / d);
    },
    decomposeScale: function (m /*m3*/, mo, dst, dsto) {
        var m11 = m[mo + 0];
        var m12 = m[mo + 1];
        var m21 = m[mo + 3];
        var m22 = m[mo + 4];
        dst[dsto] = Math.sqrt(m11 * m11 + m12 * m12);
        dst[dsto + 1] = Math.sqrt(m21 * m21 + m22 * m22);
    },
    copy: function (m /*m3*/, mo, dst, dsto) {
        if (m.length === 9) {
            dst.set(m, dsto);
        }
        else {
            for (var i = 0; i < 9; i++) {
                dst[dsto + i] = m[mo + i];
            }
        }
    },
};
exports.m4Helper = {
    lookAt: function (position, positionOffset, target, targetOffset, up, upOffset, dst, dsto) {
        var zAxis = tempV3_1;
        var xAxis = tempV3_2;
        var yAxis = tempV3_3;
        exports.v3Helper.sub(position, positionOffset, target, targetOffset, zAxis, 0);
        exports.v3Helper.normalize(zAxis, 0, zAxis, 0);
        exports.v3Helper.cross(up, upOffset, zAxis, 0, xAxis, 0);
        exports.v3Helper.normalize(xAxis, 0, xAxis, 0);
        exports.v3Helper.cross(zAxis, 0, xAxis, 0, yAxis, 0);
        exports.v3Helper.normalize(yAxis, 0, yAxis, 0);
        dst.set(DEFAULT_IDENTITY, dsto);
        dst[dsto] = xAxis[0];
        dst[dsto + 1] = xAxis[1];
        dst[dsto + 2] = xAxis[2];
        dst[dsto + 4] = yAxis[0];
        dst[dsto + 5] = yAxis[1];
        dst[dsto + 6] = yAxis[2];
        dst[dsto + 8] = zAxis[0];
        dst[dsto + 9] = zAxis[1];
        dst[dsto + 10] = zAxis[2];
        dst[dsto + 12] = position[positionOffset];
        dst[dsto + 13] = position[positionOffset + 1];
        dst[dsto + 14] = position[positionOffset + 2];
    },
    perspective: function (fieldOfViewRadians, aspect, near, far, dst, dsto) {
        var f = Math.tan(Math.PI * 0.5 - 0.5 * fieldOfViewRadians);
        var rangeInv = 1.0 / (near - far);
        dst.set(DEFAULT_PERSPECTIVE, dsto);
        dst[dsto] = f / aspect;
        dst[dsto + 5] = f;
        dst[dsto + 10] = (near + far) * rangeInv;
        dst[dsto + 14] = near * far * rangeInv * 2;
    },
    orthographic: function (left, right, bottom, top, near, far, dst, dsto) {
        dst.set(DEFAULT_ORTHO, dsto);
        dst[dsto] = 2 / (right - left);
        dst[dsto + 5] = 2 / (top - bottom);
        dst[dsto + 10] = 2 / (near - far);
        dst[dsto + 12] = (left + right) / (left - right);
        dst[dsto + 13] = (bottom + top) / (bottom - top);
        dst[dsto + 14] = (near + far) / (near - far);
    },
    xRotation: function (rad, dst, dsto) {
        var c = Math.cos(rad);
        var s = Math.sin(rad);
        dst.set(DEFAULT_IDENTITY, dsto);
        dst[dsto + 5] = c;
        dst[dsto + 6] = s;
        dst[dsto + 9] = -s;
        dst[dsto + 10] = c;
    },
    yRotation: function (rad, dst, dsto) {
        var c = Math.cos(rad);
        var s = Math.sin(rad);
        dst.set(DEFAULT_IDENTITY, dsto);
        dst[dsto] = c;
        dst[dsto + 2] = -s;
        dst[dsto + 8] = s;
        dst[dsto + 10] = c;
    },
    zRotation: function (rad, dst, dsto) {
        var c = Math.cos(rad);
        var s = Math.sin(rad);
        dst.set(DEFAULT_IDENTITY, dsto);
        dst[dsto] = c;
        dst[dsto + 1] = s;
        dst[dsto + 4] = -s;
        dst[dsto + 5] = c;
    },
    axisRotation: function (axis, axiso, angleInRadians, dst, dsto) {
        var x = axis[axiso];
        var y = axis[axiso + 1];
        var z = axis[axiso + 2];
        var n = Math.sqrt(x * x + y * y + z * z);
        x /= n;
        y /= n;
        z /= n;
        var xx = x * x;
        var yy = y * y;
        var zz = z * z;
        var c = Math.cos(angleInRadians);
        var s = Math.sin(angleInRadians);
        var oneMinusCosine = 1 - c;
        dst.set(DEFAULT_IDENTITY, dsto);
        dst[dsto] = xx + (1 - xx) * c;
        dst[dsto + 1] = x * y * oneMinusCosine + z * s;
        dst[dsto + 2] = x * z * oneMinusCosine - y * s;
        dst[dsto + 4] = x * y * oneMinusCosine - z * s;
        dst[dsto + 5] = yy + (1 - yy) * c;
        dst[dsto + 6] = y * z * oneMinusCosine + x * s;
        dst[dsto + 8] = x * z * oneMinusCosine + y * s;
        dst[dsto + 9] = y * z * oneMinusCosine - x * s;
        dst[dsto + 10] = zz + (1 - zz) * c;
        return dst;
    },
    composeTRS: function (trans, transo, rot, roto, scale, scaleo, dst, dsto) {
        if (rot.length === 16) {
            dst.set(rot, dsto);
        }
        else {
            dst[dsto + 3] = 0;
            dst[dsto + 7] = 0;
            dst[dsto + 11] = 0;
            dst[dsto + 15] = 0;
        }
        var sx = scale[scaleo];
        var sy = scale[scaleo + 1];
        var sz = scale[scaleo + 2];
        dst[dsto + 0] = rot[roto + 0] * sx;
        dst[dsto + 1] = rot[roto + 1] * sx;
        dst[dsto + 2] = rot[roto + 2] * sx;
        dst[dsto + 4] = rot[roto + 4] * sy;
        dst[dsto + 5] = rot[roto + 5] * sy;
        dst[dsto + 6] = rot[roto + 6] * sy;
        dst[dsto + 8] = rot[roto + 8] * sz;
        dst[dsto + 9] = rot[roto + 9] * sz;
        dst[dsto + 10] = rot[roto + 10] * sz;
        dst[dsto + 12] = trans[transo];
        dst[dsto + 13] = trans[transo + 1];
        dst[dsto + 14] = trans[transo + 2];
    },
    composeTQS: function (trans, transo, quat, quato, scale, scaleo, dst, dsto) {
        exports.quatHelper.toMatrix4(quat, quato, tempM4_1, 0);
        exports.m4Helper.composeTRS(trans, transo, tempM4_1, 0, scale, scaleo, dst, dsto);
    },
    translate: function (m /*m4*/, mo, tx, ty, tz, dst, dsto) {
        var m00 = m[mo + 0];
        var m01 = m[mo + 1];
        var m02 = m[mo + 2];
        var m03 = m[mo + 3];
        var m10 = m[mo + 1 * 4 + 0];
        var m11 = m[mo + 1 * 4 + 1];
        var m12 = m[mo + 1 * 4 + 2];
        var m13 = m[mo + 1 * 4 + 3];
        var m20 = m[mo + 2 * 4 + 0];
        var m21 = m[mo + 2 * 4 + 1];
        var m22 = m[mo + 2 * 4 + 2];
        var m23 = m[mo + 2 * 4 + 3];
        var m30 = m[mo + 3 * 4 + 0];
        var m31 = m[mo + 3 * 4 + 1];
        var m32 = m[mo + 3 * 4 + 2];
        var m33 = m[mo + 3 * 4 + 3];
        if (m.length === 16) {
            // mo === 0, use Float32Array.set
            dst.set(m, dsto);
        }
        else if (dst !== m || dsto !== mo) {
            dst[dsto] = m00;
            dst[dsto + 1] = m01;
            dst[dsto + 2] = m02;
            dst[dsto + 3] = m03;
            dst[dsto + 4] = m10;
            dst[dsto + 5] = m11;
            dst[dsto + 6] = m12;
            dst[dsto + 7] = m13;
            dst[dsto + 8] = m20;
            dst[dsto + 9] = m21;
            dst[dsto + 10] = m22;
            dst[dsto + 11] = m23;
        }
        dst[dsto + 12] = m00 * tx + m10 * ty + m20 * tz + m30;
        dst[dsto + 13] = m01 * tx + m11 * ty + m21 * tz + m31;
        dst[dsto + 14] = m02 * tx + m12 * ty + m22 * tz + m32;
        dst[dsto + 15] = m03 * tx + m13 * ty + m23 * tz + m33;
    },
    scale: function (m /*m4*/, mo, sx, sy, sz, dst, dsto) {
        dst[dsto + 0] = sx * m[mo + 0 * 4 + 0];
        dst[dsto + 1] = sx * m[mo + 0 * 4 + 1];
        dst[dsto + 2] = sx * m[mo + 0 * 4 + 2];
        dst[dsto + 3] = sx * m[mo + 0 * 4 + 3];
        dst[dsto + 4] = sy * m[mo + 1 * 4 + 0];
        dst[dsto + 5] = sy * m[mo + 1 * 4 + 1];
        dst[dsto + 6] = sy * m[mo + 1 * 4 + 2];
        dst[dsto + 7] = sy * m[mo + 1 * 4 + 3];
        dst[dsto + 8] = sz * m[mo + 2 * 4 + 0];
        dst[dsto + 9] = sz * m[mo + 2 * 4 + 1];
        dst[dsto + 10] = sz * m[mo + 2 * 4 + 2];
        dst[dsto + 11] = sz * m[mo + 2 * 4 + 3];
        if (dst !== m || dsto !== mo) {
            dst[dsto + 12] = m[mo + 12];
            dst[dsto + 13] = m[mo + 13];
            dst[dsto + 14] = m[mo + 14];
            dst[dsto + 15] = m[mo + 15];
        }
    },
    xRotate: function (m /*m4*/, mo, rx, dst, dsto) {
        if (m.length === 16) {
            // mo === 0, use Float32Array.set
            dst.set(m, dsto);
        }
        else if (dst !== m || dsto !== mo) {
            dst[dsto + 0] = m[mo + 0];
            dst[dsto + 1] = m[mo + 1];
            dst[dsto + 2] = m[mo + 2];
            dst[dsto + 3] = m[mo + 3];
            dst[dsto + 12] = m[mo + 12];
            dst[dsto + 13] = m[mo + 13];
            dst[dsto + 14] = m[mo + 14];
            dst[dsto + 15] = m[mo + 15];
        }
        var m10 = m[mo + 4];
        var m11 = m[mo + 5];
        var m12 = m[mo + 6];
        var m13 = m[mo + 7];
        var m20 = m[mo + 8];
        var m21 = m[mo + 9];
        var m22 = m[mo + 10];
        var m23 = m[mo + 11];
        var c = Math.cos(rx);
        var s = Math.sin(rx);
        dst[dsto + 4] = c * m10 + s * m20;
        dst[dsto + 5] = c * m11 + s * m21;
        dst[dsto + 6] = c * m12 + s * m22;
        dst[dsto + 7] = c * m13 + s * m23;
        dst[dsto + 8] = c * m20 - s * m10;
        dst[dsto + 9] = c * m21 - s * m11;
        dst[dsto + 10] = c * m22 - s * m12;
        dst[dsto + 11] = c * m23 - s * m13;
    },
    yRotate: function (m /*m4*/, mo, ry, dst, dsto) {
        if (m.length === 16) {
            // mo === 0, use Float32Array.set
            dst.set(m, dsto);
        }
        else if (dst !== m || dsto !== mo) {
            dst[dsto + 4] = m[mo + 4];
            dst[dsto + 5] = m[mo + 5];
            dst[dsto + 6] = m[mo + 6];
            dst[dsto + 7] = m[mo + 7];
            dst[dsto + 12] = m[mo + 12];
            dst[dsto + 13] = m[mo + 13];
            dst[dsto + 14] = m[mo + 14];
            dst[dsto + 15] = m[mo + 15];
        }
        var m00 = m[mo + 0 * 4 + 0];
        var m01 = m[mo + 0 * 4 + 1];
        var m02 = m[mo + 0 * 4 + 2];
        var m03 = m[mo + 0 * 4 + 3];
        var m20 = m[mo + 2 * 4 + 0];
        var m21 = m[mo + 2 * 4 + 1];
        var m22 = m[mo + 2 * 4 + 2];
        var m23 = m[mo + 2 * 4 + 3];
        var c = Math.cos(ry);
        var s = Math.sin(ry);
        dst[dsto + 0] = c * m00 - s * m20;
        dst[dsto + 1] = c * m01 - s * m21;
        dst[dsto + 2] = c * m02 - s * m22;
        dst[dsto + 3] = c * m03 - s * m23;
        dst[dsto + 8] = c * m20 + s * m00;
        dst[dsto + 9] = c * m21 + s * m01;
        dst[dsto + 10] = c * m22 + s * m02;
        dst[dsto + 11] = c * m23 + s * m03;
    },
    zRotate: function (m /*m4*/, mo, rz, dst, dsto) {
        if (m.length === 16) {
            // mo === 0, use Float32Array.set
            dst.set(m, dsto);
        }
        else if (dst !== m || dsto !== mo) {
            dst[dsto + 8] = m[mo + 8];
            dst[dsto + 9] = m[mo + 9];
            dst[dsto + 10] = m[mo + 10];
            dst[dsto + 11] = m[mo + 11];
            dst[dsto + 12] = m[mo + 12];
            dst[dsto + 13] = m[mo + 13];
            dst[dsto + 14] = m[mo + 14];
            dst[dsto + 15] = m[mo + 15];
        }
        var m00 = m[mo + 0 * 4 + 0];
        var m01 = m[mo + 0 * 4 + 1];
        var m02 = m[mo + 0 * 4 + 2];
        var m03 = m[mo + 0 * 4 + 3];
        var m10 = m[mo + 1 * 4 + 0];
        var m11 = m[mo + 1 * 4 + 1];
        var m12 = m[mo + 1 * 4 + 2];
        var m13 = m[mo + 1 * 4 + 3];
        var c = Math.cos(rz);
        var s = Math.sin(rz);
        dst[dsto + 0] = c * m00 + s * m10;
        dst[dsto + 1] = c * m01 + s * m11;
        dst[dsto + 2] = c * m02 + s * m12;
        dst[dsto + 3] = c * m03 + s * m13;
        dst[dsto + 4] = c * m10 - s * m00;
        dst[dsto + 5] = c * m11 - s * m01;
        dst[dsto + 6] = c * m12 - s * m02;
        dst[dsto + 7] = c * m13 - s * m03;
    },
    axisRotate: function (m /*m4*/, mo, axis, axiso, angleInRadians, dst, dsto) {
        var x = axis[axiso];
        var y = axis[axiso + 1];
        var z = axis[axiso + 2];
        var n = Math.sqrt(x * x + y * y + z * z);
        x /= n;
        y /= n;
        z /= n;
        var xx = x * x;
        var yy = y * y;
        var zz = z * z;
        var c = Math.cos(angleInRadians);
        var s = Math.sin(angleInRadians);
        var oneMinusCosine = 1 - c;
        var r00 = xx + (1 - xx) * c;
        var r01 = x * y * oneMinusCosine + z * s;
        var r02 = x * z * oneMinusCosine - y * s;
        var r10 = x * y * oneMinusCosine - z * s;
        var r11 = yy + (1 - yy) * c;
        var r12 = y * z * oneMinusCosine + x * s;
        var r20 = x * z * oneMinusCosine + y * s;
        var r21 = y * z * oneMinusCosine - x * s;
        var r22 = zz + (1 - zz) * c;
        var m00 = m[mo + 0];
        var m01 = m[mo + 1];
        var m02 = m[mo + 2];
        var m03 = m[mo + 3];
        var m10 = m[mo + 4];
        var m11 = m[mo + 5];
        var m12 = m[mo + 6];
        var m13 = m[mo + 7];
        var m20 = m[mo + 8];
        var m21 = m[mo + 9];
        var m22 = m[mo + 10];
        var m23 = m[mo + 11];
        dst[dsto + 0] = r00 * m00 + r01 * m10 + r02 * m20;
        dst[dsto + 1] = r00 * m01 + r01 * m11 + r02 * m21;
        dst[dsto + 2] = r00 * m02 + r01 * m12 + r02 * m22;
        dst[dsto + 3] = r00 * m03 + r01 * m13 + r02 * m23;
        dst[dsto + 4] = r10 * m00 + r11 * m10 + r12 * m20;
        dst[dsto + 5] = r10 * m01 + r11 * m11 + r12 * m21;
        dst[dsto + 6] = r10 * m02 + r11 * m12 + r12 * m22;
        dst[dsto + 7] = r10 * m03 + r11 * m13 + r12 * m23;
        dst[dsto + 8] = r20 * m00 + r21 * m10 + r22 * m20;
        dst[dsto + 9] = r20 * m01 + r21 * m11 + r22 * m21;
        dst[dsto + 10] = r20 * m02 + r21 * m12 + r22 * m22;
        dst[dsto + 11] = r20 * m03 + r21 * m13 + r22 * m23;
        if (dst !== m || dsto !== mo) {
            dst[dsto + 12] = m[mo + 12];
            dst[dsto + 13] = m[mo + 13];
            dst[dsto + 14] = m[mo + 14];
            dst[dsto + 15] = m[mo + 15];
        }
    },
    // todo: 这里考虑下沉native?
    multiply: function (mA /*m4*/, mAo, mB /*m4*/, mBo, dst, dsto) {
        var b00 = mB[mBo + 0 * 4 + 0];
        var b01 = mB[mBo + 0 * 4 + 1];
        var b02 = mB[mBo + 0 * 4 + 2];
        var b03 = mB[mBo + 0 * 4 + 3];
        var b10 = mB[mBo + 1 * 4 + 0];
        var b11 = mB[mBo + 1 * 4 + 1];
        var b12 = mB[mBo + 1 * 4 + 2];
        var b13 = mB[mBo + 1 * 4 + 3];
        var b20 = mB[mBo + 2 * 4 + 0];
        var b21 = mB[mBo + 2 * 4 + 1];
        var b22 = mB[mBo + 2 * 4 + 2];
        var b23 = mB[mBo + 2 * 4 + 3];
        var b30 = mB[mBo + 3 * 4 + 0];
        var b31 = mB[mBo + 3 * 4 + 1];
        var b32 = mB[mBo + 3 * 4 + 2];
        var b33 = mB[mBo + 3 * 4 + 3];
        var a00 = mA[mAo + 0 * 4 + 0];
        var a01 = mA[mAo + 0 * 4 + 1];
        var a02 = mA[mAo + 0 * 4 + 2];
        var a03 = mA[mAo + 0 * 4 + 3];
        var a10 = mA[mAo + 1 * 4 + 0];
        var a11 = mA[mAo + 1 * 4 + 1];
        var a12 = mA[mAo + 1 * 4 + 2];
        var a13 = mA[mAo + 1 * 4 + 3];
        var a20 = mA[mAo + 2 * 4 + 0];
        var a21 = mA[mAo + 2 * 4 + 1];
        var a22 = mA[mAo + 2 * 4 + 2];
        var a23 = mA[mAo + 2 * 4 + 3];
        var a30 = mA[mAo + 3 * 4 + 0];
        var a31 = mA[mAo + 3 * 4 + 1];
        var a32 = mA[mAo + 3 * 4 + 2];
        var a33 = mA[mAo + 3 * 4 + 3];
        dst[dsto + 0] = b00 * a00 + b01 * a10 + b02 * a20 + b03 * a30;
        dst[dsto + 1] = b00 * a01 + b01 * a11 + b02 * a21 + b03 * a31;
        dst[dsto + 2] = b00 * a02 + b01 * a12 + b02 * a22 + b03 * a32;
        dst[dsto + 3] = b00 * a03 + b01 * a13 + b02 * a23 + b03 * a33;
        dst[dsto + 4] = b10 * a00 + b11 * a10 + b12 * a20 + b13 * a30;
        dst[dsto + 5] = b10 * a01 + b11 * a11 + b12 * a21 + b13 * a31;
        dst[dsto + 6] = b10 * a02 + b11 * a12 + b12 * a22 + b13 * a32;
        dst[dsto + 7] = b10 * a03 + b11 * a13 + b12 * a23 + b13 * a33;
        dst[dsto + 8] = b20 * a00 + b21 * a10 + b22 * a20 + b23 * a30;
        dst[dsto + 9] = b20 * a01 + b21 * a11 + b22 * a21 + b23 * a31;
        dst[dsto + 10] = b20 * a02 + b21 * a12 + b22 * a22 + b23 * a32;
        dst[dsto + 11] = b20 * a03 + b21 * a13 + b22 * a23 + b23 * a33;
        dst[dsto + 12] = b30 * a00 + b31 * a10 + b32 * a20 + b33 * a30;
        dst[dsto + 13] = b30 * a01 + b31 * a11 + b32 * a21 + b33 * a31;
        dst[dsto + 14] = b30 * a02 + b31 * a12 + b32 * a22 + b33 * a32;
        dst[dsto + 15] = b30 * a03 + b31 * a13 + b32 * a23 + b33 * a33;
    },
    transformVector: function (m /*m4*/, mo, v /*v4*/, vo, dst, dsto) {
        var dstBase = 0;
        var mBase = 0;
        for (var i = 0; i < 4; ++i) {
            dstBase = dsto + i;
            mBase = mo + i;
            dst[dstBase] = 0.0;
            for (var j = 0; j < 4; ++j) {
                dst[dstBase] += v[vo + j] * m[mBase + j * 4];
            }
        }
    },
    transformDirection: function (m /*m4*/, mo, v /*v3*/, vo, dst, dsto) {
        var v0 = v[vo + 0];
        var v1 = v[vo + 1];
        var v2 = v[vo + 2];
        dst[dsto + 0] = v0 * m[mo + 0 * 4 + 0] + v1 * m[mo + 1 * 4 + 0] + v2 * m[mo + 2 * 4 + 0];
        dst[dsto + 1] = v0 * m[mo + 0 * 4 + 1] + v1 * m[mo + 1 * 4 + 1] + v2 * m[mo + 2 * 4 + 1];
        dst[dsto + 2] = v0 * m[mo + 0 * 4 + 2] + v1 * m[mo + 1 * 4 + 2] + v2 * m[mo + 2 * 4 + 2];
    },
    transformPoint: function (m /*m4*/, mo, v /*v3*/, vo, dst, dsto) {
        var v0 = v[vo + 0];
        var v1 = v[vo + 1];
        var v2 = v[vo + 2];
        var d = v0 * m[mo + 0 * 4 + 3] + v1 * m[mo + 1 * 4 + 3] + v2 * m[mo + 2 * 4 + 3] + m[mo + 3 * 4 + 3];
        dst[dsto + 0] = (v0 * m[mo + 0 * 4 + 0] + v1 * m[mo + 1 * 4 + 0] + v2 * m[mo + 2 * 4 + 0] + m[mo + 3 * 4 + 0]) / d;
        dst[dsto + 1] = (v0 * m[mo + 0 * 4 + 1] + v1 * m[mo + 1 * 4 + 1] + v2 * m[mo + 2 * 4 + 1] + m[mo + 3 * 4 + 1]) / d;
        dst[dsto + 2] = (v0 * m[mo + 0 * 4 + 2] + v1 * m[mo + 1 * 4 + 2] + v2 * m[mo + 2 * 4 + 2] + m[mo + 3 * 4 + 2]) / d;
    },
    decomposeTransRotMatScale: function (m /*m4*/, mo, trans, transo, rot, roto, scale, scaleo) {
        trans[transo + 0] = m[mo + 12];
        trans[transo + 1] = m[mo + 13];
        trans[transo + 2] = m[mo + 14];
        var m11 = m[mo + 0];
        var m12 = m[mo + 1];
        var m13 = m[mo + 2];
        var m21 = m[mo + 4];
        var m22 = m[mo + 5];
        var m23 = m[mo + 6];
        var m31 = m[mo + 8];
        var m32 = m[mo + 9];
        var m33 = m[mo + 10];
        var sX = (scale[scaleo + 0] = Math.sqrt(m11 * m11 + m12 * m12 + m13 * m13));
        var sY = (scale[scaleo + 1] = Math.sqrt(m21 * m21 + m22 * m22 + m23 * m23));
        var sZ = (scale[scaleo + 2] = Math.sqrt(m31 * m31 + m32 * m32 + m33 * m33));
        rot.set(DEFAULT_IDENTITY, roto);
        if (sX === 0 || sY === 0 || sZ === 0) {
            return false;
        }
        var at = tempV3_1;
        at[0] = m31 / sZ;
        at[1] = m32 / sZ;
        at[2] = m33 / sZ;
        var tempRight = tempV3_2;
        tempRight[0] = m11 / sX;
        tempRight[1] = m12 / sX;
        tempRight[2] = m13 / sX;
        var up = tempV3_3;
        exports.v3Helper.cross(at, 0, tempRight, 0, up, 0);
        var right = tempRight;
        exports.v3Helper.cross(up, 0, at, 0, right, 0);
        rot.set(right, roto);
        rot.set(up, roto + 4);
        rot.set(at, roto + 8);
        // tslint:disable-next-line:no-unused-expression
        rot[roto + 0] * m11 + rot[roto + 1] * m12 + rot[roto + 2] * m13 < 0.0 && (scale[scaleo + 0] = -sX);
        // tslint:disable-next-line:no-unused-expression
        rot[roto + 4] * m21 + rot[roto + 5] * m22 + rot[roto + 6] * m23 < 0.0 && (scale[scaleo + 1] = -sY);
        // tslint:disable-next-line:no-unused-expression
        rot[roto + 8] * m31 + rot[roto + 9] * m32 + rot[roto + 10] * m33 < 0.0 && (scale[scaleo + 2] = -sZ);
        return true;
    },
    inverse: function (m /*m4*/, mo, dst, dsto) {
        var m00 = m[mo + 0 * 4 + 0];
        var m01 = m[mo + 0 * 4 + 1];
        var m02 = m[mo + 0 * 4 + 2];
        var m03 = m[mo + 0 * 4 + 3];
        var m10 = m[mo + 1 * 4 + 0];
        var m11 = m[mo + 1 * 4 + 1];
        var m12 = m[mo + 1 * 4 + 2];
        var m13 = m[mo + 1 * 4 + 3];
        var m20 = m[mo + 2 * 4 + 0];
        var m21 = m[mo + 2 * 4 + 1];
        var m22 = m[mo + 2 * 4 + 2];
        var m23 = m[mo + 2 * 4 + 3];
        var m30 = m[mo + 3 * 4 + 0];
        var m31 = m[mo + 3 * 4 + 1];
        var m32 = m[mo + 3 * 4 + 2];
        var m33 = m[mo + 3 * 4 + 3];
        var tmp_0 = m22 * m33;
        var tmp_1 = m32 * m23;
        var tmp_2 = m12 * m33;
        var tmp_3 = m32 * m13;
        var tmp_4 = m12 * m23;
        var tmp_5 = m22 * m13;
        var tmp_6 = m02 * m33;
        var tmp_7 = m32 * m03;
        var tmp_8 = m02 * m23;
        var tmp_9 = m22 * m03;
        var tmp_10 = m02 * m13;
        var tmp_11 = m12 * m03;
        var tmp_12 = m20 * m31;
        var tmp_13 = m30 * m21;
        var tmp_14 = m10 * m31;
        var tmp_15 = m30 * m11;
        var tmp_16 = m10 * m21;
        var tmp_17 = m20 * m11;
        var tmp_18 = m00 * m31;
        var tmp_19 = m30 * m01;
        var tmp_20 = m00 * m21;
        var tmp_21 = m20 * m01;
        var tmp_22 = m00 * m11;
        var tmp_23 = m10 * m01;
        var t0 = tmp_0 * m11 + tmp_3 * m21 + tmp_4 * m31 - (tmp_1 * m11 + tmp_2 * m21 + tmp_5 * m31);
        var t1 = tmp_1 * m01 + tmp_6 * m21 + tmp_9 * m31 - (tmp_0 * m01 + tmp_7 * m21 + tmp_8 * m31);
        var t2 = tmp_2 * m01 + tmp_7 * m11 + tmp_10 * m31 - (tmp_3 * m01 + tmp_6 * m11 + tmp_11 * m31);
        var t3 = tmp_5 * m01 + tmp_8 * m11 + tmp_11 * m21 - (tmp_4 * m01 + tmp_9 * m11 + tmp_10 * m21);
        var d = 1.0 / (m00 * t0 + m10 * t1 + m20 * t2 + m30 * t3);
        dst[dsto + 0] = d * t0;
        dst[dsto + 1] = d * t1;
        dst[dsto + 2] = d * t2;
        dst[dsto + 3] = d * t3;
        dst[dsto + 4] = d * (tmp_1 * m10 + tmp_2 * m20 + tmp_5 * m30 - (tmp_0 * m10 + tmp_3 * m20 + tmp_4 * m30));
        dst[dsto + 5] = d * (tmp_0 * m00 + tmp_7 * m20 + tmp_8 * m30 - (tmp_1 * m00 + tmp_6 * m20 + tmp_9 * m30));
        dst[dsto + 6] = d * (tmp_3 * m00 + tmp_6 * m10 + tmp_11 * m30 - (tmp_2 * m00 + tmp_7 * m10 + tmp_10 * m30));
        dst[dsto + 7] = d * (tmp_4 * m00 + tmp_9 * m10 + tmp_10 * m20 - (tmp_5 * m00 + tmp_8 * m10 + tmp_11 * m20));
        dst[dsto + 8] = d * (tmp_12 * m13 + tmp_15 * m23 + tmp_16 * m33 - (tmp_13 * m13 + tmp_14 * m23 + tmp_17 * m33));
        dst[dsto + 9] = d * (tmp_13 * m03 + tmp_18 * m23 + tmp_21 * m33 - (tmp_12 * m03 + tmp_19 * m23 + tmp_20 * m33));
        dst[dsto + 10] = d * (tmp_14 * m03 + tmp_19 * m13 + tmp_22 * m33 - (tmp_15 * m03 + tmp_18 * m13 + tmp_23 * m33));
        dst[dsto + 11] = d * (tmp_17 * m03 + tmp_20 * m13 + tmp_23 * m23 - (tmp_16 * m03 + tmp_21 * m13 + tmp_22 * m23));
        dst[dsto + 12] = d * (tmp_14 * m22 + tmp_17 * m32 + tmp_13 * m12 - (tmp_16 * m32 + tmp_12 * m12 + tmp_15 * m22));
        dst[dsto + 13] = d * (tmp_20 * m32 + tmp_12 * m02 + tmp_19 * m22 - (tmp_18 * m22 + tmp_21 * m32 + tmp_13 * m02));
        dst[dsto + 14] = d * (tmp_18 * m12 + tmp_23 * m32 + tmp_15 * m02 - (tmp_22 * m32 + tmp_14 * m02 + tmp_19 * m12));
        dst[dsto + 15] = d * (tmp_22 * m22 + tmp_16 * m02 + tmp_21 * m12 - (tmp_20 * m12 + tmp_23 * m22 + tmp_17 * m02));
    },
    transpose: function (m /*m4*/, mo, dst, dsto) {
        dst[dsto + 0] = m[mo + 0];
        dst[dsto + 1] = m[mo + 4];
        dst[dsto + 2] = m[mo + 8];
        dst[dsto + 3] = m[mo + 12];
        dst[dsto + 4] = m[mo + 1];
        dst[dsto + 5] = m[mo + 5];
        dst[dsto + 6] = m[mo + 9];
        dst[dsto + 7] = m[mo + 13];
        dst[dsto + 8] = m[mo + 2];
        dst[dsto + 9] = m[mo + 6];
        dst[dsto + 10] = m[mo + 10];
        dst[dsto + 11] = m[mo + 14];
        dst[dsto + 12] = m[mo + 3];
        dst[dsto + 13] = m[mo + 7];
        dst[dsto + 14] = m[mo + 11];
        dst[dsto + 15] = m[mo + 15];
    },
    composeRST3toRST4: function (m /*m3*/, mo, dst, dsto) {
        dst.set(DEFAULT_IDENTITY, dsto);
        dst[dsto + 0] = m[mo + 0];
        dst[dsto + 1] = m[mo + 1];
        dst[dsto + 4] = m[mo + 3];
        dst[dsto + 5] = m[mo + 4];
        dst[dsto + 10] = 1;
        dst[dsto + 12] = m[mo + 6];
        dst[dsto + 13] = m[mo + 7];
        dst[dsto + 15] = m[mo + 8];
    },
    copy: function (m /*m4*/, mo, dst, dsto) {
        if (m.length === 16) {
            dst.set(m, dsto);
        }
        else {
            for (var i = 0; i < 16; i++) {
                dst[dsto + i] = m[mo + i];
            }
        }
    },
};
var tempV3_1 = new Float32Array(3);
var tempV3_2 = new Float32Array(3);
var tempV3_3 = new Float32Array(3);
var tempV4 = new Float32Array(4);
var DEFAULT_IDENTITY = new Float32Array(16);
DEFAULT_IDENTITY.set([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1], 0);
var DEFAULT_PERSPECTIVE = new Float32Array(16).fill(0);
DEFAULT_PERSPECTIVE[11] = -1;
var DEFAULT_ORTHO = new Float32Array(16).fill(0);
DEFAULT_ORTHO[15] = 1;
var tempV3ForwardRH = new Float32Array([0, 0, -1]);
var tempV3Up = new Float32Array([0, 1, 0]);
var tempV3Zero = new Float32Array([0, 0, 0]);
var tempM4_1 = new Float32Array(16);
var tempM4_2 = new Float32Array(16);


/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
// import m3 from "../../lib/3rd/2dmath";
var vector2_1 = tslib_1.__importDefault(__webpack_require__(22));
var utils_1 = __webpack_require__(20);
// read only temp value
var tempIdentityArray = new Float32Array(9);
tempIdentityArray.set([1, 0, 0, 0, 1, 0, 0, 0, 1], 0);
var Matrix3 = /** @class */ (function () {
    function Matrix3(raw, offset) {
        this._raw = raw ? raw : new Float32Array(9);
        this._offset = offset ? offset : 0;
    }
    Object.defineProperty(Matrix3, "IDENTITY", {
        /**
         * 单位矩阵
         * 每次访问会重新创建
         * @readonly
         * @static
         * @type {Matrix3}
         * @memberof Matrix3
         */
        get: function () {
            // return new Matrix3(m3.identity());
            var ret = new Matrix3();
            ret._raw.set(tempIdentityArray);
            return ret;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * 使用一个数组创建
     * 此操作会拷贝一份数组
     *
     * @static
     * @param {number[]} array
     * @returns {Matrix3}
     * @memberof Matrix3
     */
    Matrix3.createFromArray = function (array) {
        if (array.length !== 9) {
            throw new Error("create Matrix Error:array length is wrong");
        }
        return new Matrix3(new Float32Array(array));
    };
    /**
     * 使用某个已有的typedArray创建
     * 此操作不会拷贝数据，而是在原来的内存区域上操作
     *
     * @static
     * @param {Float32Array} array
     * @returns {Matrix3}
     * @memberof Matrix3
     */
    Matrix3.createFromTypedArray = function (array, offset) {
        if (offset === void 0) { offset = 0; }
        if (array.length - offset < 9) {
            throw new Error("create Matrix Error:array length is wrong");
        }
        return new Matrix3(array, offset);
    };
    Object.defineProperty(Matrix3.prototype, "raw", {
        get: function () {
            if (!this.__raw) {
                this.__raw = new Float32Array(this._raw.buffer, this._offset * 4, 9);
            }
            return this.__raw;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * 返回数组
     *
     * @returns {number[]}
     * @memberof Matrix3
     */
    Matrix3.prototype.toArray = function () {
        var arr = new Array(9);
        for (var i = 0; i < 9; i++) {
            arr[i] = this._raw[this._offset + i];
        }
        return arr;
    };
    /**
     * 位移变换
     *
     * @param {number} tx
     * @param {number} ty
     * @param {Matrix3} [dst]
     * @returns {Matrix3}
     * @memberof Matrix3
     */
    Matrix3.prototype.translate = function (tx, ty, dst) {
        dst = dst || new Matrix3();
        utils_1.m3Helper.translate(this._raw, this._offset, tx, ty, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 缩放变换
     *
     * @param {number} sx
     * @param {number} sy
     * @param {Matrix3} [dst]
     * @returns {Matrix3}
     * @memberof Matrix3
     */
    Matrix3.prototype.scale = function (sx, sy, dst) {
        dst = dst || new Matrix3();
        utils_1.m3Helper.scale(this._raw, this._offset, sx, sy, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 旋转变换，以弧度表示
     *
     * @param {number} radians 角度以弧度表示
     * @param {Matrix3} [dst]
     * @returns {Matrix3}
     * @memberof Matrix3
     */
    Matrix3.prototype.rotate = function (radians, dst) {
        dst = dst || new Matrix3();
        utils_1.m3Helper.rotate(this._raw, this._offset, radians, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 矩阵的逆
     *
     * @param {Matrix3} [dst]
     * @returns {Matrix3}
     * @memberof Matrix3
     */
    Matrix3.prototype.inverse = function (dst) {
        dst = dst || new Matrix3();
        utils_1.m3Helper.inverse(this._raw, this._offset, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 矩阵相乘
     *
     * @param {Matrix3} m
     * @param {Matrix3} [dst]
     * @returns {Matrix3}
     * @memberof Matrix3
     */
    Matrix3.prototype.multiply = function (m, dst) {
        dst = dst || new Matrix3();
        utils_1.m3Helper.multiply(this._raw, this._offset, m._raw, m._offset, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 矩阵变换作用于点
     *
     * @param {Vector2} v
     * @param {Vector2} [dst]
     * @returns {Vector2}
     * @memberof Matrix3
     */
    Matrix3.prototype.transformPoint = function (v, dst) {
        dst = dst || vector2_1.default.ZERO;
        utils_1.m3Helper.transformPoint(this._raw, this._offset, v._raw, v._offset, dst._raw, dst._offset);
        return dst;
    };
    return Matrix3;
}());
exports.default = Matrix3;


/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/*
 * @Author: bluecatliao
 * @Date: 2019-04-11 17:26:10
 * @Last Modified by: roamye
 * @Last Modified time: 2020-05-06 16:38:39
 * 二维向量类，尽量使用setValue来更新自身的值，否则无法触发脏位
 */
var utils_1 = __webpack_require__(20);
/**
 * @public
 */
var Vector2 = /** @class */ (function () {
    function Vector2(raw, offset) {
        this._raw = raw ? raw : new Float32Array(2);
        this._offset = offset ? offset : 0;
    }
    Object.defineProperty(Vector2.prototype, "x", {
        get: function () {
            return this._raw[this._offset];
        },
        set: function (val) {
            this._raw[this._offset] = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Vector2.prototype, "y", {
        get: function () {
            return this._raw[this._offset + 1];
        },
        set: function (val) {
            this._raw[this._offset + 1] = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Vector2, "ZERO", {
        get: function () {
            var raw = new Float32Array([0, 0]);
            return new Vector2(raw);
        },
        enumerable: false,
        configurable: true
    });
    /**
     * 使用数值创建
     * 推荐使用这种方式代替new Vector2
     *
     * @static
     * @param {number} [x]
     * @param {number} [y]
     * @returns {Vector2}
     * @memberof Vector2
     */
    Vector2.createFromNumber = function (x, y) {
        var raw = new Float32Array(2);
        raw[0] = x || 0;
        raw[1] = y || 0;
        return new Vector2(raw);
    };
    /**
     * 使用一个数组创建
     * 此操作会拷贝一份数组
     *
     * @static
     * @param {number[]} array
     * @returns {Vector2}
     * @memberof Vector2
     */
    Vector2.createFromArray = function (array) {
        if (array.length !== 2) {
            array = new Array(2).fill(0);
        }
        return new Vector2(new Float32Array(array));
    };
    /**
     * 使用某个已有的typedArray创建
     * 此操作不会拷贝数据，而是在原来的内存区域上操作
     *
     * @static
     * @param {Float32Array} array
     * @returns {Vector2}
     * @memberof Vector2
     */
    Vector2.createFromTypedArray = function (array, offset) {
        if (offset === void 0) { offset = 0; }
        if (array.length - offset < 2) {
            array = new Float32Array(2).fill(0);
            offset = 0;
        }
        return new Vector2(array, offset);
    };
    Vector2.prototype.toArray = function () {
        return [this._raw[this._offset], this._raw[this._offset + 1]];
    };
    Vector2.prototype.equal = function (v) {
        return utils_1.v2Helper.equal(this._raw, this._offset, v._raw, v._offset);
    };
    Vector2.prototype.set = function (v) {
        // this._raw.set(v._raw, this._offset);
        if (v._raw.length === 2) {
            this._raw.set(v._raw, this._offset);
        }
        else {
            for (var i = 0; i < 2; i++) {
                this._raw[this._offset + i] = v._raw[v._offset + i];
            }
        }
    };
    Vector2.prototype.setValue = function (x, y) {
        this._raw[this._offset] = x;
        this._raw[this._offset + 1] = y;
        return this;
    };
    Vector2.prototype.add = function (v, dst) {
        dst = dst || new Vector2();
        utils_1.v2Helper.add(this._raw, this._offset, v._raw, v._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector2.prototype.sub = function (v, dst) {
        dst = dst || new Vector2();
        utils_1.v2Helper.sub(this._raw, this._offset, v._raw, v._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector2.prototype.normalize = function (dst) {
        dst = dst || new Vector2();
        utils_1.v2Helper.normalize(this._raw, this._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector2.prototype.scale = function (f, dst) {
        dst = dst || new Vector2();
        utils_1.v2Helper.scale(this._raw, this._offset, f, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector2.prototype.lerp = function (v, f, dst) {
        dst = dst || new Vector2();
        utils_1.v2Helper.lerp(this._raw, this._offset, v._raw, v._offset, f, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector2.prototype.dot = function (v) {
        return utils_1.v2Helper.dot(this._raw, this._offset, v._raw, v._offset);
    };
    Vector2.prototype.length = function () {
        return utils_1.v2Helper.length(this._raw, this._offset);
    };
    Vector2.prototype.clone = function () {
        return Vector2.createFromNumber(this._raw[this._offset + 0], this._raw[this._offset + 1]);
    };
    Vector2.prototype.isZero = function () {
        return utils_1.v2Helper.isZero(this._raw, this._offset);
    };
    Vector2.prototype.getAngle = function () {
        return utils_1.v2Helper.getAngle(this._raw, this._offset);
    };
    return Vector2;
}());
exports.default = Vector2;
var tempDst = new Vector2();


/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.VertexLayoutNative = exports.createdVertexLayout = void 0;
var tslib_1 = __webpack_require__(1);
var def_1 = __webpack_require__(2);
var vertexBatcher_1 = tslib_1.__importDefault(__webpack_require__(24));
var idCounter = 0;
function requestID() {
    return idCounter++;
}
var vertexFormat2ByteSize = {};
vertexFormat2ByteSize[def_1.EnumVertexFormat.BYTE4] = 4;
vertexFormat2ByteSize[def_1.EnumVertexFormat.BYTE4N] = 4;
vertexFormat2ByteSize[def_1.EnumVertexFormat.FLOAT] = 4;
vertexFormat2ByteSize[def_1.EnumVertexFormat.FLOAT2] = 8;
vertexFormat2ByteSize[def_1.EnumVertexFormat.FLOAT3] = 12;
vertexFormat2ByteSize[def_1.EnumVertexFormat.FLOAT4] = 16;
vertexFormat2ByteSize[def_1.EnumVertexFormat.SHORT2] = 4;
vertexFormat2ByteSize[def_1.EnumVertexFormat.SHORT2N] = 4;
vertexFormat2ByteSize[def_1.EnumVertexFormat.SHORT4] = 8;
vertexFormat2ByteSize[def_1.EnumVertexFormat.SHORT4N] = 8;
vertexFormat2ByteSize[def_1.EnumVertexFormat.UBYTE4] = 4;
vertexFormat2ByteSize[def_1.EnumVertexFormat.UBYTE4N] = 4;
exports.createdVertexLayout = [];
var VertexLayoutNative = /** @class */ (function () {
    function VertexLayoutNative(config, gfx) {
        this._id = requestID();
        this._gfx = gfx;
        this._config = config;
        this._calStride();
        this._batcher = new vertexBatcher_1.default(this._gfx);
        exports.createdVertexLayout.push(this);
    }
    // 计算stride
    // todo:这里没有考虑多buffer的情况
    VertexLayoutNative.prototype._calStride = function () {
        var strideCount = 0;
        for (var _i = 0, _a = this._config.layout.attrs; _i < _a.length; _i++) {
            var attr = _a[_i];
            strideCount += vertexFormat2ByteSize[attr.format];
        }
        this._stride = strideCount;
    };
    VertexLayoutNative.prototype._getBatcher = function () {
        return this._batcher;
    };
    return VertexLayoutNative;
}());
exports.VertexLayoutNative = VertexLayoutNative;


/***/ }),
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var VB_SIZE = 2000 * 1024;
var IB_SIZE = 1200 * 1024;
var VertexBatcher = /** @class */ (function () {
    function VertexBatcher(gfx) {
        this._vbOffset = 0; // vertexOffset by Byte
        this._ibCount = 0; // index Offset by Uint16
        this._iBase = 0;
        this._inited = false;
        this._gfx = gfx;
    }
    VertexBatcher.prototype.init = function () {
        var desc = {
            type: wgfx.EnumBufferType.VERTEXBUFFER,
            usage: wgfx.EnumUsage.DYNAMIC,
            size: VB_SIZE
        };
        this._vertexBuffer = this._gfx.makeBuffer(desc);
        var desc2 = {
            type: wgfx.EnumBufferType.INDEXBUFFER,
            usage: wgfx.EnumUsage.DYNAMIC,
            size: IB_SIZE
        };
        this._indexBuffer = this._gfx.makeBuffer(desc2);
        this._vbView = new Uint8Array(VB_SIZE);
        this._ibView = new Uint16Array(IB_SIZE / 2);
        this._inited = true;
    };
    VertexBatcher.prototype.reset = function () {
        this._vbOffset = 0;
        this._ibCount = 0;
        this._iBase = 0;
    };
    VertexBatcher.prototype.batchMesh = function (vb, ib, indexBufferIndex, indexBufferOffset) {
        if (indexBufferOffset === void 0) { indexBufferOffset = ib._dataView.length; }
        // indexBufferIndex 是要从 IndexBuffer 中截取的起点
        // indexBufferOffset 是要截取的长度，是 UInt16Array 的数组长度
        if (!this._inited) {
            this.init();
        }
        // vertex
        this._vbView.set(vb._finalBufferView, this._vbOffset);
        this._vbOffset += vb._finalBufferView.byteLength;
        // index
        var iCount = this._ibCount;
        var _oriIndices = ib._dataView;
        var ibase = this._iBase;
        for (var i = indexBufferIndex, len = indexBufferOffset; i < len; i++) {
            this._ibView[iCount + i] = ibase + _oriIndices[i];
        }
        this._iBase += vb._count; // 顶点数
        this._ibCount += indexBufferOffset; // 索引偏移
    };
    VertexBatcher.prototype.uploadBuffer = function () {
        if (!this._inited) {
            return;
        }
        this._gfx.updateBuffer(this._vertexBuffer, 0, this._vbView, 0, this._vbOffset);
        this._gfx.updateBuffer(this._indexBuffer, 0, this._ibView, 0, this._ibCount * 2);
    };
    return VertexBatcher;
}());
exports.default = VertexBatcher;


/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/*
 * @Author: bluecatliao
 * @Date: 2019-03-18 13:15:42
 * @Last Modified by: bluecatliao
 * @Last Modified time: 2019-03-18 13:22:13
 * 代表一个区域，生成后不可变
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.RectNative = void 0;
var RectNative = /** @class */ (function () {
    function RectNative(x, y, width, height) {
        this._x = x;
        this._y = y;
        this._width = width;
        this._height = height;
    }
    return RectNative;
}());
exports.RectNative = RectNative;


/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var commandBuffer_1 = tslib_1.__importDefault(__webpack_require__(15));
var RenderCommandDecoder = /** @class */ (function () {
    function RenderCommandDecoder() {
        this.bufferStack = []; // 用于记录是否产生调用嵌套
    }
    RenderCommandDecoder.prototype._setCommandExecutor = function (executor) {
        this._executor = executor;
    };
    RenderCommandDecoder.prototype.decodeAndExecCommandBuffer = function (cb) {
        this.bufferStack.push(cb);
        for (var _i = 0, _a = cb._array; _i < _a.length; _i++) {
            var command = _a[_i];
            if (command instanceof commandBuffer_1.default) {
                if (this.bufferStack.indexOf(command) > -1) {
                    // 阻止嵌套调用
                    console.warn("execute command buffer error: has infinite loop");
                    return;
                }
                else {
                    this.decodeAndExecCommandBuffer(command);
                }
            }
            else {
                this.drawRenderDraw(command);
            }
        }
        this.bufferStack.pop();
    };
    /**
     * Cmd Handlers
     */
    RenderCommandDecoder.prototype.drawRenderDraw = function (renderDraw) {
        this._executor.drawRenderDraw(renderDraw);
    };
    return RenderCommandDecoder;
}());
exports.default = RenderCommandDecoder;


/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.RenderViewNative = void 0;
var RenderViewNative = /** @class */ (function () {
    function RenderViewNative(pass /*GFXPass*/, passAction /*GFXPassAction*/, viewport, scissor) {
        this._pass = pass;
        this._passAction = passAction;
        this._viewport = viewport;
        this._scissor = scissor;
        this._isDefaultView = (this._pass.id === 0);
    }
    return RenderViewNative;
}());
exports.RenderViewNative = RenderViewNative;


/***/ }),
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.BatchableVertexBufferNative = void 0;
var tslib_1 = __webpack_require__(1);
var vector2_1 = tslib_1.__importDefault(__webpack_require__(22));
var BatchableVertexBufferNative = /** @class */ (function () {
    function BatchableVertexBufferNative(count, vertexLayout) {
        this._count = count;
        if (!count) {
            this.data = null;
            return;
        }
        var _size = count * vertexLayout._stride;
        this.data = new ArrayBuffer(_size);
        this._finalBuffer = new ArrayBuffer(_size);
        this._dataView = new Uint8Array(this.data);
        this._finalBufferView = new Uint8Array(this._finalBuffer);
        this._calPositionOffset(vertexLayout);
    }
    BatchableVertexBufferNative.prototype._cloneBuffer = function () {
        this._finalBufferView.set(this._dataView);
    };
    BatchableVertexBufferNative.prototype._calPositionOffset = function (vertexLayout) {
        // todo:目前以name来找，以后要改
        for (var _i = 0, _a = vertexLayout._config.layout.attrs; _i < _a.length; _i++) {
            var attr = _a[_i];
            if (attr.name == 'a_position') {
                this._positionOffset = attr.offset;
            }
        }
        this._positionViews = [];
        this._worldPositionViews = [];
        for (var i = 0; i < this._count; i++) {
            // 根据vertexLayout来确定position的arrayBuffer
            var vec = new vector2_1.default(new Float32Array(this.data, i * vertexLayout._stride + this._positionOffset, 2));
            this._positionViews.push(vec);
            var vec2 = new vector2_1.default(new Float32Array(this._finalBuffer, i * vertexLayout._stride + this._positionOffset, 2));
            this._worldPositionViews.push(vec2);
        }
    };
    return BatchableVertexBufferNative;
}());
exports.BatchableVertexBufferNative = BatchableVertexBufferNative;


/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/*
 * @Author: bluecatliao
 * @Date: 2019-07-09 15:56:30
 * @Last Modified by: bluecatliao
 * @Last Modified time: 2019-07-09 22:36:24
 * 用于可合批的索引，默认16bit
 * todo:将来客户端需要支持32bit
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.BatchableIndexBufferNative = void 0;
var BatchableIndexBufferNative = /** @class */ (function () {
    function BatchableIndexBufferNative(count, is32Bit) {
        this._count = count;
        //const byteSize = is32Bit?4:2;
        //const _size = count * byteSize;
        this._dataView = new Uint16Array(count);
        this.data = this._dataView.buffer;
    }
    return BatchableIndexBufferNative;
}());
exports.BatchableIndexBufferNative = BatchableIndexBufferNative;


/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var mockLogicAcceleratorWorker_1 = tslib_1.__importDefault(__webpack_require__(5));
var accelerateManager_1 = __webpack_require__(31);
var logicManager_1 = __webpack_require__(65);
var componentDef_1 = __webpack_require__(33);
var def_1 = __webpack_require__(6);
var entity2D_1 = tslib_1.__importDefault(__webpack_require__(48));
var entity3D_1 = tslib_1.__importDefault(__webpack_require__(49));
var physicsManager_1 = tslib_1.__importDefault(__webpack_require__(76));
var physics_1 = tslib_1.__importDefault(__webpack_require__(77));
/**
 * GA兼容方案
 * 客户端与Mock保持数据层统一，差异为数据来源与后续运算逻辑。
 */
var LogicAccelerator = /** @class */ (function () {
    function LogicAccelerator(worker, config) {
        this.config = config;
        this.isEngineNative = config.isEngineNative;
        this.isPhysicsNative = config.isPhysicsNative;
        this.gaVersion = config.gaVersion;
        // bind APIs
        if (this.isEngineNative) {
            // 支持客户端加速
            this.worker = worker;
            var manager = new accelerateManager_1.AccelerateManager(this.worker, config);
            this.manager = manager;
            this.createEntity3D = manager.createEntity3D.bind(manager);
            this.createEntity2D = manager.createEntity2D.bind(manager);
            this._createCullableComponent = manager.createCullableComponent.bind(manager);
            this._createAnimatorComponent = manager.createAnimatorComponent.bind(manager);
            this._createSkinnedSkeletonComponent = manager.createSkinnedSkeletonComponent.bind(manager);
            this.createEntity2DGroup = manager.createEntity2DGroup.bind(manager);
            this.createEntity3DGroup = manager.createEntity3DGroup.bind(manager);
            this.createDataBuffer = manager.createDataBuffer.bind(manager);
            this.createDataModel = manager.createDataModel.bind(manager);
            this.createAnimationClipBinding = manager.createAnimationClipBinding.bind(manager);
            this.createAnimatorController = manager.createAnimatorController.bind(manager);
            this.createAnimatorControllerStateModel = manager.createAnimatorControllerStateModel.bind(manager);
            // 节点相关逻辑
            this.entityAddChild = manager.entityAddChild.bind(manager);
            this.entityAddChildAtIndex = manager.entityAddChildAtIndex.bind(manager);
            this.entityRemoveFromParent = manager.entityRemoveFromParent.bind(manager);
            this.entityDestroy = manager.entityDestroy.bind(manager);
            this.entityClear = manager.entityClear.bind(manager);
            this.entitySetActive = manager.entitySetActive.bind(manager);
            this.entitySetLocalMatrixDirty = manager.entitySetLocalMatrixDirty.bind(manager);
            this.entitiesSetLocalMatrixDirty = manager.entitiesSetLocalMatrixDirty.bind(manager);
            this.entitiesSetLocalMatrixDirtyById = manager.entitiesSetLocalMatrixDirtyById.bind(manager);
            // 节点组相关逻辑
            this.entityGroupAddChild = manager.entityGroupAddChild.bind(manager);
            this.entityGroupAddChildAtIndex = manager.entityGroupAddChildAtIndex.bind(manager);
            this.entityGroupRemoveFromParent = manager.entityGroupRemoveFromParent.bind(manager);
            this.entityGroupDestroy = manager.entityGroupDestroy.bind(manager);
            this.entityGroupClear = manager.entityGroupClear.bind(manager);
            this.entityGroupSetActive = manager.entityGroupSetActive.bind(manager);
            this.entityGroupSetLocalMatrixDirty = manager.entityGroupSetLocalMatrixDirty.bind(manager);
            this.entityGroupSetLocalMatrixDirtyAll = manager.entityGroupSetLocalMatrixDirtyAll.bind(manager);
            this.componentBindEntity = manager.componentBindEntity.bind(manager);
            this.componentUnbindEntity = manager.componentUnbindEntity.bind(manager);
            this.setRootEntity = manager.setRootEntity.bind(manager);
            this.updateAnimator = manager.updateAnimator.bind(manager);
            this.updateAnimators = manager.updateAnimators.bind(manager);
            this.updateAnimatorControllers = manager.updateAnimatorControllers.bind(manager);
            this.updateSkinningMatrix = manager.updateSkinningMatrix.bind(manager);
            this.updateSkinningMatrices = manager.updateSkinningMatrices.bind(manager);
            this.bindEntitiesToBones = manager.bindEntitiesToBones.bind(manager);
            this.unbindEntitiesFromBones = manager.unbindEntitiesFromBones.bind(manager);
            this.bindEntitiesToBonesWithIndex = manager.bindEntitiesToBonesWithIndex.bind(manager);
            this.unbindEntitiesFromBonesWithIndex = manager.unbindEntitiesFromBonesWithIndex.bind(manager);
            this.refreshWorldTransform = manager.refreshWorldTransform.bind(manager);
            this.frameStart = manager.frameStart.bind(manager);
            this.cullWithCameraPerspective = manager.cullWithCameraPerspective.bind(manager);
            this.cullWithCameraOrthographic = manager.cullWithCameraOrthographic.bind(manager);
            // ArrayBuffer传递剔除结果方案
            if (this.worker.cullingResult) {
                this.initCullingArrayBuffer = manager.initCullingArrayBuffer.bind(manager);
                this.cullWithCameraPerspectiveByArrayBuffer = manager.cullWithCameraPerspectiveV2.bind(manager);
                this.cullWithCameraOrthographicByArrayBuffer = manager.cullWithCameraOrthographicV2.bind(manager);
            }
        }
        else {
            // 不支持客户端加速，直接走Mock
            this.mockWorker = worker;
            var logicManager = this._getMockAccelerateWorker();
            this.createEntity3D = logicManager.createEntity3D.bind(logicManager);
            this.createEntity2D = logicManager.createEntity2D.bind(logicManager);
            this._createCullableComponent = logicManager.createCullableComponent.bind(logicManager);
            this._createAnimatorComponent = logicManager.createAnimatorComponent.bind(logicManager);
            this._createSkinnedSkeletonComponent = logicManager.createSkinnedSkeletonComponent.bind(logicManager);
            this.createEntity2DGroup = logicManager.createEntity2DGroup.bind(logicManager);
            this.createEntity3DGroup = logicManager.createEntity3DGroup.bind(logicManager);
            this.createDataModel = logicManager.createDataModel.bind(logicManager);
            this.createDataBuffer = logicManager.createDataBuffer.bind(logicManager);
            this.createAnimationClipBinding = logicManager.createAnimationClipBinding.bind(logicManager);
            this.createAnimatorController = logicManager.createAnimatorController.bind(logicManager);
            this.createAnimatorControllerStateModel = logicManager.createAnimatorControllerStateModel.bind(logicManager);
            // 节点相关逻辑
            this.entityAddChild = logicManager.entityAddChild.bind(logicManager);
            this.entityAddChildAtIndex = logicManager.entityAddChildAtIndex.bind(logicManager);
            this.entityRemoveFromParent = logicManager.entityRemoveFromParent.bind(logicManager);
            this.entityDestroy = logicManager.entityDestroy.bind(logicManager);
            this.entityClear = logicManager.entityClear.bind(logicManager);
            this.entitySetActive = logicManager.entitySetActive.bind(logicManager);
            this.entitySetLocalMatrixDirty = logicManager.entitySetLocalMatrixDirty.bind(logicManager);
            this.entitiesSetLocalMatrixDirty = logicManager.entitiesSetLocalMatrixDirty.bind(logicManager);
            this.entitiesSetLocalMatrixDirtyById = logicManager.entitiesSetLocalMatrixDirtyById.bind(logicManager);
            // 节点组相关逻辑
            this.entityGroupAddChild = logicManager.entityGroupAddChild.bind(logicManager);
            this.entityGroupAddChildAtIndex = logicManager.entityGroupAddChildAtIndex.bind(logicManager);
            this.entityGroupRemoveFromParent = logicManager.entityGroupRemoveFromParent.bind(logicManager);
            this.entityGroupDestroy = logicManager.entityGroupDestroy.bind(logicManager);
            this.entityGroupClear = logicManager.entityGroupClear.bind(logicManager);
            this.entityGroupSetActive = logicManager.entityGroupSetActive.bind(logicManager);
            this.entityGroupSetLocalMatrixDirty = logicManager.entityGroupSetLocalMatrixDirty.bind(logicManager);
            this.entityGroupSetLocalMatrixDirtyAll = logicManager.entityGroupSetLocalMatrixDirtyAll.bind(logicManager);
            this.componentBindEntity = logicManager.componentBindEntity.bind(logicManager);
            this.componentUnbindEntity = logicManager.componentUnbindEntity.bind(logicManager);
            this.setRootEntity = logicManager.setRootEntity.bind(logicManager);
            this.cullWithCameraPerspective = logicManager.cullWithCameraPerspective.bind(logicManager);
            this.cullWithCameraOrthographic = logicManager.cullWithCameraOrthographic.bind(logicManager);
            this.updateAnimator = logicManager.updateAnimator.bind(logicManager);
            this.updateAnimators = logicManager.updateAnimators.bind(logicManager);
            this.updateAnimatorControllers = logicManager.updateAnimatorControllers.bind(logicManager);
            this.updateSkinningMatrix = logicManager.updateSkinningMatrix.bind(logicManager);
            this.updateSkinningMatrices = logicManager.updateSkinningMatrices.bind(logicManager);
            this.bindEntitiesToBones = logicManager.bindEntitiesToBones.bind(logicManager);
            this.unbindEntitiesFromBones = logicManager.unbindEntitiesFromBones.bind(logicManager);
            this.bindEntitiesToBonesWithIndex = logicManager.bindEntitiesToBonesWithIndex.bind(logicManager);
            this.unbindEntitiesFromBonesWithIndex = logicManager.unbindEntitiesFromBonesWithIndex.bind(logicManager);
            this.refreshWorldTransform = logicManager.refreshWorldTransform.bind(logicManager);
            this.frameStart = logicManager.frameStart.bind(logicManager);
        }
        if (this.isPhysicsNative) {
            // @ts-ignore
            var phys3D = NativeGlobal.Phys3D;
            if (!phys3D) {
                // console.error("No native physics engine found!");
            }
            else {
                // console.log("native WXGame Phys3D");
                this.phys3D = new physicsManager_1.default(phys3D, this, this.isEngineNative);
            }
        }
        else {
            /**
             * 为了在外网版本隐藏物理功能，先暂时不报任何log
             */
            var phys3D = void 0;
            try {
                // @ts-ignore
                phys3D = physics_1.default().Phys3D;
            }
            catch (e) {
                // console.error(e.stack);
            }
            // const phys3D = PHYSX.getPhysicsEngine().Phys3D;
            if (!phys3D) {
                // console.error("No mock physics engine found!");
            }
            else {
                // console.log("mock WXGame Phys3D");
                this.phys3D = new physicsManager_1.default(phys3D, this, this.isEngineNative);
            }
        }
    }
    LogicAccelerator.prototype.createComponent = function (typeID) {
        var ctor = componentDef_1.componentType2Ctor[typeID];
        if (!ctor) {
            console.warn("can not support dataModel [" + typeID + "]");
            return null;
        }
        switch (typeID) {
            case def_1.enumComponentType.Cullable:
                return this._createCullableComponent();
            case def_1.enumComponentType.Animator:
                return this._createAnimatorComponent();
            case def_1.enumComponentType.SkinnedSkeleton:
                return this._createSkinnedSkeletonComponent();
        }
        return null;
    };
    /**
     * 根据数据，返回二维节点对应结构的Float32array
     */
    LogicAccelerator.prototype.composeRawBufferEntity2D = function (rotation, position, scale) {
        var rawBuffer = new ArrayBuffer(4 * entity2D_1.default.ENTITY2D_SIZE);
        var f32View = new Float32Array(rawBuffer);
        f32View[entity2D_1.default.OFFSET_ROTATION] = rotation;
        f32View[entity2D_1.default.OFFSET_POSITION] = position[0];
        f32View[entity2D_1.default.OFFSET_POSITION + 1] = position[1];
        f32View[entity2D_1.default.OFFSET_SCALE] = scale[0];
        f32View[entity2D_1.default.OFFSET_SCALE + 1] = scale[1];
        return f32View;
    };
    /**
     * 根据数据，返回三维节点对应结构的Float32array，除WorldMatrix。
     */
    LogicAccelerator.prototype.composeRawBufferEntity3D = function (useEuler, rotation, position, scale) {
        var rawBuffer = new ArrayBuffer(4 * (entity3D_1.default.ENTITY3D_SIZE - 16));
        var u32View = new Uint32Array(rawBuffer);
        var f32View = new Float32Array(rawBuffer);
        // u32View[0] = 0xffffffff;
        u32View[entity3D_1.default.OFFSET_ROTATIONTYPE] = useEuler ? 0 : 1;
        f32View.set(rotation, entity3D_1.default.OFFSET_ROTATION /* 2*4 */);
        f32View.set(position, entity3D_1.default.OFFSET_POSITION /* 6*4 */);
        f32View.set(scale, entity3D_1.default.OFFSET_SCALE /* 9*4 */);
        return f32View;
    };
    /**
     * 根据数据，返回三维节点对应结构的Float32array
     */
    LogicAccelerator.prototype.composeRawBufferEntity3DWhole = function (useEuler, rotation, position, scale) {
        var rawBuffer = new ArrayBuffer(4 * entity3D_1.default.ENTITY3D_SIZE);
        var u32View = new Uint32Array(rawBuffer);
        var f32View = new Float32Array(rawBuffer);
        // u32View[0] = 0xffffffff;
        u32View[entity3D_1.default.OFFSET_ROTATIONTYPE] = useEuler ? 0 : 1;
        f32View.set(rotation, entity3D_1.default.OFFSET_ROTATION /* 2*4 */);
        f32View.set(position, entity3D_1.default.OFFSET_POSITION /* 6*4 */);
        f32View.set(scale, entity3D_1.default.OFFSET_SCALE /* 9*4 */);
        return f32View;
    };
    /**
     * 根据数据，返回二维节点组对应结构的Float32array
     */
    LogicAccelerator.prototype.composeRawBufferEntity2DGroup = function (infoList) {
        var rawBuffer = new ArrayBuffer(4 * entity2D_1.default.ENTITY2D_SIZE * infoList.length);
        var f32View = new Float32Array(rawBuffer);
        for (var i = 0; i < infoList.length; i++) {
            var listItem = infoList[i];
            f32View[i * entity2D_1.default.ENTITY2D_SIZE + entity2D_1.default.OFFSET_ROTATION] = listItem.rotation;
            f32View[i * entity2D_1.default.ENTITY2D_SIZE + entity2D_1.default.OFFSET_POSITION] = listItem.position[0];
            f32View[i * entity2D_1.default.ENTITY2D_SIZE + entity2D_1.default.OFFSET_POSITION + 1] = listItem.position[1];
            f32View[i * entity2D_1.default.ENTITY2D_SIZE + entity2D_1.default.OFFSET_SCALE] = listItem.scale[0];
            f32View[i * entity2D_1.default.ENTITY2D_SIZE + entity2D_1.default.OFFSET_SCALE + 1] = listItem.scale[1];
        }
        return f32View;
    };
    /**
     * 根据数据，返回三维节点组对应结构的Float32array
     */
    LogicAccelerator.prototype.composeRawBufferEntity3DGroup = function (infoList) {
        var rawBuffer = new ArrayBuffer(4 * entity3D_1.default.ENTITY3D_SIZE * infoList.length);
        var u32View = new Uint32Array(rawBuffer);
        var f32View = new Float32Array(rawBuffer);
        for (var i = 0; i < infoList.length; i++) {
            var listItem = infoList[i];
            u32View[entity3D_1.default.OFFSET_ROTATIONTYPE] = listItem.useEuler ? 0 : 1;
            f32View.set(listItem.rotation, i * entity3D_1.default.ENTITY3D_SIZE + entity3D_1.default.OFFSET_ROTATION /* 2*4 */);
            f32View.set(listItem.position, i * entity3D_1.default.ENTITY3D_SIZE + entity3D_1.default.OFFSET_POSITION /* 6*4 */);
            f32View.set(listItem.scale, i * entity3D_1.default.ENTITY3D_SIZE + entity3D_1.default.OFFSET_SCALE /* 9*4 */);
        }
        return f32View;
    };
    /**
     * 调试接口的包装
     */
    LogicAccelerator.prototype.getAccObjNumber = function () {
        return {
            entity2D: this.manager.poolManager._entity2DPoolUsedLength
        };
    };
    LogicAccelerator.prototype._getMockAccelerateWorker = function () {
        if (!this.logicManager) {
            if (!this.mockWorker) {
                this.mockWorker = new mockLogicAcceleratorWorker_1.default();
            }
            this.logicManager = new logicManager_1.LogicManager(this.mockWorker, this.config);
        }
        return this.logicManager;
    };
    return LogicAccelerator;
}());
exports.default = LogicAccelerator;


/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.AccelerateManager = void 0;
var tslib_1 = __webpack_require__(1);
var nativeObject_1 = __webpack_require__(32);
var componentDef_1 = __webpack_require__(33);
var cullableComponent_1 = tslib_1.__importStar(__webpack_require__(35));
var animatorComponent_1 = tslib_1.__importStar(__webpack_require__(34));
var skinnedSkeletonComponent_1 = tslib_1.__importDefault(__webpack_require__(37));
var dataBuffer_1 = tslib_1.__importStar(__webpack_require__(47));
var dataModel_1 = __webpack_require__(39);
var def_1 = __webpack_require__(6);
var entity2D_1 = tslib_1.__importStar(__webpack_require__(48));
var entity3D_1 = tslib_1.__importStar(__webpack_require__(49));
var entityGroup_1 = __webpack_require__(50);
var entity2DGroup_1 = tslib_1.__importDefault(__webpack_require__(51));
var entity3DGroup_1 = tslib_1.__importDefault(__webpack_require__(52));
var entityCommand_1 = tslib_1.__importStar(__webpack_require__(53));
var dirtyEntitiesCommand_1 = tslib_1.__importStar(__webpack_require__(55));
var animatorCommand_1 = tslib_1.__importDefault(__webpack_require__(56));
var skinningMatrixCommand_1 = tslib_1.__importDefault(__webpack_require__(57));
var poolManager_1 = tslib_1.__importDefault(__webpack_require__(58));
var AnimatorController_1 = __webpack_require__(60);
var animatorControllerState_1 = __webpack_require__(62);
var animatorControllerCommand_1 = tslib_1.__importDefault(__webpack_require__(63));
var animationClipBinding_1 = __webpack_require__(64);
var AccelerateManager = /** @class */ (function () {
    function AccelerateManager(worker, config) {
        this.worker = worker;
        this.config = config;
        this.poolManager = new poolManager_1.default(this.worker);
        this.dirtyEntitiesCommand = new dirtyEntitiesCommand_1.default(this.worker.dirtyEntities);
        this.entityCommand = new entityCommand_1.default(worker.entityCommands);
        this.animatorCommand = new animatorCommand_1.default();
        this.animatorControllerCommand = new animatorControllerCommand_1.default();
        this.skinningMatrixCommand = new skinningMatrixCommand_1.default();
        entity2D_1.staticInitEntity2D(this);
        entity3D_1.staticInitEntity3D(this);
        entityGroup_1.staticInitEntityGroup(this);
        animatorComponent_1.staticInitAnimatorComponent(this);
        cullableComponent_1.staticInitCullableComponent(this);
        nativeObject_1.staticInitNativeObject(this.worker);
        AnimatorController_1.staticInitAnimatorController(this);
        animationClipBinding_1.staticInitAnimationClipBinding(this);
        animatorControllerState_1.staticInitAnimatorControllerLayerBlend(this.worker);
        dataModel_1.staticInitAccelerateModel(this.worker);
        dataBuffer_1.staticInitAccelerateDataBuffer(this.worker);
        entityCommand_1.staticInitAccelerateEntityCommand(this.worker);
        dirtyEntitiesCommand_1.staticInitAccelerateDirtiesCommand(this.worker);
    }
    AccelerateManager.prototype.createEntity3D = function () {
        var nativeEntityID = this.poolManager.getEntity3D();
        var entity = new entity3D_1.default(nativeEntityID, this.poolManager.entity3DPools);
        entity.isUsing = true;
        this.entitySetActive(entity, true);
        return entity;
    };
    AccelerateManager.prototype.createEntity2D = function () {
        var nativeEntityID = this.poolManager.getEntity2D();
        var entity = new entity2D_1.default(nativeEntityID, this.poolManager.entity2DPools);
        entity.isUsing = true;
        this.entitySetActive(entity, true);
        return entity;
    };
    AccelerateManager.prototype.createEntity2DGroup = function (length) {
        var nativeEntity = this.worker.createEntity(def_1.enumEntityType.Entity2D, length);
        var entity = new entity2DGroup_1.default(nativeEntity, length);
        return entity;
    };
    AccelerateManager.prototype.createEntity3DGroup = function (length) {
        var nativeEntity = this.worker.createEntity(def_1.enumEntityType.Entity3D, length);
        var entity = new entity3DGroup_1.default(nativeEntity, length);
        return entity;
    };
    AccelerateManager.prototype.createCullableComponent = function () {
        var nativeCullableComponentID = this.poolManager.getCullableComponent();
        var comp = new cullableComponent_1.default(nativeCullableComponentID, this.poolManager.cullableComponentPools);
        comp.isUsing = true;
        comp.setActive(true);
        return comp;
    };
    // 兼容0.1.1版本GA逻辑
    AccelerateManager.prototype.createCullableComponentSingle = function () {
        var nativeCullableComponentID = this.poolManager.getCullableComponentSingle();
        var comp = new cullableComponent_1.default(nativeCullableComponentID, this.poolManager.cullableComponentPools);
        comp.setActive(true);
        return comp;
    };
    AccelerateManager.prototype.createAnimatorComponent = function () {
        return new animatorComponent_1.default();
    };
    AccelerateManager.prototype.createSkinnedSkeletonComponent = function () {
        return new skinnedSkeletonComponent_1.default();
    };
    AccelerateManager.prototype.createDataModel = function (typeID) {
        var ctor = componentDef_1.dataModel2Ctor[typeID];
        if (!ctor) {
            console.warn("can not support dataModel [" + typeID + "]");
            return null;
        }
        var model = new ctor();
        return model;
    };
    AccelerateManager.prototype.createDataBuffer = function (byteSize) {
        var nativeObject = this.worker.createDataBuffer(byteSize);
        var dataBuffer = new dataBuffer_1.default(nativeObject);
        return dataBuffer;
    };
    AccelerateManager.prototype.createAnimationClipBinding = function (clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, useDefaultAddedNodesAction, rootEntity) {
        return new animationClipBinding_1.AnimationClipBinding(clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, useDefaultAddedNodesAction, rootEntity);
    };
    AccelerateManager.prototype.createAnimatorControllerStateModel = function (length) {
        return new animatorControllerState_1.AnimatorControllerState(length);
    };
    AccelerateManager.prototype.createAnimatorController = function (layerCount) {
        return new AnimatorController_1.AnimatorController(layerCount);
    };
    /*
    * 节点相关方法
    */
    AccelerateManager.prototype.entityAddChild = function (entity, child) {
        this.entityCommand.addChild(entity.id, child.id);
    };
    AccelerateManager.prototype.entityAddChildAtIndex = function (entity, child, index) {
        this.entityCommand.addChildAtIndex(entity.id, child.id, index);
    };
    AccelerateManager.prototype.entityRemoveFromParent = function (entity) {
        this.entityCommand.removeFromParent(entity.id);
    };
    AccelerateManager.prototype.entityDestroy = function (entity) {
        this.entityCommand.removeFromParent(entity.id);
        if (entity instanceof entity2D_1.default) {
            this.poolManager.disposeEntity2D(entity);
        }
        else if (entity instanceof entity3D_1.default) {
            this.poolManager.disposeEntity3D(entity);
        }
    };
    AccelerateManager.prototype.entityClear = function (entity) {
        this.entityCommand.disperseSubTree(entity.id);
    };
    AccelerateManager.prototype.entitySetActive = function (entity, active) {
        if (active) {
            this.entityCommand.entityCommandActive(entity.id);
        }
        else {
            this.entityCommand.entityCommandInActive(entity.id);
        }
    };
    AccelerateManager.prototype.entitySetLocalMatrixDirty = function (entity) {
        this.dirtyEntitiesCommand.addDirtyEntity(entity);
    };
    AccelerateManager.prototype.entitiesSetLocalMatrixDirty = function (entitis, length) {
        this.dirtyEntitiesCommand.addDirtyEntities(entitis, length);
    };
    AccelerateManager.prototype.entitiesSetLocalMatrixDirtyById = function (entityIds, length) {
        this.dirtyEntitiesCommand.addDirtyEntitiesById(entityIds, length);
    };
    AccelerateManager.prototype.componentBindEntity = function (component, entity) {
        component.bindEntityNative(entity);
    };
    AccelerateManager.prototype.componentUnbindEntity = function (component) {
        this.poolManager.disposeCullableComponent(component);
    };
    AccelerateManager.prototype.setRootEntity = function (entity) {
        this.entityCommand.setRootEntity(entity.id);
    };
    /*
    * 节点组相关方法
    */
    AccelerateManager.prototype.entityGroupAddChild = function (entity, child, entityIndex, childIndex) {
        this.entityCommand.addChild(entity.id, child.id);
    };
    AccelerateManager.prototype.entityGroupAddChildAtIndex = function (entity, child, index, entityIndex, childIndex) {
        this.entityCommand.addChildAtIndex(entity.id, child.id, index);
    };
    AccelerateManager.prototype.entityGroupRemoveFromParent = function (entity, entityIndex) {
        this.entityCommand.removeFromParent(entity.id);
    };
    AccelerateManager.prototype.entityGroupDestroy = function (entity, entityIndex) {
        this.entityCommand.removeFromParent(entity.id);
        if (entity instanceof entity2D_1.default) {
            this.poolManager.disposeEntity2D(entity);
        }
        else if (entity instanceof entity3D_1.default) {
            this.poolManager.disposeEntity3D(entity);
        }
    };
    AccelerateManager.prototype.entityGroupClear = function (entity, entityIndex) {
        this.entityCommand.disperseSubTree(entity.id);
    };
    AccelerateManager.prototype.entityGroupSetActive = function (entity, active, entityIndex) {
        if (active) {
            this.entityCommand.entityCommandActive(entity.id);
        }
        else {
            this.entityCommand.entityCommandInActive(entity.id);
        }
    };
    AccelerateManager.prototype.entityGroupSetLocalMatrixDirty = function (entity, entityIndex) {
        this.dirtyEntitiesCommand.addDirtyEntity(entity);
    };
    AccelerateManager.prototype.entityGroupSetLocalMatrixDirtyAll = function (entityGroup) {
        this.dirtyEntitiesCommand.addDirtyEntityGroupAll(entityGroup);
    };
    AccelerateManager.prototype.componentBindEntityGroup = function (component, entity, componentIndex, entityIndex) {
        component.bindEntityNative(entity);
    };
    AccelerateManager.prototype.componentUnbindEntityGroup = function (component, componentIndex) {
        component.unbindEntityNative();
        this.poolManager.disposeCullableComponent(component);
    };
    AccelerateManager.prototype.setRootEntityGroup = function (entity, entityIndex) {
        this.entityCommand.setRootEntity(entity.id);
    };
    // 兼容0.1.1版本GA逻辑
    AccelerateManager.prototype.componentUnbindEntitySingle = function (component) {
        component.unbindEntityNative();
        this.poolManager.disposeCullableComponentSingle(component);
    };
    AccelerateManager.prototype.refreshWorldTransform = function () {
        this.worker.refreshWorldTransform();
    };
    AccelerateManager.prototype.cullWithCameraPerspective = function (cullMask, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ, fovy, aspect, zNear, zFar) {
        var result = this.worker.frustumCulling(cullMask, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ, fovy, aspect, zNear, zFar);
        if (!result) {
            return { hash: 0, objects: [], distances: [] };
        }
        return {
            hash: result.hash,
            objects: new Uint32Array(result.objects),
            distances: new Float32Array(result.distances),
        };
    };
    AccelerateManager.prototype.cullWithCameraOrthographic = function (cullMask, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ, xwMin, xwMax, ywMin, ywMax, zNear, zFar) {
        var result = this.worker.orthoCulling(cullMask, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ, xwMin, xwMax, ywMin, ywMax, zNear, zFar);
        if (!result) {
            return { hash: 0, objects: [], distances: [] };
        }
        return {
            hash: result.hash,
            objects: new Uint32Array(result.objects),
            distances: new Float32Array(result.distances),
        };
    };
    AccelerateManager.prototype.initCullingArrayBuffer = function () {
        var cullingArrayBuffer = this.worker.cullingResult;
        return {
            u32View: new Uint32Array(cullingArrayBuffer),
            f32View: new Float32Array(cullingArrayBuffer),
        };
    };
    AccelerateManager.prototype.cullWithCameraPerspectiveV2 = function (cullMask, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ, fovy, aspect, zNear, zFar) {
        var result = this.worker.frustumCullingV2(cullMask, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ, fovy, aspect, zNear, zFar);
        return !!result;
    };
    AccelerateManager.prototype.cullWithCameraOrthographicV2 = function (cullMask, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ, xwMin, xwMax, ywMin, ywMax, zNear, zFar) {
        var result = this.worker.orthoCullingV2(cullMask, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ, xwMin, xwMax, ywMin, ywMax, zNear, zFar);
        return !!result;
    };
    AccelerateManager.prototype.updateAnimator = function (comp) {
        this.worker.updateAnimator(comp.id);
    };
    AccelerateManager.prototype.updateAnimators = function (comps, length) {
        this.animatorCommand.updateAnimators(comps, length);
        this.worker.updateAnimators(this.animatorCommand.buffer);
    };
    AccelerateManager.prototype.updateAnimatorControllers = function (comps, length) {
        this.animatorControllerCommand.updateAnimatorControllers(comps, length);
        this.worker.updateAnimatorControllers(this.animatorControllerCommand.buffer);
    };
    AccelerateManager.prototype.updateSkinningMatrix = function (comp) {
        this.worker.updateSkinningMatrix(comp.id);
    };
    AccelerateManager.prototype.updateSkinningMatrices = function (comps, length) {
        this.skinningMatrixCommand.updateSkinningMatrices(comps, length);
        this.worker.updateSkinningMatrices(this.skinningMatrixCommand.buffer);
    };
    AccelerateManager.prototype.bindEntitiesToBones = function (entitis, boneEntitis) {
        this.entityCommand.bindToBones(entitis, boneEntitis);
    };
    AccelerateManager.prototype.unbindEntitiesFromBones = function (entitis) {
        this.entityCommand.unBindFromBones(entitis);
    };
    AccelerateManager.prototype.bindEntitiesToBonesWithIndex = function (entitis, boneEntitis, entityIndexs, boneIndexs) {
        this.entityCommand.bindToBones(entitis, boneEntitis);
    };
    AccelerateManager.prototype.unbindEntitiesFromBonesWithIndex = function (entitis, entityIndexs) {
        this.entityCommand.unBindFromBones(entitis);
    };
    AccelerateManager.prototype.frameStart = function () {
        this.worker.frameStart();
    };
    // 把entity的名字同步给native，debug用。by jackjhu/zombieyang 2020.4
    AccelerateManager.prototype.setEntityName = function (id, name) {
        this.worker.setEntityName(id, name);
    };
    return AccelerateManager;
}());
exports.AccelerateManager = AccelerateManager;


/***/ }),
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.staticInitNativeObject = void 0;
// import { nativeMemory } from '../nativeMemory';
var worker;
function staticInitNativeObject(m_worker) {
    worker = m_worker;
}
exports.staticInitNativeObject = staticInitNativeObject;
// const DF_ACTIVE = 1 << 31;
// const OFFSET_DIRTYFLAG = 0;
var NativeObject = /** @class */ (function () {
    function NativeObject() {
    }
    // 初始化共享内存
    NativeObject.prototype._init = function (info) {
        this._fastInit(info);
        this._initU32View();
    };
    NativeObject.prototype._fastInit = function (info) {
        this._nativeObj = info;
        var id = info.id, buffer = info.buffer;
        var size = buffer.byteLength;
        var offset = 0;
        this._id = id;
        this._bufferLength = size;
        this._byteOffset = offset;
        this._buffer = buffer;
        this._f32view = new Float32Array(buffer, offset, size / 4);
        // this._u32view = new Uint32Array(buffer, offset, size / 4);
        this.id = this._id;
    };
    NativeObject.prototype._initU32View = function () {
        this._u32view = new Uint32Array(this._buffer, this._byteOffset, this._bufferLength / 4);
    };
    // 组件用方法
    NativeObject.prototype._createNativeComponent = function (typeID, parm1, parm2) {
        var nativeObj = worker.createComponent(typeID, parm1, parm2);
        if (nativeObj.id < 0 || !nativeObj.buffer) {
            // 分配失败，返回避免报错
            return null;
        }
        this._init(nativeObj);
        return nativeObj;
    };
    /*
      给子类用的工具
    */
    NativeObject.prototype._initPropertyView = function (offset, length) {
        return new Float32Array(this._buffer, this._byteOffset + offset * 4, length);
    };
    NativeObject.prototype.setRawBuffer = function (data) {
        this._f32view.set(data);
    };
    return NativeObject;
}());
exports.default = NativeObject;


/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/*
 * @Author: bluecatliao
 * @Date: 2018-11-20 21:26:46
 * @Last Modified by: roamye
 * @Last Modified time: 2019-12-17 22:09:26
 * ComponentType到Component 构造器的映射，需与def.ts中enumComponentType一致
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.dataModel2CtorMock = exports.dataModel2Ctor = exports.componentType2Ctor = void 0;
var tslib_1 = __webpack_require__(1);
var animatorComponent_1 = tslib_1.__importDefault(__webpack_require__(34));
var cullableComponent_1 = tslib_1.__importDefault(__webpack_require__(35));
var skinnedSkeletonComponent_1 = tslib_1.__importDefault(__webpack_require__(37));
var def_1 = __webpack_require__(6);
var animationClipModel_1 = tslib_1.__importDefault(__webpack_require__(38));
var skeletonBoneInverseModel_1 = tslib_1.__importDefault(__webpack_require__(40));
var animationClipModel_2 = tslib_1.__importDefault(__webpack_require__(41));
var skeletonBoneInverseModel_2 = tslib_1.__importDefault(__webpack_require__(43));
exports.componentType2Ctor = {};
exports.componentType2Ctor[def_1.enumComponentType.Undefined] = null;
exports.componentType2Ctor[def_1.enumComponentType.Cullable] = cullableComponent_1.default;
exports.componentType2Ctor[def_1.enumComponentType.SkinnedSkeleton] = skinnedSkeletonComponent_1.default;
exports.componentType2Ctor[def_1.enumComponentType.Animator] = animatorComponent_1.default;
exports.dataModel2Ctor = {};
exports.dataModel2Ctor[def_1.enumModelType.SkeletonBoneInverseModel] = skeletonBoneInverseModel_1.default;
exports.dataModel2Ctor[def_1.enumModelType.AnimationClipModel] = animationClipModel_1.default;
exports.dataModel2CtorMock = {};
exports.dataModel2CtorMock[def_1.enumModelType.SkeletonBoneInverseModel] = skeletonBoneInverseModel_2.default;
exports.dataModel2CtorMock[def_1.enumModelType.AnimationClipModel] = animationClipModel_2.default;


/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.staticInitAnimatorComponent = void 0;
var tslib_1 = __webpack_require__(1);
var nativeObject_1 = tslib_1.__importDefault(__webpack_require__(32));
var def_1 = __webpack_require__(6);
var frameIndexUseFloat = false;
var useLastAsRoot = false;
var manager;
function staticInitAnimatorComponent(m_manager) {
    manager = m_manager;
    var versionNumber = manager.config.gaVersion.versionNumber;
    frameIndexUseFloat = versionNumber >= 120;
    useLastAsRoot = versionNumber < 120;
}
exports.staticInitAnimatorComponent = staticInitAnimatorComponent;
var AnimatorComponent = /** @class */ (function (_super) {
    tslib_1.__extends(AnimatorComponent, _super);
    function AnimatorComponent() {
        var _this = _super.call(this) || this;
        _this._offsetEntityIds = 0;
        _this._animationClipCount = 0;
        _this._nodeCount = 0;
        return _this;
    }
    AnimatorComponent.prototype.bindAnimations = function (animationClipModels, entitys, rootEntity) {
        this._animationClipCount = animationClipModels.length;
        var nodesLength = entitys.length;
        for (var i in entitys) {
            nodesLength += entitys[i].length;
        }
        this._nodeCount = nodesLength;
        this._createNativeComponent(def_1.enumComponentType.Animator, animationClipModels.length, nodesLength);
        if (!this._nativeObj)
            return;
        for (var i = 0; i < animationClipModels.length; i++) {
            this._u32view[i * 3] = animationClipModels[i].id;
        }
        this._offsetEntityIds = animationClipModels.length * 3;
        var nodeSum = 0;
        var existEntityId;
        for (var i = 0; i < entitys.length; i++) {
            for (var j = 0; j < entitys[i].length; j++) {
                if (entitys[i][j] != null) {
                    this._u32view[this._offsetEntityIds + nodeSum + j] = entitys[i][j].id;
                    if (!existEntityId) {
                        existEntityId = entitys[i][j].id;
                    }
                }
                else {
                    this._u32view[this._offsetEntityIds + nodeSum + j] = 4294967295;
                }
                this._u32view[this._offsetEntityIds + nodeSum + j] = (entitys[i][j] != null) ? entitys[i][j].id : 4294967295;
            }
            nodeSum += entitys[i].length;
        }
        // 兼容旧版本
        if (useLastAsRoot) {
            // 兼容第一位为空的情况
            if (this._u32view[this._offsetEntityIds] === 4294967295) {
                if (rootEntity != undefined && rootEntity.id) {
                    this._u32view[this._offsetEntityIds] = rootEntity.id;
                }
                else {
                    if (existEntityId) {
                        this._u32view[this._offsetEntityIds] = existEntityId;
                    }
                }
            }
        }
    };
    AnimatorComponent.prototype.setClipParams = function (index, frameIndex, blendWeight) {
        if (!this._nativeObj)
            return;
        var offsetBase = index * 3;
        if (frameIndexUseFloat) {
            this._f32view[offsetBase + 1] = frameIndex;
        }
        else {
            this._u32view[offsetBase + 1] = Math.round(frameIndex);
        }
        this._f32view[offsetBase + 2] = blendWeight;
    };
    AnimatorComponent.prototype.getAnimationClipCount = function () {
        return this._animationClipCount;
    };
    AnimatorComponent.prototype.getNodeCount = function () {
        return this._nodeCount;
    };
    AnimatorComponent.prototype.getAnimationParamater = function (index) {
        var offsetBase = index * 3;
        return {
            animationClipId: this._u32view[offsetBase],
            frameIndex: this._f32view[offsetBase + 1],
            percentage: this._f32view[offsetBase + 2],
        };
    };
    AnimatorComponent.prototype.getEntity = function (index) {
        return this._u32view[this._offsetEntityIds + index];
    };
    return AnimatorComponent;
}(nativeObject_1.default));
exports.default = AnimatorComponent;


/***/ }),
/* 35 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.staticInitCullableComponent = void 0;
var tslib_1 = __webpack_require__(1);
/*
 * @Author: bluecatliao
 * @Date: 2018-11-21 14:33:22
 * @Last Modified by: roamye
 * @Last Modified time: 2020-05-08 22:09:08
 * 剔除组件，包含CullMask，包围球信息(Local)，用于3D物体的剔除
 */
var def_1 = __webpack_require__(6);
var poolObject_1 = tslib_1.__importDefault(__webpack_require__(36));
var manager;
function staticInitCullableComponent(m_manager) {
    manager = m_manager;
}
exports.staticInitCullableComponent = staticInitCullableComponent;
var CullableComponent = /** @class */ (function (_super) {
    tslib_1.__extends(CullableComponent, _super);
    function CullableComponent(nativeObjId, cullableComponentPools) {
        var _this = _super.call(this, nativeObjId, cullableComponentPools) || this;
        _this.entityOffset = _this._poolIndex * def_1.CULLABLECOMPONENT_SIZE;
        _this._activeOffset = _this.entityOffset + def_1.CULLABLECOMPONENT_OFFSET.OFFSET_ACTIVE;
        _this._cullmaskOffset = _this.entityOffset + def_1.CULLABLECOMPONENT_OFFSET.OFFSET_CULLMASK;
        _this._boundingBallCenterOffset = _this.entityOffset + def_1.CULLABLECOMPONENT_OFFSET.OFFSET_BOUDINGBALL_CENTER;
        _this._boundingBallRadiusOffset = _this.entityOffset + def_1.CULLABLECOMPONENT_OFFSET.OFFSET_BOUDINGBALL_RADIUS;
        _this._entityIdOffset = _this.entityOffset + def_1.CULLABLECOMPONENT_OFFSET.OFFSET_ENTITYID;
        return _this;
        // console.log('cullable', this._nativePool,this._poolId, this._poolIndex, this._entityOffset);
    }
    CullableComponent.prototype.getActive = function () {
        return (this._nativePool._u32view[this._activeOffset] & def_1.CULLABLECOMPONENT_OFFSET.DF_ACTIVE) != 0 ? true : false;
    };
    CullableComponent.prototype.setActive = function (val) {
        if (val) {
            this._nativePool._u32view[this._activeOffset] |= def_1.CULLABLECOMPONENT_OFFSET.DF_ACTIVE;
        }
        else {
            this._nativePool._u32view[this._activeOffset] &= ~def_1.CULLABLECOMPONENT_OFFSET.DF_ACTIVE;
        }
    };
    CullableComponent.prototype.getCullMask = function () {
        return this._nativePool._u32view[this._cullmaskOffset];
    };
    CullableComponent.prototype.setCullMask = function (val) {
        this._nativePool._u32view[this._cullmaskOffset] = val;
    };
    CullableComponent.prototype.bindEntityNative = function (entity) {
        this._nativePool._u32view[this._entityIdOffset] = entity.id;
    };
    CullableComponent.prototype.unbindEntityNative = function () {
        this._nativePool._u32view[this._entityIdOffset] = 0;
    };
    CullableComponent.prototype.getBoundingBallCenter = function () {
        if (!this._boundingBallCenter) {
            this._boundingBallCenter = new Float32Array(this._nativePool._buffer, this._boundingBallCenterOffset * 4, 3);
        }
        return this._boundingBallCenter;
    };
    CullableComponent.prototype.setBoundingBallCenter = function (val, offset) {
        if (offset === void 0) { offset = 0; }
        if (val[offset] === this._nativePool._f32view[this._boundingBallCenterOffset] && val[offset + 1] === this._nativePool._f32view[this._boundingBallCenterOffset + 1] && val[offset + 2] === this._nativePool._f32view[this._boundingBallCenterOffset] + 3) {
            return;
        }
        if (val.length === 3) {
            this._nativePool._f32view.set(val, this._boundingBallCenterOffset);
        }
        else {
            this._nativePool._f32view[this._boundingBallCenterOffset] = val[offset];
            this._nativePool._f32view[this._boundingBallCenterOffset + 1] = val[offset + 1];
            this._nativePool._f32view[this._boundingBallCenterOffset + 2] = val[offset + 2];
        }
    };
    CullableComponent.prototype.getBoundingBallRadius = function () {
        return this._nativePool._f32view[this._boundingBallRadiusOffset];
    };
    CullableComponent.prototype.setBoundingBallRadius = function (val) {
        this._nativePool._f32view[this._boundingBallRadiusOffset] = val;
    };
    Object.defineProperty(CullableComponent.prototype, "active", {
        // 兼容上一版本属性
        get: function () {
            return (this._nativePool._u32view[this._activeOffset] & def_1.CULLABLECOMPONENT_OFFSET.DF_ACTIVE) != 0 ? true : false;
        },
        set: function (val) {
            if (val) {
                this._nativePool._u32view[this._activeOffset] |= def_1.CULLABLECOMPONENT_OFFSET.DF_ACTIVE;
            }
            else {
                this._nativePool._u32view[this._activeOffset] &= ~def_1.CULLABLECOMPONENT_OFFSET.DF_ACTIVE;
            }
        },
        enumerable: false,
        configurable: true
    });
    CullableComponent.prototype.bindEntity = function (entity) {
        manager.componentBindEntity(this, entity);
    };
    CullableComponent.prototype.unbindEntity = function () {
        manager.componentUnbindEntity(this);
    };
    return CullableComponent;
}(poolObject_1.default));
exports.default = CullableComponent;


/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var def_1 = __webpack_require__(6);
var PoolObject = /** @class */ (function () {
    function PoolObject(nativeObjId, nativePools) {
        this._nativeId = nativeObjId;
        this._poolId = nativeObjId & def_1.POOLID_AND;
        this._poolIndex = nativeObjId & def_1.POOLINDEX_AND;
        this._nativePool = nativePools[this._poolId];
        this.float32View = this._nativePool._f32view;
        this.uint32View = this._nativePool._u32view;
        this.id = this._nativeId;
        this.poolId = this._poolId;
        this.poolIndex = this._poolIndex;
    }
    PoolObject.prototype.setRawBuffer = function (data) {
        this._nativePool._f32view.set(data, this.entityOffset);
    };
    return PoolObject;
}());
exports.default = PoolObject;


/***/ }),
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
/*
 * @Author: bluecatliao
 * @Date: 2018-11-21 14:33:22
 * @Last Modified by: roamye
 * @Last Modified time: 2020-05-08 19:48:57
 * 变长部分布局为:BoneInverseModelId|BoneNum|BoneIndices(BoneNum*1)|BoneEntityIds(BoneNum*1)|BoneOutputMatrix(BoneNum*16)
 */
var nativeObject_1 = tslib_1.__importDefault(__webpack_require__(32));
var def_1 = __webpack_require__(6);
// Buffer Offset in Float32
var OFFSET_BONEINVERSEMODELID = 0;
var OFFSET_BONEINDICES = 1;
var SkinnedSkeletonComponent = /** @class */ (function (_super) {
    tslib_1.__extends(SkinnedSkeletonComponent, _super);
    function SkinnedSkeletonComponent() {
        var _this = _super.call(this) || this;
        _this._boneNum = 0;
        return _this;
    }
    SkinnedSkeletonComponent.prototype.setBoneMatrix = function (boneInverseModel, boneNum, boneIndices, boneEntitis) {
        if (boneIndices.length !== boneNum || boneEntitis.length !== boneNum) {
            console.warn("setBoneMatrix Error");
            return;
        }
        this._boneNum = boneNum;
        this._createNativeComponent(def_1.enumComponentType.SkinnedSkeleton, boneNum);
        if (!this._nativeObj)
            return;
        var boneEntityIds = [];
        for (var i = 0; i < boneNum; i++) {
            boneEntityIds.push(boneEntitis[i].id);
        }
        this._u32view[OFFSET_BONEINVERSEMODELID] = boneInverseModel.id;
        this._u32view.set(boneIndices, OFFSET_BONEINDICES);
        var offset_boneEntityIds = OFFSET_BONEINDICES + boneNum;
        this._u32view.set(boneEntityIds, offset_boneEntityIds);
        this._boneOffsetMatrices = new Float32Array(this._buffer, this._byteOffset + (OFFSET_BONEINDICES + boneNum * 2) * 4, boneNum * 16);
    };
    SkinnedSkeletonComponent.prototype.getBoneNum = function () {
        return this._boneNum;
    };
    SkinnedSkeletonComponent.prototype.getBoneOffsetMatrices = function () {
        return this._boneOffsetMatrices;
    };
    return SkinnedSkeletonComponent;
}(nativeObject_1.default));
exports.default = SkinnedSkeletonComponent;


/***/ }),
/* 38 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var dataModel_1 = tslib_1.__importDefault(__webpack_require__(39));
var def_1 = __webpack_require__(6);
var AnimationClipModel = /** @class */ (function (_super) {
    tslib_1.__extends(AnimationClipModel, _super);
    function AnimationClipModel() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    AnimationClipModel.prototype.setAnimationClip = function (ab) {
        this._createNativeModel(def_1.enumModelType.AnimationClipModel, ab);
    };
    return AnimationClipModel;
}(dataModel_1.default));
exports.default = AnimationClipModel;


/***/ }),
/* 39 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.staticInitAccelerateModel = void 0;
var worker;
function staticInitAccelerateModel(m_worker) {
    worker = m_worker;
}
exports.staticInitAccelerateModel = staticInitAccelerateModel;
var DataModel = /** @class */ (function () {
    function DataModel() {
    }
    DataModel.prototype._createNativeModel = function (type, buffer) {
        var model = worker.createDataModel(type, buffer);
        this._nativeObj = model;
        this._id = model ? model.id : 0;
        this.id = this._id;
    };
    return DataModel;
}());
exports.default = DataModel;


/***/ }),
/* 40 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var dataModel_1 = tslib_1.__importDefault(__webpack_require__(39));
var def_1 = __webpack_require__(6);
var SkeletonBoneInverseModel = /** @class */ (function (_super) {
    tslib_1.__extends(SkeletonBoneInverseModel, _super);
    function SkeletonBoneInverseModel() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SkeletonBoneInverseModel.prototype.setBoneInverseMatrix = function (matrices) {
        var view = new Float32Array(matrices.length);
        view.set(matrices);
        this._createNativeModel(def_1.enumModelType.SkeletonBoneInverseModel, view.buffer);
    };
    return SkeletonBoneInverseModel;
}(dataModel_1.default));
exports.default = SkeletonBoneInverseModel;


/***/ }),
/* 41 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
/*
 * @Author: bluecatliao
 * @Date: 2018-12-18 14:47:41
 * @Last Modified by: roamye
 * @Last Modified time: 2019-12-17 16:19:28
 * buffer内容为: animationClipCount | nodeCount | [animation_clip_id,frame_index,blendWeight] * animationClipCount | [entityId] * nodeCount
 */
var curve_1 = __webpack_require__(42);
// Buffer Offset in Uint32
var OFFSET_ANIMATIONCLIPNODES = 4;
// tslint:disable-next-line: class-name
var AnimationClipModel = /** @class */ (function () {
    function AnimationClipModel(id) {
        this.contentoffset = 0;
        this.frameRate = 0;
        this.frameLength = 0;
        this.totalSampleGroup = 0;
        this.nodes = {};
        this.nodesLength = 0;
        this._id = id;
        this.id = this._id;
    }
    AnimationClipModel.prototype.setAnimationClip = function (buffer) {
        this._f32View = new Float32Array(buffer);
        this._u32View = new Uint32Array(buffer);
        this.contentoffset = this._u32View[0];
        this.frameRate = this._f32View[1];
        this.frameLength = this._u32View[2];
        this.totalSampleGroup = this._u32View[3];
        this.nodes = {};
        this._initAnimationClipNodes();
        this.nodesLength = Object.keys(this.nodes).length;
    };
    AnimationClipModel.prototype._initAnimationClipNodes = function () {
        if (!(this._f32View && this._u32View)) {
            return;
        }
        this.contentoffset = this._u32View[0];
        this.frameRate = this._f32View[1];
        this.frameLength = this._u32View[2];
        this.totalSampleGroup = this._u32View[3];
        var smapleIndex = 0;
        for (var i = 0; i < this.totalSampleGroup; i++) {
            var nodeId = this._u32View[OFFSET_ANIMATIONCLIPNODES + i * 3 + 0];
            var type = this._u32View[OFFSET_ANIMATIONCLIPNODES + i * 3 + 1];
            var count = this._u32View[OFFSET_ANIMATIONCLIPNODES + i * 3 + 2];
            var transformCurves = this.nodes[nodeId] || (new curve_1.TransformCurve(this.frameRate, this.frameLength, curve_1.CurveMode.Hermite));
            for (var j = 0; j < count; j++) {
                var index = this._u32View[OFFSET_ANIMATIONCLIPNODES + this.totalSampleGroup * 3 + smapleIndex * 4 + 0];
                var value = this._f32View[OFFSET_ANIMATIONCLIPNODES + this.totalSampleGroup * 3 + smapleIndex * 4 + 1];
                var inTangent = this._f32View[OFFSET_ANIMATIONCLIPNODES + this.totalSampleGroup * 3 + smapleIndex * 4 + 2];
                var outTangent = this._f32View[OFFSET_ANIMATIONCLIPNODES + this.totalSampleGroup * 3 + smapleIndex * 4 + 3];
                if (index >= this.frameLength) {
                    console.error("Index out of range: ", index, this.frameLength);
                }
                smapleIndex++;
                transformCurves.addKeyFrame({ index: index, value: value, inTangent: inTangent, outTangent: outTangent }, type);
            }
            this.nodes[nodeId] = transformCurves;
        }
        this.nodesLength = Object.keys(this.nodes).length;
    };
    AnimationClipModel.prototype.evaluate = function (frameIndex) {
        while (frameIndex > this.frameLength - 1) {
            frameIndex -= this.frameLength - 1;
        }
        var targetIndex = frameIndex;
        var result = Object.create(null);
        for (var nodeId in this.nodes) {
            result[nodeId] = this.nodes[nodeId].evaluate(targetIndex);
        }
        return result;
    };
    return AnimationClipModel;
}());
exports.default = AnimationClipModel;


/***/ }),
/* 42 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.TransformCurve = exports.TransformCurveRotationMode = exports.TransformCurveType = exports.Curve = exports.CurveMode = void 0;
var CurveMode;
(function (CurveMode) {
    CurveMode[CurveMode["Hermite"] = 0] = "Hermite";
    // Catmull_Rom,
    // CentripetalCatmull_Rom,
})(CurveMode = exports.CurveMode || (exports.CurveMode = {}));
var Curve = /** @class */ (function () {
    function Curve(keyFrames, fps, frameCount, mode) {
        if (mode === void 0) { mode = CurveMode.Hermite; }
        this.keyFrames = keyFrames;
        this.fps = fps;
        this.frameCount = frameCount;
        this.mode = mode;
    }
    Curve.prototype.evaluate = function (index, blendForLoop) {
        if (blendForLoop === void 0) { blendForLoop = false; }
        if (this.mode === CurveMode.Hermite) {
            /* curve do not need cache ,because of model cache */
            return this._evaluate(index, blendForLoop);
        }
        return null;
    };
    Object.defineProperty(Curve.prototype, "keyCount", {
        get: function () {
            return this.keyFrames.length;
        },
        enumerable: false,
        configurable: true
    });
    Curve.prototype.addKeyFraem = function (keyFrame) {
        var found = this._findKeyIndex(keyFrame.index);
        this.keyFrames.splice(found, 0, keyFrame);
    };
    Curve.prototype._evaluate = function (index, blendForLoop) {
        if (!this.keyFrames.length) {
            return null;
        }
        var keyIndex = this._findKeyIndex(index);
        if (this.keyFrames[keyIndex] && this.keyFrames[keyIndex].index === index) {
            return this.keyFrames[keyIndex].value;
        }
        else if (keyIndex === 0 || keyIndex === this.keyFrames.length) {
            /**
             * Before the fisrt key or after the last key
             */
            if (blendForLoop) {
                if (this.mode === CurveMode.Hermite) {
                    var v1 = this.keyFrames[this.keyFrames.length - 1];
                    var v2 = this.keyFrames[0];
                    var dt = (this.frameCount - 1 - v1.index + index) / this.fps;
                    var coef = (keyIndex === 0 ? index - v1.index + index : index - v2.index) / (v2.index - v1.index);
                    var coef_2 = coef * coef;
                    var coef_3 = coef_2 * coef;
                    return (2 * coef_3 - 3 * coef_2 + 1) * v1.value + (coef_3 - 2 * coef_2 + coef) * dt * v1.outTangent + (-2 * coef_3 + 3 * coef_2) * v2.value + (coef_3 - coef_2) * dt * v2.inTangent;
                }
                else {
                    return null;
                }
            }
            else {
                if (this.mode === CurveMode.Hermite) {
                    return this.keyFrames[keyIndex === 0 ? 0 : this.keyFrames.length - 1].value;
                }
                else {
                    return null;
                }
            }
        }
        else {
            if (this.mode === CurveMode.Hermite) {
                var v1 = this.keyFrames[keyIndex - 1];
                var v2 = this.keyFrames[keyIndex];
                var dt = (v2.index - v1.index) / this.fps;
                var coef = (index - v1.index) / (v2.index - v1.index);
                var coef_2 = coef * coef;
                var coef_3 = coef_2 * coef;
                if (Number.isFinite(v1.outTangent) && Number.isFinite(v2.inTangent))
                    return (2 * coef_3 - 3 * coef_2 + 1) * v1.value + (coef_3 - 2 * coef_2 + coef) * dt * v1.outTangent + (-2 * coef_3 + 3 * coef_2) * v2.value + (coef_3 - coef_2) * dt * v2.inTangent;
                else
                    return v1.value;
            }
            else {
                return null;
            }
        }
    };
    Curve.prototype._findKeyIndex = function (index) {
        var left = 0;
        var right = this.keyFrames.length;
        var mid = Math.floor((left + right) / 2);
        while (left < right) {
            mid = Math.floor((left + right) / 2);
            if (this.keyFrames[mid].index >= index) {
                right = mid;
            }
            else {
                left = mid + 1;
            }
        }
        return left;
    };
    return Curve;
}());
exports.Curve = Curve;
var TransformCurveType;
(function (TransformCurveType) {
    TransformCurveType[TransformCurveType["TranslateX"] = 1] = "TranslateX";
    TransformCurveType[TransformCurveType["TranslateY"] = 2] = "TranslateY";
    TransformCurveType[TransformCurveType["TranslateZ"] = 3] = "TranslateZ";
    TransformCurveType[TransformCurveType["ScaleX"] = 4] = "ScaleX";
    TransformCurveType[TransformCurveType["ScaleY"] = 5] = "ScaleY";
    TransformCurveType[TransformCurveType["ScaleZ"] = 6] = "ScaleZ";
    TransformCurveType[TransformCurveType["QuaternionX"] = 7] = "QuaternionX";
    TransformCurveType[TransformCurveType["QuaternionY"] = 8] = "QuaternionY";
    TransformCurveType[TransformCurveType["QuaternionZ"] = 9] = "QuaternionZ";
    TransformCurveType[TransformCurveType["QuaternionW"] = 10] = "QuaternionW";
    TransformCurveType[TransformCurveType["EulerX"] = 11] = "EulerX";
    TransformCurveType[TransformCurveType["EulerY"] = 12] = "EulerY";
    TransformCurveType[TransformCurveType["EulerZ"] = 13] = "EulerZ";
})(TransformCurveType = exports.TransformCurveType || (exports.TransformCurveType = {}));
var TransformCurveRotationMode;
(function (TransformCurveRotationMode) {
    TransformCurveRotationMode[TransformCurveRotationMode["None"] = 0] = "None";
    TransformCurveRotationMode[TransformCurveRotationMode["Euler"] = 1] = "Euler";
    TransformCurveRotationMode[TransformCurveRotationMode["Quaternion"] = 2] = "Quaternion";
})(TransformCurveRotationMode = exports.TransformCurveRotationMode || (exports.TransformCurveRotationMode = {}));
var TransformCurve = /** @class */ (function () {
    function TransformCurve(fps, frameLength, mode) {
        if (mode === void 0) { mode = CurveMode.Hermite; }
        this.fps = fps;
        this.frameLength = frameLength;
        this.mode = mode;
        this._rotationMode = TransformCurveRotationMode.None;
        this._translateX = new Curve([], fps, frameLength, mode);
        this._translateY = new Curve([], fps, frameLength, mode);
        this._translateZ = new Curve([], fps, frameLength, mode);
        this._scaleX = new Curve([], fps, frameLength, mode);
        this._scaleY = new Curve([], fps, frameLength, mode);
        this._scaleZ = new Curve([], fps, frameLength, mode);
        this._rotationX = new Curve([], fps, frameLength, mode);
        this._rotationY = new Curve([], fps, frameLength, mode);
        this._rotationZ = new Curve([], fps, frameLength, mode);
        this._rotationW = new Curve([], fps, frameLength, mode);
    }
    Object.defineProperty(TransformCurve.prototype, "rotationMode", {
        get: function () {
            return this._rotationMode;
        },
        enumerable: false,
        configurable: true
    });
    TransformCurve.prototype.addKeyFrame = function (value, type) {
        switch (type) {
            case TransformCurveType.TranslateX:
                this._translateX.addKeyFraem(value);
                break;
            case TransformCurveType.TranslateY:
                this._translateY.addKeyFraem(value);
                break;
            case TransformCurveType.TranslateZ:
                this._translateZ.addKeyFraem(value);
                break;
            case TransformCurveType.ScaleX:
                this._scaleX.addKeyFraem(value);
                break;
            case TransformCurveType.ScaleY:
                this._scaleY.addKeyFraem(value);
                break;
            case TransformCurveType.ScaleZ:
                this._scaleZ.addKeyFraem(value);
                break;
            case TransformCurveType.QuaternionX:
            case TransformCurveType.EulerX:
                this._rotationX.addKeyFraem(value);
                break;
            case TransformCurveType.QuaternionY:
            case TransformCurveType.EulerY:
                this._rotationY.addKeyFraem(value);
                break;
            case TransformCurveType.QuaternionZ:
            case TransformCurveType.EulerZ:
                this._rotationZ.addKeyFraem(value);
                break;
            case TransformCurveType.QuaternionW:
                this._rotationW.addKeyFraem(value);
                break;
            default: break;
        }
    };
    TransformCurve.prototype.evaluate = function (frameIndex) {
        var result = Object.create(null);
        result.tx = this._translateX.evaluate(frameIndex);
        result.ty = this._translateY.evaluate(frameIndex);
        result.tz = this._translateZ.evaluate(frameIndex);
        result.sx = this._scaleX.evaluate(frameIndex);
        result.sy = this._scaleY.evaluate(frameIndex);
        result.sz = this._scaleZ.evaluate(frameIndex);
        result.rx = this._rotationX.evaluate(frameIndex);
        result.ry = this._rotationY.evaluate(frameIndex);
        result.rz = this._rotationZ.evaluate(frameIndex);
        result.rw = this._rotationW.evaluate(frameIndex);
        if (result.rw) {
            if (result.rx === null || result.ry === null || result.rz === null) {
                result.rx = result.ry = result.rz = result.rw = null;
                result.use_quaternion = false;
            }
            else {
                var length = Math.sqrt(result.rx * result.rx + result.ry * result.ry + result.rz * result.rz + result.rw * result.rw);
                result.rx /= length;
                result.ry /= length;
                result.rz /= length;
                result.rw /= length;
                result.use_quaternion = true;
            }
        }
        else {
            result.use_quaternion = false;
        }
        return result;
    };
    TransformCurve.TransformCurveRotationMode = TransformCurveRotationMode;
    TransformCurve.TransformCurveType = TransformCurveType;
    return TransformCurve;
}());
exports.TransformCurve = TransformCurve;


/***/ }),
/* 43 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/*
 * @Author: roamye
 * @Date: 2019-10-14 21:35:37
 * @Last Modified by: roamye
 * @Last Modified time: 2019-12-17 15:54:21
 * buffer内容为 所有的骨骼节点的inverseMatrix
 */
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var matrix4_1 = tslib_1.__importDefault(__webpack_require__(44));
var SkeletonBoneInverseModel = /** @class */ (function () {
    function SkeletonBoneInverseModel(id) {
        this.boneNum = 0;
        this.inverseMatrixs = [];
        this._id = id;
        this.id = this._id;
    }
    SkeletonBoneInverseModel.prototype.setBoneInverseMatrix = function (matrices) {
        var view = new Float32Array(matrices.length);
        view.set(matrices);
        var buffer = view.buffer;
        this.inverseMatrixs = [];
        var boneNum = (this.boneNum = buffer.byteLength / 64);
        for (var i = 0; i < boneNum; i++) {
            this.inverseMatrixs.push(matrix4_1.default.createFromTypedArray(new Float32Array(buffer, i * 64, 16)));
        }
    };
    return SkeletonBoneInverseModel;
}());
exports.default = SkeletonBoneInverseModel;


/***/ }),
/* 44 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var utils_1 = __webpack_require__(20);
var vector3_1 = tslib_1.__importDefault(__webpack_require__(45));
var vector4_1 = tslib_1.__importDefault(__webpack_require__(46));
// read only temp value
var tempIdentityArray = new Float32Array(16);
tempIdentityArray.set([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1], 0);
/**
 * @public
 */
var Matrix4 = /** @class */ (function () {
    function Matrix4(raw, offset) {
        this._raw = raw ? raw : new Float32Array(16);
        this._offset = offset ? offset : 0;
    }
    Object.defineProperty(Matrix4, "IDENTITY", {
        /**
         * 单位矩阵
         * 每次访问会重新创建
         *
         * @readonly
         * @static
         * @memberof Matrix4
         */
        get: function () {
            var ret = new Matrix4();
            ret._raw.set(tempIdentityArray);
            return ret;
        },
        enumerable: false,
        configurable: true
    });
    /**
     * 相机矩阵
     *
     * @static
     * @param {Vector3} position
     * @param {Vector3} target
     * @param {Vector3} up
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.lookAt = function (position, target, up, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.lookAt(position._raw, position._offset, target._raw, target._offset, up._raw, up._offset, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 透视投影矩阵
     *
     * @static
     * @param {number} fieldOfViewRadians 用弧度表示
     * @param {number} aspect
     * @param {number} near
     * @param {number} far
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.perspective = function (fieldOfViewRadians, aspect, near, far, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.perspective(fieldOfViewRadians, aspect, near, far, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 正交投影矩阵
     *
     * @static
     * @param {number} left
     * @param {number} right
     * @param {number} bottom
     * @param {number} top
     * @param {number} near
     * @param {number} far
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.orthographic = function (left, right, bottom, top, near, far, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.orthographic(left, right, bottom, top, near, far, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 从四元数创建旋转矩阵
     *
     * @static
     * @param {Quaternion} rotation
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.fromQuaternion = function (rotation, dst) {
        dst = dst || new Matrix4();
        utils_1.quatHelper.toMatrix4(rotation._raw, rotation._offset, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 使用一个数组创建
     * 此操作会拷贝一份数组
     *
     * @static
     * @param {number[]} array
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.createFromArray = function (array) {
        if (array.length !== 16) {
            throw new Error("create Matrix Error:array length is wrong");
        }
        return new Matrix4(new Float32Array(array));
    };
    /**
     * 使用某个已有的typedArray创建
     * 此操作不会拷贝数据，而是在原来的内存区域上操作
     *
     * @static
     * @param {Float32Array} array
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.createFromTypedArray = function (array, offset) {
        if (offset === void 0) { offset = 0; }
        if (array.length - offset < 16) {
            throw new Error("create Matrix Error:array length is wrong");
        }
        return new Matrix4(array, offset);
    };
    /**
     * 绕Z轴旋转的矩阵
     *
     * @static
     * @param {number} rad
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.createRotationX = function (rad, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.xRotation(rad, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 绕Y轴旋转的矩阵
     *
     * @static
     * @param {number} rad
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.createRotationY = function (rad, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.yRotation(rad, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 绕Z轴旋转的矩阵
     *
     * @static
     * @param {number} rad
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.createRotationZ = function (rad, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.zRotation(rad, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 绕指定轴旋转的矩阵
     *
     * @static
     * @param {Vector3} axis
     * @param {number} angleInRadians
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.createRotationAxis = function (axis, angleInRadians, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.axisRotation(axis._raw, axis._offset, angleInRadians, dst._raw, dst._offset);
        return dst;
    };
    Matrix4.composeTRS = function (translation, rotation, scale, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.composeTRS(translation._raw, translation._offset, rotation._raw, rotation._offset, scale._raw, scale._offset, dst._raw, dst._offset);
        return dst;
    };
    Matrix4.composeTQS = function (translation, rotation, scale, dst) {
        dst = Matrix4.fromQuaternion(rotation, dst);
        Matrix4.composeTRS(translation, dst, scale, dst);
        return dst;
    };
    /**
     * 从matrix3的RST矩阵扩展到matrix4
     *
     * @static
     * @param {Matrix3} m3
     * @param {Matrix4} [dst]
     * @memberof Matrix4
     */
    Matrix4.composeFromRST3 = function (m3, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.composeRST3toRST4(m3._raw, m3._offset, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 返回数组
     *
     * @returns {number[]}
     * @memberof Matrix4
     */
    Matrix4.prototype.toArray = function () {
        var arr = new Array(16);
        for (var i = 0; i < 16; i++) {
            arr[i] = this._raw[this._offset + i];
        }
        return arr;
    };
    /**
     * 位移变换
     *
     * @param {number} tx
     * @param {number} ty
     * @param {number} tz
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.prototype.translate = function (tx, ty, tz, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.translate(this._raw, this._offset, tx, ty, tz, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 缩放变换
     *
     * @param {number} sx
     * @param {number} sy
     * @param {number} sz
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.prototype.scale = function (sx, sy, sz, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.scale(this._raw, this._offset, sx, sy, sz, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 绕x轴旋转
     *
     * @param {number} rx 用弧度表示
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.prototype.xRotate = function (rx, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.xRotate(this._raw, this._offset, rx, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 绕y轴旋转
     *
     * @param {number} ry 用弧度表示
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.prototype.yRotate = function (ry, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.yRotate(this._raw, this._offset, ry, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 绕z轴旋转
     *
     * @param {number} rz 用弧度表示
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.prototype.zRotate = function (rz, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.zRotate(this._raw, this._offset, rz, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 绕指定轴旋转
     *
     * @param {Vector3} axis 轴向量
     * @param {number} angleInRadians 用弧度表示
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.prototype.axisRotate = function (axis, angleInRadians, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.axisRotate(this._raw, this._offset, axis._raw, axis._offset, angleInRadians, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 使用指定四元数旋转
     *
     * @param {Quaternion} quaternion
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.prototype.rotateByQuaternion = function (quaternion, dst) {
        dst = dst || new Matrix4();
        var matRotation = temp_Mat4;
        Matrix4.fromQuaternion(quaternion, matRotation);
        this.multiply(matRotation, dst);
        return dst;
    };
    /**
     * 矩阵的逆
     *
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.prototype.inverse = function (dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.inverse(this._raw, this._offset, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 矩阵的转置
     *
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.prototype.transpose = function (dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.transpose(this._raw, this._offset, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 矩阵相乘
     *
     * @param {Matrix4} m
     * @param {Matrix4} [dst]
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.prototype.multiply = function (m, dst) {
        dst = dst || new Matrix4();
        utils_1.m4Helper.multiply(this._raw, this._offset, m._raw, m._offset, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 矩阵变换作用于向量
     *
     * @param {Vector4} v
     * @param {Vector4} [dst]
     * @returns {Vector4}
     * @memberof Matrix4
     */
    Matrix4.prototype.transformVector = function (v, dst) {
        dst = dst || new vector4_1.default();
        utils_1.m4Helper.transformVector(this._raw, this._offset, v._raw, v._offset, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 矩阵变换作用于方向
     * 这里将忽略位移分量，相当于transformVector(p.x,p.y,p.z,0)
     *
     *
     * @param {Vector3} dir
     * @param {Vector3} [dst]
     * @returns {Vector3}
     * @memberof Matrix4
     */
    Matrix4.prototype.transformDirection = function (dir, dst) {
        dst = dst || vector3_1.default.ZERO;
        utils_1.m4Helper.transformDirection(this._raw, this._offset, dir._raw, dir._offset, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 矩阵变换作用于点
     * 这里相当于transformVector(p.x,p.y,p.z,1)
     *
     * @param {Vector3} p
     * @param {Vector3} [dst]
     * @returns {Vector3}
     * @memberof Matrix4
     */
    Matrix4.prototype.transformPoint = function (p, dst) {
        dst = dst || vector3_1.default.ZERO;
        utils_1.m4Helper.transformPoint(this._raw, this._offset, p._raw, p._offset, dst._raw, dst._offset);
        return dst;
    };
    /**
     * 设置矩阵的值
     *
     * @param {Matrix4} val
     * @memberof Matrix4
     */
    Matrix4.prototype.set = function (val) {
        utils_1.m4Helper.copy(val._raw, val._offset, this._raw, this._offset);
        return this;
    };
    /**
     * 克隆矩阵
     *
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.prototype.clone = function () {
        var newm = new Matrix4();
        utils_1.m4Helper.copy(this._raw, this._offset, newm._raw, newm._offset);
        return newm;
    };
    /**
     * 分解矩阵为位移、旋转、缩放向量，返回是否成功
     *
     * @param {Vector3} translation
     * @param {Matrix4} rotationMatrix
     * @param {Vector3} scale
     * @returns {boolean}
     * @memberof Matrix4
     */
    Matrix4.prototype.decomposeTransRotMatScale = function (translation, rotationMatrix, scale) {
        return utils_1.m4Helper.decomposeTransRotMatScale(this._raw, this._offset, translation._raw, translation._offset, rotationMatrix._raw, rotationMatrix._offset, scale._raw, scale._offset);
    };
    /**
     * 设置矩阵某行某列的值
     *
     * @param {number} value
     * @param {number} column
     * @param {number} row
     * @returns {Matrix4} 返回自身
     * @memberof Matrix4
     */
    Matrix4.prototype.setValue = function (value, column, row) {
        this._raw[this._offset + column * 4 + row] = value;
        return this;
    };
    /**
     * 获取矩阵某行某列的值
     *
     *
     * @param {number} column
     * @param {number} row
     * @returns {number}
     * @memberof Matrix4
     */
    Matrix4.prototype.getValue = function (column, row) {
        return this._raw[this._offset + column * 4 + row];
    };
    /**
     * 设置矩阵某列
     *
     * @param {V4ReadOnly} vec
     * @param {number} column
     * @returns {Matrix4}
     * @memberof Matrix4
     */
    Matrix4.prototype.setColumn = function (vec, column) {
        var base = this._offset + column * 4;
        this._raw[base] = vec.x;
        this._raw[base + 1] = vec.y;
        this._raw[base + 2] = vec.z;
        this._raw[base + 3] = vec.w;
        return this;
    };
    /**
     * 获取矩阵某列
     *
     * @param {number} column
     * @param {Vector4} [dst]
     * @returns {Vector4}
     * @memberof Matrix4
     */
    Matrix4.prototype.getColumn = function (column, dst) {
        dst = dst || new vector4_1.default();
        var base = this._offset + column * 4;
        dst.setValue(this._raw[base], this._raw[base + 1], this._raw[base + 2], this._raw[base + 3]);
        return dst;
    };
    /**
     * 设置矩阵某行
     *
     * @param {V4ReadOnly} vec
     * @param {number} row
     * @returns {Matrix4} 返回自身
     * @memberof Matrix4
     */
    Matrix4.prototype.setRow = function (vec, row) {
        var base = this._offset + row;
        this._raw[base] = vec.x;
        this._raw[base + 1 * 4] = vec.y;
        this._raw[base + 2 * 4] = vec.z;
        this._raw[base + 3 * 4] = vec.w;
        return this;
    };
    /**
     * 获取矩阵某行
     *
     * @param {number} row
     * @param {Vector4} [dst]
     * @returns {Vector4}
     * @memberof Matrix4
     */
    Matrix4.prototype.getRow = function (row, dst) {
        dst = dst || new vector4_1.default();
        var base = this._offset + row;
        dst.setValue(this._raw[base], this._raw[base + 1 * 4], this._raw[base + 2 * 4], this._raw[base + 3 * 4]);
        return dst;
    };
    return Matrix4;
}());
exports.default = Matrix4;
var temp_Mat4 = new Matrix4();


/***/ }),
/* 45 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var utils_1 = __webpack_require__(20);
var Vector3 = /** @class */ (function () {
    function Vector3(raw, offset) {
        this._raw = raw ? raw : new Float32Array(3);
        this._offset = offset ? offset : 0;
    }
    Object.defineProperty(Vector3.prototype, "x", {
        get: function () {
            return this._raw[this._offset];
        },
        set: function (val) {
            this._raw[this._offset] = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Vector3.prototype, "y", {
        get: function () {
            return this._raw[this._offset + 1];
        },
        set: function (val) {
            this._raw[this._offset + 1] = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Vector3.prototype, "z", {
        get: function () {
            return this._raw[this._offset + 2];
        },
        set: function (val) {
            this._raw[this._offset + 2] = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Vector3, "ZERO", {
        get: function () {
            var raw = new Float32Array([0, 0, 0]);
            return new Vector3(raw);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Vector3, "ONE", {
        /**
         * create by clairli
         */
        get: function () {
            var raw = new Float32Array([1, 1, 1]);
            return new Vector3(raw);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Vector3, "Up", {
        /**
         * create by clairli
         */
        get: function () {
            var raw = new Float32Array([0, 1, 0]);
            return new Vector3(raw);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Vector3, "ForwardRH", {
        /**
         * create by clairli
         */
        get: function () {
            var raw = new Float32Array([0, 0, -1]);
            return new Vector3(raw);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Vector3, "ForwardLH", {
        /**
         * create by clairli
         */
        get: function () {
            var raw = new Float32Array([0, 0, 1]);
            return new Vector3(raw);
        },
        enumerable: false,
        configurable: true
    });
    /**
     * 使用数值创建
     * 推荐使用这种方式代替new Vector3
     *
     * @static
     * @param {number} [x]
     * @param {number} [y]
     * @param {number} [z]
     * @returns {Vector3}
     * @memberof Vector3
     */
    Vector3.createFromNumber = function (x, y, z) {
        var raw = new Float32Array(3);
        raw[0] = x;
        raw[1] = y;
        raw[2] = z;
        return new Vector3(raw);
    };
    /**
     * 使用一个数组创建
     * 此操作会拷贝一份数组
     *
     * @static
     * @param {number[]} array
     * @returns {Vector3}
     * @memberof Vector3
     */
    Vector3.createFromArray = function (array) {
        if (array.length !== 3) {
            array = new Array(3).fill(0);
        }
        return new Vector3(new Float32Array(array));
    };
    /**
     * 使用某个已有的typedArray创建
     * 此操作不会拷贝数据，而是在原来的内存区域上操作
     *
     * @static
     * @param {Float32Array} array
     * @returns {Vector3}
     * @memberof Vector3
     */
    Vector3.createFromTypedArray = function (array, offset) {
        if (offset === void 0) { offset = 0; }
        if (array.length - offset < 3) {
            array = new Float32Array(3).fill(0);
            offset = 0;
        }
        return new Vector3(array, offset);
    };
    /**
     * create by clairli
     * @param source
     * @param rotation
     * @param dst
     */
    Vector3.transformQuat = function (source, rotation, dst) {
        dst = dst || Vector3.ZERO;
        utils_1.quatHelper.transformDirection(rotation._raw, rotation._offset, source._raw, source._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    /**
     * create by clairli
     * @param coordinate
     * @param transform
     * @param dst
     */
    Vector3.transformCoordinate = function (coordinate, transform, dst) {
        dst = transform.transformPoint(coordinate, dst);
        return dst;
    };
    Vector3.prototype.toArray = function () {
        var thisRaw = this._raw;
        return [thisRaw[this._offset], thisRaw[this._offset + 1], thisRaw[this._offset + 2]];
    };
    Vector3.prototype.equal = function (v) {
        return utils_1.v3Helper.equal(this._raw, this._offset, v._raw, v._offset);
    };
    Vector3.prototype.set = function (v) {
        utils_1.v3Helper.copy(v._raw, v._offset, this._raw, this._offset);
    };
    Vector3.prototype.setValue = function (x, y, z) {
        var thisRaw = this._raw;
        thisRaw[this._offset] = x;
        thisRaw[this._offset + 1] = y;
        thisRaw[this._offset + 2] = z;
        return this;
    };
    Vector3.prototype.add = function (v, dst) {
        dst = dst || new Vector3();
        utils_1.v3Helper.add(this._raw, this._offset, v._raw, v._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector3.prototype.sub = function (v, dst) {
        dst = dst || new Vector3();
        utils_1.v3Helper.sub(this._raw, this._offset, v._raw, v._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector3.prototype.cross = function (v, dst) {
        dst = dst || new Vector3();
        utils_1.v3Helper.cross(this._raw, this._offset, v._raw, v._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector3.prototype.normalize = function (dst) {
        dst = dst || new Vector3();
        utils_1.v3Helper.normalize(this._raw, this._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector3.prototype.scale = function (f, dst) {
        dst = dst || new Vector3();
        utils_1.v3Helper.scale(this._raw, this._offset, f, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector3.prototype.scaleXYZ = function (x, y, z, dst) {
        dst = dst || new Vector3();
        var thisRaw = this._raw;
        dst.setValue(thisRaw[this._offset] * x, thisRaw[this._offset + 1] * y, thisRaw[this._offset + 2] * z);
        return dst;
    };
    Vector3.prototype.lerp = function (v, f, dst) {
        dst = dst || new Vector3();
        utils_1.v3Helper.lerp(this._raw, this._offset, v._raw, v._offset, f, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector3.prototype.dot = function (v) {
        return utils_1.v3Helper.dot(this._raw, this._offset, v._raw, v._offset);
    };
    Vector3.prototype.length = function () {
        return utils_1.v3Helper.length(this._raw, this._offset);
    };
    Vector3.prototype.clone = function () {
        var dst = new Vector3();
        utils_1.v3Helper.copy(this._raw, this._offset, dst._raw, dst._offset);
        return dst;
    };
    Vector3.prototype.isZero = function () {
        return utils_1.v3Helper.isZero(this._raw, this._offset);
    };
    Vector3.prototype.distanceTo = function (v) {
        return utils_1.v3Helper.distance(this._raw, this._offset, v._raw, v._offset);
    };
    Vector3.prototype.angleTo = function (location, dst) {
        dst = dst || Vector3.ZERO;
        utils_1.v3Helper.angleTo(this._raw, this._offset, location._raw, location._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector3.prototype.setFromMatrixColumn = function (m, index) {
        return this.fromArray(m._raw, index * 4);
    };
    Vector3.prototype.fromArray = function (array, offset) {
        if (offset === undefined) {
            offset = 0;
        }
        var thisRaw = this._raw;
        thisRaw[this._offset] = array[offset];
        thisRaw[this._offset + 1] = array[offset + 1];
        thisRaw[this._offset + 2] = array[offset + 2];
        return this;
    };
    Vector3.prototype.setFromMatrixScale = function (m) {
        var sx = this.setFromMatrixColumn(m, 0).length();
        var sy = this.setFromMatrixColumn(m, 1).length();
        var sz = this.setFromMatrixColumn(m, 2).length();
        var thisRaw = this._raw;
        thisRaw[this._offset] = sx;
        thisRaw[this._offset + 1] = sy;
        thisRaw[this._offset + 2] = sz;
        return this;
    };
    /**
     * create by janzen
     * Sets this vector to the position elements of the transformation matrix
     */
    Vector3.prototype.setFromMatrixPosition = function (worldMatrix) {
        var e = worldMatrix._raw;
        var thisRaw = this._raw;
        thisRaw[this._offset] = e[worldMatrix._offset + 12];
        thisRaw[this._offset + 1] = e[worldMatrix._offset + 13];
        thisRaw[this._offset + 2] = e[worldMatrix._offset + 14];
        return this;
    };
    /**
     * create by janzen
     * Multiplies this vector (with an implicit 1 in the 4th dimension) and m, and divides by perspective.
     */
    Vector3.prototype.applyMatrix4 = function (m) {
        return Vector3.transformCoordinate(this, m, this);
    };
    /**
     * create by janzen
     * Transforms the direction of this vector by a matrix (the upper left 3 x 3 subset of a m) and then normalizes the result.
     */
    Vector3.prototype.transformDirection = function (m) {
        // input: THREE.Matrix4 affine matrix
        // vector interpreted as a direction
        var thisRaw = this._raw;
        // tslint:disable-next-line:one-variable-per-declaration
        var x = thisRaw[this._offset], y = thisRaw[this._offset + 1], z = thisRaw[this._offset + 2];
        var e = m._raw;
        thisRaw[this._offset] = e[m._offset] * x + e[m._offset + 4] * y + e[m._offset + 8] * z;
        thisRaw[this._offset + 1] = e[m._offset + 1] * x + e[m._offset + 5] * y + e[m._offset + 9] * z;
        thisRaw[this._offset + 2] = e[m._offset + 2] * x + e[m._offset + 6] * y + e[m._offset + 10] * z;
        return this.normalize();
    };
    return Vector3;
}());
exports.default = Vector3;
var tempDst = new Vector3();


/***/ }),
/* 46 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var utils_1 = __webpack_require__(20);
var Vector4 = /** @class */ (function () {
    function Vector4(raw, offset) {
        this._raw = raw ? raw : new Float32Array(4);
        this._offset = offset ? offset : 0;
    }
    Object.defineProperty(Vector4.prototype, "x", {
        get: function () {
            return this._raw[this._offset];
        },
        set: function (val) {
            this._raw[this._offset] = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Vector4.prototype, "y", {
        get: function () {
            return this._raw[this._offset + 1];
        },
        set: function (val) {
            this._raw[this._offset + 1] = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Vector4.prototype, "z", {
        get: function () {
            return this._raw[this._offset + 2];
        },
        set: function (val) {
            this._raw[this._offset + 2] = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Vector4.prototype, "w", {
        get: function () {
            return this._raw[this._offset + 3];
        },
        set: function (val) {
            this._raw[this._offset + 3] = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Vector4, "ZERO", {
        get: function () {
            var raw = new Float32Array(4);
            raw.fill(0);
            return new Vector4(raw);
        },
        enumerable: false,
        configurable: true
    });
    /**
     * 使用数值创建
     * 推荐使用这种方式代替new Vector4
     *
     * @static
     * @param {number} [x]
     * @param {number} [y]
     * @param {number} [z]
     * @param {number} [w]
     * @returns {Vector4}
     * @memberof Vector4
     */
    Vector4.createFromNumber = function (x, y, z, w) {
        var raw = new Float32Array(4);
        raw[0] = x;
        raw[1] = y;
        raw[2] = z;
        raw[3] = w;
        return new Vector4(raw);
    };
    /**
     * 使用一个数组创建
     * 此操作会拷贝一份数组
     *
     * @static
     * @param {number[]} array
     * @returns {Vector4}
     * @memberof Vector4
     */
    Vector4.createFromArray = function (array) {
        if (array.length !== 4) {
            array = new Array(4).fill(0);
        }
        return new Vector4(new Float32Array(array));
    };
    /**
     * 使用某个已有的typedArray创建
     * 此操作不会拷贝数据，而是在原来的内存区域上操作
     *
     * @static
     * @param {Float32Array} array
     * @returns {Vector4}
     * @memberof Vector4
     */
    Vector4.createFromTypedArray = function (array, offset) {
        if (offset === void 0) { offset = 0; }
        if (array.length - offset < 4) {
            array = new Float32Array(4).fill(0);
            offset = 0;
        }
        return new Vector4(array);
    };
    Vector4.prototype.toArray = function () {
        var thisRaw = this._raw;
        return [thisRaw[this._offset + 0], thisRaw[this._offset + 1], thisRaw[this._offset + 2], thisRaw[this._offset + 3]];
    };
    Vector4.prototype.equal = function (v) {
        return utils_1.v4Helper.equal(this._raw, this._offset, v._raw, v._offset);
    };
    Vector4.prototype.set = function (v) {
        utils_1.v4Helper.copy(v._raw, v._offset, this._raw, this._offset);
    };
    Vector4.prototype.setValue = function (x, y, z, w) {
        var thisRaw = this._raw;
        thisRaw[this._offset + 0] = x;
        thisRaw[this._offset + 1] = y;
        thisRaw[this._offset + 2] = z;
        thisRaw[this._offset + 3] = w;
        return this;
    };
    Vector4.prototype.add = function (v, dst) {
        dst = dst || new Vector4();
        utils_1.v4Helper.add(this._raw, this._offset, v._raw, v._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector4.prototype.sub = function (v, dst) {
        dst = dst || new Vector4();
        utils_1.v4Helper.sub(this._raw, this._offset, v._raw, v._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector4.prototype.scale = function (f, dst) {
        dst = dst || new Vector4();
        utils_1.v4Helper.scale(this._raw, this._offset, f, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector4.prototype.lerp = function (v, f, dst) {
        dst = dst || new Vector4();
        utils_1.v4Helper.lerp(this._raw, this._offset, v._raw, v._offset, f, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Vector4.prototype.dot = function (v) {
        return utils_1.v4Helper.dot(this._raw, this._offset, v._raw, v._offset);
    };
    Vector4.prototype.isZero = function () {
        return utils_1.v4Helper.isZero(this._raw, this._offset);
    };
    Vector4.prototype.clone = function () {
        var dst = new Vector4();
        utils_1.v4Helper.copy(this._raw, this._offset, dst._raw, dst._offset);
        return dst;
    };
    return Vector4;
}());
exports.default = Vector4;
var tempDst = new Vector4();


/***/ }),
/* 47 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.staticInitAccelerateDataBuffer = void 0;
var tslib_1 = __webpack_require__(1);
var nativeObject_1 = tslib_1.__importDefault(__webpack_require__(32));
var worker;
function staticInitAccelerateDataBuffer(m_worker) {
    worker = m_worker;
}
exports.staticInitAccelerateDataBuffer = staticInitAccelerateDataBuffer;
var DataBuffer = /** @class */ (function (_super) {
    tslib_1.__extends(DataBuffer, _super);
    function DataBuffer(nativeObj) {
        var _this = _super.call(this) || this;
        _this._init(nativeObj);
        return _this;
    }
    Object.defineProperty(DataBuffer.prototype, "dataLength", {
        get: function () {
            return this._u32view[0];
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(DataBuffer.prototype, "byteOffset", {
        // 数据区起始
        get: function () {
            return this._byteOffset + 4;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(DataBuffer.prototype, "arrayBuffer", {
        get: function () {
            return this._buffer;
        },
        enumerable: false,
        configurable: true
    });
    return DataBuffer;
}(nativeObject_1.default));
exports.default = DataBuffer;


/***/ }),
/* 48 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.staticInitEntity2D = void 0;
var tslib_1 = __webpack_require__(1);
/*
 * @Author: bluecatliao
 * @Date: 2018-11-19 19:02:44
 * @Last Modified by: roamye
 * @Last Modified time: 2020-05-09 00:05:15
 * Entity2D包含了Entity+Transform2D，利用客户端可以加速worldTransform的计算
 */
var def_1 = __webpack_require__(6);
var poolObject_1 = tslib_1.__importDefault(__webpack_require__(36));
var manager;
function staticInitEntity2D(m_manager) {
    manager = m_manager;
}
exports.staticInitEntity2D = staticInitEntity2D;
var Entity2D = /** @class */ (function (_super) {
    tslib_1.__extends(Entity2D, _super);
    function Entity2D(nativeObjId, entity2DPools) {
        var _this = _super.call(this, nativeObjId, entity2DPools) || this;
        _this.entityOffset = _this._poolIndex * def_1.ENTITY2D_SIZE;
        _this.localRotationOffset = _this.entityOffset + def_1.ENTITY2D_OFFSET.OFFSET_ROTATION;
        _this.localPositionOffset = _this.entityOffset + def_1.ENTITY2D_OFFSET.OFFSET_POSITION;
        _this.localScaleOffset = _this.entityOffset + def_1.ENTITY2D_OFFSET.OFFSET_SCALE;
        _this.worldMatrixOffset = _this.entityOffset + def_1.ENTITY2D_OFFSET.OFFSET_WORLDMATRIX;
        return _this;
        // console.log('2d', this._nativePool, this._poolId, this._poolIndex);
    }
    Object.defineProperty(Entity2D.prototype, "localPositionView", {
        get: function () {
            if (!this._localPositionView) {
                this._localPositionView = new Float32Array(this._nativePool._buffer, this.localPositionOffset * 4, 2);
            }
            return this._localPositionView;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Entity2D.prototype, "localRotationView", {
        get: function () {
            if (!this._localRotationView) {
                this._localRotationView = new Float32Array(this._nativePool._buffer, this.localRotationOffset * 4, 1);
            }
            return this._localRotationView;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Entity2D.prototype, "localScaleView", {
        get: function () {
            if (!this._localScaleView) {
                this._localScaleView = new Float32Array(this._nativePool._buffer, this.localScaleOffset * 4, 2);
            }
            return this._localScaleView;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Entity2D.prototype, "worldMatrixView", {
        get: function () {
            if (!this._worldMatrixView) {
                this._worldMatrixView = new Float32Array(this._nativePool._buffer, this.worldMatrixOffset * 4, 9);
            }
            return this._worldMatrixView;
        },
        enumerable: false,
        configurable: true
    });
    Entity2D.prototype.addChild = function (child) {
        manager.entityAddChild(this, child);
    };
    Entity2D.prototype.addChildAtIndex = function (child, index) {
        manager.entityAddChildAtIndex(this, child, index);
    };
    Entity2D.prototype.removeFromParent = function () {
        manager.entityRemoveFromParent(this);
    };
    Entity2D.prototype.destroy = function () {
        manager.entityRemoveFromParent(this);
    };
    Entity2D.prototype.clear = function () {
        manager.entityClear(this);
    };
    Entity2D.prototype.setLocalMatrixDirty = function () {
        manager.entitySetLocalMatrixDirty(this);
    };
    Object.defineProperty(Entity2D.prototype, "active", {
        set: function (val) {
            manager.entitySetActive(this, val);
        },
        enumerable: false,
        configurable: true
    });
    // Static Offset
    Entity2D.OFFSET_ROTATION = def_1.ENTITY2D_OFFSET.OFFSET_ROTATION;
    Entity2D.OFFSET_POSITION = def_1.ENTITY2D_OFFSET.OFFSET_POSITION;
    Entity2D.OFFSET_SCALE = def_1.ENTITY2D_OFFSET.OFFSET_SCALE;
    Entity2D.OFFSET_WORLDMATRIX = def_1.ENTITY2D_OFFSET.OFFSET_WORLDMATRIX;
    Entity2D.ENTITY2D_SIZE = def_1.ENTITY2D_SIZE;
    return Entity2D;
}(poolObject_1.default));
exports.default = Entity2D;


/***/ }),
/* 49 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.staticInitEntity3D = void 0;
var tslib_1 = __webpack_require__(1);
/*
 * @Author: bluecatliao
 * @Date: 2018-11-19 19:02:44
 * @Last Modified by: roamye
 * @Last Modified time: 2020-05-09 00:05:27
 * Entity3D包含了Entity+Transform3D，利用客户端可以加速worldTransform的计算
 * 支持四元数和欧拉角两种模式，但是暂不支持互相转换（即set欧拉角然后get四元数）
 */
// import { NativeObjectInfo, ENTITY3D_OFFSET } from "../def";
// import NativeObject from "../nativeObject";
var def_1 = __webpack_require__(6);
var poolObject_1 = tslib_1.__importDefault(__webpack_require__(36));
var manager;
function staticInitEntity3D(m_manager) {
    manager = m_manager;
}
exports.staticInitEntity3D = staticInitEntity3D;
var Entity3D = /** @class */ (function (_super) {
    tslib_1.__extends(Entity3D, _super);
    function Entity3D(nativeObjId, entity3DPools) {
        var _this = _super.call(this, nativeObjId, entity3DPools) || this;
        _this.entityOffset = _this._poolIndex * def_1.ENTITY3D_SIZE;
        _this.localRotationTypeOffset = _this.entityOffset + def_1.ENTITY3D_OFFSET.OFFSET_ROTATIONTYPE;
        _this.localQuaternionOffset = _this.entityOffset + def_1.ENTITY3D_OFFSET.OFFSET_ROTATION;
        _this.localPositionOffset = _this.entityOffset + def_1.ENTITY3D_OFFSET.OFFSET_POSITION;
        _this.localScaleOffset = _this.entityOffset + def_1.ENTITY3D_OFFSET.OFFSET_SCALE;
        _this.worldMatrixOffset = _this.entityOffset + def_1.ENTITY3D_OFFSET.OFFSET_WORLDMATRIX;
        return _this;
        // console.log('3d', this._nativePool,this._poolId, this._poolIndex, this._entityOffset);
    }
    Entity3D.prototype.setUsingEuler = function (on) {
        if (on) {
            this._nativePool._u32view[this.localRotationTypeOffset] &= ~def_1.ENTITY3D_OFFSET.DF_ROTATIONTYPE;
        }
        else {
            this._nativePool._u32view[this.localRotationTypeOffset] |= def_1.ENTITY3D_OFFSET.DF_ROTATIONTYPE;
        }
    };
    Entity3D.prototype.isUsingEuler = function () {
        return (this._nativePool._u32view[this.localRotationTypeOffset] & def_1.ENTITY3D_OFFSET.DF_ROTATIONTYPE) != 0 ? false : true;
    };
    Object.defineProperty(Entity3D.prototype, "localPositionView", {
        get: function () {
            if (!this._localPositionView) {
                this._localPositionView = new Float32Array(this._nativePool._buffer, this.localPositionOffset * 4, 3);
            }
            return this._localPositionView;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Entity3D.prototype, "localQuaternionView", {
        get: function () {
            if (!this._localQuaternionView) {
                this._localQuaternionView = new Float32Array(this._nativePool._buffer, this.localQuaternionOffset * 4, 4);
            }
            return this._localQuaternionView;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Entity3D.prototype, "localScaleView", {
        get: function () {
            if (!this._localScaleView) {
                this._localScaleView = new Float32Array(this._nativePool._buffer, this.localScaleOffset * 4, 3);
            }
            return this._localScaleView;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Entity3D.prototype, "worldMatrixView", {
        get: function () {
            if (!this._worldMatrixView) {
                this._worldMatrixView = new Float32Array(this._nativePool._buffer, this.worldMatrixOffset * 4, 16);
            }
            return this._worldMatrixView;
        },
        enumerable: false,
        configurable: true
    });
    Entity3D.prototype.addChild = function (child) {
        manager.entityAddChild(this, child);
    };
    Entity3D.prototype.addChildAtIndex = function (child, index) {
        manager.entityAddChildAtIndex(this, child, index);
    };
    Entity3D.prototype.removeFromParent = function () {
        manager.entityRemoveFromParent(this);
    };
    Entity3D.prototype.destroy = function () {
        manager.entityRemoveFromParent(this);
    };
    Entity3D.prototype.clear = function () {
        manager.entityClear(this);
    };
    Entity3D.prototype.setLocalMatrixDirty = function () {
        manager.entitySetLocalMatrixDirty(this);
    };
    Object.defineProperty(Entity3D.prototype, "active", {
        set: function (val) {
            manager.entitySetActive(this, val);
        },
        enumerable: false,
        configurable: true
    });
    Entity3D.prototype.setEntityDebugName = function (name) {
        manager.setEntityName(this.id, name);
    };
    // Static Offset
    Entity3D.OFFSET_ROTATIONTYPE = def_1.ENTITY3D_OFFSET.OFFSET_ROTATIONTYPE;
    Entity3D.OFFSET_ROTATION = def_1.ENTITY3D_OFFSET.OFFSET_ROTATION;
    Entity3D.OFFSET_POSITION = def_1.ENTITY3D_OFFSET.OFFSET_POSITION;
    Entity3D.OFFSET_SCALE = def_1.ENTITY3D_OFFSET.OFFSET_SCALE;
    Entity3D.OFFSET_WORLDMATRIX = def_1.ENTITY3D_OFFSET.OFFSET_WORLDMATRIX;
    Entity3D.DF_ROTATIONTYPE = def_1.ENTITY3D_OFFSET.DF_ROTATIONTYPE;
    Entity3D.ENTITY3D_SIZE = def_1.ENTITY3D_SIZE;
    return Entity3D;
}(poolObject_1.default));
exports.default = Entity3D;


/***/ }),
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.staticInitEntityGroup = void 0;
var tslib_1 = __webpack_require__(1);
var nativeObject_1 = tslib_1.__importDefault(__webpack_require__(32));
var manager;
function staticInitEntityGroup(m_manager) {
    manager = m_manager;
}
exports.staticInitEntityGroup = staticInitEntityGroup;
var EntityGroup = /** @class */ (function (_super) {
    tslib_1.__extends(EntityGroup, _super);
    function EntityGroup(nativeObj, length) {
        var _this = _super.call(this) || this;
        _this._init(nativeObj);
        _this.entityLength = length;
        return _this;
    }
    EntityGroup.prototype.getEntityIdByIndex = function (index) {
        return this._id + index;
    };
    EntityGroup.prototype.getEntityOffsetByIndex = function (index) {
        return index * this.objectSize;
    };
    EntityGroup.prototype.setRawBuffer = function (data, offset) {
        if (offset === void 0) { offset = 0; }
        this._f32view.set(data, offset);
    };
    EntityGroup.prototype.setLocalMatrixDirtyAll = function () {
        manager.entityGroupSetLocalMatrixDirtyAll(this);
    };
    return EntityGroup;
}(nativeObject_1.default));
exports.default = EntityGroup;


/***/ }),
/* 51 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/*
 * @Author: roamye
 * @Date: 2020-05-06 21:10:52
 * @Last Modified by: roamye
 * @Last Modified time: 2020-05-08 23:37:04
 */
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var def_1 = __webpack_require__(6);
var entityGroup_1 = tslib_1.__importDefault(__webpack_require__(50));
var Entity2DGroup = /** @class */ (function (_super) {
    tslib_1.__extends(Entity2DGroup, _super);
    function Entity2DGroup(nativeObj, length) {
        var _this = _super.call(this, nativeObj, length) || this;
        _this.objectSize = def_1.ENTITY2D_SIZE;
        return _this;
    }
    Entity2DGroup.OFFSET_ROTATION = def_1.ENTITY2D_OFFSET.OFFSET_ROTATION;
    Entity2DGroup.OFFSET_POSITION = def_1.ENTITY2D_OFFSET.OFFSET_POSITION;
    Entity2DGroup.OFFSET_SCALE = def_1.ENTITY2D_OFFSET.OFFSET_SCALE;
    Entity2DGroup.OFFSET_WORLDMATRIX = def_1.ENTITY2D_OFFSET.OFFSET_WORLDMATRIX;
    return Entity2DGroup;
}(entityGroup_1.default));
exports.default = Entity2DGroup;


/***/ }),
/* 52 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
/*
 * @Author: roamye
 * @Date: 2020-05-06 21:10:52
 * @Last Modified by: roamye
 * @Last Modified time: 2020-05-08 23:26:23
 * Entity2D包含了Entity+Transform2D，利用客户端可以加速worldTransform的计算
 */
var def_1 = __webpack_require__(6);
var entityGroup_1 = tslib_1.__importDefault(__webpack_require__(50));
var Entity3DGroup = /** @class */ (function (_super) {
    tslib_1.__extends(Entity3DGroup, _super);
    function Entity3DGroup(nativeObj, length) {
        var _this = _super.call(this, nativeObj, length) || this;
        _this.objectSize = def_1.ENTITY3D_SIZE;
        return _this;
    }
    Entity3DGroup.OFFSET_ROTATIONTYPE = def_1.ENTITY3D_OFFSET.OFFSET_ROTATIONTYPE;
    Entity3DGroup.OFFSET_ROTATION = def_1.ENTITY3D_OFFSET.OFFSET_ROTATION;
    Entity3DGroup.OFFSET_POSITION = def_1.ENTITY3D_OFFSET.OFFSET_POSITION;
    Entity3DGroup.OFFSET_SCALE = def_1.ENTITY3D_OFFSET.OFFSET_SCALE;
    Entity3DGroup.OFFSET_WORLDMATRIX = def_1.ENTITY3D_OFFSET.OFFSET_WORLDMATRIX;
    return Entity3DGroup;
}(entityGroup_1.default));
exports.default = Entity3DGroup;


/***/ }),
/* 53 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.staticInitAccelerateEntityCommand = void 0;
var tslib_1 = __webpack_require__(1);
var commandArray_1 = tslib_1.__importStar(__webpack_require__(54));
var def_1 = __webpack_require__(6);
var worker;
function staticInitAccelerateEntityCommand(m_worker) {
    worker = m_worker;
}
exports.staticInitAccelerateEntityCommand = staticInitAccelerateEntityCommand;
var EntityCommand = /** @class */ (function (_super) {
    tslib_1.__extends(EntityCommand, _super);
    function EntityCommand(entityCommandBuffer) {
        return _super.call(this, entityCommandBuffer) || this;
    }
    EntityCommand.prototype._checkBufferSize = function (size) {
        if (commandArray_1.SIZE_UINT32 + this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + size > this._bufferSize) {
            worker.refreshWorldTransform();
        }
    };
    EntityCommand.prototype.setRootEntity = function (entityId) {
        var size = 2 * commandArray_1.SIZE_UINT32;
        this._checkBufferSize(size);
        var offset = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] / commandArray_1.SIZE_UINT32 + 1;
        this._u32view[offset] = def_1.enumEntityCommandType.SetRootEntity;
        this._u32view[offset + 1] = entityId;
        this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + size);
    };
    EntityCommand.prototype.addChild = function (entityId, childEntityId) {
        var size = 3 * commandArray_1.SIZE_UINT32;
        this._checkBufferSize(size);
        var offset = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] / commandArray_1.SIZE_UINT32 + 1;
        this._u32view[offset] = def_1.enumEntityCommandType.AddChild;
        this._u32view[offset + 1] = entityId;
        this._u32view[offset + 2] = childEntityId;
        this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + size);
    };
    EntityCommand.prototype.addChildAtIndex = function (entityId, childEntityId, index) {
        var size = 4 * commandArray_1.SIZE_UINT32;
        this._checkBufferSize(size);
        var offset = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] / commandArray_1.SIZE_UINT32 + 1;
        this._u32view[offset] = def_1.enumEntityCommandType.AddChildAtIndex;
        this._u32view[offset + 1] = entityId;
        this._u32view[offset + 2] = childEntityId;
        this._u32view[offset + 3] = index;
        this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + size);
    };
    EntityCommand.prototype.removeFromParent = function (entityId) {
        var size = 2 * commandArray_1.SIZE_UINT32;
        this._checkBufferSize(size);
        var offset = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] / commandArray_1.SIZE_UINT32 + 1;
        this._u32view[offset] = def_1.enumEntityCommandType.RemoveFromParent;
        this._u32view[offset + 1] = entityId;
        this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + size);
    };
    EntityCommand.prototype.disperseSubTree = function (entityId) {
        var size = 2 * commandArray_1.SIZE_UINT32;
        this._checkBufferSize(size);
        var offset = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] / commandArray_1.SIZE_UINT32 + 1;
        this._u32view[offset] = def_1.enumEntityCommandType.DisperseSubTree;
        this._u32view[offset + 1] = entityId;
        this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + size);
    };
    EntityCommand.prototype.bindToBone = function (entityId, boneId) {
        var size = 3 * commandArray_1.SIZE_UINT32;
        this._checkBufferSize(size);
        var offset = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] / commandArray_1.SIZE_UINT32 + 1;
        this._u32view[offset] = def_1.enumEntityCommandType.BindToBone;
        this._u32view[offset + 1] = entityId;
        this._u32view[offset + 2] = boneId;
        this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + size);
    };
    EntityCommand.prototype.unBindFromBone = function (entityId) {
        var size = 2 * commandArray_1.SIZE_UINT32;
        this._checkBufferSize(size);
        var offset = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] / commandArray_1.SIZE_UINT32 + 1;
        this._u32view[offset] = def_1.enumEntityCommandType.UnBindFromBone;
        this._u32view[offset + 1] = entityId;
        this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + size);
    };
    EntityCommand.prototype.entityCommandActive = function (entityId) {
        var size = 2 * commandArray_1.SIZE_UINT32;
        this._checkBufferSize(size);
        var offset = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] / commandArray_1.SIZE_UINT32 + 1;
        this._u32view[offset] = def_1.enumEntityCommandType.EntityCommandActive;
        this._u32view[offset + 1] = entityId;
        this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + size);
    };
    EntityCommand.prototype.entityCommandInActive = function (entityId) {
        var size = 2 * commandArray_1.SIZE_UINT32;
        this._checkBufferSize(size);
        var offset = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] / commandArray_1.SIZE_UINT32 + 1;
        this._u32view[offset] = def_1.enumEntityCommandType.EntityCommandInActive;
        this._u32view[offset + 1] = entityId;
        this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + size);
    };
    // 兼容旧版接口
    EntityCommand.prototype.bindToBones = function (entities, bones) {
        var entitiesLength = entities.length;
        var size = (2 + entitiesLength * 2) * commandArray_1.SIZE_UINT32;
        this._checkBufferSize(size);
        var offset = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] / commandArray_1.SIZE_UINT32 + 1;
        this._u32view[offset] = def_1.enumEntityCommandType.BindToBones;
        this._u32view[offset + 1] = entitiesLength;
        for (var i = 0; i < entitiesLength; i++) {
            var entity = entities[i];
            var bone = bones[i];
            this._u32view[offset + 2 + i] = entity.id;
            this._u32view[offset + 2 + entitiesLength + i] = bone.id;
        }
        this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + size);
    };
    EntityCommand.prototype.unBindFromBones = function (entities) {
        var entitiesLength = entities.length;
        var size = (2 + entitiesLength) * commandArray_1.SIZE_UINT32;
        this._checkBufferSize(size);
        var offset = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] / commandArray_1.SIZE_UINT32 + 1;
        this._u32view[offset] = def_1.enumEntityCommandType.UnBindFromBones;
        this._u32view[offset + 1] = entitiesLength;
        for (var i = 0; i < entitiesLength; i++) {
            var entity = entities[i];
            this._u32view[offset + 2 + i] = entity.id;
        }
        this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + size);
    };
    return EntityCommand;
}(commandArray_1.default));
exports.default = EntityCommand;


/***/ }),
/* 54 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.OFFSET_COMMANDLENGTH = exports.SIZE_UINT32 = void 0;
var DEAFAULT_BUFFER_SIZE = 1024;
exports.SIZE_UINT32 = 4;
exports.OFFSET_COMMANDLENGTH = 0;
var Command = /** @class */ (function () {
    function Command(buffer) {
        this._bufferSize = 0;
        if (buffer) {
            this.buffer = buffer;
            this._u32view = new Uint32Array(this.buffer, 0, this.buffer.byteLength / 4);
            this._bufferSize = this.buffer.byteLength;
        }
        else {
            this.buffer = new ArrayBuffer(DEAFAULT_BUFFER_SIZE);
            this._u32view = new Uint32Array(this.buffer, 0, this.buffer.byteLength / 4);
            this._bufferSize = DEAFAULT_BUFFER_SIZE;
        }
    }
    Command.prototype._checkBufferSize = function (size) { };
    Command.prototype.setCommandSize = function (val) {
        this._u32view[exports.OFFSET_COMMANDLENGTH] = val;
    };
    return Command;
}());
exports.default = Command;


/***/ }),
/* 55 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.staticInitAccelerateDirtiesCommand = void 0;
var tslib_1 = __webpack_require__(1);
var commandArray_1 = tslib_1.__importStar(__webpack_require__(54));
var worker;
function staticInitAccelerateDirtiesCommand(m_worker) {
    worker = m_worker;
}
exports.staticInitAccelerateDirtiesCommand = staticInitAccelerateDirtiesCommand;
var DirtyEntitiesCommand = /** @class */ (function (_super) {
    tslib_1.__extends(DirtyEntitiesCommand, _super);
    function DirtyEntitiesCommand(dirtyEntities) {
        return _super.call(this, dirtyEntities) || this;
    }
    DirtyEntitiesCommand.prototype._checkBufferSize = function (size) {
        if (this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + size + 1 > this._u32view.length) {
            worker.refreshWorldTransform();
        }
    };
    DirtyEntitiesCommand.prototype.addDirtyEntity = function (entity) {
        this._checkBufferSize(1);
        this._u32view[this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + 1] = entity.id;
        this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + 1);
    };
    DirtyEntitiesCommand.prototype.addDirtyEntityId = function (entityId) {
        this._checkBufferSize(1);
        this._u32view[this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + 1] = entityId;
        this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + 1);
    };
    DirtyEntitiesCommand.prototype.addDirtyEntities = function (entities, entitiesLength) {
        this._checkBufferSize(entitiesLength);
        if (entitiesLength > this._u32view.length) {
            var startIndex = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + 1;
            var len = entitiesLength - (this._u32view.length - 1);
            for (var i = 0; i < len; i++) {
                this._u32view[startIndex + i] = entities[i].id;
            }
            var resetLen = entitiesLength - len;
            for (var i = len; i < resetLen; i++) {
                this.addDirtyEntityId(entities[i].id);
            }
        }
        else {
            var len = entitiesLength;
            var startIndex = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + 1;
            for (var i = 0; i < len; i++) {
                this._u32view[startIndex + i] = entities[i].id;
            }
            this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + len);
        }
    };
    DirtyEntitiesCommand.prototype.addDirtyEntitiesById = function (entityIds, entitiesLength) {
        this._checkBufferSize(entitiesLength);
        if (entitiesLength > this._u32view.length) {
            var startIndex = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + 1;
            var len = entitiesLength - (this._u32view.length - 1);
            for (var i = 0; i < len; i++) {
                this._u32view[startIndex + i] = entityIds[i];
            }
            var resetLen = entitiesLength - len;
            for (var i = len; i < resetLen; i++) {
                this.addDirtyEntityId(entityIds[i]);
            }
        }
        else {
            var len = entitiesLength;
            var startIndex = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + 1;
            for (var i = 0; i < len; i++) {
                this._u32view[startIndex + i] = entityIds[i];
            }
            this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + len);
        }
    };
    DirtyEntitiesCommand.prototype.addDirtyEntityGroupAll = function (entityGroup) {
        this._checkBufferSize(entityGroup.entityLength);
        if (entityGroup.entityLength > this._u32view.length) {
            var startIndex = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + 1;
            var len = entityGroup.entityLength - (this._u32view.length - 1);
            for (var i = 0; i < len; i++) {
                this._u32view[startIndex + i] = entityGroup.getEntityIdByIndex(i);
            }
            var resetLen = entityGroup.entityLength - len;
            for (var i = len; i < resetLen; i++) {
                this.addDirtyEntityId(entityGroup.getEntityIdByIndex(i));
            }
        }
        else {
            var len = entityGroup.entityLength;
            var startIndex = this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + 1;
            for (var i = 0; i < len; i++) {
                this._u32view[startIndex + i] = entityGroup.getEntityIdByIndex(i);
            }
            this.setCommandSize(this._u32view[commandArray_1.OFFSET_COMMANDLENGTH] + len);
        }
    };
    return DirtyEntitiesCommand;
}(commandArray_1.default));
exports.default = DirtyEntitiesCommand;


/***/ }),
/* 56 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var commandArray_1 = tslib_1.__importDefault(__webpack_require__(54));
var SCALE_SIZE = 2;
var SIZE_UINT32 = 4;
var AnimationCommand = /** @class */ (function (_super) {
    tslib_1.__extends(AnimationCommand, _super);
    function AnimationCommand() {
        return _super.call(this) || this;
    }
    AnimationCommand.prototype._checkBufferSize = function (size) {
        if (SIZE_UINT32 + size > this._bufferSize) {
            var scaleSize = (SIZE_UINT32 + size) * SCALE_SIZE;
            this.buffer = new ArrayBuffer(scaleSize);
            this._u32view = new Uint32Array(this.buffer, 0, scaleSize / 4);
            this._bufferSize = scaleSize;
        }
    };
    AnimationCommand.prototype.updateAnimators = function (comps, length) {
        this._checkBufferSize(length * SIZE_UINT32);
        var offset = 1;
        for (var i = 0; i < length; i++) {
            this._u32view[offset + i] = comps[i].id;
        }
        this.setCommandSize(length);
    };
    return AnimationCommand;
}(commandArray_1.default));
exports.default = AnimationCommand;


/***/ }),
/* 57 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var commandArray_1 = tslib_1.__importDefault(__webpack_require__(54));
var SCALE_SIZE = 2;
var SIZE_UINT32 = 4;
var SkinningMatrixCommand = /** @class */ (function (_super) {
    tslib_1.__extends(SkinningMatrixCommand, _super);
    function SkinningMatrixCommand() {
        return _super.call(this) || this;
    }
    SkinningMatrixCommand.prototype._checkBufferSize = function (size) {
        if (SIZE_UINT32 + size > this._bufferSize) {
            var scaleSize = (SIZE_UINT32 + size) * SCALE_SIZE;
            this.buffer = new ArrayBuffer(scaleSize);
            this._u32view = new Uint32Array(this.buffer, 0, scaleSize / 4);
            this._bufferSize = scaleSize;
        }
    };
    SkinningMatrixCommand.prototype.updateSkinningMatrices = function (comps, length) {
        this._checkBufferSize(length * SIZE_UINT32);
        var offset = 1;
        for (var i = 0; i < length; i++) {
            this._u32view[offset + i] = comps[i].id;
        }
        this.setCommandSize(length);
    };
    return SkinningMatrixCommand;
}(commandArray_1.default));
exports.default = SkinningMatrixCommand;


/***/ }),
/* 58 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.scaleNumberArray = exports.NativePools = void 0;
var tslib_1 = __webpack_require__(1);
var def_1 = __webpack_require__(6);
var pool_1 = tslib_1.__importDefault(__webpack_require__(59));
var ENTITY_POOL_LENGTH = 4000;
var NativePools = /** @class */ (function () {
    function NativePools() {
    }
    return NativePools;
}());
exports.NativePools = NativePools;
;
/*
* ENTITY2D_TEMPLATE
*/
var entity2DTemplateF32View = new Float32Array(new ArrayBuffer(4 * def_1.ENTITY2D_SIZE));
// rotation/position/scale
entity2DTemplateF32View.set([0, 0, 0, 1, 1], 0);
/*
* ENTITY3D_TEMPLATE
*/
var entity3DTemplate = new Uint32Array(new ArrayBuffer(4 * def_1.ENTITY3D_SIZE));
var entity3DTemplateF32View = new Float32Array(entity3DTemplate.buffer);
// use quaternion
entity3DTemplate[0] = 1;
// quaternion
entity3DTemplateF32View.set([0, 0, 0, 1], 1 /* 1*4 */);
// position
entity3DTemplateF32View.set([0, 0, 0], 5 /* 5*4 */);
// scale
entity3DTemplateF32View.set([1, 1, 1], 8 /* 8*4 */);
/*
* CULLABLECOMPONET_TEMPLATE
*/
var cullableComponentTemplate = new Uint32Array(new ArrayBuffer(4 * def_1.CULLABLECOMPONENT_SIZE));
var cullableComponentTemplateF32View = new Float32Array(cullableComponentTemplate.buffer);
var scaleNumberArray = /** @class */ (function () {
    function scaleNumberArray(len) {
        this._index = 0;
        this._size = (len != undefined) ? len : 500;
        this._array = new Array(this._size);
    }
    scaleNumberArray.prototype.push = function (val) {
        if (this._index >= this._size) {
            this._size *= 2;
            this._array.length = this._size;
        }
        this._array[this._index] = val;
        this._index++;
    };
    ;
    scaleNumberArray.prototype.pop = function () {
        this._index--;
        return this._array[this._index];
    };
    scaleNumberArray.prototype.getByIndex = function (index) {
        if (index >= this._index) {
            return -1;
        }
        return this._array[index];
    };
    scaleNumberArray.prototype.size = function () {
        return this._index;
    };
    scaleNumberArray.prototype.clear = function () {
        this._index = 0;
    };
    return scaleNumberArray;
}());
exports.scaleNumberArray = scaleNumberArray;
var PoolManager = /** @class */ (function () {
    function PoolManager(worker) {
        this.worker = worker;
        this.entity2DPools = {};
        this._entity2DPoolIndex = 0;
        this._entity2DPoolUsedLength = 0;
        this._entity2DPoolLength = 0;
        this._entity2DDisposedIds = new scaleNumberArray();
        this.entity3DPools = {};
        this._entity3DPoolIndex = 0;
        this._entity3DPoolUsedLength = 0;
        this._entity3DPoolLength = 0;
        this._entity3DDisposedIds = new scaleNumberArray();
        this.cullableComponentPools = {};
        this._cullableComponentPoolIndex = 0;
        this._cullableComponentPoolUsedLength = 0;
        this._cullableComponentPoolLength = 0;
        this._cullableComponentDisposedIds = new scaleNumberArray();
    }
    /*
    * 内部方法
    */
    PoolManager.prototype._enlargeEntity2DPool = function (size) {
        var entity2DPoolNative = this.worker.createEntity(def_1.enumEntityType.Entity2D, size);
        var entity2DPool = new pool_1.default(entity2DPoolNative);
        this._entity2DPoolIndex = entity2DPool.id;
        this.entity2DPools[entity2DPool.id] = entity2DPool;
        this._entity2DPoolLength += size;
    };
    PoolManager.prototype._enlargeEntity3DPool = function (size) {
        var entity3DPoolNative = this.worker.createEntity(def_1.enumEntityType.Entity3D, size);
        var entity3DPool = new pool_1.default(entity3DPoolNative);
        this._entity3DPoolIndex = entity3DPool.id;
        this.entity3DPools[entity3DPool.id] = entity3DPool;
        this._entity3DPoolLength += size;
    };
    PoolManager.prototype._enlargeCullableComponentPool = function (size) {
        var cullableComponentPoolNative = this.worker.createComponent(def_1.enumComponentType.Cullable, size);
        var cullableComponentPool = new pool_1.default(cullableComponentPoolNative);
        this._cullableComponentPoolIndex = cullableComponentPool.id;
        this.cullableComponentPools[cullableComponentPool.id] = cullableComponentPool;
        this._cullableComponentPoolLength += size;
    };
    /*
    * 对外方法
    */
    // 申请2D节点
    PoolManager.prototype.getEntity2D = function () {
        if (this._entity2DDisposedIds.size() > 0) {
            this._entity2DPoolUsedLength++;
            return this._entity2DDisposedIds.pop();
        }
        if (this._entity2DPoolUsedLength >= this._entity2DPoolLength) {
            this._enlargeEntity2DPool(ENTITY_POOL_LENGTH);
        }
        var entity2DID = this._entity2DPoolIndex;
        this._entity2DPoolIndex += 1;
        this._entity2DPoolUsedLength++;
        return entity2DID;
    };
    // 回收2D节点
    PoolManager.prototype.disposeEntity2D = function (entity2D) {
        if (entity2D.isUsing) {
            this._entity2DDisposedIds.push(entity2D.id);
            this._entity2DPoolUsedLength--;
            entity2D.setRawBuffer(entity2DTemplateF32View);
            entity2D.isUsing = false;
        }
    };
    // 申请3D节点
    PoolManager.prototype.getEntity3D = function () {
        if (this._entity3DDisposedIds.size() > 0) {
            this._entity3DPoolUsedLength++;
            // console.log('Entity3D Pop ' + this._entity3DDisposedIds.size());
            return this._entity3DDisposedIds.pop();
        }
        if (this._entity3DPoolUsedLength >= this._entity3DPoolLength) {
            // console.log('enlargeEntity3DPool');
            this._enlargeEntity3DPool(ENTITY_POOL_LENGTH);
        }
        var entity3DID = this._entity3DPoolIndex;
        this._entity3DPoolIndex += 1;
        this._entity3DPoolUsedLength++;
        // console.log('Entity3D ' + entity3DID + ' created!');
        return entity3DID;
    };
    // 回收3D节点
    PoolManager.prototype.disposeEntity3D = function (entity3D) {
        // console.log('Entity3D ' + entity3D.id + ' destroy!');
        if (entity3D.isUsing) {
            this._entity3DDisposedIds.push(entity3D.id);
            this._entity3DPoolUsedLength--;
            entity3D.setRawBuffer(entity3DTemplateF32View);
            entity3D.isUsing = false;
        }
    };
    // 申请剔除组件
    PoolManager.prototype.getCullableComponent = function () {
        if (this._cullableComponentDisposedIds.size() > 0) {
            this._cullableComponentPoolUsedLength++;
            // console.log('cullableComponent Pop ' + this._cullableComponentDisposedIds.size());
            return this._cullableComponentDisposedIds.pop();
        }
        if (this._cullableComponentPoolUsedLength >= this._cullableComponentPoolLength) {
            // console.log('enlargeCullableComponentPool');
            this._enlargeCullableComponentPool(ENTITY_POOL_LENGTH);
        }
        // 暂时不使用剔除池
        // this._enlargeCullableComponentPool(1);
        var cullableComponentID = this._cullableComponentPoolIndex;
        this._cullableComponentPoolIndex += 1;
        this._cullableComponentPoolUsedLength++;
        // console.log('cullableComponent ' + cullableComponentID + ' created!');
        return cullableComponentID;
    };
    // 回收剔除组件
    PoolManager.prototype.disposeCullableComponent = function (cullableComponent) {
        // console.log('cullableComponent ' + cullableComponent.id + ' destroy!');
        // this.cullableComponentPools[cullableComponent.id] = null;
        if (cullableComponent.isUsing) {
            this._cullableComponentDisposedIds.push(cullableComponent.id);
            this._cullableComponentPoolUsedLength--;
            cullableComponent.setRawBuffer(cullableComponentTemplateF32View);
            cullableComponent.isUsing = false;
        }
    };
    // 兼容0.1.1版本GA逻辑
    PoolManager.prototype.getCullableComponentSingle = function () {
        // 暂时不使用剔除池
        this._enlargeCullableComponentPool(1);
        var cullableComponentID = this._cullableComponentPoolIndex;
        return cullableComponentID;
    };
    // 兼容0.1.1版本GA逻辑
    PoolManager.prototype.disposeCullableComponentSingle = function (cullableComponent) {
        this.cullableComponentPools[cullableComponent.id] = null;
    };
    return PoolManager;
}());
exports.default = PoolManager;


/***/ }),
/* 59 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var nativeObject_1 = tslib_1.__importDefault(__webpack_require__(32));
var Pool = /** @class */ (function (_super) {
    tslib_1.__extends(Pool, _super);
    function Pool(nativeObj) {
        var _this = _super.call(this) || this;
        _this._init(nativeObj);
        return _this;
    }
    return Pool;
}(nativeObject_1.default));
exports.default = Pool;


/***/ }),
/* 60 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.AnimatorControllerMock = exports.AnimatorController = exports.AnimatorControllerModelMock = exports.staticInitAnimatorController = void 0;
var tslib_1 = __webpack_require__(1);
var util_1 = __webpack_require__(8);
var vector3_1 = tslib_1.__importDefault(__webpack_require__(45));
var quaternion_1 = tslib_1.__importDefault(__webpack_require__(61));
var vector4_1 = tslib_1.__importDefault(__webpack_require__(46));
var manager;
function staticInitAnimatorController(m_manager) {
    manager = m_manager;
}
exports.staticInitAnimatorController = staticInitAnimatorController;
var tempVector3 = new vector3_1.default();
var tempQuaternion_1 = new quaternion_1.default();
var tempQuaternion_2 = new quaternion_1.default();
var tempVector4_1 = new vector4_1.default();
var tempVector4_2 = new vector4_1.default();
/**
 * binding_id | (blend_type, weight, state_model_id) [layer_count]
 */
var AnimatorControllerModelMock = /** @class */ (function () {
    function AnimatorControllerModelMock(layerCount) {
        this.layerCount = layerCount;
        this.id = util_1.requestAccelerateObjectID();
        this.masks = [];
        this.buffer = new ArrayBuffer(4 + 3 * 4 * layerCount);
        this.uint32 = new Uint32Array(this.buffer);
        for (var i = 0; i < layerCount; i++) {
            this.masks.push(null);
        }
    }
    AnimatorControllerModelMock.prototype.setMaskAtIndex = function (index, mask, offset, length) {
        this.masks[index] = [];
        if (mask) {
            var f32 = new Float32Array(mask, offset, length * 2);
            var uint32 = new Uint32Array(mask, offset, length * 2);
            for (var i = 0; i < length; i++) {
                this.masks[index].push({
                    entity: uint32[2 * i],
                    weight: f32[2 * i + 1],
                });
            }
        }
    };
    return AnimatorControllerModelMock;
}());
exports.AnimatorControllerModelMock = AnimatorControllerModelMock;
var BlendType;
(function (BlendType) {
    BlendType[BlendType["Override"] = 0] = "Override";
    BlendType[BlendType["Additive"] = 1] = "Additive";
})(BlendType || (BlendType = {}));
var BlendNode = /** @class */ (function () {
    function BlendNode() {
        this.tx = [0, 0];
        this.ty = [0, 0];
        this.tz = [0, 0];
        this.sx = [0, 0];
        this.sy = [0, 0];
        this.sz = [0, 0];
        this.use_quaternion = true;
        this.r_weight = 0;
        this.rx = 0;
        this.ry = 0;
        this.rz = 0;
        this.rw = 0;
    }
    return BlendNode;
}());
var AnimatorController = /** @class */ (function () {
    function AnimatorController(layerCount) {
        this.layerCount = layerCount;
        this.nativeObject = manager.worker.createAnimatorControllerModel(layerCount);
        this._uint32View = new Uint32Array(this.nativeObject.buffer);
        this._f32View = new Float32Array(this.nativeObject.buffer);
        for (var layerIndex = 0; layerIndex < layerCount; layerIndex++) {
            this._uint32View[1 + 3 * layerIndex] = 1;
            this._f32View[1 + 3 * layerIndex + 1] = 0;
            this._f32View[1 + 3 * layerIndex + 2] = 4294967295;
        }
    }
    Object.defineProperty(AnimatorController.prototype, "id", {
        get: function () {
            return this.nativeObject.id;
        },
        enumerable: false,
        configurable: true
    });
    AnimatorController.prototype.setAnimationClipBinding = function (binding) {
        this._uint32View[0] = binding ? binding.id : 4294967295;
    };
    // 0
    AnimatorController.prototype.setLayerBlendType = function (layerIndex, blendType) {
        this._uint32View[1 + 3 * layerIndex] = blendType;
    };
    // 1
    AnimatorController.prototype.setLayerWeight = function (layerIndex, weight) {
        this._f32View[1 + 3 * layerIndex + 1] = weight;
    };
    // 2
    AnimatorController.prototype.setLayerBlend = function (layerIndex, blend) {
        if (blend) {
            this._uint32View[1 + 3 * layerIndex + 2] = blend.id;
        }
        else {
            this._uint32View[1 + 3 * layerIndex + 2] = 4294967295;
        }
    };
    // native
    AnimatorController.prototype.setLayerMask = function (layerIndex, mask) {
        this.nativeObject.setMaskAtIndex(layerIndex, mask.buffer, mask.offset, mask.length);
    };
    AnimatorController.prototype.update = function () {
        this.nativeObject.update();
    };
    return AnimatorController;
}());
exports.AnimatorController = AnimatorController;
function FixInterpolateRotation(node, use_default, default_value, quaternion) {
    var has_rotaion = false;
    if (node.use_quaternion) {
        if (node.rx !== null && node.ry !== null && node.rz !== null && node.rw !== null) {
            has_rotaion = true;
            quaternion[0] = node.rx;
            quaternion[1] = node.ry;
            quaternion[2] = node.rz;
            quaternion[3] = node.rw;
        }
        else {
            has_rotaion = false;
        }
    }
    else {
        if (node.rx !== null && node.ry !== null && node.rz !== null) {
            has_rotaion = true;
            tempVector3.setValue(node.rx, node.ry, node.rz);
            quaternion_1.default.fromEulerAngles(tempVector3, tempQuaternion_1);
            quaternion[0] = tempQuaternion_1.x;
            quaternion[1] = tempQuaternion_1.y;
            quaternion[2] = tempQuaternion_1.z;
            quaternion[3] = tempQuaternion_1.w;
        }
        else {
            if (use_default && default_value) {
                has_rotaion = true;
                tempVector3.setValue(node.rx === null ? default_value.getEuler()[0] : node.rx, node.ry === null ? default_value.getEuler()[1] : node.ry, node.rz === null ? default_value.getEuler()[2] : node.rz);
                quaternion_1.default.fromEulerAngles(tempVector3, tempQuaternion_1);
                quaternion[0] = tempQuaternion_1.x;
                quaternion[1] = tempQuaternion_1.y;
                quaternion[2] = tempQuaternion_1.z;
                quaternion[3] = tempQuaternion_1.w;
            }
            else {
                has_rotaion = false;
            }
        }
    }
    return has_rotaion;
}
var AnimatorControllerMock = /** @class */ (function () {
    function AnimatorControllerMock(layerCount) {
        this.layerCount = layerCount;
        this.binding = null;
        this._blendMap = new Map();
        this.nativeObject = new AnimatorControllerModelMock(layerCount);
        this._uint32View = new Uint32Array(this.nativeObject.buffer);
        this._f32View = new Float32Array(this.nativeObject.buffer);
        for (var layerIndex = 0; layerIndex < layerCount; layerIndex++) {
            this._uint32View[1 + 3 * layerIndex] = 1;
            this._f32View[1 + 3 * layerIndex + 1] = 0;
            this._f32View[1 + 3 * layerIndex + 2] = 4294967295;
        }
    }
    Object.defineProperty(AnimatorControllerMock.prototype, "id", {
        get: function () {
            return this.nativeObject.id;
        },
        enumerable: false,
        configurable: true
    });
    AnimatorControllerMock.prototype.setAnimationClipBinding = function (binding) {
        this._uint32View[0] = binding ? binding.id : 4294967295;
        this.binding = binding;
    };
    // 0
    AnimatorControllerMock.prototype.setLayerBlendType = function (layerIndex, blendType) {
        this._uint32View[1 + 3 * layerIndex] = blendType;
    };
    // 1
    AnimatorControllerMock.prototype.setLayerWeight = function (layerIndex, weight) {
        this._f32View[1 + 3 * layerIndex + 1] = weight;
    };
    // 2
    AnimatorControllerMock.prototype.setLayerBlend = function (layerIndex, blend) {
        if (blend) {
            this._uint32View[1 + 3 * layerIndex + 2] = blend.id;
        }
        else {
            this._uint32View[1 + 3 * layerIndex + 2] = 4294967295;
        }
        if (blend) {
            this._blendMap.set(blend.id, blend);
        }
    };
    // native
    AnimatorControllerMock.prototype.setLayerMask = function (layerIndex, mask) {
        this.nativeObject.setMaskAtIndex(layerIndex, mask.buffer, mask.offset, mask.length);
    };
    AnimatorControllerMock.prototype.update = function () {
        var _this = this;
        if (!this.binding) {
            return;
        }
        var layer_blends = [];
        var default_values = this.binding.defaultValues;
        var _loop_1 = function (i) {
            var layer_blend_result = new Map();
            var blend_type = this_1._uint32View[1 + 3 * i];
            if (blend_type !== BlendType.Override && blend_type !== BlendType.Additive) {
                layer_blends.push(layer_blend_result);
                return "continue";
            }
            var is_additive = blend_type === BlendType.Additive;
            var state_model_id = this_1._uint32View[1 + 3 * i + 2];
            var state_model = this_1._blendMap.get(state_model_id);
            if (!state_model) {
                layer_blends.push(layer_blend_result);
                return "continue";
            }
            var states = [];
            while (state_model) {
                if (state_model.weight) {
                    states.push(state_model);
                }
                state_model = state_model.nextState;
            }
            var _loop_3 = function (k) {
                var state_blend = this_1._blendState(states[k], is_additive, this_1.nativeObject.masks[i]);
                var state_weight = states[k].weight;
                state_blend.forEach(function (value, entity) {
                    if (!layer_blend_result.has(entity)) {
                        var node = new BlendNode();
                        node.tx[1] = NaN;
                        node.ty[1] = NaN;
                        node.tz[1] = NaN;
                        node.sx[1] = NaN;
                        node.sy[1] = NaN;
                        node.sz[1] = NaN;
                        node.r_weight = NaN;
                        layer_blend_result.set(entity, node);
                    }
                    var node_result = layer_blend_result.get(entity);
                    if (!isNaN(value.tx[1]) && value.tx[1] !== 0) {
                        if (isNaN(node_result.tx[1])) {
                            node_result.tx[1] = 0;
                        }
                        node_result.tx[0] += value.tx[0] * state_weight;
                        node_result.tx[1] += value.tx[1] * state_weight;
                    }
                    if (!isNaN(value.ty[1]) && value.ty[1] !== 0) {
                        if (isNaN(node_result.ty[1])) {
                            node_result.ty[1] = 0;
                        }
                        node_result.ty[0] += value.ty[0] * state_weight;
                        node_result.ty[1] += value.ty[1] * state_weight;
                    }
                    if (!isNaN(value.tz[1]) && value.tz[1] !== 0) {
                        if (isNaN(node_result.tz[1])) {
                            node_result.tz[1] = 0;
                        }
                        node_result.tz[0] += value.tz[0] * state_weight;
                        node_result.tz[1] += value.tz[1] * state_weight;
                    }
                    if (!isNaN(value.sx[1]) && value.sx[1] !== 0) {
                        if (isNaN(node_result.sx[1])) {
                            node_result.sx[1] = 0;
                        }
                        node_result.sx[0] += value.sx[0] * state_weight;
                        node_result.sx[1] += value.sx[1] * state_weight;
                    }
                    if (!isNaN(value.sy[1]) && value.sy[1] !== 0) {
                        if (isNaN(node_result.sy[1])) {
                            node_result.sy[1] = 0;
                        }
                        node_result.sy[0] += value.sy[0] * state_weight;
                        node_result.sy[1] += value.sy[1] * state_weight;
                    }
                    if (!isNaN(value.sz[1]) && value.sz[1] !== 0) {
                        if (isNaN(node_result.sz[1])) {
                            node_result.sz[1] = 0;
                        }
                        node_result.sz[0] += value.sz[0] * state_weight;
                        node_result.sz[1] += value.sz[1] * state_weight;
                    }
                    if (!isNaN(value.r_weight) && value.r_weight !== 0) {
                        if (isNaN(node_result.r_weight)) {
                            node_result.r_weight = 0;
                        }
                        var base = tempVector4_1;
                        base.setValue(node_result.rx, node_result.ry, node_result.rz, node_result.rw);
                        var quaternion = tempVector4_2;
                        quaternion.setValue(value.rx, value.ry, value.rz, value.rw);
                        base.add(quaternion.scale(base.dot(quaternion) < 0 ? -value.r_weight * state_weight : value.r_weight * state_weight, quaternion), base);
                        node_result.rx = base.x;
                        node_result.ry = base.y;
                        node_result.rz = base.z;
                        node_result.rw = base.w;
                        node_result.r_weight += value.r_weight * state_weight;
                    }
                });
            };
            for (var k = 0; k < states.length; k++) {
                _loop_3(k);
            }
            if (is_additive) {
                layer_blend_result.forEach(function (layer_blend_node, entityID) {
                    if (!isNaN(layer_blend_node.r_weight)) {
                        var quaternion = tempVector4_1;
                        quaternion.setValue(layer_blend_node.rx * layer_blend_node.r_weight, layer_blend_node.ry * layer_blend_node.r_weight, layer_blend_node.rz * layer_blend_node.r_weight, layer_blend_node.rw);
                        var length = quaternion.dot(quaternion);
                        if (length > 0) {
                            quaternion.scale(1 / Math.sqrt(length), quaternion);
                        }
                        layer_blend_node.rx = quaternion.x;
                        layer_blend_node.ry = quaternion.y;
                        layer_blend_node.rz = quaternion.z;
                        layer_blend_node.rw = quaternion.w;
                    }
                });
            }
            else {
                layer_blend_result.forEach(function (layer_blend_node, entityID) {
                    var entity = _this.binding.entities.get(entityID);
                    var default_value = default_values.get(entity);
                    if (!isNaN(layer_blend_node.tx[1]) && layer_blend_node.tx[1] < 1) {
                        layer_blend_node.tx[0] += (1 - layer_blend_node.tx[1]) * default_value.position[0];
                    }
                    if (!isNaN(layer_blend_node.ty[1]) && layer_blend_node.ty[1] < 1) {
                        layer_blend_node.ty[0] += (1 - layer_blend_node.ty[1]) * default_value.position[1];
                    }
                    if (!isNaN(layer_blend_node.tz[1]) && layer_blend_node.tz[1] < 1) {
                        layer_blend_node.tz[0] += (1 - layer_blend_node.tz[1]) * default_value.position[2];
                    }
                    if (!isNaN(layer_blend_node.sx[1]) && layer_blend_node.sx[1] < 1) {
                        layer_blend_node.sx[0] += (1 - layer_blend_node.sx[1]) * default_value.scale[0];
                    }
                    if (!isNaN(layer_blend_node.sy[1]) && layer_blend_node.sy[1] < 1) {
                        layer_blend_node.sy[0] += (1 - layer_blend_node.sy[1]) * default_value.scale[1];
                    }
                    if (!isNaN(layer_blend_node.sz[1]) && layer_blend_node.sz[1] < 1) {
                        layer_blend_node.sz[0] += (1 - layer_blend_node.sz[1]) * default_value.scale[2];
                    }
                    if (!isNaN(layer_blend_node.r_weight) && layer_blend_node.r_weight < 1) {
                        var q_tuple = default_value.getQuaternion();
                        var base = tempVector4_1;
                        base.setValue(layer_blend_node.rx, layer_blend_node.ry, layer_blend_node.rz, layer_blend_node.rw);
                        var quaternion = tempVector4_2;
                        quaternion.setValue(q_tuple[0], q_tuple[1], q_tuple[2], q_tuple[3]);
                        base.add(quaternion.scale(base.dot(quaternion) < 0 ? -(1 - layer_blend_node.r_weight) : (1 - layer_blend_node.r_weight), quaternion), base);
                        layer_blend_node.rx = base.x;
                        layer_blend_node.ry = base.y;
                        layer_blend_node.rz = base.z;
                        layer_blend_node.rw = base.w;
                    }
                    if (!isNaN(layer_blend_node.r_weight)) {
                        var quaternion = tempVector4_1;
                        quaternion.setValue(layer_blend_node.rx, layer_blend_node.ry, layer_blend_node.rz, layer_blend_node.rw);
                        var length = quaternion.dot(quaternion);
                        if (length > 0) {
                            quaternion.scale(1 / Math.sqrt(length), quaternion);
                        }
                        layer_blend_node.rx = quaternion.x;
                        layer_blend_node.ry = quaternion.y;
                        layer_blend_node.rz = quaternion.z;
                        layer_blend_node.rw = quaternion.w;
                    }
                });
            }
            layer_blends.push(layer_blend_result);
        };
        var this_1 = this;
        for (var i = 0; i < this.layerCount; i++) {
            _loop_1(i);
        }
        var machine_blend_result = new Map();
        var _loop_2 = function (i) {
            var blend_type = this_2._uint32View[1 + 3 * i];
            var is_additive = blend_type === BlendType.Additive;
            var layer_weight = this_2._f32View[1 + 3 * i + 1];
            var layer_blend = layer_blends[i];
            layer_blend.forEach(function (layer_blend_node, entityID) {
                if (!machine_blend_result.has(entityID)) {
                    var node = new BlendNode();
                    node.tx[1] = NaN;
                    node.ty[1] = NaN;
                    node.tz[1] = NaN;
                    node.sx[1] = NaN;
                    node.sy[1] = NaN;
                    node.sz[1] = NaN;
                    node.r_weight = NaN;
                    machine_blend_result.set(entityID, node);
                }
                var machine_blend_node = machine_blend_result.get(entityID);
                if (is_additive) {
                    if (i === 0) {
                        var default_value = default_values.get(_this.binding.entities.get(entityID));
                        if (!isNaN(layer_blend_node.tx[1])) {
                            if (isNaN(machine_blend_node.tx[1])) {
                                machine_blend_node.tx[1] = 0;
                            }
                            machine_blend_node.tx[0] = default_value.position[0] + layer_blend_node.tx[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.ty[1])) {
                            if (isNaN(machine_blend_node.ty[1])) {
                                machine_blend_node.ty[1] = 0;
                            }
                            machine_blend_node.ty[0] = default_value.position[1] + layer_blend_node.ty[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.tz[1])) {
                            if (isNaN(machine_blend_node.tz[1])) {
                                machine_blend_node.tz[1] = 0;
                            }
                            machine_blend_node.tz[0] = default_value.position[2] + layer_blend_node.tz[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.sx[1])) {
                            if (isNaN(machine_blend_node.sx[1])) {
                                machine_blend_node.sx[1] = 0;
                            }
                            machine_blend_node.sx[0] = default_value.scale[0] * (1 - layer_weight) + layer_blend_node.sx[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.sy[1])) {
                            if (isNaN(machine_blend_node.sy[1])) {
                                machine_blend_node.sy[1] = 0;
                            }
                            machine_blend_node.sy[0] = default_value.scale[1] * (1 - layer_weight) * layer_blend_node.sy[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.sz[1])) {
                            if (isNaN(machine_blend_node.sz[1])) {
                                machine_blend_node.sz[1] = 0;
                            }
                            machine_blend_node.sz[0] = default_value.scale[2] * (1 - layer_weight) * layer_blend_node.sz[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.r_weight)) {
                            if (isNaN(machine_blend_node.r_weight)) {
                                machine_blend_node.r_weight = 0;
                            }
                            var default_q_tuple = default_value.getQuaternion();
                            var base_quaternion = tempVector4_1;
                            base_quaternion.setValue(default_q_tuple[0], default_q_tuple[1], default_q_tuple[2], default_q_tuple[3]);
                            var base = tempQuaternion_1;
                            base.setValue(base_quaternion.x, base_quaternion.y, base_quaternion.z, base_quaternion.w);
                            var quaternion = tempVector4_2;
                            quaternion.setValue(layer_blend_node.rx * layer_weight, layer_blend_node.ry * layer_weight, layer_blend_node.rz * layer_weight, layer_blend_node.rw);
                            var length = quaternion.dot(quaternion);
                            if (length >= 0) {
                                quaternion.scale(1 / Math.sqrt(length), quaternion);
                            }
                            var value = tempQuaternion_2;
                            value.setValue(quaternion.x, quaternion.y, quaternion.z, quaternion.w);
                            value.multiply(base, value);
                            machine_blend_node.rx = value.x;
                            machine_blend_node.ry = value.y;
                            machine_blend_node.rz = value.z;
                            machine_blend_node.rw = value.w;
                        }
                    }
                    else {
                        if (!isNaN(layer_blend_node.tx[1])) {
                            if (isNaN(machine_blend_node.tx[1])) {
                                machine_blend_node.tx[1] = 0;
                            }
                            machine_blend_node.tx[0] += layer_blend_node.tx[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.ty[1])) {
                            if (isNaN(machine_blend_node.ty[1])) {
                                machine_blend_node.ty[1] = 0;
                            }
                            machine_blend_node.ty[0] += layer_blend_node.ty[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.tz[1])) {
                            if (isNaN(machine_blend_node.tz[1])) {
                                machine_blend_node.tz[1] = 0;
                            }
                            machine_blend_node.tz[0] += layer_blend_node.tz[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.sx[1])) {
                            if (isNaN(machine_blend_node.sx[1])) {
                                machine_blend_node.sx[1] = 0;
                            }
                            machine_blend_node.sx[0] += layer_blend_node.sx[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.sy[1])) {
                            if (isNaN(machine_blend_node.sy[1])) {
                                machine_blend_node.sy[1] = 0;
                            }
                            machine_blend_node.sy[0] += layer_blend_node.sy[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.sz[1])) {
                            if (isNaN(machine_blend_node.sz[1])) {
                                machine_blend_node.sz[1] = 0;
                            }
                            machine_blend_node.sz[0] += layer_blend_node.sz[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.r_weight)) {
                            if (isNaN(machine_blend_node.r_weight)) {
                                machine_blend_node.r_weight = 0;
                                var default_value = default_values.get(_this.binding.entities.get(entityID));
                                var default_q_tuple = default_value.getQuaternion();
                                machine_blend_node.rx = default_q_tuple[0];
                                machine_blend_node.ry = default_q_tuple[1];
                                machine_blend_node.rz = default_q_tuple[2];
                                machine_blend_node.rw = default_q_tuple[3];
                            }
                            var quaternion = tempVector4_2;
                            quaternion.setValue(layer_blend_node.rx * layer_weight, layer_blend_node.ry * layer_weight, layer_blend_node.rz * layer_weight, layer_blend_node.rw);
                            var length = quaternion.dot(quaternion);
                            if (length >= 0) {
                                quaternion.scale(1 / Math.sqrt(length), quaternion);
                            }
                            var value = tempQuaternion_2;
                            value.setValue(quaternion.x, quaternion.y, quaternion.z, quaternion.w);
                            var base = tempQuaternion_1;
                            base.setValue(machine_blend_node.rx, machine_blend_node.ry, machine_blend_node.rz, machine_blend_node.rw);
                            value.multiply(base, value);
                            machine_blend_node.rx = value.x;
                            machine_blend_node.ry = value.y;
                            machine_blend_node.rz = value.z;
                            machine_blend_node.rw = value.w;
                        }
                    }
                }
                else {
                    if (layer_weight < 1) {
                        var default_value = default_values.get(_this.binding.entities.get(entityID));
                        if (!isNaN(layer_blend_node.tx[1])) {
                            if (isNaN(machine_blend_node.tx[1])) {
                                machine_blend_node.tx[1] = 0;
                            }
                            machine_blend_node.tx[0] = default_value.position[0] * (1 - layer_weight) + layer_blend_node.tx[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.ty[1])) {
                            if (isNaN(machine_blend_node.ty[1])) {
                                machine_blend_node.ty[1] = 0;
                            }
                            machine_blend_node.ty[0] = default_value.position[1] * (1 - layer_weight) + layer_blend_node.ty[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.tz[1])) {
                            if (isNaN(machine_blend_node.tz[1])) {
                                machine_blend_node.tz[1] = 0;
                            }
                            machine_blend_node.tz[0] = default_value.position[2] * (1 - layer_weight) + layer_blend_node.tz[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.sx[1])) {
                            if (isNaN(machine_blend_node.sx[1])) {
                                machine_blend_node.sx[1] = 0;
                            }
                            machine_blend_node.sx[0] = default_value.scale[0] * (1 - layer_weight) + layer_blend_node.sx[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.sy[1])) {
                            if (isNaN(machine_blend_node.sy[1])) {
                                machine_blend_node.sy[1] = 0;
                            }
                            machine_blend_node.sy[0] = default_value.scale[1] * (1 - layer_weight) + layer_blend_node.sy[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.sz[1])) {
                            if (isNaN(machine_blend_node.sz[1])) {
                                machine_blend_node.sz[1] = 0;
                            }
                            machine_blend_node.sz[0] = default_value.scale[2] * (1 - layer_weight) + layer_blend_node.sz[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.r_weight)) {
                            if (isNaN(machine_blend_node.r_weight)) {
                                machine_blend_node.r_weight = 0;
                            }
                            var default_q_tuple = default_value.getQuaternion();
                            var default_q = tempVector4_1;
                            default_q.setValue(default_q_tuple[0], default_q_tuple[1], default_q_tuple[2], default_q_tuple[3]);
                            var value_q = tempVector4_2;
                            value_q.setValue(layer_blend_node.rx, layer_blend_node.ry, layer_blend_node.rz, layer_blend_node.rw);
                            var sign = value_q.dot(default_q) >= 0 ? 1 : -1;
                            var blend_q = value_q.scale(sign).sub(default_q).scale(layer_weight).add(default_q);
                            var length = blend_q.dot(blend_q);
                            if (length >= 0) {
                                blend_q.scale(1 / Math.sqrt(length), blend_q);
                            }
                            machine_blend_node.rx = blend_q.x;
                            machine_blend_node.ry = blend_q.y;
                            machine_blend_node.rz = blend_q.z;
                            machine_blend_node.rw = blend_q.w;
                        }
                    }
                    else {
                        if (!isNaN(layer_blend_node.tx[1])) {
                            if (isNaN(machine_blend_node.tx[1])) {
                                machine_blend_node.tx[1] = 0;
                            }
                            machine_blend_node.tx[0] = layer_blend_node.tx[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.ty[1])) {
                            if (isNaN(machine_blend_node.ty[1])) {
                                machine_blend_node.ty[1] = 0;
                            }
                            machine_blend_node.ty[0] = layer_blend_node.ty[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.tz[1])) {
                            if (isNaN(machine_blend_node.tz[1])) {
                                machine_blend_node.tz[1] = 0;
                            }
                            machine_blend_node.tz[0] = layer_blend_node.tz[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.sx[1])) {
                            if (isNaN(machine_blend_node.sx[1])) {
                                machine_blend_node.sx[1] = 0;
                            }
                            machine_blend_node.sx[0] = layer_blend_node.sx[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.sy[1])) {
                            if (isNaN(machine_blend_node.sy[1])) {
                                machine_blend_node.sy[1] = 0;
                            }
                            machine_blend_node.sy[0] = layer_blend_node.sy[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.sz[1])) {
                            if (isNaN(machine_blend_node.sz[1])) {
                                machine_blend_node.sz[1] = 0;
                            }
                            machine_blend_node.sz[0] = layer_blend_node.sz[0] * layer_weight;
                        }
                        if (!isNaN(layer_blend_node.r_weight)) {
                            if (isNaN(machine_blend_node.r_weight)) {
                                machine_blend_node.r_weight = 0;
                            }
                            var quaternion = tempVector4_2;
                            quaternion.setValue(layer_blend_node.rx * layer_weight, layer_blend_node.ry * layer_weight, layer_blend_node.rz * layer_weight, layer_blend_node.rw);
                            var length = quaternion.dot(quaternion);
                            if (length >= 0) {
                                quaternion.scale(1 / Math.sqrt(length), quaternion);
                            }
                            machine_blend_node.rx = quaternion.x;
                            machine_blend_node.ry = quaternion.y;
                            machine_blend_node.rz = quaternion.z;
                            machine_blend_node.rw = quaternion.w;
                        }
                    }
                }
            });
        };
        var this_2 = this;
        for (var i = 0; i < layer_blends.length; i++) {
            _loop_2(i);
        }
        machine_blend_result.forEach(function (machine_blend_node, entityID) {
            var entity = _this.binding.entities.get(entityID);
            if (!isNaN(machine_blend_node.tx[1])) {
                entity.localPositionView[0] = machine_blend_node.tx[0];
            }
            if (!isNaN(machine_blend_node.ty[1])) {
                entity.localPositionView[1] = machine_blend_node.ty[0];
            }
            if (!isNaN(machine_blend_node.tz[1])) {
                entity.localPositionView[2] = machine_blend_node.tz[0];
            }
            if (!isNaN(machine_blend_node.sx[1])) {
                entity.localScaleView[0] = machine_blend_node.sx[0];
            }
            if (!isNaN(machine_blend_node.sy[1])) {
                entity.localScaleView[1] = machine_blend_node.sy[0];
            }
            if (!isNaN(machine_blend_node.sz[1])) {
                entity.localScaleView[2] = machine_blend_node.sz[0];
            }
            if (!isNaN(machine_blend_node.r_weight)) {
                entity.localQuaternionView.set([machine_blend_node.rx, machine_blend_node.ry, machine_blend_node.rz, machine_blend_node.rw]);
                entity.setUsingEuler(false);
            }
            entity.setLocalMatrixDirty();
        });
    };
    AnimatorControllerMock.prototype._blendState = function (state, is_additive, mask) {
        var result = new Map();
        if (!this.binding) {
            return result;
        }
        var default_values = this.binding.defaultValues;
        var blend_count = state.count;
        var use_default = state.useDefault;
        for (var j = 0; j < blend_count; j++) {
            var blend = {
                clip: state.clipsMap.get(state._uint32View[3 + 5 * j]),
                frameIndex: state._f32View[3 + 5 * j + 1],
                weight: state._f32View[3 + 5 * j + 2],
                additiveReferenceClip: state.clipsMap.get(state._uint32View[3 + 5 * j + 3]),
                additiveFrameIndex: state._f32View[3 + 5 * j + 4],
            };
            if (!blend.weight || !blend.clip) {
                continue;
            }
            if (!this.binding.clipBinding.has(blend.clip)) {
                continue;
            }
            var value = blend.clip.evaluate(blend.frameIndex);
            var clip_weight = blend.weight;
            var additive_base = {};
            if (is_additive) {
                var additiveClip = blend.additiveReferenceClip ? blend.additiveReferenceClip : blend.clip;
                var additiveClipFrameIndex = blend.additiveReferenceClip ? blend.additiveFrameIndex : 0;
                if (!this.binding.clipBinding.has(additiveClip)) {
                    additiveClip = blend.clip;
                    additiveClipFrameIndex = 0;
                }
                var additive_base_result = additiveClip.evaluate(additiveClipFrameIndex);
                for (var additive_base_node in additive_base_result) {
                    var additive_base_binding = this.binding.clipBinding.get(additiveClip);
                    if (!additive_base_binding[+additive_base_node]) {
                        continue;
                    }
                    var entity = this.binding.entities.get(additive_base_binding[+additive_base_node].id);
                    if (entity) {
                        additive_base[entity.id] = additive_base_result[additive_base_node];
                    }
                }
            }
            for (var key in value) {
                var entity = this.binding.clipBinding.get(blend.clip)[+key];
                if (!entity) {
                    continue;
                }
                var mask_weight = 1;
                if (mask.length) {
                    var mask_value = NaN;
                    for (var k = 0; k < mask.length; k++) {
                        if (mask[k] && mask[k].entity === entity.id) {
                            mask_value = mask[k].weight;
                            break;
                        }
                    }
                    if (!isNaN(mask_value)) {
                        if (mask_value === 0) {
                            continue;
                        }
                        mask_weight = mask_value;
                    }
                }
                var default_value = default_values.get(entity);
                if (!default_value) {
                    continue;
                }
                var node_weight = clip_weight * mask_weight;
                var quaternion_tuple = [0, 0, 0, 0];
                var has_rotation = FixInterpolateRotation(value[key], use_default !== 0, default_value, quaternion_tuple);
                if (is_additive) {
                    var additive_base_value = additive_base[entity.id];
                    if (!additive_base_value) {
                        continue;
                    }
                    var base_quaternion_tuple = [0, 0, 0, 0];
                    var base_has_rotation = FixInterpolateRotation(additive_base_value, use_default !== 0, default_value, base_quaternion_tuple);
                    if (value[key].tx !== null && additive_base_value.tx !== null) {
                        value[key].tx -= additive_base_value.tx;
                    }
                    if (value[key].ty !== null && additive_base_value.ty !== null) {
                        value[key].ty -= additive_base_value.ty;
                    }
                    if (value[key].tz !== null && additive_base_value.tz !== null) {
                        value[key].tz -= additive_base_value.tz;
                    }
                    if (value[key].sx !== null && additive_base_value.sx !== null) {
                        value[key].sx -= additive_base_value.sx;
                    }
                    if (value[key].sy !== null && additive_base_value.sy !== null) {
                        value[key].sy -= additive_base_value.sy;
                    }
                    if (value[key].sz !== null && additive_base_value.sz !== null) {
                        value[key].sz -= additive_base_value.sz;
                    }
                    if (has_rotation && base_has_rotation) {
                        var base_q = tempQuaternion_1;
                        base_q.setValue(base_quaternion_tuple[0], base_quaternion_tuple[1], base_quaternion_tuple[2], base_quaternion_tuple[3]);
                        var value_q = tempQuaternion_2;
                        value_q.setValue(quaternion_tuple[0], quaternion_tuple[1], quaternion_tuple[2], quaternion_tuple[3]);
                        value_q.multiply(base_q.invert(base_q), value_q);
                        quaternion_tuple[0] = value[key].rx = value_q.x;
                        quaternion_tuple[1] = value[key].ry = value_q.y;
                        quaternion_tuple[2] = value[key].rz = value_q.z;
                        quaternion_tuple[3] = value[key].rw = value_q.w;
                    }
                }
                if (!result.has(entity.id)) {
                    var node_1 = new BlendNode();
                    node_1.tx[1] = NaN;
                    node_1.ty[1] = NaN;
                    node_1.tz[1] = NaN;
                    node_1.sx[1] = NaN;
                    node_1.sy[1] = NaN;
                    node_1.sz[1] = NaN;
                    node_1.r_weight = NaN;
                    result.set(entity.id, node_1);
                }
                var node = result.get(entity.id);
                if (value[key].tx !== null) {
                    if (isNaN(node.tx[1])) {
                        node.tx[1] = 0;
                    }
                    node.tx[0] += value[key].tx * node_weight;
                    node.tx[1] += node_weight;
                }
                if (value[key].ty !== null) {
                    if (isNaN(node.ty[1])) {
                        node.ty[1] = 0;
                    }
                    node.ty[0] += value[key].ty * node_weight;
                    node.ty[1] += node_weight;
                }
                if (value[key].tz !== null) {
                    if (isNaN(node.tz[1])) {
                        node.tz[1] = 0;
                    }
                    node.tz[0] += value[key].tz * node_weight;
                    node.tz[1] += node_weight;
                }
                if (value[key].sx !== null) {
                    if (isNaN(node.sx[1])) {
                        node.sx[1] = 0;
                    }
                    node.sx[0] += value[key].sx * node_weight;
                    node.sx[1] += node_weight;
                }
                if (value[key].sy !== null) {
                    if (isNaN(node.sy[1])) {
                        node.sy[1] = 0;
                    }
                    node.sy[0] += value[key].sy * node_weight;
                    node.sy[1] += node_weight;
                }
                if (value[key].sz !== null) {
                    if (isNaN(node.sz[1])) {
                        node.sz[1] = 0;
                    }
                    node.sz[0] += value[key].sz * node_weight;
                    node.sz[1] += node_weight;
                }
                if (has_rotation) {
                    if (isNaN(node.r_weight)) {
                        node.r_weight = 0;
                    }
                    node.r_weight += node_weight;
                    var base = tempVector4_1;
                    base.setValue(node.rx, node.ry, node.rz, node.rw);
                    var quaternion = tempVector4_2;
                    quaternion.setValue(quaternion_tuple[0], quaternion_tuple[1], quaternion_tuple[2], quaternion_tuple[3]);
                    base.add(quaternion.scale(base.dot(quaternion) < 0 ? -node_weight : node_weight, quaternion), base);
                    node.rx = base.x;
                    node.ry = base.y;
                    node.rz = base.z;
                    node.rw = base.w;
                }
            }
        }
        if (!is_additive && use_default !== 0) {
            default_values.forEach(function (val, entity) {
                if (mask.length) {
                    for (var k = 0; k < mask.length; k++) {
                        if (mask[k] && mask[k].entity === entity.id) {
                            if (mask[k] && mask[k].weight === 0) {
                                return;
                            }
                            break;
                        }
                    }
                }
                if (!result.has(entity.id)) {
                    result.set(entity.id, new BlendNode());
                }
            });
        }
        return result;
    };
    return AnimatorControllerMock;
}());
exports.AnimatorControllerMock = AnimatorControllerMock;


/***/ }),
/* 61 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var matrix4_1 = tslib_1.__importDefault(__webpack_require__(44));
var vector3_1 = tslib_1.__importDefault(__webpack_require__(45));
var utils_1 = __webpack_require__(20);
/**
 * @public
 */
var Quaternion = /** @class */ (function () {
    function Quaternion(raw, offset) {
        this._raw = raw ? raw : new Float32Array(4);
        this._offset = offset ? offset : 0;
    }
    Object.defineProperty(Quaternion.prototype, "x", {
        get: function () {
            return this._raw[this._offset];
        },
        set: function (val) {
            this._raw[this._offset] = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Quaternion.prototype, "y", {
        get: function () {
            return this._raw[this._offset + 1];
        },
        set: function (val) {
            this._raw[this._offset + 1] = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Quaternion.prototype, "z", {
        get: function () {
            return this._raw[this._offset + 2];
        },
        set: function (val) {
            this._raw[this._offset + 2] = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Quaternion.prototype, "w", {
        get: function () {
            return this._raw[this._offset + 3];
        },
        set: function (val) {
            this._raw[this._offset + 3] = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Quaternion, "DEFAULT", {
        get: function () {
            return Quaternion.createFromNumber(0, 0, 0, 1);
        },
        enumerable: false,
        configurable: true
    });
    /**
     * 从欧拉角创建四元数
     *
     * @static
     * @param {Vector3} euler 欧拉角，x代表pitch，y代表yaw，z代表roll
     * @param {Quaternion} [dst]
     * @returns {Quaternion}
     * @memberof Quaternion
     */
    Quaternion.fromEulerAngles = function (euler, dst) {
        dst = dst || Quaternion.DEFAULT;
        utils_1.quatHelper.fromEulerAngles(euler._raw, euler._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    /**
     * 从旋转矩阵创建
     *
     * @static
     * @param {Matrix4} mat
     * @param {Quaternion} [dst]
     * @returns {Quaternion}
     * @memberof Quaternion
     */
    Quaternion.createFromMatrix4 = function (mat, dst) {
        dst = dst || new Quaternion();
        utils_1.quatHelper.fromMatrix4(mat._raw, mat._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    /**
     * create by clairli
     * @param axis
     * @param rad
     * @param dst
     */
    Quaternion.createFromAxisAngle = function (axis, rad, dst) {
        dst = dst || new Quaternion();
        matrix4_1.default.createRotationAxis(axis, rad, tempM4_1);
        Quaternion.createFromMatrix4(tempM4_1, dst);
        return dst;
    };
    /**
     * create by clairli
     * @param forward
     * @param up
     * @param dst
     */
    Quaternion.lookRotation = function (forward, up, dst) {
        dst = dst || new Quaternion();
        matrix4_1.default.lookAt(vector3_1.default.ZERO, forward, up, tempM4_1);
        Quaternion.createFromMatrix4(tempM4_1, dst);
        return dst;
    };
    /**
     * 使用数值创建
     * 推荐使用这种方式代替new Vector4
     *
     * @static
     * @param {number} [x]
     * @param {number} [y]
     * @param {number} [z]
     * @returns {Quaternion}
     * @memberof Quaternion
     */
    Quaternion.createFromNumber = function (x, y, z, w) {
        var raw = new Float32Array(4);
        raw[0] = x;
        raw[1] = y;
        raw[2] = z;
        raw[3] = w;
        return new Quaternion(raw);
    };
    /**
     * 使用一个数组创建
     * 此操作会拷贝一份数组
     *
     * @static
     * @param {number[]} array
     * @returns {Quaternion}
     * @memberof Quaternion
     */
    Quaternion.createFromArray = function (array) {
        if (array.length !== 4) {
            array = new Array(4).fill(0);
        }
        return new Quaternion(new Float32Array(array));
    };
    /**
     * 使用某个已有的typedArray创建
     * 此操作不会拷贝数据，而是在原来的内存区域上操作
     *
     * @static
     * @param {Float32Array} array
     * @returns {Quaternion}
     * @memberof Quaternion
     */
    Quaternion.createFromTypedArray = function (array, offset) {
        if (offset === void 0) { offset = 0; }
        if (array.length - offset < 4) {
            array = new Float32Array(4).fill(0);
        }
        return new Quaternion(array, offset);
    };
    /**
     * 设置四元数的值
     *
     * @param {Quaternion} quaternion
     * @memberof Quaternion
     */
    Quaternion.prototype.set = function (v) {
        utils_1.v4Helper.copy(v._raw, v._offset, this._raw, this._offset);
    };
    /**
     * 设置四元数的值
     *
     * @param {number} x
     * @param {number} y
     * @param {number} z
     * @param {number} w
     * @returns {Quaternion}
     * @memberof Quaternion
     */
    Quaternion.prototype.setValue = function (x, y, z, w) {
        var thisRaw = this._raw;
        thisRaw[this._offset + 0] = x;
        thisRaw[this._offset + 1] = y;
        thisRaw[this._offset + 2] = z;
        thisRaw[this._offset + 3] = w;
        return this;
    };
    /**
     * 球面插值
     *
     * @param {Quaternion} right 目标四元数
     * @param {number} t 插值系数，越接近 1 则结果越接近目标
     * @param {Quaternion} [dst]
     * @returns {Quaternion}
     * @memberof Quaternion
     */
    Quaternion.prototype.slerp = function (right, t, dst) {
        dst = dst || new Quaternion();
        utils_1.quatHelper.slerp(this._raw, this._offset, right._raw, right._offset, t, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    /**
     * 四元数反转
     *
     * @param {Quaternion} [dst]
     * @returns {Quaternion}
     * @memberof Quaternion
     */
    Quaternion.prototype.invert = function (dst) {
        dst = dst || new Quaternion();
        utils_1.quatHelper.invert(this._raw, this._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    /**
     * 四元数相加
     *
     * @param {Quaternion} quat
     * @param {Quaternion} [dst]
     * @returns {Quaternion}
     * @memberof Quaternion
     */
    Quaternion.prototype.add = function (quat, dst) {
        dst = dst || Quaternion.DEFAULT;
        utils_1.v4Helper.add(this._raw, this._offset, quat._raw, quat._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    /**
     * 四元数相减
     *
     * @param {Quaternion} quat
     * @param {Quaternion} [dst]
     * @returns {Quaternion}
     * @memberof Quaternion
     */
    Quaternion.prototype.sub = function (quat, dst) {
        dst = dst || Quaternion.DEFAULT;
        utils_1.v4Helper.sub(this._raw, this._offset, quat._raw, quat._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    /**
     * 四元数相乘
     *
     * @param {Quaternion} quat
     * @param {Quaternion} [dst]
     * @returns {Quaternion}
     * @memberof Quaternion
     */
    Quaternion.prototype.multiply = function (quat, dst) {
        dst = dst || Quaternion.DEFAULT;
        utils_1.quatHelper.multiply(this._raw, this._offset, quat._raw, quat._offset, tempDst._raw, tempDst._offset), dst.set(tempDst);
        return dst;
    };
    Quaternion.prototype.clone = function () {
        var dst = new Quaternion();
        utils_1.v4Helper.copy(this._raw, this._offset, dst._raw, dst._offset);
        return dst;
    };
    Quaternion.prototype.isZero = function () {
        return utils_1.v4Helper.isZero(this._raw, this._offset);
    };
    Quaternion.prototype.isDefault = function () {
        return utils_1.v4Helper.equal(this._raw, this._offset, tempQuatDefault._raw, tempQuatDefault._offset);
    };
    /**
     * 将该四元数转换成欧拉角，x代表Pitch,y代表Yaw,z代表Roll
     * 旋转的顺序为YXZ
     *
     * @param {Vector3} [dst]
     * @returns {Vector3}
     * @memberof Quaternion
     */
    Quaternion.prototype.toEulerAngles = function (dst) {
        dst = dst || vector3_1.default.ZERO;
        utils_1.quatHelper.toEulerAngles(this._raw, this._offset, tempDstV3._raw, tempDstV3._offset), dst.set(tempDstV3);
        return dst;
    };
    Quaternion.prototype.equal = function (v) {
        return utils_1.v4Helper.equal(this._raw, this._offset, v._raw, v._offset);
    };
    return Quaternion;
}());
exports.default = Quaternion;
// temp value use to temp calculate
var tempM4_1 = new matrix4_1.default();
var tempQuatDefault = Quaternion.DEFAULT;
var tempDst = new Quaternion();
var tempDstV3 = new vector3_1.default();


/***/ }),
/* 62 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.AnimatorControllerStateMock = exports.AnimatorControllerState = exports.staticInitAnimatorControllerLayerBlend = void 0;
var worker;
function staticInitAnimatorControllerLayerBlend(m_worker) {
    worker = m_worker;
}
exports.staticInitAnimatorControllerLayerBlend = staticInitAnimatorControllerLayerBlend;
/**
 * This is lib class for wrapping GA class.
 */
var AnimatorControllerState = /** @class */ (function () {
    function AnimatorControllerState(count) {
        this.count = count;
        this._index = 0;
        this._native = worker.createAnimatorControllerStateModel(count);
        this._f32View = new Float32Array(this._native.buffer);
        this._uint32View = new Uint32Array(this._native.buffer);
        for (var i = 0; i < count; i++) {
            this._uint32View[5 * i + 3] = 0xFFFFFFFF;
            this._f32View[5 * i + 3 + 1] = 0;
            this._f32View[5 * i + 3 + 2] = 0;
            this._uint32View[5 * i + 3 + 3] = 0xFFFFFFFF;
            this._f32View[5 * i + 3 + 4] = 0;
        }
    }
    Object.defineProperty(AnimatorControllerState.prototype, "id", {
        get: function () {
            return this._native.id;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(AnimatorControllerState.prototype, "weight", {
        get: function () {
            return this._f32View[0];
        },
        set: function (weight) {
            this._f32View[0] = weight;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(AnimatorControllerState.prototype, "useDefault", {
        get: function () {
            return this._f32View[1];
        },
        set: function (useDefault) {
            this._f32View[1] = useDefault;
        },
        enumerable: false,
        configurable: true
    });
    AnimatorControllerState.prototype.resetBlendInfo = function () {
        for (var i = 0; i < this.count; i++) {
            this._f32View[5 * i + 3 + 1] = 0;
            this._f32View[5 * i + 3 + 2] = 0;
        }
        this._index = 0;
    };
    AnimatorControllerState.prototype.setNextState = function (state) {
        this._uint32View[2] = state ? state.id : 4294967295;
    };
    AnimatorControllerState.prototype.setBlendInfo = function (clip, frameIndex, blendWeight, additiveReferenceClip, additiveFrameIndex) {
        if (this._index >= this.count) {
            return false;
        }
        this._uint32View[5 * this._index + 3] = clip.id;
        this._f32View[5 * this._index + 3 + 1] = frameIndex;
        this._f32View[5 * this._index + 3 + 2] = blendWeight;
        this._uint32View[5 * this._index + 3 + 3] = additiveReferenceClip ? additiveReferenceClip.id : this._uint32View[5 * this._index + 3];
        this._f32View[5 * this._index + 3 + 4] = additiveFrameIndex;
        this._index++;
        return true;
    };
    return AnimatorControllerState;
}());
exports.AnimatorControllerState = AnimatorControllerState;
/**
 * This is lib class for wrapping GA mock class.
 */
var AnimatorControllerStateMock = /** @class */ (function () {
    function AnimatorControllerStateMock(count) {
        this.count = count;
        this.clipsMap = new Map();
        this._index = 0;
        this._native = worker.createAnimatorControllerStateModel(count);
        this._f32View = new Float32Array(this._native.buffer);
        this._uint32View = new Uint32Array(this._native.buffer);
        for (var i = 0; i < count; i++) {
            this._uint32View[5 * i + 3] = 0xFFFFFFFF;
            this._f32View[5 * i + 3 + 1] = 0;
            this._f32View[5 * i + 3 + 2] = 0;
            this._uint32View[5 * i + 3 + 3] = 0xFFFFFFFF;
            this._f32View[5 * i + 3 + 4] = 0;
        }
    }
    Object.defineProperty(AnimatorControllerStateMock.prototype, "id", {
        get: function () {
            return this._native.id;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(AnimatorControllerStateMock.prototype, "weight", {
        get: function () {
            return this._f32View[0];
        },
        set: function (weight) {
            this._f32View[0] = weight;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(AnimatorControllerStateMock.prototype, "useDefault", {
        get: function () {
            return this._f32View[1];
        },
        set: function (useDefault) {
            this._f32View[1] = useDefault;
        },
        enumerable: false,
        configurable: true
    });
    AnimatorControllerStateMock.prototype.resetBlendInfo = function () {
        for (var i = 0; i < this.count; i++) {
            this._f32View[5 * i + 3 + 1] = 0;
            this._f32View[5 * i + 3 + 2] = 0;
        }
        this._index = 0;
        this.clipsMap.clear();
    };
    AnimatorControllerStateMock.prototype.setNextState = function (state) {
        this.nextState = state;
        this._uint32View[2] = state ? state.id : 4294967295;
    };
    AnimatorControllerStateMock.prototype.setBlendInfo = function (clip, frameIndex, blendWeight, additiveReferenceClip, additiveFrameIndex) {
        if (this._index >= this.count) {
            return false;
        }
        this.clipsMap.set(clip.id, clip);
        this._uint32View[5 * this._index + 3] = clip.id;
        this._f32View[5 * this._index + 3 + 1] = frameIndex;
        this._f32View[5 * this._index + 3 + 2] = blendWeight;
        this._uint32View[5 * this._index + 3 + 3] = additiveReferenceClip ? additiveReferenceClip.id : this._uint32View[5 * this._index + 3];
        this._f32View[5 * this._index + 3 + 4] = additiveFrameIndex;
        if (additiveReferenceClip) {
            this.clipsMap.set(additiveReferenceClip.id, additiveReferenceClip);
        }
        this._index++;
        return true;
    };
    return AnimatorControllerStateMock;
}());
exports.AnimatorControllerStateMock = AnimatorControllerStateMock;


/***/ }),
/* 63 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var commandArray_1 = tslib_1.__importDefault(__webpack_require__(54));
var SCALE_SIZE = 2;
var SIZE_UINT32 = 4;
var AnimatorControllerCommand = /** @class */ (function (_super) {
    tslib_1.__extends(AnimatorControllerCommand, _super);
    function AnimatorControllerCommand() {
        return _super.call(this) || this;
    }
    AnimatorControllerCommand.prototype._checkBufferSize = function (size) {
        if (SIZE_UINT32 + size > this._bufferSize) {
            var scaleSize = (SIZE_UINT32 + size) * SCALE_SIZE;
            this.buffer = new ArrayBuffer(scaleSize);
            this._u32view = new Uint32Array(this.buffer, 0, scaleSize / 4);
            this._bufferSize = scaleSize;
        }
    };
    AnimatorControllerCommand.prototype.updateAnimatorControllers = function (comps, length) {
        this._checkBufferSize(length * SIZE_UINT32);
        var offset = 1;
        for (var i = 0; i < length; i++) {
            this._u32view[offset + i] = comps[i].id;
        }
        this.setCommandSize(length);
    };
    return AnimatorControllerCommand;
}(commandArray_1.default));
exports.default = AnimatorControllerCommand;


/***/ }),
/* 64 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.AnimationClipBindingMock = exports.AnimationClipBinding = exports.staticInitAnimationClipBinding = exports.Entity3DValue = void 0;
var tslib_1 = __webpack_require__(1);
var util_1 = __webpack_require__(8);
var quaternion_1 = tslib_1.__importDefault(__webpack_require__(61));
var vector3_1 = tslib_1.__importDefault(__webpack_require__(45));
var tempQuaternion = new quaternion_1.default();
var tempVect3 = new vector3_1.default();
var Entity3DValue = /** @class */ (function () {
    function Entity3DValue(entity) {
        this.position = [entity.localPositionView[0], entity.localPositionView[1], entity.localPositionView[2]];
        this.scale = [entity.localScaleView[0], entity.localScaleView[1], entity.localScaleView[2]];
        if (!entity.isUsingEuler()) {
            this.useQuaternion = true;
            this._quaternionInitialized = true;
            this._quaternion = [entity.localQuaternionView[0], entity.localQuaternionView[1], entity.localQuaternionView[2], entity.localQuaternionView[3]];
            this._eulerInitialized = false;
        }
        else {
            this._euler = [entity.localQuaternionView[0], entity.localQuaternionView[1], entity.localQuaternionView[2]];
            this.useQuaternion = false;
            this._quaternionInitialized = false;
            this._eulerInitialized = true;
        }
    }
    Entity3DValue.prototype.getEuler = function () {
        if (!this._eulerInitialized) {
            this._eulerInitialized = true;
            tempQuaternion.setValue(this._quaternion[0], this._quaternion[1], this._quaternion[2], this._quaternion[3]);
            tempQuaternion.toEulerAngles(tempVect3);
            this._euler = [tempVect3.x, tempVect3.y, tempVect3.z];
        }
        return this._euler;
    };
    Entity3DValue.prototype.getQuaternion = function () {
        if (!this._quaternionInitialized) {
            this._quaternionInitialized = true;
            tempVect3.setValue(this._euler[0], this._euler[1], this._euler[2]);
            quaternion_1.default.fromEulerAngles(tempVect3, tempQuaternion);
            this._quaternion = [tempQuaternion.x, tempQuaternion.y, tempQuaternion.z, tempQuaternion.w];
        }
        return this._quaternion;
    };
    Entity3DValue.prototype.syncValue = function (entity) {
        entity.localPositionView.set(this.position);
        entity.localScaleView.set(this.scale);
        if (this.useQuaternion) {
            entity.localQuaternionView.set(this._quaternion);
            entity.setUsingEuler(false);
        }
        else {
            entity.localQuaternionView.set(this._euler);
            entity.setUsingEuler(true);
        }
        entity.setLocalMatrixDirty();
    };
    return Entity3DValue;
}());
exports.Entity3DValue = Entity3DValue;
var manager;
function staticInitAnimationClipBinding(m_manager) {
    manager = m_manager;
}
exports.staticInitAnimationClipBinding = staticInitAnimationClipBinding;
var UseDefaultAddedAction;
(function (UseDefaultAddedAction) {
    UseDefaultAddedAction[UseDefaultAddedAction["Ignore"] = 0] = "Ignore";
    UseDefaultAddedAction[UseDefaultAddedAction["Refresh"] = 1] = "Refresh";
})(UseDefaultAddedAction || (UseDefaultAddedAction = {}));
var UseDefaultRetainedAction;
(function (UseDefaultRetainedAction) {
    UseDefaultRetainedAction[UseDefaultRetainedAction["Keep"] = 0] = "Keep";
    UseDefaultRetainedAction[UseDefaultRetainedAction["Refresh"] = 1] = "Refresh";
    UseDefaultRetainedAction[UseDefaultRetainedAction["WriteBack"] = 2] = "WriteBack";
})(UseDefaultRetainedAction || (UseDefaultRetainedAction = {}));
var UseDefaultRemovedAction;
(function (UseDefaultRemovedAction) {
    UseDefaultRemovedAction[UseDefaultRemovedAction["Keep"] = 0] = "Keep";
    UseDefaultRemovedAction[UseDefaultRemovedAction["Clear"] = 1] = "Clear";
    UseDefaultRemovedAction[UseDefaultRemovedAction["WriteBack"] = 2] = "WriteBack";
})(UseDefaultRemovedAction || (UseDefaultRemovedAction = {}));
/**
 * Note: GA mock cannot implement :
 *     createAnimationClipBinding: (buffer: ArrayBuffer[], offset: number, cLength: number, eLength: number, useDefaultAddedNodesAction: number) => IAnimationClipBinding;
 * Since there is not entity system in mock for id indexing.
 * So for both GA and GA mock, we use a wrapped API:
 *     createAnimationClipBinding(clipArray: AnimationClipModel[], clipArrayOffset: number, clipArrayLength: number,
    entityArray: Array<Entity3D | Entity2D | null>, entityArrayOffset: number, entityArrayLength: number,
    useDefaultAddedNodesAction: number,
  ): IAnimationClipBinding;
 */
var AnimationClipBinding = /** @class */ (function () {
    function AnimationClipBinding(clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, useDefaultAddedNodesAction, rootEntity) {
        var eLen = Math.min(entityArray.length - entityArrayOffset, entityArrayLength);
        var cLen = Math.min(clipArray.length - clipArrayOffset, clipArrayLength);
        var buffer = new ArrayBuffer(4 * (eLen + cLen));
        var view = new Uint32Array(buffer);
        var cursor = 0;
        for (var i = clipArrayOffset; i < cLen; i++) {
            view[cursor++] = clipArray[i] ? clipArray[i].id : 4294967295;
        }
        for (var i = entityArrayOffset; i < eLen; i++) {
            view[cursor++] = entityArray[i] === null ? 4294967295 : (typeof entityArray[i] === "number" ? entityArray[i] : entityArray[i].id);
        }
        this.nativeObject = manager.worker.createAnimationClipBinding(buffer, 0, cLen, eLen, useDefaultAddedNodesAction, rootEntity.id);
    }
    Object.defineProperty(AnimationClipBinding.prototype, "id", {
        get: function () {
            return this.nativeObject.id;
        },
        enumerable: false,
        configurable: true
    });
    AnimationClipBinding.prototype.updateBinding = function (clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, removeAction, retainedAction, addedAction, rootEntity) {
        var eLen = Math.min(entityArray.length - entityArrayOffset, entityArrayLength);
        var cLen = Math.min(clipArray.length - clipArrayOffset, clipArrayLength);
        var buffer = new ArrayBuffer(4 * (eLen + cLen));
        var view = new Uint32Array(buffer);
        var cursor = 0;
        for (var i = clipArrayOffset; i < cLen; i++) {
            view[cursor++] = clipArray[i] ? clipArray[i].id : 4294967295;
        }
        for (var i = entityArrayOffset; i < eLen; i++) {
            view[cursor++] = entityArray[i] === null ? 4294967295 : (typeof entityArray[i] === "number" ? entityArray[i] : entityArray[i].id);
        }
        return this.nativeObject.updateBinding(buffer, 0, cLen, eLen, removeAction, retainedAction, addedAction, rootEntity.id);
    };
    AnimationClipBinding.prototype.writeDefaultValues = function () {
        this.nativeObject.writeDefaultValues();
    };
    return AnimationClipBinding;
}());
exports.AnimationClipBinding = AnimationClipBinding;
var AnimationClipBindingMock = /** @class */ (function () {
    function AnimationClipBindingMock(clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, useDefaultAddedNodesAction, rootEntity) {
        this.clipBinding = new Map();
        this.defaultValues = new Map();
        this.id = util_1.requestAccelerateObjectID();
        this._root = null;
        this.clipModels = new Map();
        this.entities = new Map();
        var entities = [];
        if (this._updateBinding(clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, entities)) {
            if (useDefaultAddedNodesAction === UseDefaultAddedAction.Refresh) {
                for (var _i = 0, entities_1 = entities; _i < entities_1.length; _i++) {
                    var entity = entities_1[_i];
                    this.defaultValues.set(entity, new Entity3DValue(entity));
                }
                ;
            }
        }
    }
    AnimationClipBindingMock.prototype.updateBinding = function (clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, removeAction, retainedAction, addedAction, rootEntity) {
        var _this = this;
        var entities = [];
        if (!this._updateBinding(clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, entities)) {
            return false;
        }
        var lastDefaultValues = this.defaultValues;
        this.defaultValues = new Map();
        var fullUseDefaultRemovedNodesAction = removeAction;
        var useDefaultRemovedNodesAction;
        var needWriteBackDefaultForRemovedNodes;
        if (fullUseDefaultRemovedNodesAction & UseDefaultRemovedAction.WriteBack) {
            needWriteBackDefaultForRemovedNodes = true;
            useDefaultRemovedNodesAction = fullUseDefaultRemovedNodesAction & ~UseDefaultRemovedAction.WriteBack;
        }
        else {
            needWriteBackDefaultForRemovedNodes = false;
            useDefaultRemovedNodesAction = fullUseDefaultRemovedNodesAction;
        }
        var fullUseDefaultRetainedNodesAction = retainedAction;
        var useDefaultRetainedNodesAction;
        var needWriteBackDefaultForRetainedNodes;
        if (fullUseDefaultRetainedNodesAction & UseDefaultRetainedAction.WriteBack) {
            needWriteBackDefaultForRetainedNodes = true;
            useDefaultRetainedNodesAction = fullUseDefaultRetainedNodesAction & ~UseDefaultRetainedAction.WriteBack;
        }
        else {
            needWriteBackDefaultForRetainedNodes = false;
            useDefaultRetainedNodesAction = fullUseDefaultRetainedNodesAction;
        }
        var useDefaultAddedNodesAction = addedAction;
        var retained = new Set();
        var added = new Set();
        var removed = new Set();
        for (var _i = 0, entities_2 = entities; _i < entities_2.length; _i++) {
            var entity = entities_2[_i];
            if (!lastDefaultValues.has(entity)) {
                added.add(entity);
            }
            else {
                retained.add(entity);
            }
        }
        lastDefaultValues.forEach(function (val, entity) {
            if (entities.indexOf(entity) < 0) {
                removed.add(entity);
            }
        });
        if (needWriteBackDefaultForRemovedNodes) {
            removed.forEach(function (entity) {
                var val = lastDefaultValues.get(entity);
                val.syncValue(entity);
            });
        }
        if (useDefaultRemovedNodesAction === UseDefaultRemovedAction.Keep) {
            removed.forEach(function (entity) {
                var val = lastDefaultValues.get(entity);
                _this.defaultValues.set(entity, val);
            });
        }
        if (useDefaultRetainedNodesAction === UseDefaultRetainedAction.Refresh) {
            retained.forEach(function (entity) {
                _this.defaultValues.set(entity, new Entity3DValue(entity));
            });
        }
        if (needWriteBackDefaultForRetainedNodes) {
            retained.forEach(function (entity) {
                var val = lastDefaultValues.get(entity);
                val.syncValue(entity);
            });
        }
        if (useDefaultRetainedNodesAction === UseDefaultRetainedAction.Keep) {
            retained.forEach(function (entity) {
                var val = lastDefaultValues.get(entity);
                _this.defaultValues.set(entity, val);
            });
        }
        if (useDefaultAddedNodesAction === UseDefaultAddedAction.Refresh) {
            added.forEach(function (entity) {
                _this.defaultValues.set(entity, new Entity3DValue(entity));
            });
        }
        return true;
    };
    AnimationClipBindingMock.prototype.writeDefaultValues = function () {
        this.defaultValues.forEach(function (val, entity) {
            val.syncValue(entity);
        });
    };
    AnimationClipBindingMock.prototype.getRoot = function () {
        return this._root;
    };
    AnimationClipBindingMock.prototype._getRoot = function () {
        if (!this.clipBinding.size) {
            return null;
        }
        var result = null;
        this.clipBinding.forEach(function (value, key) {
            if (!result && value.length) {
                result = value[0];
            }
        });
        return result;
    };
    AnimationClipBindingMock.prototype._updateBinding = function (clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, entities) {
        clipArrayLength = Math.min(clipArray.length - clipArrayOffset, clipArrayLength);
        entityArrayLength = Math.min(entityArray.length - entityArrayOffset, entityArrayLength);
        var cursor = 0;
        var clipBinding = new Map();
        for (var i = clipArrayOffset; i < clipArrayLength; i++) {
            var clipModel = clipArray[i];
            var nodes = [];
            var nodesLength = entityArray[cursor++];
            if (typeof nodesLength !== "number") {
                return false;
            }
            if (cursor >= entityArrayLength) {
                return false;
            }
            for (var j = 0; j < nodesLength; j++) {
                if (cursor >= entityArrayLength) {
                    return false;
                }
                var entity = entityArray[entityArrayOffset + cursor];
                if (typeof entity === "number") {
                    return false;
                }
                if (entity) {
                    entities.push(entity);
                    nodes.push(entity);
                }
                else {
                    nodes.push(null);
                }
                cursor++;
            }
            clipBinding.set(clipModel, nodes);
        }
        this.clipBinding = clipBinding;
        this.entities.clear();
        for (var _i = 0, entities_3 = entities; _i < entities_3.length; _i++) {
            var entity = entities_3[_i];
            this.entities.set(entity.id, entity);
        }
        this._root = this._getRoot();
        return true;
    };
    return AnimationClipBindingMock;
}());
exports.AnimationClipBindingMock = AnimationClipBindingMock;


/***/ }),
/* 65 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.LogicManager = void 0;
var tslib_1 = __webpack_require__(1);
var nativeObject_1 = __webpack_require__(32);
var matrix4_1 = tslib_1.__importDefault(__webpack_require__(44));
var quaternion_1 = tslib_1.__importDefault(__webpack_require__(61));
var vector3_1 = tslib_1.__importDefault(__webpack_require__(45));
var def_1 = __webpack_require__(6);
var componentDef_1 = __webpack_require__(33);
var entitySystem_1 = tslib_1.__importDefault(__webpack_require__(66));
var entity2D_1 = tslib_1.__importStar(__webpack_require__(48));
var entity3D_1 = tslib_1.__importStar(__webpack_require__(49));
var entity2D_2 = tslib_1.__importDefault(__webpack_require__(67));
var entity3D_2 = tslib_1.__importDefault(__webpack_require__(69));
var entityGroup_1 = tslib_1.__importStar(__webpack_require__(50));
var entity2DGroup_1 = tslib_1.__importDefault(__webpack_require__(51));
var entity3DGroup_1 = tslib_1.__importDefault(__webpack_require__(52));
var entity2DGroup_2 = tslib_1.__importDefault(__webpack_require__(70));
var entity3DGroup_2 = tslib_1.__importDefault(__webpack_require__(72));
var animatorComponent_1 = tslib_1.__importDefault(__webpack_require__(73));
var skinnedSkeletonComponent_1 = tslib_1.__importDefault(__webpack_require__(74));
var cullableComponent_1 = tslib_1.__importStar(__webpack_require__(35));
var cullableComponent_2 = tslib_1.__importDefault(__webpack_require__(75));
var dataBuffer_1 = tslib_1.__importDefault(__webpack_require__(47));
var util_1 = __webpack_require__(8);
var poolManager_1 = tslib_1.__importDefault(__webpack_require__(58));
var vector4_1 = tslib_1.__importDefault(__webpack_require__(46));
var animationClipBinding_1 = __webpack_require__(64);
var AnimatorController_1 = __webpack_require__(60);
var animatorControllerState_1 = __webpack_require__(62);
var LogicManager = /** @class */ (function () {
    function LogicManager(worker, config) {
        this.config = config;
        // 节点与mock节点弱引用
        this.entity2mock = new WeakMap();
        this.entityGroup2mock = new WeakMap();
        this.cullableComponent2mock = new WeakMap();
        // 各个子系统
        this._entitySystem = null;
        this._modelMap = {};
        this._dataBufferMap = {};
        this.worker = worker;
        this.poolManager = new poolManager_1.default(this.worker);
        entity2D_1.staticInitEntity2D(this);
        entity3D_1.staticInitEntity3D(this);
        entityGroup_1.staticInitEntityGroup(this);
        cullableComponent_1.staticInitCullableComponent(this);
        nativeObject_1.staticInitNativeObject(this.worker);
        AnimatorController_1.staticInitAnimatorController(this);
        animationClipBinding_1.staticInitAnimationClipBinding(this);
        animatorControllerState_1.staticInitAnimatorControllerLayerBlend(this.worker);
    }
    LogicManager.prototype.createEntity3D = function () {
        var nativeEntityID = this.poolManager.getEntity3D();
        var entity = new entity3D_1.default(nativeEntityID, this.poolManager.entity3DPools);
        entity.isUsing = true;
        this.entitySetActive(entity, true);
        var entityMock = new entity3D_2.default(entity.float32View, entity.uint32View, entity.entityOffset);
        this.entity2mock.set(entity, entityMock);
        return entity;
    };
    LogicManager.prototype.createEntity2D = function () {
        var nativeEntityID = this.poolManager.getEntity2D();
        var entity = new entity2D_1.default(nativeEntityID, this.poolManager.entity2DPools);
        entity.isUsing = true;
        this.entitySetActive(entity, true);
        var entityMock = new entity2D_2.default(entity.float32View, entity.uint32View, entity.entityOffset);
        this.entity2mock.set(entity, entityMock);
        return entity;
    };
    LogicManager.prototype.createEntity2DGroup = function (length) {
        var nativeEntity = this.worker.createEntity(def_1.enumEntityType.Entity2D, length);
        var entityGroup = new entity2DGroup_1.default(nativeEntity, length);
        var entityGroupMock = new entity2DGroup_2.default(entityGroup);
        this.entityGroup2mock.set(entityGroup, entityGroupMock);
        return entityGroup;
    };
    LogicManager.prototype.createEntity3DGroup = function (length) {
        var nativeEntity = this.worker.createEntity(def_1.enumEntityType.Entity3D, length);
        var entityGroup = new entity3DGroup_1.default(nativeEntity, length);
        var entityGroupMock = new entity3DGroup_2.default(entityGroup);
        this.entityGroup2mock.set(entityGroup, entityGroupMock);
        return entityGroup;
    };
    LogicManager.prototype.createCullableComponent = function () {
        var nativeCullableComponentID = this.poolManager.getCullableComponent();
        var comp = new cullableComponent_1.default(nativeCullableComponentID, this.poolManager.cullableComponentPools);
        comp.isUsing = true;
        comp.setActive(true);
        var compMock = new cullableComponent_2.default(comp);
        this.cullableComponent2mock.set(comp, compMock);
        return comp;
    };
    LogicManager.prototype.createAnimatorComponent = function () {
        var compMock = new animatorComponent_1.default();
        return compMock;
    };
    LogicManager.prototype.createSkinnedSkeletonComponent = function () {
        var comp = new skinnedSkeletonComponent_1.default();
        return comp;
    };
    LogicManager.prototype.createDataModel = function (typeID) {
        var ctor = componentDef_1.dataModel2CtorMock[typeID];
        if (!ctor) {
            console.warn("can not support dataModel [" + typeID + "]");
            return null;
        }
        var id = util_1.requestAccelerateObjectID();
        var model = new ctor(id);
        this._modelMap[id] = model;
        return model;
    };
    LogicManager.prototype.createDataBuffer = function (byteSize) {
        var id = util_1.requestAccelerateObjectID();
        var objectInfo = {
            buffer: new ArrayBuffer(byteSize),
            id: id,
            byteSize: byteSize,
        };
        var dataBuffer = new dataBuffer_1.default(objectInfo);
        this._dataBufferMap[id] = dataBuffer;
        return dataBuffer;
    };
    LogicManager.prototype.createAnimationClipBinding = function (clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, useDefaultAddedNodesAction, rootEntity) {
        return new animationClipBinding_1.AnimationClipBindingMock(clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, useDefaultAddedNodesAction, rootEntity);
    };
    LogicManager.prototype.createAnimatorController = function (layerCount) {
        return new AnimatorController_1.AnimatorControllerMock(layerCount);
    };
    LogicManager.prototype.createAnimatorControllerStateModel = function (length) {
        return new animatorControllerState_1.AnimatorControllerStateMock(length);
    };
    /*
    * 节点相关方法
    */
    LogicManager.prototype.entityAddChild = function (entity, child) {
        var entityMock = this.entity2mock.get(entity);
        var entityChildMock = this.entity2mock.get(child);
        if (entityMock && entityChildMock) {
            entityMock.addChild(entityChildMock);
        }
    };
    LogicManager.prototype.entityAddChildAtIndex = function (entity, child, index) {
        var entityMock = this.entity2mock.get(entity);
        var entityChildMock = this.entity2mock.get(child);
        if (entityMock && entityChildMock) {
            entityMock.addChildAtIndex(entityChildMock, index);
        }
    };
    LogicManager.prototype.entityRemoveFromParent = function (entity) {
        var entityMock = this.entity2mock.get(entity);
        if (entityMock) {
            entityMock.removeFromParent();
        }
    };
    LogicManager.prototype.entityDestroy = function (entity) {
        var entityMock = this.entity2mock.get(entity);
        if (entityMock) {
            entityMock.destroy();
        }
        if (entity instanceof entity2D_1.default) {
            this.poolManager.disposeEntity2D(entity);
        }
        else if (entity instanceof entity3D_1.default) {
            this.poolManager.disposeEntity3D(entity);
        }
    };
    LogicManager.prototype.entityClear = function (entity) {
        var entityMock = this.entity2mock.get(entity);
        if (entityMock) {
            entityMock.clear();
        }
    };
    LogicManager.prototype.entitySetActive = function (entity, active) {
        var entityMock = this.entity2mock.get(entity);
        if (entityMock) {
            entityMock.active = active;
        }
    };
    LogicManager.prototype.entitySetLocalMatrixDirty = function (entity) {
        var entityMock = this.entity2mock.get(entity);
        if (entityMock) {
            entityMock.setLocalMatrixDirty();
        }
    };
    LogicManager.prototype.entitiesSetLocalMatrixDirty = function (entitis, length) {
        for (var i = 0; i < length; i++) {
            var entity = entitis[i];
            var entityMock = this.entity2mock.get(entity);
            if (entityMock) {
                entityMock.setLocalMatrixDirty();
            }
        }
    };
    LogicManager.prototype.entitiesSetLocalMatrixDirtyById = function (entityIds, length) {
        /**
         * Todo
         */
    };
    LogicManager.prototype.componentBindEntity = function (component, entity) {
        var componentMock = this.cullableComponent2mock.get(component);
        var entityMock = this.entity2mock.get(entity);
        if (componentMock && entityMock) {
            componentMock.bindEntity(entityMock);
        }
    };
    LogicManager.prototype.componentUnbindEntity = function (component) {
        var componentMock = this.cullableComponent2mock.get(component);
        if (componentMock) {
            componentMock.unbindEntity();
        }
        this.poolManager.disposeCullableComponent(component);
    };
    LogicManager.prototype.setRootEntity = function (entity) {
        var entityMock = this.entity2mock.get(entity);
        if (entityMock) {
            if (entityMock instanceof entity3D_2.default) {
                this._getEntitySystem().setEntityRoot3D(entityMock);
            }
            else {
                this._getEntitySystem().setEntityRoot2D(entityMock);
            }
        }
    };
    /*
    * 节点组相关方法
    */
    LogicManager.prototype.entityGroupAddChild = function (entity, child, entityIndex, childIndex) {
        var entityMock;
        var entityChildMock;
        if (entity instanceof entityGroup_1.default) {
            var entityGroupMock = this.entityGroup2mock.get(entity);
            entityMock = entityGroupMock.entitis[entityIndex];
        }
        else {
            entityMock = this.entity2mock.get(entity);
        }
        if (child instanceof entityGroup_1.default) {
            var entityGroupMock = this.entityGroup2mock.get(child);
            entityChildMock = entityGroupMock.entitis[childIndex];
        }
        else {
            entityChildMock = this.entity2mock.get(child);
        }
        if (entityMock && entityChildMock) {
            entityMock.addChild(entityChildMock);
        }
    };
    LogicManager.prototype.entityGroupAddChildAtIndex = function (entity, child, index, entityIndex, childIndex) {
        var entityMock;
        var entityChildMock;
        if (entity instanceof entityGroup_1.default) {
            var entityGroupMock = this.entityGroup2mock.get(entity);
            entityMock = entityGroupMock.entitis[entityIndex];
        }
        else {
            entityMock = this.entity2mock.get(entity);
        }
        if (child instanceof entityGroup_1.default) {
            var entityGroupMock = this.entityGroup2mock.get(child);
            entityChildMock = entityGroupMock.entitis[childIndex];
        }
        else {
            entityChildMock = this.entity2mock.get(child);
        }
        if (entityMock && entityChildMock) {
            entityMock.addChildAtIndex(entityChildMock, index);
        }
    };
    LogicManager.prototype.entityGroupRemoveFromParent = function (entity, entityIndex) {
        var entityMock;
        if (entity instanceof entityGroup_1.default) {
            var entityGroupMock = this.entityGroup2mock.get(entity);
            entityMock = entityGroupMock.entitis[entityIndex];
        }
        else {
            entityMock = this.entity2mock.get(entity);
        }
        if (entityMock) {
            entityMock.removeFromParent();
        }
    };
    LogicManager.prototype.entityGroupDestroy = function (entity, entityIndex) {
        var entityMock;
        if (entity instanceof entityGroup_1.default) {
            var entityGroupMock = this.entityGroup2mock.get(entity);
            entityMock = entityGroupMock.entitis[entityIndex];
        }
        else {
            entityMock = this.entity2mock.get(entity);
        }
        if (entityMock) {
            entityMock.destroy();
        }
        if (entity instanceof entity2D_1.default) {
            this.poolManager.disposeEntity2D(entity);
        }
        else if (entity instanceof entity3D_1.default) {
            this.poolManager.disposeEntity3D(entity);
        }
    };
    LogicManager.prototype.entityGroupClear = function (entity, entityIndex) {
        var entityMock;
        if (entity instanceof entityGroup_1.default) {
            var entityGroupMock = this.entityGroup2mock.get(entity);
            entityMock = entityGroupMock.entitis[entityIndex];
        }
        else {
            entityMock = this.entity2mock.get(entity);
        }
        if (entityMock) {
            entityMock.clear();
        }
    };
    LogicManager.prototype.entityGroupSetActive = function (entity, active, entityIndex) {
        var entityMock;
        if (entity instanceof entityGroup_1.default) {
            var entityGroupMock = this.entityGroup2mock.get(entity);
            entityMock = entityGroupMock.entitis[entityIndex];
        }
        else {
            entityMock = this.entity2mock.get(entity);
        }
        if (entityMock) {
            entityMock.active = active;
        }
    };
    LogicManager.prototype.entityGroupSetLocalMatrixDirty = function (entity, entityIndex) {
        var entityMock;
        if (entity instanceof entityGroup_1.default) {
            var entityGroupMock = this.entityGroup2mock.get(entity);
            entityMock = entityGroupMock.entitis[entityIndex];
        }
        else {
            entityMock = this.entity2mock.get(entity);
        }
        if (entityMock) {
            entityMock.setLocalMatrixDirty();
        }
    };
    LogicManager.prototype.entityGroupSetLocalMatrixDirtyAll = function (entityGroup) {
        var entityGroupMock = this.entityGroup2mock.get(entityGroup);
        if (entityGroupMock) {
            entityGroupMock.setLocalMatrixDirtyAll();
        }
    };
    LogicManager.prototype.componentBindEntityWithIndex = function (component, entity, componentIndex, entityIndex) {
        var componentMock = this.cullableComponent2mock.get(component);
        var entityMock;
        if (entity instanceof entityGroup_1.default) {
            var entityGroupMock = this.entityGroup2mock.get(entity);
            entityMock = entityGroupMock.entitis[entityIndex];
        }
        else {
            entityMock = this.entity2mock.get(entity);
        }
        if (componentMock && entityMock) {
            componentMock.bindEntity(entityMock);
        }
    };
    LogicManager.prototype.componentUnbindEntityWithIndex = function (component, componentIndex) {
        var componentMock = this.cullableComponent2mock.get(component);
        if (componentMock) {
            componentMock.unbindEntity();
        }
        this.poolManager.disposeCullableComponent(component);
    };
    LogicManager.prototype.setRootEntityGroup = function (entity, entityIndex) {
        if (entityIndex === void 0) { entityIndex = 0; }
        var entityMock;
        if (entity instanceof entityGroup_1.default) {
            var entityGroupMock = this.entityGroup2mock.get(entity);
            entityMock = entityGroupMock.entitis[entityIndex];
        }
        else {
            entityMock = this.entity2mock.get(entity);
        }
        if (entityMock) {
            if (entityMock instanceof entity3D_2.default) {
                this._getEntitySystem().setEntityRoot3D(entityMock);
            }
            else {
                this._getEntitySystem().setEntityRoot2D(entityMock);
            }
        }
    };
    LogicManager.prototype.refreshWorldTransform = function () {
        this._getEntitySystem().refreshWorldTransform();
    };
    // 投影剔除
    LogicManager.prototype.cullWithCameraPerspective = function (cullMask, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ, fovy, aspect, zNear, zFar) {
        var rootEntity = this._getEntitySystem().root3D;
        var resultIds = [];
        var resultDistances = [];
        var eye = vector3_1.default.createFromNumber(eyeX, eyeY, eyeZ);
        var center = vector3_1.default.createFromNumber(centerX, centerY, centerZ);
        var up = vector3_1.default.createFromNumber(upX, upY, upZ);
        var tang = Math.tan(fovy / 2.0);
        var nh = zNear * tang;
        var nw = nh * aspect;
        var axisZ = eye.sub(center).normalize();
        var axisX = up.cross(axisZ).normalize();
        var axisY = axisZ.cross(axisX);
        var p = eye;
        var nc = p.sub(axisZ.scale(zNear));
        var fc = p.sub(axisZ.scale(zFar));
        var planes = [];
        // near
        planes[0] = {};
        planes[0].point = nc;
        planes[0].normal = axisZ.scale(-1);
        planes[0].distance = planes[0].point.dot(planes[0].normal.scale(-1));
        // far
        planes[1] = {};
        planes[1].point = fc;
        planes[1].normal = axisZ;
        planes[1].distance = planes[1].point.dot(planes[1].normal.scale(-1));
        // Top
        planes[2] = {};
        planes[2].point = nc.add(axisY.scale(nh));
        planes[2].normal = planes[2].point
            .sub(p)
            .normalize()
            .cross(axisX);
        planes[2].distance = planes[2].point.dot(planes[2].normal.scale(-1));
        // Bottom
        planes[3] = {};
        planes[3].point = nc.sub(axisY.scale(nh));
        planes[3].normal = axisX.cross(planes[3].point.sub(p).normalize());
        planes[3].distance = planes[3].point.dot(planes[3].normal.scale(-1));
        // Left
        planes[4] = {};
        planes[4].point = nc.sub(axisX.scale(nw));
        planes[4].normal = planes[4].point
            .sub(p)
            .normalize()
            .cross(axisY);
        planes[4].distance = planes[4].point.dot(planes[4].normal.scale(-1));
        // Right
        planes[5] = {};
        planes[5].point = nc.add(axisX.scale(nw));
        planes[5].normal = axisY.cross(planes[5].point.sub(p).normalize());
        planes[5].distance = planes[5].point.dot(planes[5].normal.scale(-1));
        if (rootEntity) {
            rootEntity.travelChild(function (child) {
                // todo cull and sort
                var comps = child._cullableComps;
                for (var _i = 0, comps_1 = comps; _i < comps_1.length; _i++) {
                    var comp = comps_1[_i];
                    if (!comp || !comp.active || (comp.entity !== child) || !child.active) {
                        return true;
                    }
                    if (!(cullMask & comp.cullMask)) {
                        return true;
                    }
                    var isOut = false;
                    var worldMatrix = child.worldMatrix;
                    var worldMatrixRaw = worldMatrix._raw;
                    var worldMatrixOffset = worldMatrix._offset;
                    var sx = vector3_1.default.createFromNumber(worldMatrixRaw[worldMatrixOffset + 0 * 4 + 0], worldMatrixRaw[worldMatrixOffset + 0 * 4 + 1], worldMatrixRaw[worldMatrixOffset + 0 * 4 + 2]).length();
                    var sy = vector3_1.default.createFromNumber(worldMatrixRaw[worldMatrixOffset + 1 * 4 + 0], worldMatrixRaw[worldMatrixOffset + 1 * 4 + 1], worldMatrixRaw[worldMatrixOffset + 1 * 4 + 2]).length();
                    var sz = vector3_1.default.createFromNumber(worldMatrixRaw[worldMatrixOffset + 2 * 4 + 0], worldMatrixRaw[worldMatrixOffset + 2 * 4 + 1], worldMatrixRaw[worldMatrixOffset + 2 * 4 + 2]).length();
                    var max_scale = sx > sy ? sx : sy;
                    max_scale = max_scale > sz ? max_scale : sz;
                    var center_1 = worldMatrix.transformPoint(vector3_1.default.createFromTypedArray(comp.boundingBallCenter));
                    var raduis = comp.boundingBallRadius * max_scale;
                    for (var i = 0; i < 6; i++) {
                        var distance = planes[i].normal.dot(center_1) + planes[i].distance;
                        if (distance < -raduis) {
                            isOut = true;
                            break;
                        }
                    }
                    if (!isOut) {
                        resultIds.push(comp._componetModel.id);
                        resultDistances.push(0);
                    }
                }
            });
        }
        var result = {
            objects: new Uint32Array(resultIds).buffer,
            hash: Math.ceil(Math.random() * 1000000),
            distances: new Float32Array(resultDistances).buffer,
        };
        if (!result) {
            return { hash: 0, objects: [], distances: [] };
        }
        return {
            hash: result.hash,
            objects: new Uint32Array(result.objects),
            distances: new Float32Array(result.distances),
        };
    };
    // 正交剔除
    LogicManager.prototype.cullWithCameraOrthographic = function (cullMask, eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ, xwMin, xwMax, ywMin, ywMax, zNear, zFar) {
        var rootEntity = this._getEntitySystem().root3D;
        var resultIds = [];
        var resultDistances = [];
        var eye = vector3_1.default.createFromNumber(eyeX, eyeY, eyeZ);
        var center = vector3_1.default.createFromNumber(centerX, centerY, centerZ);
        var up = vector3_1.default.createFromNumber(upX, upY, upZ);
        var axisZ = eye.sub(center).normalize();
        var axisX = up.cross(axisZ).normalize();
        var axisY = axisZ.cross(axisX);
        var p = eye;
        var nc = p.sub(axisZ.scale(zNear));
        var fc = p.sub(axisZ.scale(zFar));
        var planes = [];
        // near
        planes[0] = {};
        planes[0].point = nc;
        planes[0].normal = axisZ.scale(-1);
        planes[0].distance = planes[0].point.dot(planes[0].normal.scale(-1));
        // far
        planes[1] = {};
        planes[1].point = fc;
        planes[1].normal = axisZ;
        planes[1].distance = planes[1].point.dot(planes[1].normal.scale(-1));
        // Top
        planes[2] = {};
        planes[2].point = nc.add(axisY.scale(ywMax));
        planes[2].normal = axisY.scale(-1);
        planes[2].distance = planes[2].point.dot(planes[2].normal.scale(-1));
        // Bottom
        planes[3] = {};
        planes[3].point = nc.add(axisY.scale(ywMin));
        planes[3].normal = axisY;
        planes[3].distance = planes[3].point.dot(planes[3].normal.scale(-1));
        // Left
        planes[4] = {};
        planes[4].point = nc.add(axisX.scale(xwMin));
        planes[4].normal = axisX;
        planes[4].distance = planes[4].point.dot(planes[4].normal.scale(-1));
        // Right
        planes[5] = {};
        planes[5].point = nc.add(axisX.scale(xwMax));
        planes[5].normal = axisX.scale(-1);
        planes[5].distance = planes[5].point.dot(planes[5].normal.scale(-1));
        if (rootEntity) {
            rootEntity.travelChild(function (child) {
                // todo cull and sort
                var comps = child._cullableComps;
                for (var _i = 0, comps_2 = comps; _i < comps_2.length; _i++) {
                    var comp = comps_2[_i];
                    if (!comp || !comp.active || (comp.entity !== child) || !child.active) {
                        return true;
                    }
                    if (!(cullMask & comp.cullMask)) {
                        return true;
                    }
                    var isOut = false;
                    var worldMatrix = child.worldMatrix;
                    var worldMatrixRaw = worldMatrix._raw;
                    var worldMatrixOffset = worldMatrix._offset;
                    var sx = vector3_1.default.createFromNumber(worldMatrixRaw[worldMatrixOffset + 0 * 4 + 0], worldMatrixRaw[worldMatrixOffset + 0 * 4 + 1], worldMatrixRaw[worldMatrixOffset + 0 * 4 + 2]).length();
                    var sy = vector3_1.default.createFromNumber(worldMatrixRaw[worldMatrixOffset + 1 * 4 + 0], worldMatrixRaw[worldMatrixOffset + 1 * 4 + 1], worldMatrixRaw[worldMatrixOffset + 1 * 4 + 2]).length();
                    var sz = vector3_1.default.createFromNumber(worldMatrixRaw[worldMatrixOffset + 2 * 4 + 0], worldMatrixRaw[worldMatrixOffset + 2 * 4 + 1], worldMatrixRaw[worldMatrixOffset + 2 * 4 + 2]).length();
                    var max_scale = sx > sy ? sx : sy;
                    max_scale = max_scale > sz ? max_scale : sz;
                    var center_2 = worldMatrix.transformPoint(vector3_1.default.createFromTypedArray(comp.boundingBallCenter));
                    var raduis = comp.boundingBallRadius * max_scale;
                    for (var i = 0; i < 6; i++) {
                        var distance = planes[i].normal.dot(center_2) + planes[i].distance;
                        if (distance < -raduis) {
                            isOut = true;
                            break;
                        }
                    }
                    if (!isOut) {
                        resultIds.push(comp._componetModel.id);
                        resultDistances.push(0);
                    }
                }
            });
        }
        var result = {
            objects: new Uint32Array(resultIds).buffer,
            hash: Math.ceil(Math.random() * 1000000),
            distances: new Float32Array(resultDistances).buffer,
        };
        if (!result) {
            return { hash: 0, objects: [], distances: [] };
        }
        return {
            hash: result.hash,
            objects: new Uint32Array(result.objects),
            distances: new Float32Array(result.distances),
        };
    };
    LogicManager.prototype.SyncValuesToEntity3D = function (result, bone) {
        if (result.tx !== null) {
            bone.float32View[bone.localPositionOffset] = result.tx;
        }
        if (result.ty !== null) {
            bone.float32View[bone.localPositionOffset + 1] = result.ty;
        }
        if (result.tz !== null) {
            bone.float32View[bone.localPositionOffset + 2] = result.tz;
        }
        if (result.sx !== null) {
            bone.float32View[bone.localScaleOffset + 0] = result.sx;
        }
        if (result.sy !== null) {
            bone.float32View[bone.localScaleOffset + 1] = result.sy;
        }
        if (result.sz !== null) {
            bone.float32View[bone.localScaleOffset + 2] = result.sz;
        }
        if (result.rw !== null) {
            bone.setUsingEuler(false);
            bone.float32View[bone.localQuaternionOffset + 0] = result.rx;
            bone.float32View[bone.localQuaternionOffset + 1] = result.ry;
            bone.float32View[bone.localQuaternionOffset + 2] = result.rz;
            bone.float32View[bone.localQuaternionOffset + 3] = result.rw;
        }
        else {
            if (result.rx !== null || result.ry !== null || result.rz !== null) {
                //console.log("Euler animation detected.");
                //bone.setUsingEuler(true);
            }
            // if (result.rx !== null) { bone._localEuler.x = result.rx; }
            // if (result.ry !== null) { bone._localEuler.y = result.ry; }
            // if (result.rz !== null) { bone._localEuler.z = result.rz; }
        }
        this.entitySetLocalMatrixDirty(bone);
    };
    LogicManager.prototype.updateAnimator = function (comp) {
        this._updateAnimator(comp);
        if (comp) {
            // 找到根节点进行WorldMartix运算
            var entityMock = this.entity2mock.get(comp.culEntity3DTreeNode);
            if (entityMock) {
                // entityMock._computeRootWorldMatrixRecursive();
                this.computeRootWorldMatrixRecursive(entityMock);
            }
        }
    };
    LogicManager.prototype.updateAnimatorController = function (comp) {
        if (comp && comp.binding && comp.binding.getRoot()) {
            comp.update();
            // 找到根节点进行WorldMartix运算
            var entityMock = this.entity2mock.get(comp.binding.getRoot());
            if (entityMock) {
                // entityMock._computeRootWorldMatrixRecursive();
                this.computeRootWorldMatrixRecursive(entityMock);
            }
        }
    };
    LogicManager.prototype.computeRootWorldMatrixRecursive = function (entity) {
        var parent = entity.parent;
        if (parent) {
            this.computeRootWorldMatrixRecursive(parent);
        }
        else {
            if (entity != this._getEntitySystem().root3D) {
                entity._computeWorldMatrixRecursive(false);
            }
        }
    };
    LogicManager.prototype._updateAnimator = function (comp) {
        if (!comp) {
            return;
        }
        var vaildParameters = [];
        var nodesCountSum = 0;
        for (var i = 0; i < comp.animationClipCount; i++) {
            var para = comp.getAnimationParamater(i);
            if (para.percentage !== undefined) {
                var vaildPara = tslib_1.__assign({}, para);
                vaildPara.nodeIndex = nodesCountSum;
                vaildParameters.push(vaildPara);
            }
            nodesCountSum += this._modelMap[para.animationClipId].nodesLength;
        }
        if (vaildParameters.length === 0) {
            return;
        }
        var clip0 = this._modelMap[vaildParameters[0].animationClipId];
        if (clip0 === undefined) {
            console.log("AnimationClipModel not found");
            return;
        }
        if (vaildParameters.length === 1) {
            var result = clip0.evaluate(vaildParameters[0].frameIndex);
            for (var i in result) {
                var entity = comp.getEntity(Number(i) + vaildParameters[0].nodeIndex);
                if (entity) {
                    var transformResult = result[i];
                    var transform = tslib_1.__assign({}, result[i]);
                    delete transform.use_quaternion;
                    this.SyncValuesToEntity3D(transformResult, entity);
                }
            }
        }
        else {
            var entityBlendInfo = {};
            var animatorComponent = comp;
            var clipInfos = vaildParameters;
            for (var i = 0; i < clipInfos.length; i++) {
                if (!this._modelMap[clipInfos[i].animationClipId]) {
                    console.log("Fail to get native animation-clip resource.");
                    continue;
                }
                var clip = this._modelMap[clipInfos[i].animationClipId];
                var result = clip.evaluate(clipInfos[i].frameIndex);
                for (var nodeId in result) {
                    var entity = animatorComponent.getEntity(Number(nodeId) + clipInfos[i].nodeIndex);
                    if (!entity) {
                        continue;
                    }
                    var entityId = entity.id;
                    var transform = tslib_1.__assign({}, result[nodeId]);
                    var percentage = tslib_1.__assign({}, result[nodeId]);
                    delete transform.use_quaternion;
                    delete percentage.use_quaternion;
                    for (var key in transform) {
                        if (transform[key] !== null) {
                            percentage[key] = clipInfos[i].percentage;
                        }
                    }
                    if (!entityBlendInfo[entityId]) {
                        entityBlendInfo[entityId] = {
                            entity: entity,
                            transforms: [],
                            percentages: [],
                        };
                    }
                    entityBlendInfo[entityId].transforms.push(transform);
                    entityBlendInfo[entityId].percentages.push(percentage);
                }
            }
            var entityBlendChannelInfo = {};
            var entityBlendResult = {};
            for (var entityId in entityBlendInfo) {
                entityBlendChannelInfo[entityId] = {
                    tx: [],
                    ty: [],
                    tz: [],
                    sx: [],
                    sy: [],
                    sz: [],
                    rx: [],
                    ry: [],
                    rz: [],
                    rw: [],
                };
                var blendCount = entityBlendInfo[entityId].transforms.length;
                for (var i = 0; i < blendCount; i++) {
                    var transform = entityBlendInfo[entityId].transforms[i];
                    var percentage = entityBlendInfo[entityId].percentages[i];
                    for (var channel in percentage) {
                        if (percentage[channel] !== null) {
                            entityBlendChannelInfo[entityId][channel].push({
                                value: transform[channel],
                                percentage: percentage[channel],
                            });
                        }
                    }
                }
            }
            for (var entityId in entityBlendChannelInfo) {
                entityBlendResult[entityId] = {
                    tx: null,
                    ty: null,
                    tz: null,
                    sx: null,
                    sy: null,
                    sz: null,
                    rx: null,
                    ry: null,
                    rz: null,
                    rw: null,
                    use_quaternion: true
                };
                var entityBCInfo = entityBlendChannelInfo[entityId];
                for (var channel in entityBCInfo) {
                    if (!entityBCInfo[channel].length) {
                        continue;
                    }
                    /**
                     * Linear blend
                     */
                    if (["tx", "ty", "tz", "sx", "sy", "sz"].indexOf(channel) >= 0) {
                        if (entityBlendResult[entityId][channel] === null) {
                            entityBlendResult[entityId][channel] = 0;
                        }
                        for (var j = 0; j < entityBCInfo[channel].length; j++) {
                            var info = entityBCInfo[channel][j];
                            entityBlendResult[entityId][channel] += info.value * info.percentage;
                        }
                    }
                }
                if (entityBCInfo.rx.length &&
                    entityBCInfo.rx.length === entityBCInfo.ry.length &&
                    entityBCInfo.rx.length === entityBCInfo.rz.length &&
                    entityBCInfo.rx.length === entityBCInfo.rw.length) {
                    /**
                     * Weight consistency need check.
                     * rx ry rz rw should be the same weight.
                     */
                    if (entityBCInfo.rx.length !== 2) {
                        var value4 = new vector4_1.default();
                        for (var k = 0; k < entityBCInfo.rx.length; k++) {
                            var w = entityBCInfo.rx[k].percentage;
                            var valuei = vector4_1.default.createFromNumber(entityBCInfo.rx[k].value, entityBCInfo.ry[k].value, entityBCInfo.rz[k].value, entityBCInfo.rw[k].value);
                            value4.add(value4.dot(valuei) < 0 ? valuei.scale(-w) : valuei.scale(w), value4);
                        }
                        value4.scale(1 / Math.sqrt(value4.dot(value4)), value4);
                        entityBlendResult[entityId].rx = value4.x;
                        entityBlendResult[entityId].ry = value4.y;
                        entityBlendResult[entityId].rz = value4.z;
                        entityBlendResult[entityId].rw = value4.w;
                    }
                    else {
                        var rot = new quaternion_1.default();
                        rot.setValue(entityBCInfo.rx[0].value, entityBCInfo.ry[0].value, entityBCInfo.rz[0].value, entityBCInfo.rw[0].value);
                        var rot2 = new quaternion_1.default();
                        rot2.setValue(entityBCInfo.rx[1].value, entityBCInfo.ry[1].value, entityBCInfo.rz[1].value, entityBCInfo.rw[1].value);
                        rot.slerp(rot2, (entityBCInfo.rx[1].percentage / (entityBCInfo.rx[0].percentage + entityBCInfo.rx[1].percentage)), rot);
                        entityBlendResult[entityId].rx = rot.x;
                        entityBlendResult[entityId].ry = rot.y;
                        entityBlendResult[entityId].rz = rot.z;
                        entityBlendResult[entityId].rw = rot.w;
                    }
                }
            }
            for (var entityId in entityBlendResult) {
                this.SyncValuesToEntity3D(entityBlendResult[entityId], entityBlendInfo[entityId].entity);
            }
        }
    };
    LogicManager.prototype.updateAnimators = function (comps) {
        for (var i = 0; i < comps.length; i++) {
            this.updateAnimator(comps[i]);
        }
    };
    LogicManager.prototype.updateAnimatorControllers = function (comps, length) {
        for (var i = 0; i < length; i++) {
            this.updateAnimatorController(comps[i]);
        }
    };
    LogicManager.prototype.updateSkinningMatrix = function (comp) {
        if (!comp)
            return;
        var model = this._modelMap[comp.getBoneInverseModelId()];
        for (var i = 0; i < comp.getBoneNum(); i++) {
            var boneIndice = comp.getBoneIndices(i);
            var boneEntity = comp.getBoneEntity(i);
            var wt = matrix4_1.default.createFromTypedArray(boneEntity.float32View, boneEntity.worldMatrixOffset);
            var inverseMat = model.inverseMatrixs[boneIndice];
            wt.multiply(inverseMat, comp.outputBoneInverseMatrixs[i]);
        }
    };
    LogicManager.prototype.updateSkinningMatrices = function (comps) {
        for (var i = 0; i < comps.length; i++) {
            this.updateSkinningMatrix(comps[i]);
        }
    };
    LogicManager.prototype.bindEntitiesToBones = function (entitis, boneEntitis) {
        for (var i = 0; i < entitis.length; i++) {
            var entity = entitis[i];
            var boneEntity = boneEntitis[i];
            var entityMock = this.entity2mock.get(entity);
            var boneEntityMock = this.entity2mock.get(boneEntity);
            if (entityMock && boneEntityMock) {
                entityMock._linkBoneEntity = boneEntityMock;
                boneEntityMock._linkEntity = entityMock;
            }
        }
    };
    LogicManager.prototype.unbindEntitiesFromBones = function (entitis) {
        for (var i = 0; i < entitis.length; i++) {
            var entity = entitis[i];
            var entityMock = this.entity2mock.get(entity);
            if (entityMock && entityMock._linkBoneEntity) {
                entityMock._linkBoneEntity._linkEntity = null;
                entityMock._linkEntity = null;
            }
        }
    };
    LogicManager.prototype.bindEntitiesToBonesWithIndex = function (entitis, boneEntitis, entityIndexs, boneIndexs) {
        for (var i = 0; i < entitis.length; i++) {
            var entity = entitis[i];
            var boneEntity = boneEntitis[i];
            var entityMock = this.entity2mock.get(entity);
            var boneEntityMock = this.entity2mock.get(boneEntity);
            if (entityMock && boneEntityMock) {
                entityMock._linkBoneEntity = boneEntityMock;
                boneEntityMock._linkEntity = entityMock;
            }
        }
    };
    LogicManager.prototype.unbindEntitiesFromBonesWithIndex = function (entitis, entityIndexs) {
        for (var i = 0; i < entitis.length; i++) {
            var entity = entitis[i];
            var entityMock = this.entity2mock.get(entity);
            if (entityMock && entityMock._linkBoneEntity) {
                entityMock._linkBoneEntity._linkEntity = null;
                entityMock._linkEntity = null;
            }
        }
    };
    LogicManager.prototype._getEntitySystem = function () {
        if (!this._entitySystem) {
            this._entitySystem = new entitySystem_1.default(this);
        }
        return this._entitySystem;
    };
    LogicManager.prototype.frameStart = function () { };
    // 把entity的名字同步给native，debug用。by jackjhu/zombieyang 2020.4
    LogicManager.prototype.setEntityName = function (id, name) { };
    return LogicManager;
}());
exports.LogicManager = LogicManager;


/***/ }),
/* 66 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
// import { requestAccelerateObjectID } from "../util";
var EntitySystem = /** @class */ (function () {
    // private _entityMap3D: { [id: number]: Entity3D_S } = {};
    // private _entityMap2D: { [id: number]: Entity2D_S } = {};
    function EntitySystem(manager) {
        this.root3D = null;
        this.root3Ds = [];
        this.root2Ds = [];
        this._manager = manager;
    }
    // public addEntity(entity: Entity2D_S | Entity3D_S, type: enumEntityType){
    //   const mockId = requestAccelerateObjectID();
    //   entity.id = mockId;
    //   if (type === enumEntityType.Entity3D) {
    //     this._entityMap3D[mockId] = entity as Entity3D_S;
    //   } else {
    //     this._entityMap2D[mockId] = entity as Entity2D_S;
    //   }
    // }
    // public getEntity2DById(entityId: number): Entity2D_S {
    //   return this._entityMap2D[entityId];
    // }
    // public getEntity3DById(entityId: number): Entity3D_S {
    //   return this._entityMap3D[entityId];
    // }
    EntitySystem.prototype.refreshWorldTransform = function () {
        this.root3D._computeWorldMatrixRecursive(true);
        this.root2Ds.forEach(function (root2D) {
            root2D._computeWorldMatrixRecursive(true);
        });
    };
    EntitySystem.prototype.setEntityRoot3D = function (entity) {
        this.root3D = entity;
        this.root3Ds.push(entity);
    };
    EntitySystem.prototype.setEntityRoot2D = function (entity) {
        this.root2Ds.push(entity);
    };
    EntitySystem.prototype.entityAddChild = function (parentEntity, childEntity) {
        // 3D不能加在2D下面
        parentEntity.addChild(childEntity);
    };
    EntitySystem.prototype.entityAddChildAtIndex = function (parentEntity, childEntity, index) {
        parentEntity.addChildAtIndex(childEntity, index);
    };
    EntitySystem.prototype.entityRemoveFromParent = function (entity) {
        // tslint:disable-next-line: no-unused-expression
        entity.parent && entity.parent.removeChild(entity);
    };
    return EntitySystem;
}());
exports.default = EntitySystem;


/***/ }),
/* 67 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
/*
 * @Author: bluecatliao
 * @Date: 2018-11-19 19:02:44
 * @Last Modified by: roamye
 * @Last Modified time: 2020-05-08 21:59:41
 * Entity2D包含了Entity+Transform2D，利用客户端可以加速worldTransform的计算
 */
var matrix3_1 = tslib_1.__importDefault(__webpack_require__(21));
var vector2_1 = tslib_1.__importDefault(__webpack_require__(22));
var entity2D_1 = tslib_1.__importDefault(__webpack_require__(48));
var entity_1 = tslib_1.__importDefault(__webpack_require__(68));
var Entity2D_S = /** @class */ (function (_super) {
    tslib_1.__extends(Entity2D_S, _super);
    function Entity2D_S(_raw, _u32View, offset) {
        var _this = _super.call(this) || this;
        _this._localMatrix = matrix3_1.default.IDENTITY;
        _this._raw = _raw;
        _this._rawU32 = _u32View;
        _this._offset = offset;
        _this.localRotationOffset = _this._offset + entity2D_1.default.OFFSET_ROTATION;
        _this.localPositionOffset = _this._offset + entity2D_1.default.OFFSET_POSITION;
        _this.localScaleOffset = _this._offset + entity2D_1.default.OFFSET_SCALE;
        _this.worldMatrixOffset = _this._offset + entity2D_1.default.OFFSET_WORLDMATRIX;
        return _this;
    }
    Object.defineProperty(Entity2D_S.prototype, "localPosition", {
        /*
         * Mock
         */
        get: function () {
            if (!this._localPosition) {
                this._localPosition = vector2_1.default.createFromTypedArray(this._raw, this.localPositionOffset);
            }
            return this._localPosition;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Entity2D_S.prototype, "localRotation", {
        get: function () {
            return this._raw[this.localRotationOffset];
        },
        set: function (val) {
            this._raw[this.localRotationOffset] = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Entity2D_S.prototype, "localScale", {
        get: function () {
            if (!this._localScale) {
                this._localScale = vector2_1.default.createFromTypedArray(this._raw, this.localScaleOffset);
            }
            return this._localScale;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Entity2D_S.prototype, "worldMatrix", {
        get: function () {
            if (!this._worldMatrix) {
                this._worldMatrix = matrix3_1.default.createFromTypedArray(this._raw, this.worldMatrixOffset);
            }
            return this._worldMatrix;
        },
        enumerable: false,
        configurable: true
    });
    // 刷新该节点的子节点的worldTransform
    Entity2D_S.prototype._computeWorldMatrixRecursive = function (parentDirty) {
        var isLocalDirty = this._culLocalTransform();
        var thisDirty = (parentDirty || isLocalDirty);
        if (thisDirty) {
            var parent = this.parent;
            if (parent) {
                parent.worldMatrix.multiply(this._localMatrix, this.worldMatrix);
            }
            else {
                this.worldMatrix._raw.set(this._localMatrix._raw, this.worldMatrix._offset);
            }
        }
        this._isWorldMatrixDirty = true;
        for (var _i = 0, _a = this.children; _i < _a.length; _i++) {
            var child = _a[_i];
            if (child.active) {
                child._computeWorldMatrixRecursive(thisDirty);
            }
        }
    };
    Entity2D_S.prototype._culLocalTransform = function () {
        var isLocalDirty = this._isLocalMatrixDirty;
        if (isLocalDirty) {
            var pos = this.localPosition;
            var rot = this.localRotation;
            var scale = this.localScale;
            matrix3_1.default.IDENTITY.translate(pos.x, pos.y, this._localMatrix)
                .rotate(rot, this._localMatrix)
                .scale(scale.x, scale.y, this._localMatrix);
            // 清除标记位
            this._isLocalMatrixDirty = false;
        }
        return isLocalDirty;
    };
    return Entity2D_S;
}(entity_1.default));
exports.default = Entity2D_S;


/***/ }),
/* 68 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Entity_S = /** @class */ (function () {
    function Entity_S() {
        this.children = [];
        this.parent = null;
        this.components = [];
        this.id = 0;
        this.active = true;
        this._isLocalMatrixDirty = false;
        this._isWorldMatrixDirty = false;
    }
    /*
      implements
    */
    Entity_S.prototype.setLocalMatrixDirty = function () {
        this._isLocalMatrixDirty = true;
    };
    Entity_S.prototype._computeWorldMatrixRecursive = function (parentDirty) { };
    /*
      mock
    */
    Entity_S.prototype.bindComponet = function (comp) {
        this.components.push(comp);
        comp.entity = this;
        comp._onAdd();
    };
    Entity_S.prototype.unbindComponent = function (comp) {
        var componentIndex = this.components.indexOf(comp);
        if (comp.entity || componentIndex !== -1) {
            this.components.splice(componentIndex, 1);
            comp.entity = null;
            comp._onDestroy();
        }
    };
    /**
     * 获取指定构造函数的第一个组件实例
     * @param ctor
     */
    Entity_S.prototype.getComponent = function (ctor) {
        var allComponents = this.getAllComponents(ctor);
        return (allComponents.length ? allComponents[0] : void 0);
    };
    /**
     * 获取指定构造函数的所有组件实例
     * @param ctor
     */
    Entity_S.prototype.getAllComponents = function (ctor) {
        return (this.components.filter(function (comp) { return comp instanceof ctor; }) || []);
    };
    Entity_S.prototype.travelChild = function (cb) {
        cb(this);
        for (var i = 0; i < this.children.length; i++) {
            this.children[i].travelChild(cb);
        }
    };
    // todo 编码
    Entity_S.prototype.addChild = function (child) {
        this.addChildAtIndex(child, this.children.length);
    };
    Entity_S.prototype.addChildAtIndex = function (child, index) {
        if (child.parent) {
            child.parent.removeChild(child);
        }
        if (this.children.indexOf(child) === -1) {
            if (index >= this.children.length) {
                this.children.push(child);
            }
            else {
                this.children.splice(index, 0, child);
            }
            child.parent = this;
        }
    };
    Entity_S.prototype.removeChild = function (child) {
        var index = this.children.indexOf(child);
        if (index > -1) {
            this.children.splice(index, 1);
        }
    };
    Entity_S.prototype.removeFromParent = function () {
        this.parent && this.parent.removeChild(this);
    };
    Entity_S.prototype.destroy = function () {
        for (var _i = 0, _a = this.components; _i < _a.length; _i++) {
            var comp = _a[_i];
            comp._onDestroy();
            comp.entity = null;
        }
        this.components = [];
        this.parent && this.parent.removeChild(this);
        this.parent = null;
    };
    Entity_S.prototype.clear = function () {
        for (var _i = 0, _a = this.components; _i < _a.length; _i++) {
            var comp = _a[_i];
            comp._onDestroy();
            comp.entity = null;
        }
        this.components = [];
        this.parent && this.parent.removeChild(this);
        this.parent = null;
        for (var _b = 0, _c = this.children; _b < _c.length; _b++) {
            var child = _c[_b];
            child.clear();
        }
    };
    return Entity_S;
}());
exports.default = Entity_S;


/***/ }),
/* 69 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
/*
 * @Author: bluecatliao
 * @Date: 2018-11-19 19:02:44
 * @Last Modified by: roamye
 * @Last Modified time: 2020-06-09 19:08:47
 * Entity3D包含了Entity+Transform3D，利用客户端可以加速worldTransform的计算
 * 支持四元数和欧拉角两种模式，但是暂不支持互相转换（即set欧拉角然后get四元数）
 */
var matrix4_1 = tslib_1.__importDefault(__webpack_require__(44));
var quaternion_1 = tslib_1.__importDefault(__webpack_require__(61));
var vector3_1 = tslib_1.__importDefault(__webpack_require__(45));
var entity_1 = tslib_1.__importDefault(__webpack_require__(68));
var entity3D_1 = tslib_1.__importDefault(__webpack_require__(49));
var Entity3D_S = /** @class */ (function (_super) {
    tslib_1.__extends(Entity3D_S, _super);
    function Entity3D_S(_raw, _u32View, offset) {
        var _this = _super.call(this) || this;
        _this._localMatrix = matrix4_1.default.IDENTITY;
        // components
        _this._cullableComps = [];
        // 动画骨骼同步
        _this._linkEntity = null;
        _this._linkBoneEntity = null;
        _this._raw = _raw;
        _this._rawU32 = _u32View;
        _this._offset = offset;
        _this.localRotationTypeOffset = _this._offset + entity3D_1.default.OFFSET_ROTATIONTYPE;
        _this.localQuaternionOffset = _this._offset + entity3D_1.default.OFFSET_ROTATION;
        _this.localPositionOffset = _this._offset + entity3D_1.default.OFFSET_POSITION;
        _this.localScaleOffset = _this._offset + entity3D_1.default.OFFSET_SCALE;
        _this.worldMatrixOffset = _this._offset + entity3D_1.default.OFFSET_WORLDMATRIX;
        return _this;
    }
    Object.defineProperty(Entity3D_S.prototype, "localPosition", {
        /*
         * Mock
         */
        get: function () {
            if (!this._localPosition) {
                this._localPosition = vector3_1.default.createFromTypedArray(this._raw, this.localPositionOffset);
            }
            return this._localPosition;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Entity3D_S.prototype, "localQuaternion", {
        get: function () {
            if (!this._localQuaternion) {
                this._localQuaternion = new quaternion_1.default(this._raw, this.localQuaternionOffset);
            }
            return this._localQuaternion;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Entity3D_S.prototype, "localScale", {
        get: function () {
            if (!this._localScale) {
                this._localScale = vector3_1.default.createFromTypedArray(this._raw, this.localScaleOffset);
            }
            return this._localScale;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Entity3D_S.prototype, "worldMatrix", {
        get: function () {
            if (!this._worldMatrix) {
                this._worldMatrix = matrix4_1.default.createFromTypedArray(this._raw, this.worldMatrixOffset);
            }
            return this._worldMatrix;
        },
        enumerable: false,
        configurable: true
    });
    // 确保该节点的worldTransform正确
    // 从该节点向上遍历到根节点，再回溯回来
    Entity3D_S.prototype._refreshWorldTransform = function () {
        var parent = this.parent;
        if (parent) {
            parent._refreshWorldTransform();
        }
        // 回溯
        var isLocalDirty = this._culLocalTransform();
        if (parent) {
            parent.worldMatrix.multiply(this._localMatrix, this.worldMatrix);
        }
        else {
            this.worldMatrix._raw.set(this._localMatrix._raw, this.worldMatrix._offset);
        }
        this._isWorldMatrixDirty = true;
    };
    Entity3D_S.prototype._computeWorldMatrixRecursive = function (parentDirty) {
        var isLocalDirty = this._culLocalTransform();
        var thisDirty = parentDirty || isLocalDirty;
        if (thisDirty) {
            var parent = this.parent;
            if (parent) {
                parent.worldMatrix.multiply(this._localMatrix, this.worldMatrix);
            }
            else {
                this.worldMatrix._raw.set(this._localMatrix._raw, this.worldMatrix._offset);
            }
            if (this._linkEntity) {
                this._SyncTransform();
            }
            this._isWorldMatrixDirty = true;
        }
        for (var _i = 0, _a = this.children; _i < _a.length; _i++) {
            var child = _a[_i];
            if (child.active) {
                child._computeWorldMatrixRecursive(thisDirty);
            }
        }
    };
    Entity3D_S.prototype._culLocalTransform = function () {
        var isLocalDirty = this._isLocalMatrixDirty;
        if (isLocalDirty) {
            if (this.isUsingEuler()) {
                // 欧拉角
                // const pos = this._localPosition;
                // const rot = this._localEuler;
                // const scale = this._localScale;
                // const rotM = Matrix4.IDENTITY;
                // rotM.yRotate(rot.y, rotM).xRotate(rot.x, rotM).zRotate(rot.z, rotM);
                // Matrix4.composeTRS(pos, rotM,scale,this._localMatrix);
                // Matrix4.IDENTITY.translate(pos.x, pos.y, pos.z, this._localMatrix)
                //   .yRotate(rot.y, this._localMatrix).xRotate(rot.x, this._localMatrix).zRotate(rot.z, this._localMatrix)
                //   .scale(scale.x, scale.y, scale.z, this._localMatrix);
            }
            else {
                // 四元数
                var pos = this.localPosition;
                var rot = this.localQuaternion;
                var scale = this.localScale;
                matrix4_1.default.composeTQS(pos, rot, scale, this._localMatrix);
            }
            // 清除标记位
            this._isLocalMatrixDirty = false;
        }
        return isLocalDirty;
    };
    Entity3D_S.prototype._SyncTransform = function () {
        var mat = this.worldMatrix;
        var translate = vector3_1.default.ZERO;
        var scale = vector3_1.default.ZERO;
        var rotatioMatrix = matrix4_1.default.IDENTITY;
        mat.decomposeTransRotMatScale(translate, rotatioMatrix, scale);
        if (this._linkEntity) {
            this._linkEntity.localPosition.set(translate);
            this._linkEntity.localScale.set(scale);
            var quaternion = quaternion_1.default.createFromMatrix4(rotatioMatrix);
            if (this._linkEntity.isUsingEuler()) {
                // 欧拉角
                // const euler = quaternion.toEuler();
                // this._linkEntity._localEuler.set(euler);
            }
            else {
                // 四元数
                this._linkEntity.localQuaternion.set(quaternion);
            }
            this._linkEntity._isLocalMatrixDirty = true;
        }
    };
    /*
      interfaces
    */
    Entity3D_S.prototype.setUsingEuler = function (on) {
        if (on) {
            this._rawU32[this.localRotationTypeOffset] &= ~entity3D_1.default.DF_ROTATIONTYPE;
        }
        else {
            this._rawU32[this.localRotationTypeOffset] |= entity3D_1.default.DF_ROTATIONTYPE;
        }
    };
    Entity3D_S.prototype.isUsingEuler = function () {
        return (this._rawU32[this.localRotationTypeOffset] & entity3D_1.default.DF_ROTATIONTYPE) != 0 ? false : true;
    };
    return Entity3D_S;
}(entity_1.default));
exports.default = Entity3D_S;


/***/ }),
/* 70 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
/*
 * @Author: roamye
 * @Date: 2020-05-06 21:10:52
 * @Last Modified by: roamye
 * @Last Modified time: 2020-05-08 23:08:50
 */
var entity2D_1 = tslib_1.__importDefault(__webpack_require__(67));
var entityGroup_1 = tslib_1.__importDefault(__webpack_require__(71));
var Entity2DGroup_S = /** @class */ (function (_super) {
    tslib_1.__extends(Entity2DGroup_S, _super);
    function Entity2DGroup_S(entity2DGroup) {
        var _this = _super.call(this, entity2DGroup) || this;
        _this.entitis = [];
        for (var i = 0; i < entity2DGroup.entityLength; i++) {
            var entityMock = new entity2D_1.default(entity2DGroup._f32view, entity2DGroup._u32view, i * entity2DGroup.objectSize);
            _this.entitis.push(entityMock);
        }
        return _this;
    }
    return Entity2DGroup_S;
}(entityGroup_1.default));
exports.default = Entity2DGroup_S;


/***/ }),
/* 71 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var EntityGroup_S = /** @class */ (function () {
    function EntityGroup_S(entityGroup) {
        this.entitis = [];
    }
    EntityGroup_S.prototype.setLocalMatrixDirtyAll = function () {
        for (var i = 0; i < this.entitis.length; i++) {
            var entityMock = this.entitis.length[i];
            entityMock.setLocalMatrixDirty();
        }
    };
    return EntityGroup_S;
}());
exports.default = EntityGroup_S;


/***/ }),
/* 72 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
/*
 * @Author: roamye
 * @Date: 2020-05-06 21:10:52
 * @Last Modified by: roamye
 * @Last Modified time: 2020-05-08 23:09:38
 */
var entity3D_1 = tslib_1.__importDefault(__webpack_require__(69));
var entityGroup_1 = tslib_1.__importDefault(__webpack_require__(71));
var Entity3DGroup_S = /** @class */ (function (_super) {
    tslib_1.__extends(Entity3DGroup_S, _super);
    function Entity3DGroup_S(entity3DGroup) {
        var _this = _super.call(this, entity3DGroup) || this;
        _this.entitis = [];
        for (var i = 0; i < entity3DGroup.entityLength; i++) {
            var entityMock = new entity3D_1.default(entity3DGroup._f32view, entity3DGroup._u32view, i * entity3DGroup.objectSize);
            _this.entitis.push(entityMock);
        }
        return _this;
    }
    return Entity3DGroup_S;
}(entityGroup_1.default));
exports.default = Entity3DGroup_S;


/***/ }),
/* 73 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var AnimatorComponent_S = /** @class */ (function () {
    function AnimatorComponent_S() {
        this._animationClipCount = 0;
        this._nodeCount = 0;
        this._animationClipModels = [];
        this._frameIndexs = [];
        this._blendWeight = [];
        this._entityIds = {};
    }
    // 重载过程方法
    AnimatorComponent_S.prototype._getNeedMemorySize = function () {
        return 4 * this.nodeCount * this.animationClipCount;
    };
    Object.defineProperty(AnimatorComponent_S.prototype, "animationClipCount", {
        get: function () {
            return this._animationClipCount;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(AnimatorComponent_S.prototype, "nodeCount", {
        get: function () {
            return this._nodeCount;
        },
        enumerable: false,
        configurable: true
    });
    AnimatorComponent_S.prototype.getAnimationParamater = function (index) {
        return {
            animationClipId: this._animationClipModels[index].id,
            frameIndex: this._frameIndexs[index],
            percentage: this._blendWeight[index],
        };
    };
    AnimatorComponent_S.prototype.bindAnimations = function (animationClipModels, entitys, rootEntity) {
        this._entityIds = {};
        this._animationClipModels = animationClipModels;
        this._frameIndexs = new Array(animationClipModels.length);
        this._blendWeight = new Array(animationClipModels.length);
        // 运算节点数量
        var nodesLength = entitys.length;
        for (var i in entitys) {
            nodesLength += entitys[i].length;
        }
        this._animationClipCount = animationClipModels.length;
        this._nodeCount = nodesLength;
        var nodeSum = 0;
        var existEntity;
        for (var i = 0; i < entitys.length; i++) {
            for (var j = 0; j < entitys[i].length; j++) {
                // this._u32view[nodeSum + j] = (entitys[i][j] != null) ? entitys[i][j].id : 4294967295;
                if (entitys[i][j]) {
                    this._entityIds[nodeSum + j] = entitys[i][j];
                    if (!existEntity) {
                        existEntity = entitys[i][j];
                    }
                }
            }
            nodeSum += entitys[i].length;
        }
        if (rootEntity != undefined && rootEntity.id) {
            this.culEntity3DTreeNode = rootEntity;
        }
        else {
            if (existEntity) {
                this.culEntity3DTreeNode = existEntity;
            }
        }
    };
    AnimatorComponent_S.prototype.setClipParams = function (index, frameIndex, blendWeight) {
        this._frameIndexs[index] = frameIndex;
        this._blendWeight[index] = blendWeight;
    };
    AnimatorComponent_S.prototype.getEntity = function (index) {
        return this._entityIds[index];
    };
    return AnimatorComponent_S;
}());
exports.default = AnimatorComponent_S;


/***/ }),
/* 74 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
/*
 * @Author: bluecatliao
 * @Date: 2018-11-21 14:33:22
 * @Last Modified by: roamye
 * @Last Modified time: 2020-05-08 17:49:46
 * 变长部分布局为:BoneInverseModelId|BoneNum|BoneIndices(BoneNum*1)|BoneEntityIds(BoneNum*1)|BoneOutputMatrix(BoneNum*16)
 */
var matrix4_1 = tslib_1.__importDefault(__webpack_require__(44));
var SkinnedSkeletonComponent_S = /** @class */ (function () {
    function SkinnedSkeletonComponent_S() {
        this._boneInverseModelId = 0;
        this._boneNum = 0;
    }
    // 重载过程方法
    SkinnedSkeletonComponent_S.prototype._getNeedMemorySize = function () {
        return 4 * (this._boneNum * 18);
    };
    /*
      interfaces
    */
    SkinnedSkeletonComponent_S.prototype.setBoneMatrix = function (boneInverseModel, boneNum, boneIndices, boneEntities) {
        if (boneIndices.length !== boneNum || boneEntities.length !== boneNum) {
            console.warn("setBoneMatrix Error");
            return;
        }
        this._boneInverseModelId = boneInverseModel.id;
        this._boneNum = boneNum;
        this.boneIndices = boneIndices;
        this.boneEntities = boneEntities;
        // boneOffsetMatrices buffer初始化
        var _buffer = new ArrayBuffer(this._getNeedMemorySize());
        this.outputBoneInverseMatrixs = new Array(boneNum);
        for (var i = 0; i < boneNum; i++) {
            var f32view = new Float32Array(_buffer, boneNum * 2 * 4 + 64 * i, 16);
            this.outputBoneInverseMatrixs[i] = matrix4_1.default.createFromTypedArray(f32view);
        }
        this._boneOffsetMatrices = new Float32Array(_buffer, this._boneNum * 2 * 4, this._boneNum * 16);
    };
    SkinnedSkeletonComponent_S.prototype.getBoneNum = function () {
        return this._boneNum;
    };
    SkinnedSkeletonComponent_S.prototype.getBoneInverseModelId = function () {
        return this._boneInverseModelId;
    };
    SkinnedSkeletonComponent_S.prototype.getBoneIndices = function (index) {
        return this.boneIndices[index];
    };
    SkinnedSkeletonComponent_S.prototype.getBoneEntity = function (index) {
        return this.boneEntities[index];
    };
    SkinnedSkeletonComponent_S.prototype.getBoneOffsetMatrices = function () {
        return this._boneOffsetMatrices;
    };
    return SkinnedSkeletonComponent_S;
}());
exports.default = SkinnedSkeletonComponent_S;


/***/ }),
/* 75 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var CullableComponent_S = /** @class */ (function () {
    function CullableComponent_S(comp) {
        this.entity = null;
        this._componetModel = comp;
    }
    CullableComponent_S.prototype.destroy = function () {
        // 异步销毁
        if (!this.entity) {
            return;
        }
        var entity = this.entity;
        var index = entity.components.indexOf(this);
        if (index > -1) {
            entity.components.splice(index, 1);
            this._onDestroy();
        }
    };
    // life cycle
    CullableComponent_S.prototype._onAdd = function () {
        this.entity._cullableComps.push(this);
    };
    CullableComponent_S.prototype._onDestroy = function () {
        if (this.entity) {
            var comps = this.entity._cullableComps;
            var componentIndex = comps.indexOf(this);
            if (componentIndex !== -1) {
                comps.splice(componentIndex, 1);
            }
        }
    };
    Object.defineProperty(CullableComponent_S.prototype, "active", {
        /*
          interfaces
        */
        get: function () {
            return this._componetModel.getActive();
        },
        set: function (val) {
            this._componetModel.setActive(val);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(CullableComponent_S.prototype, "cullMask", {
        get: function () {
            return this._componetModel.getCullMask();
        },
        set: function (val) {
            this._componetModel.setCullMask(val);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(CullableComponent_S.prototype, "boundingBallCenter", {
        get: function () {
            return this._componetModel.getBoundingBallCenter();
        },
        set: function (val) {
            this._componetModel.setBoundingBallCenter(val);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(CullableComponent_S.prototype, "boundingBallRadius", {
        get: function () {
            return this._componetModel.getBoundingBallRadius();
        },
        set: function (val) {
            this._componetModel.setBoundingBallRadius(val);
        },
        enumerable: false,
        configurable: true
    });
    CullableComponent_S.prototype.bindEntity = function (entity) {
        this.entity = entity;
        this.entity.bindComponet(this);
    };
    CullableComponent_S.prototype.unbindEntity = function () {
        this.entity.unbindComponent(this);
    };
    return CullableComponent_S;
}());
exports.default = CullableComponent_S;


/***/ }),
/* 76 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var matrix4_1 = tslib_1.__importDefault(__webpack_require__(44));
var vector3_1 = tslib_1.__importDefault(__webpack_require__(45));
var quaternion_1 = tslib_1.__importDefault(__webpack_require__(61));
var proxy = function (target, propertyKey) {
    Object.defineProperty(target, propertyKey, {
        get: function () { return this._phys3D[propertyKey]; },
        set: function () { }
    });
};
function isFloatEqual(f1, f2, digits) {
    if (digits === void 0) { digits = 0.00001; }
    return Math.abs(f1 - f2) < digits;
}
var PhysicsManager = /** @class */ (function () {
    function PhysicsManager(phys3D, ga, isEngineNative) {
        this._reverseBindMap = new WeakMap();
        this._bindMap = new WeakMap();
        this._colliderToEntityMap = new WeakMap();
        this._ccReverseBindMap = new WeakMap();
        this._ccbindMap = new WeakMap();
        /**
         * entity的scale变化之后需要同步到物理引擎，该map用来遍历重置物理的scale
         */
        this._colliderSet = new Set();
        this._phys3D = phys3D;
        this._ga = ga;
        this._isNative = isEngineNative;
        if (!this._isNative) {
            this._mock = ga._getMockAccelerateWorker();
        }
        // @ts-ignore
        // window.PhysicsManager = this;
    }
    PhysicsManager.prototype.clear = function () {
        this._reverseBindMap = new WeakMap();
        this._bindMap = new WeakMap();
        this._colliderToEntityMap = new WeakMap();
        this._ccReverseBindMap = new WeakMap();
        this._ccbindMap = new WeakMap();
        this._colliderSet.clear();
    };
    /**
     * 将物理层的RigidBody和引擎(native和mock)形成绑定关系
     */
    PhysicsManager.prototype.bindRigidbodyToEntity = function (rigidbody, entity, name) {
        if (this._isNative) {
            // @ts-ignore
            rigidbody.AttachToEntity(entity._nativePool._nativeObj, entity._nativeId);
        }
        else {
            var mockEntity = this._mock.entity2mock.get(entity);
            this._bindMap.set(rigidbody, mockEntity);
            this._reverseBindMap.set(mockEntity, rigidbody);
            // this._alignRigidbodyWithEntity(rigidbody, mockEntity);
        }
    };
    /**
     * 将物理层的Collider和引擎(native和mock)形成绑定关系
     */
    PhysicsManager.prototype.bindColliderToEntity = function (collider, entity) {
        if (!this._isNative) {
            var mockEntity = this._mock.entity2mock.get(entity);
            this._colliderToEntityMap.set(collider, mockEntity);
            this._colliderSet.add(collider);
        }
    };
    /**
     * 将物理层的CharacterController和引擎(native和mock)形成绑定关系
     */
    PhysicsManager.prototype.bindCCToEntity = function (cc, entity) {
        if (this._isNative) {
            // @ts-ignore
            cc.AttachToEntity(entity._nativePool._nativeObj, entity._nativeId);
        }
        else {
            var mockEntity = this._mock.entity2mock.get(entity);
            this._ccbindMap.set(cc, mockEntity);
            this._ccReverseBindMap.set(mockEntity, cc);
            /**
             * 这里和rigidbody逻辑不一样的是，rigidbody每一次simulation都会更新位置和旋转信息到渲染层，
             * cc在创建的时候需要手动更新一次
             */
            this._alignCCWithEntity(cc, mockEntity);
        }
    };
    PhysicsManager.prototype.unbindCCT = function (cc) {
        if (!this._isNative) {
            var entity = this._ccbindMap.get(cc);
            if (entity) {
                this._ccReverseBindMap.delete(entity);
            }
            this._ccbindMap.delete(cc);
        }
    };
    /**
     * 将entity在渲染层的信息同步到物理层的CharacterController
     */
    PhysicsManager.prototype._alignCCWithEntity = function (cc, entity) {
        var mat = entity.worldMatrix;
        var translate = vector3_1.default.ZERO;
        var scale = vector3_1.default.ZERO;
        var rotationMatrix = matrix4_1.default.IDENTITY;
        mat.decomposeTransRotMatScale(translate, rotationMatrix, scale);
        var quaternion = quaternion_1.default.createFromMatrix4(rotationMatrix);
        // 客户端会自动处理center逻辑，因此只需要将渲染位置直接传递给物理层即可
        cc.position = new this._phys3D.RawVec3f(translate.x, translate.y, translate.z);
    };
    /**
     * 将entity在渲染层的信息同步到物理层的Rigidbody
     */
    PhysicsManager.prototype._alignRigidbodyWithEntity = function (rigidbody, entity) {
        var mat = entity.worldMatrix;
        var translate = vector3_1.default.ZERO;
        var scale = vector3_1.default.ZERO;
        var rotationMatrix = matrix4_1.default.IDENTITY;
        mat.decomposeTransRotMatScale(translate, rotationMatrix, scale);
        var quaternion = quaternion_1.default.createFromMatrix4(rotationMatrix);
        rigidbody.position = new this._phys3D.RawVec3f(translate.x, translate.y, translate.z);
        rigidbody.rotation = new this._phys3D.RawQuaternion(quaternion.x, quaternion.y, quaternion.z, quaternion.w);
    };
    PhysicsManager.prototype.alignRigidbodyWithEntity = function (rigidbody, entity) {
        var mockEntity = this._mock.entity2mock.get(entity);
        this._alignRigidbodyWithEntity(rigidbody, mockEntity);
    };
    PhysicsManager.prototype.unbindRigidbody = function (rigidbody) {
        if (this._isNative) {
            rigidbody.Detach();
        }
        else {
            var entity = this._bindMap.get(rigidbody);
            if (entity) {
                this._reverseBindMap.delete(entity);
            }
            this._bindMap.delete(rigidbody);
        }
    };
    PhysicsManager.prototype.unbindCollider = function (collider) {
        if (!this._isNative) {
            this._colliderSet.delete(collider);
            this._colliderToEntityMap.delete(collider);
        }
    };
    /**
     * 从entity同步到物理世界
     */
    PhysicsManager.prototype._syncForward = function () {
        // this._mock._getEntitySystem().root3D._computeWorldMatrixRecursive(false);
        // 这一步要在recursivelySyncForwardEntity之前，不可交换顺序
        this.syncEntityScaleToPhysic();
        this.recursivelySyncForwardEntity(this._mock._getEntitySystem().root3D);
    };
    /**
     * 渲染scale同步到物理scale逻辑
     */
    PhysicsManager.prototype.syncEntityScaleToPhysic = function () {
        var _this = this;
        this._colliderSet.forEach(function (collider) {
            var entity = _this._colliderToEntityMap.get(collider);
            // 脏位还没用完，不能重置
            if (entity._isWorldMatrixDirty) {
                var mat = entity.worldMatrix;
                var translate = vector3_1.default.ZERO;
                var scale = vector3_1.default.ZERO;
                var rotationMatrix = matrix4_1.default.IDENTITY;
                mat.decomposeTransRotMatScale(translate, rotationMatrix, scale);
                var pScale = collider.scale;
                // 判断出entity的scale真的发生了scale转换再来重置物理层的scale
                if (!isFloatEqual(pScale.x, scale.x) || !isFloatEqual(pScale.y, scale.y) || !isFloatEqual(pScale.z, scale.z)) {
                    collider.scale = new _this._phys3D.RawVec3f(scale.x, scale.y, scale.z);
                }
            }
        });
    };
    // 从渲染同步到物理
    PhysicsManager.prototype.recursivelySyncForwardEntity = function (entity) {
        var _this = this;
        if (entity._isWorldMatrixDirty) {
            var cc = this._ccReverseBindMap.get(entity);
            var rigidbody = this._reverseBindMap.get(entity);
            if (cc) {
                this._alignCCWithEntity(cc, entity);
            }
            if (rigidbody) {
                this._alignRigidbodyWithEntity(rigidbody, entity);
            }
            entity._isWorldMatrixDirty = false;
        }
        entity.children.forEach(function (child) {
            _this.recursivelySyncForwardEntity(child);
        });
    };
    /**
     * 从物理世界同步到entity
     */
    PhysicsManager.prototype._syncBack = function () {
        this.recursivelySyncBackEntity(this._mock._getEntitySystem().root3D, false);
    };
    /**
     * 调用了move逻辑之后，调用此函数将物理层CharacterController同步到渲染层
     */
    PhysicsManager.prototype.recursivelySyncCCBackEntity = function (entity, dirty) {
        var _this = this;
        if (dirty === void 0) { dirty = false; }
        if (this._isNative) {
            return;
        }
        var mockEntity = this._mock.entity2mock.get(entity);
        var cc = this._ccReverseBindMap.get(mockEntity);
        if (cc) {
            var position = cc.position;
            var center = cc.center;
            var pw = mockEntity.parent ? mockEntity.parent.worldMatrix : matrix4_1.default.IDENTITY;
            // 渲染的实际位置为物理位置减去center的值
            var cp = vector3_1.default.createFromNumber(position.x, position.y, position.z);
            // const cp = Vector3.createFromNumber(position.x - center.x, position.y - center.y, position.z - center.z);
            var cr = mockEntity.localQuaternion;
            var cw = matrix4_1.default.composeTQS(cp, cr, mockEntity.localScale);
            var cl = pw.inverse().multiply(cw);
            var rm = matrix4_1.default.IDENTITY;
            cl.decomposeTransRotMatScale(mockEntity.localPosition, rm, vector3_1.default.ONE);
            var q = quaternion_1.default.createFromMatrix4(rm);
            mockEntity.localQuaternion.set(q);
            mockEntity.worldMatrix.set(cw);
            matrix4_1.default.composeTQS(mockEntity.localPosition, mockEntity.localQuaternion, mockEntity.localScale, mockEntity._localMatrix);
            dirty = true;
        }
        else if (dirty) {
            var pw = mockEntity.parent ? mockEntity.parent.worldMatrix : matrix4_1.default.IDENTITY;
            mockEntity.worldMatrix.set(pw.multiply(mockEntity._localMatrix));
        }
        mockEntity.children.forEach(function (child) {
            _this.recursivelySyncBackEntity(child, dirty);
        });
    };
    /**
     * 每一次simulate递归地将物理层的位置同步到渲染层
     */
    PhysicsManager.prototype.recursivelySyncBackEntity = function (entity, dirty) {
        var _this = this;
        var rigidbody = this._reverseBindMap.get(entity);
        if (rigidbody) {
            var pw = entity.parent ? entity.parent.worldMatrix : matrix4_1.default.IDENTITY;
            var cp = vector3_1.default.createFromNumber(rigidbody.position.x, rigidbody.position.y, rigidbody.position.z);
            var cr = quaternion_1.default.createFromNumber(rigidbody.rotation.x, rigidbody.rotation.y, rigidbody.rotation.z, rigidbody.rotation.w);
            var cw = matrix4_1.default.composeTQS(cp, cr, entity.localScale);
            var cl = pw.inverse().multiply(cw);
            var rm = matrix4_1.default.IDENTITY;
            cl.decomposeTransRotMatScale(entity.localPosition, rm, vector3_1.default.ONE);
            var q = quaternion_1.default.createFromMatrix4(rm);
            entity.localQuaternion.set(q);
            entity.worldMatrix.set(cw);
            matrix4_1.default.composeTQS(entity.localPosition, entity.localQuaternion, entity.localScale, entity._localMatrix);
            dirty = true;
        }
        else if (dirty) {
            var pw = entity.parent ? entity.parent.worldMatrix : matrix4_1.default.IDENTITY;
            entity.worldMatrix.set(pw.multiply(entity._localMatrix));
        }
        entity._isWorldMatrixDirty = false;
        entity._isLocalMatrixDirty = false;
        entity.children.forEach(function (child) {
            _this.recursivelySyncBackEntity(child, dirty);
        });
    };
    Object.defineProperty(PhysicsManager.prototype, "PhysSystem", {
        get: function () {
            var that = this;
            return function (physicsDebugConfig) {
                var p;
                // 没有传physicsDebugConfig不要将null或者undefined透传给客户端，会crash
                if (physicsDebugConfig) {
                    // console.log('physicsDebugConfig', physicsDebugConfig)
                    p = new that._phys3D.PhysSystem(physicsDebugConfig);
                }
                else {
                    p = new that._phys3D.PhysSystem();
                }
                if (!that._isNative) {
                    p._Simulate = p.Simulate;
                    p.Simulate = function (dt) {
                        that._syncForward();
                        p._Simulate(dt);
                        that._syncBack();
                    };
                }
                return p;
            };
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(PhysicsManager.prototype, "DynamicRigidbody", {
        get: function () {
            var that = this;
            return function (sys) {
                var r = new that._phys3D.DynamicRigidbody(sys);
                if (!that._isNative) {
                    r._isAttached = r.isAttached;
                    r.isAttached = function () {
                        return that._bindMap.has(r);
                    };
                }
                return r;
            };
        },
        enumerable: false,
        configurable: true
    });
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "RawVec3f", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "RawVec2f", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "PhysMesh", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "Collider", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "MeshCollider", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "CombineMode", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "Material", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "CapsuleCollider", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "Joint", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "ContactPoint", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "Collision", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "SphereCollider", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "Bounds", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "StaticRigidbody", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "RawQuaternion", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "BoxCollider", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "RaycastHit", void 0);
    tslib_1.__decorate([
        proxy
    ], PhysicsManager.prototype, "CharacterController", void 0);
    return PhysicsManager;
}());
exports.default = PhysicsManager;


/***/ }),
/* 77 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
/**
 * 仅在工具环境下起作用
 * 获取mock的物理引擎(node addon)
 */
var nodeRequire_1 = tslib_1.__importDefault(__webpack_require__(78));
var physicsNodeInstance;
function default_1() {
    if (physicsNodeInstance) {
        return physicsNodeInstance;
    }
    var nodeInstance = nodeRequire_1.default('phye');
    if (nodeInstance && nodeInstance.Phys3D) {
        physicsNodeInstance = nodeInstance;
    }
    else {
        // engineNativeError();
    }
    return physicsNodeInstance;
}
exports.default = default_1;
;


/***/ }),
/* 78 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/**
 * 仅在工具环境下起作用
 * 获取mock的物理引擎(node addon)
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.pid = void 0;
var PUBLIKEY = "-----BEGIN PUBLIC KEY-----\nMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCIfocuCk0FdG9zN9C6GqhJRVNG\n1FbJa8aUAZDawoCcwowIc/zMHRCl3srHUOQi3fjZpSObiVbvLidlWDSOw/rdBxbU\nG/4BqJFuIUQziCnqdRiCyYV2w9Z29/qNcKbr1gxmqXVgo0WRbkKlIFKGvSXFiVM3\nn49RQm2mgWsvqXn2vQIDAQAB\n-----END PUBLIC KEY-----";
var nodeRequire = null;
var nodeFs = null;
exports.pid = 0;
/**
 * 持有require句柄
 */
var alreadyRewrite = false;
function rewriteRequire() {
    if (alreadyRewrite) {
        return;
    }
    alreadyRewrite = true;
    // 获取node层require
    // @ts-ignore
    if (window.__global && window.__global.require) {
        try {
            // @ts-ignore
            nodeRequire = window.__global.require;
            // @ts-ignore
            delete window.__global.require; // 清除，不能被外部调用node的require能力
            // @ts-ignore
            nodeFs = nodeRequire('fs');
            if (!nodeFs || !nodeFs.readFileSync) {
                throw new Error();
            }
            exports.pid = nodeRequire('process').pid;
        }
        catch (error) { // 没有开启底层加速 
            nodeFs = null;
            nodeRequire = null;
            // engineNativeError();
        }
    }
}
/**
 * 获取文件md5
 * @param filePath
 */
function getFileMd5(filePath) {
    var buffer = nodeFs.readFileSync(filePath);
    var crypto = nodeRequire('crypto');
    var md5sum = crypto.createHash('md5');
    md5sum.update(buffer);
    var md5 = md5sum.digest('hex');
    return md5;
}
/**
 * 校验签名
 * @param origin
 * @param signature
 */
function verifySignature(origin, signature) {
    // @ts-ignore
    var buf = window.Buffer.from(signature, 'base64');
    var crypto = nodeRequire('crypto');
    var verify = crypto.createVerify('RSA-SHA1');
    verify.update(origin);
    if (verify.verify(PUBLIKEY, buf)) {
        return true;
    }
    return false;
}
/**
 * 检查文件签名
 * @param filePath
 * @param signature
 */
function checkFileSignature(filePath, signature) {
    if (!signature) {
        return false;
    }
    var md5 = getFileMd5(filePath);
    return verifySignature(md5, signature);
}
/**
 * 检测md5
 * @param filePath
 * @param distMd5
 */
function checkFileMd5(filePath, distMd5) {
    if (!distMd5) {
        return false;
    }
    var md5 = getFileMd5(filePath);
    return md5 === distMd5;
}
/**
 * 包装后的require
 * @param mod
 */
function myRequire(mod) {
    if (!nodeRequire) { // 没有node require模块
        // engineNativeError();
        return null;
    }
    // @ts-ignore
    var runtimeLibConfigPath;
    var isDev = false;
    // @ts-ignore
    var devtoolsConfig = window.__devtoolsConfig || window.top.__devtoolsConfig || {};
    if (devtoolsConfig.__runtimeLibConfigPath) {
        runtimeLibConfigPath = devtoolsConfig.__runtimeLibConfigPath;
        isDev = devtoolsConfig.appConfig.isDev;
    }
    if (!runtimeLibConfigPath) {
        throw new Error('cannot find runtimeLibConfigPath');
    }
    var libConfigMap = nodeRequire(runtimeLibConfigPath);
    if (!libConfigMap) {
        throw new Error('connot find lib config');
    }
    // 非法模块
    if (!Object.keys(libConfigMap).includes(mod)) {
        throw new Error('the mod cannot be require');
    }
    var _a = libConfigMap[mod], filePath = _a.path, signature = _a.signature, distMd5 = _a.distMd5;
    // 非dev环境要验证
    if (!isDev) {
        var success = false;
        if (signature) {
            success = checkFileSignature(filePath, signature); // 签名校验
        }
        else if (distMd5) {
            success = checkFileMd5(filePath, distMd5);
        }
        if (!success) {
            throw new Error('node addon is not safe!');
        }
    }
    var nodeInstance = nodeRequire(filePath);
    return nodeInstance;
}
function default_1(moduleName) {
    console.log('require module: ' + moduleName);
    rewriteRequire();
    return myRequire(moduleName);
}
exports.default = default_1;
;


/***/ }),
/* 79 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.nativeValue2Native = void 0;
exports.nativeValue2Native = new WeakMap();
var NativeValue = /** @class */ (function () {
    function NativeValue(native) {
        this._native = native;
        this.data = this._native.data;
        exports.nativeValue2Native.set(this, native);
    }
    return NativeValue;
}());
exports.default = NativeValue;


/***/ }),
/* 80 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = __webpack_require__(1);
var commandBuffer_1 = tslib_1.__importDefault(__webpack_require__(81));
var commandBuffer_2 = tslib_1.__importDefault(__webpack_require__(87));
var rect_1 = tslib_1.__importStar(__webpack_require__(89));
var renderDraw_1 = tslib_1.__importDefault(__webpack_require__(82));
var renderDraw_2 = tslib_1.__importDefault(__webpack_require__(88));
var renderView_1 = tslib_1.__importDefault(__webpack_require__(83));
var vertexLayout_1 = tslib_1.__importStar(__webpack_require__(84));
var batchableVertexBuffer_1 = tslib_1.__importDefault(__webpack_require__(85));
var batchableIndexBuffer_1 = tslib_1.__importDefault(__webpack_require__(86));
var Renderer = /** @class */ (function () {
    function Renderer(native, config) {
        this._native = native;
        if (config.isRenderNative) {
            this.createRenderDraw = this.createRenderDrawAccelerate.bind(this);
            this.createCommandBuffer = this.createCommandBufferAccelerate.bind(this);
        }
        else {
            this.createRenderDraw = this.createRenderDrawLocal.bind(this);
            this.createCommandBuffer = this.createCommandBufferLocal.bind(this);
        }
    }
    Renderer.prototype.createCommandBufferAccelerate = function (defaultRenderDrawCount, defaultSubCommandBufferCount) {
        return new commandBuffer_2.default(this._native, defaultRenderDrawCount, defaultSubCommandBufferCount);
    };
    Renderer.prototype.createCommandBufferLocal = function () {
        var native = this._native.createCommandBuffer();
        return new commandBuffer_1.default(native);
    };
    Renderer.prototype.createRect = function (x, y, width, height) {
        var native = this._native.createRect(x, y, width, height);
        return new rect_1.default(native);
    };
    Renderer.prototype.createRenderDrawLocal = function () {
        var native = this._native.createRenderDraw();
        return new renderDraw_1.default(native);
    };
    Renderer.prototype.createRenderDrawAccelerate = function () {
        var native = this._native.createRenderDraw();
        return new renderDraw_2.default(native);
    };
    Renderer.prototype.createVertexLayout = function (config) {
        var native = this._native.createVertexLayout(JSON.stringify(config));
        return new vertexLayout_1.default(native);
    };
    Renderer.prototype.createRenderView = function (pass, passAction, viewport, scissor) {
        var passObj = pass ? pass : 0;
        var native = this._native.createView(passObj, passAction, rect_1.rect2Native.get(viewport), rect_1.rect2Native.get(scissor));
        return new renderView_1.default(native);
    };
    Renderer.prototype.createBatchableVertexBuffer = function (count, vertexLayout) {
        var native = this._native.createBatchableVertexBuffer(count, vertexLayout_1.vertexLayout2Native.get(vertexLayout));
        return new batchableVertexBuffer_1.default(native);
    };
    Renderer.prototype.createBatchableIndexBuffer = function (count) {
        var native = this._native.createBatchableIndexBuffer(count);
        return new batchableIndexBuffer_1.default(native);
    };
    return Renderer;
}());
exports.default = Renderer;


/***/ }),
/* 81 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.commandBuffer2Native = void 0;
var renderDraw_1 = __webpack_require__(82);
exports.commandBuffer2Native = new WeakMap();
var CommandBuffer = /** @class */ (function () {
    function CommandBuffer(native) {
        this._native = native;
        exports.commandBuffer2Native.set(this, native);
    }
    CommandBuffer.prototype.putRenderDraw = function (renderDraw) {
        this._native.putRenderDraw(renderDraw_1.renderDraw2Native.get(renderDraw));
    };
    CommandBuffer.prototype.batchPutRenderDraw = function (renderDraws, len) {
        len = (len !== undefined) ? len : renderDraws.length;
        for (var i = 0; i < len; i++) {
            var renderDraw = renderDraws[i];
            this._native.putRenderDraw(renderDraw_1.renderDraw2Native.get(renderDraw));
        }
    };
    CommandBuffer.prototype.putSubCommandBuffer = function (commandBuffer) {
        this._native.putSubCommandBuffer(commandBuffer._native);
    };
    CommandBuffer.prototype.reset = function () {
        this._native.reset();
    };
    CommandBuffer.prototype.execute = function () {
        this._native.execute();
    };
    return CommandBuffer;
}());
exports.default = CommandBuffer;


/***/ }),
/* 82 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.renderDraw2Native = void 0;
var tslib_1 = __webpack_require__(1);
var nativeValue_1 = __webpack_require__(79);
var renderDrawEncodeDefines_1 = tslib_1.__importDefault(__webpack_require__(18));
var renderView_1 = __webpack_require__(83);
var vertexLayout_1 = __webpack_require__(84);
var batchableVertexBuffer_1 = __webpack_require__(85);
var batchableIndexBuffer_1 = __webpack_require__(86);
exports.renderDraw2Native = new WeakMap();
var renderViewDefaultStatus = {
    raster: renderDrawEncodeDefines_1.default.WRITE_SET(wgfx.EnumIndexType.UINT16, renderDrawEncodeDefines_1.default.INDEX_TYPE_MASK, renderDrawEncodeDefines_1.default.INDEX_TYPE_SHIFT) |
        renderDrawEncodeDefines_1.default.WRITE_SET(wgfx.EnumCullMode.BACK, renderDrawEncodeDefines_1.default.CULL_MODE_MASK, renderDrawEncodeDefines_1.default.CULL_MODE_SHIFT) |
        renderDrawEncodeDefines_1.default.WRITE_SET(wgfx.EnumPrimitiveType.TRIANGLES, renderDrawEncodeDefines_1.default.PRIMITIVE_TYPE_MASK, renderDrawEncodeDefines_1.default.PRIMITIVE_TYPE_SHIFT) |
        renderDrawEncodeDefines_1.default.WRITE_SET(wgfx.EnumFaceWinding.CW, renderDrawEncodeDefines_1.default.FACE_WINDING_MASK, renderDrawEncodeDefines_1.default.FACE_WINDING_SHIFT),
    stencilDepth: renderDrawEncodeDefines_1.default.WRITE_SET(1, renderDrawEncodeDefines_1.default.DEPTH_WRITE_ENABLE_FUNC_MASK, renderDrawEncodeDefines_1.default.DEPTH_WRITE_ENABLE_FUNC_SHIFT) |
        renderDrawEncodeDefines_1.default.WRITE_SET(wgfx.EnumCompareFunc.LESS_EQUAL, renderDrawEncodeDefines_1.default.DEPTH_COMPARE_FUNC_MASK, renderDrawEncodeDefines_1.default.DEPTH_COMPARE_FUNC_SHIFT),
};
// mock处理逻辑
var RenderDraw = /** @class */ (function () {
    function RenderDraw(native) {
        this._native = native;
        exports.renderDraw2Native.set(this, native);
        Object.assign(this._native, renderViewDefaultStatus);
    }
    Object.defineProperty(RenderDraw.prototype, "renderView", {
        set: function (val) {
            this._native.view = renderView_1.renderView2Native.get(val);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "shader", {
        set: function (val) {
            this._native.shader = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "vertexLayout", {
        set: function (val) {
            this._native.vertexLayout = vertexLayout_1.vertexLayout2Native.get(val);
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "indexBuffer", {
        /*
        set blend(val: number){
          this._native.blend = val;
        }
        set rgba(val: number) {
          this._native.rgba = val;
        }
        set stencilOpTest(val: number) {
          this._native.stencilOpTest = val;
        }
        set stencilDepth(val: number) {
          this._native.stencilDepth = val;
        }
        set raster(val: number) {
          this._native.raster = val;
        }
        */
        set: function (val) {
            this._native.indexBuffer = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "vertexBuffers", {
        set: function (val) {
            this._native.vertexBuffers = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "nativeValues", {
        set: function (val) {
            var arr = [];
            for (var _i = 0, val_1 = val; _i < val_1.length; _i++) {
                var item = val_1[_i];
                arr.push(nativeValue_1.nativeValue2Native.get(item));
            }
            this._native.nativeValues = arr;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "images", {
        set: function (val) {
            this._native.images = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "baseElement", {
        set: function (val) {
            this._native.baseElement = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "numElements", {
        set: function (val) {
            this._native.numElements = val;
        },
        enumerable: false,
        configurable: true
    });
    RenderDraw.prototype.applyUpdate = function () {
        this._native.applyUpdate();
    };
    // blend
    RenderDraw.prototype.setBlendOn = function (on) {
        this._native.blend &= ~renderDrawEncodeDefines_1.default.BLEND_ENABLE_MASK;
        if (on) {
            this._native.blend |= renderDrawEncodeDefines_1.default.WRITE_SET(1, renderDrawEncodeDefines_1.default.BLEND_ENABLE_MASK, renderDrawEncodeDefines_1.default.BLEND_ENABLE_SHIFT);
        }
    };
    RenderDraw.prototype.setBlendMode = function (src, dst, func) {
        this.setBlendModeSeparate(src, src, dst, dst, func, func);
    };
    RenderDraw.prototype.setBlendModeSeparate = function (srcRGB, srcAlpha, dstRGB, dstAlpha, funcRGB, funcAlpha) {
        // clear
        this._native.blend &= ~(renderDrawEncodeDefines_1.default.BLEND_OP_RGB_MASK |
            renderDrawEncodeDefines_1.default.BLEND_OP_ALPHA_MASK |
            renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_RGB_MASK |
            renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_ALPHA_MASK |
            renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_RGB_MASK |
            renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_ALPHA_MASK);
        // set
        this._native.blend |=
            renderDrawEncodeDefines_1.default.WRITE_SET(funcRGB, renderDrawEncodeDefines_1.default.BLEND_OP_RGB_MASK, renderDrawEncodeDefines_1.default.BLEND_OP_RGB_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(funcAlpha, renderDrawEncodeDefines_1.default.BLEND_OP_ALPHA_MASK, renderDrawEncodeDefines_1.default.BLEND_OP_ALPHA_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(srcRGB, renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_RGB_MASK, renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_RGB_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(srcAlpha, renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_ALPHA_MASK, renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_ALPHA_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(dstRGB, renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_RGB_MASK, renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_RGB_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(dstAlpha, renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_ALPHA_MASK, renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_ALPHA_SHIFT);
    };
    RenderDraw.prototype.setColorMask = function (colorMask) {
        // clear
        this._native.blend &= ~(renderDrawEncodeDefines_1.default.COLOR_WRITE_MASK);
        // set
        this._native.blend |=
            renderDrawEncodeDefines_1.default.WRITE_SET(colorMask, renderDrawEncodeDefines_1.default.COLOR_WRITE_MASK, renderDrawEncodeDefines_1.default.COLOR_WRITE_SHIFT);
    };
    RenderDraw.prototype.setDepthWriteOn = function (on) {
        // clear
        this._native.stencilDepth &= ~renderDrawEncodeDefines_1.default.DEPTH_WRITE_ENABLE_FUNC_MASK;
        // set
        if (on) {
            this._native.stencilDepth |= renderDrawEncodeDefines_1.default.WRITE_SET(1, renderDrawEncodeDefines_1.default.DEPTH_WRITE_ENABLE_FUNC_MASK, renderDrawEncodeDefines_1.default.DEPTH_WRITE_ENABLE_FUNC_SHIFT);
        }
    };
    RenderDraw.prototype.setDepthTest = function (func) {
        // clear
        this._native.stencilDepth &= ~renderDrawEncodeDefines_1.default.DEPTH_COMPARE_FUNC_MASK;
        // set
        this._native.stencilDepth |= renderDrawEncodeDefines_1.default.WRITE_SET(func, renderDrawEncodeDefines_1.default.DEPTH_COMPARE_FUNC_MASK, renderDrawEncodeDefines_1.default.DEPTH_COMPARE_FUNC_SHIFT);
    };
    RenderDraw.prototype.setStencilTestOn = function (on) {
        // clear
        this._native.stencilDepth &= ~renderDrawEncodeDefines_1.default.STENCIL_ENABLE_FUNC_MASK;
        // set
        if (on) {
            this._native.stencilDepth |= renderDrawEncodeDefines_1.default.WRITE_SET(1, renderDrawEncodeDefines_1.default.STENCIL_ENABLE_FUNC_MASK, renderDrawEncodeDefines_1.default.STENCIL_ENABLE_FUNC_SHIFT);
        }
    };
    RenderDraw.prototype.setStencilWriteMask = function (mask) {
        // clear
        this._native.stencilDepth &= ~renderDrawEncodeDefines_1.default.STENCIL_WRITE_MASK;
        // set
        this._native.stencilDepth |= renderDrawEncodeDefines_1.default.WRITE_SET(mask, renderDrawEncodeDefines_1.default.STENCIL_WRITE_MASK, renderDrawEncodeDefines_1.default.STENCIL_WRITE_SHIFT);
    };
    RenderDraw.prototype.setStencilReadMask = function (mask) {
        // clear
        this._native.stencilDepth &= ~renderDrawEncodeDefines_1.default.STENCIL_READ_MASK;
        // set
        this._native.stencilDepth |= renderDrawEncodeDefines_1.default.WRITE_SET(mask, renderDrawEncodeDefines_1.default.STENCIL_READ_MASK, renderDrawEncodeDefines_1.default.STENCIL_READ_SHIFT);
    };
    RenderDraw.prototype.setStencilRef = function (ref) {
        // clear
        this._native.stencilDepth &= ~renderDrawEncodeDefines_1.default.STENCIL_REF_MASK;
        // set
        this._native.stencilDepth |= renderDrawEncodeDefines_1.default.WRITE_SET(ref, renderDrawEncodeDefines_1.default.STENCIL_REF_MASK, renderDrawEncodeDefines_1.default.STENCIL_REF_SHIFT);
    };
    RenderDraw.prototype.setStencilTestMode = function (func, fail, zfail, pass) {
        var frontStencil = renderDrawEncodeDefines_1.default.WRITE_SET(func, renderDrawEncodeDefines_1.default.STENCIL_FRONT_COMPARE_FUN_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_COMPARE_FUN_SHIFT) |
            renderDrawEncodeDefines_1.default.WRITE_SET(fail, renderDrawEncodeDefines_1.default.STENCIL_FRONT_FAIL_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_FAIL_OP_SHIFT) |
            renderDrawEncodeDefines_1.default.WRITE_SET(zfail, renderDrawEncodeDefines_1.default.STENCIL_FRONT_DEPTH_FAIL_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_DEPTH_FAIL_OP_SHIFT) |
            renderDrawEncodeDefines_1.default.WRITE_SET(pass, renderDrawEncodeDefines_1.default.STENCIL_FRONT_PASS_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_PASS_OP_SHIFT);
        this._native.stencilOpTest = frontStencil + (frontStencil << 16 >>> 0);
        //this.setStencilTestModeSeparate(func, fail, zfail, pass, func, fail, zfail, pass);
    };
    RenderDraw.prototype.setStencilTestModeSeparate = function (funcFront, failFront, zfailFront, passFront, funcBack, failBack, zfailBack, passBack) {
        // clear
        this._native.stencilOpTest = 0;
        // set
        this._native.stencilOpTest =
            renderDrawEncodeDefines_1.default.WRITE_SET(funcFront, renderDrawEncodeDefines_1.default.STENCIL_FRONT_COMPARE_FUN_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_COMPARE_FUN_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(failFront, renderDrawEncodeDefines_1.default.STENCIL_FRONT_FAIL_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_FAIL_OP_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(zfailFront, renderDrawEncodeDefines_1.default.STENCIL_FRONT_DEPTH_FAIL_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_DEPTH_FAIL_OP_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(passFront, renderDrawEncodeDefines_1.default.STENCIL_FRONT_PASS_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_PASS_OP_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET_SAFE(funcBack, renderDrawEncodeDefines_1.default.STENCIL_BACK_COMPARE_FUN_MASK, renderDrawEncodeDefines_1.default.STENCIL_BACK_COMPARE_FUN_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(failBack, renderDrawEncodeDefines_1.default.STENCIL_BACK_FAIL_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_BACK_FAIL_OP_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(zfailBack, renderDrawEncodeDefines_1.default.STENCIL_BACK_DEPTH_FAIL_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_BACK_DEPTH_FAIL_OP_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(passBack, renderDrawEncodeDefines_1.default.STENCIL_BACK_PASS_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_BACK_PASS_OP_SHIFT);
    };
    RenderDraw.prototype.setCullMode = function (mode) {
        // clear
        this._native.raster &= ~renderDrawEncodeDefines_1.default.CULL_MODE_MASK;
        // set
        this._native.raster |= renderDrawEncodeDefines_1.default.WRITE_SET(mode, renderDrawEncodeDefines_1.default.CULL_MODE_MASK, renderDrawEncodeDefines_1.default.CULL_MODE_SHIFT);
    };
    RenderDraw.prototype.setFaceWinding = function (type) {
        // clear
        this._native.raster &= ~renderDrawEncodeDefines_1.default.FACE_WINDING_MASK;
        // set
        this._native.raster |= renderDrawEncodeDefines_1.default.WRITE_SET(type, renderDrawEncodeDefines_1.default.FACE_WINDING_MASK, renderDrawEncodeDefines_1.default.FACE_WINDING_SHIFT);
    };
    RenderDraw.prototype.setPrimitiveType = function (type) {
        // clear
        this._native.raster &= ~renderDrawEncodeDefines_1.default.PRIMITIVE_TYPE_MASK;
        // set
        this._native.raster |= renderDrawEncodeDefines_1.default.WRITE_SET(type, renderDrawEncodeDefines_1.default.PRIMITIVE_TYPE_MASK, renderDrawEncodeDefines_1.default.PRIMITIVE_TYPE_SHIFT);
    };
    RenderDraw.prototype.setIndexType = function (type) {
        // clear
        this._native.raster &= ~renderDrawEncodeDefines_1.default.INDEX_TYPE_MASK;
        // set
        this._native.raster |= renderDrawEncodeDefines_1.default.WRITE_SET(type, renderDrawEncodeDefines_1.default.INDEX_TYPE_MASK, renderDrawEncodeDefines_1.default.INDEX_TYPE_SHIFT);
    };
    RenderDraw.prototype.setPassDepthFormat = function (pixelFormat) {
        // clear
        this._native.raster &= ~renderDrawEncodeDefines_1.default.DEPTH_FORMAT_MASK;
        // set
        this._native.raster |= renderDrawEncodeDefines_1.default.WRITE_SET(pixelFormat, renderDrawEncodeDefines_1.default.DEPTH_FORMAT_MASK, renderDrawEncodeDefines_1.default.DEPTH_FORMAT_SHIFT);
    };
    RenderDraw.prototype.setPassColorFormat = function (pixelFormat, attachmentCount) {
        // clear
        this._native.raster &= ~(renderDrawEncodeDefines_1.default.COLOR_ATTACHMENT_COUNT_MASK | renderDrawEncodeDefines_1.default.COLOR_FORMAT_MASK);
        // set
        this._native.raster |= renderDrawEncodeDefines_1.default.WRITE_SET(pixelFormat, renderDrawEncodeDefines_1.default.COLOR_FORMAT_MASK, renderDrawEncodeDefines_1.default.COLOR_FORMAT_SHIFT) |
            renderDrawEncodeDefines_1.default.WRITE_SET(attachmentCount, renderDrawEncodeDefines_1.default.COLOR_ATTACHMENT_COUNT_MASK, renderDrawEncodeDefines_1.default.COLOR_ATTACHMENT_COUNT_SHIFT);
    };
    RenderDraw.prototype.setUnBatchable = function () {
        this._native.batchable = false;
        this._native.renderDataDirty = false;
    };
    // batchable
    RenderDraw.prototype.setBatchable = function (vertexBuffer, indexBuffer, worldTransform) {
        this._native.batchable = true;
        this._native.renderDataDirty = true;
        this._native.vertexBuffers = [batchableVertexBuffer_1.batchableVertexBuffer2Native.get(vertexBuffer)];
        this._native.indexBuffer = batchableIndexBuffer_1.batchableIndexBuffer2Native.get(indexBuffer);
        this._native.worldTransform = nativeValue_1.nativeValue2Native.get(worldTransform);
    };
    // set dirty
    RenderDraw.prototype.setBatchableRenderDataDirty = function () {
        this._native.renderDataDirty = true;
    };
    return RenderDraw;
}());
exports.default = RenderDraw;


/***/ }),
/* 83 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.renderView2Native = void 0;
exports.renderView2Native = new WeakMap();
var RenderView = /** @class */ (function () {
    function RenderView(native) {
        this._native = native;
        exports.renderView2Native.set(this, native);
    }
    return RenderView;
}());
exports.default = RenderView;


/***/ }),
/* 84 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.vertexLayout2Native = void 0;
exports.vertexLayout2Native = new WeakMap();
var VertexLayout = /** @class */ (function () {
    function VertexLayout(native) {
        this._native = native;
        exports.vertexLayout2Native.set(this, native);
    }
    return VertexLayout;
}());
exports.default = VertexLayout;


/***/ }),
/* 85 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.batchableVertexBuffer2Native = void 0;
exports.batchableVertexBuffer2Native = new WeakMap();
var BatchableVertexBuffer = /** @class */ (function () {
    function BatchableVertexBuffer(native) {
        this._native = native;
        this.data = native.data;
        exports.batchableVertexBuffer2Native.set(this, native);
    }
    return BatchableVertexBuffer;
}());
exports.default = BatchableVertexBuffer;


/***/ }),
/* 86 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.batchableIndexBuffer2Native = void 0;
exports.batchableIndexBuffer2Native = new WeakMap();
var BatchableIndexBuffer = /** @class */ (function () {
    function BatchableIndexBuffer(native) {
        this._native = native;
        this.data = native.data;
        exports.batchableIndexBuffer2Native.set(this, native);
    }
    return BatchableIndexBuffer;
}());
exports.default = BatchableIndexBuffer;


/***/ }),
/* 87 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

/*
 * @Author: bluecatliao
 * @Date: 2019-03-18 22:51:39
 * @Last Modified by: bluecatliao
 * @Last Modified time: 2020-03-24 19:09:43
 * 封装了native提供的CommandBuffer
 */
Object.defineProperty(exports, "__esModule", { value: true });
var renderDraw_1 = __webpack_require__(88);
var CommandType;
(function (CommandType) {
    CommandType[CommandType["CommandRenderDraw"] = 1] = "CommandRenderDraw";
    CommandType[CommandType["CommandSubBuffer"] = 2] = "CommandSubBuffer";
})(CommandType || (CommandType = {}));
var SIZE_UINT32 = 4;
var OFFSET_COMMANDLENGTH = 0;
var INIT_COMMANDBUFFER_SIZE = 1024;
var COMMANDBUFFER_SCALE = 2;
var COMMAND_PUSH_SIZE = 2;
var COMMAND_PUSHSUB_SIZE = 2;
var CommandBuffer = /** @class */ (function () {
    function CommandBuffer(renderer, defaultRenderDrawCount, defaultSubCommandBufferCount) {
        this._bufferSize = 0;
        this._renderer = renderer;
        if ((defaultRenderDrawCount && defaultRenderDrawCount != 0) || (defaultSubCommandBufferCount && defaultSubCommandBufferCount != 0)) {
            var rdCount = defaultRenderDrawCount || 0;
            var subCount = defaultSubCommandBufferCount || 0;
            this._initCommandBuffer((rdCount * COMMAND_PUSH_SIZE + subCount * COMMAND_PUSHSUB_SIZE) * SIZE_UINT32);
        }
        else {
            this._initCommandBuffer(INIT_COMMANDBUFFER_SIZE);
        }
    }
    CommandBuffer.prototype.batchPutRenderDraw = function (renderDraws, len) {
        len = (len !== undefined) ? len : renderDraws.length;
        var commandSize = len * COMMAND_PUSH_SIZE * SIZE_UINT32;
        this._checkSize(commandSize);
        var offset = (this._u32view[OFFSET_COMMANDLENGTH] / SIZE_UINT32) + 1;
        for (var i = 0; i < len; i++) {
            var renderDraw = renderDraws[i];
            this._u32view[offset] = CommandType.CommandRenderDraw;
            this._u32view[offset + 1] = renderDraw_1.renderDraw2Native.get(renderDraw).id;
            offset += COMMAND_PUSH_SIZE;
        }
        for (var _i = 0, renderDraws_1 = renderDraws; _i < renderDraws_1.length; _i++) {
            var renderDraw = renderDraws_1[_i];
        }
        this.setCommandSize((this._u32view[OFFSET_COMMANDLENGTH]) + commandSize);
    };
    CommandBuffer.prototype.putSubCommandBuffer = function (commandBuffer) {
        var commandSize = COMMAND_PUSHSUB_SIZE * SIZE_UINT32;
        this._checkSize(commandSize);
        var offset = (this._u32view[OFFSET_COMMANDLENGTH] / SIZE_UINT32) + 1;
        this._u32view[offset] = CommandType.CommandSubBuffer;
        this._u32view[offset + 1] = commandBuffer._native.id;
        this.setCommandSize((this._u32view[OFFSET_COMMANDLENGTH]) + commandSize);
    };
    CommandBuffer.prototype.reset = function () {
        this.setCommandSize(0);
    };
    CommandBuffer.prototype.execute = function () {
        this._native.execute();
    };
    CommandBuffer.prototype._initCommandBuffer = function (commandSize) {
        this._native = this._renderer.createCommandBuffer(commandSize);
        this._u32view = new Uint32Array(this._native.data, 0, this._native.data.byteLength / 4);
        this._bufferSize = commandSize;
    };
    CommandBuffer.prototype._extendCommandBuffer = function (commandSize) {
        this._native.extend(commandSize);
        this._u32view = new Uint32Array(this._native.data, 0, this._native.data.byteLength / 4);
        this._bufferSize = commandSize;
    };
    CommandBuffer.prototype._checkSize = function (commandSize) {
        if (SIZE_UINT32 + (this._u32view[OFFSET_COMMANDLENGTH]) + commandSize > this._bufferSize) {
            var sizeScale = (SIZE_UINT32 + (this._u32view[OFFSET_COMMANDLENGTH]) + commandSize) * COMMANDBUFFER_SCALE;
            this._extendCommandBuffer(sizeScale);
        }
    };
    CommandBuffer.prototype.setCommandSize = function (length) {
        this._u32view[OFFSET_COMMANDLENGTH] = length;
    };
    return CommandBuffer;
}());
exports.default = CommandBuffer;


/***/ }),
/* 88 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.renderDraw2Native = void 0;
var tslib_1 = __webpack_require__(1);
var nativeValue_1 = __webpack_require__(79);
var renderDrawEncodeDefines_1 = tslib_1.__importDefault(__webpack_require__(18));
var renderView_1 = __webpack_require__(83);
var vertexLayout_1 = __webpack_require__(84);
var batchableVertexBuffer_1 = __webpack_require__(85);
var batchableIndexBuffer_1 = __webpack_require__(86);
exports.renderDraw2Native = new WeakMap();
// Uint32
var OFFSET_VIEW_ID = 0;
var OFFSET_SCISSOR = 1;
var OFFSET_SHADER_ID = 2;
var OFFSET_VERTEX_LAYOUT_ID = 3;
var OFFSET_BLEND = 4;
var OFFSET_RGBA = 5;
var OFFSET_STENCIL_OP_TEST = 6;
var OFFSET_DEPTH = 7;
var OFFSET_RASTER = 8;
var OFFSET_INDEX_BUFFER = 9;
var OFFSET_VERTEX_BUFFERS = 10;
var OFFSET_NATIVE_VALUES = 14;
var OFFSET_IMAGES = 30;
var OFFSET_BASE_ELEMENT = 46;
var OFFSET_NUM_ELEMENTS = 47;
var OFFSET_WORLD_TRANSFROM = 49;
var RENDERDRAW_SIZE = 200;
// Uint8
var OFFSET_BATCHABLE = 192;
var OFFSET_DATA_DIRTY = 193;
// Default 
var DEFAULT_RASTER = renderDrawEncodeDefines_1.default.WRITE_SET(wgfx.EnumIndexType.UINT16, renderDrawEncodeDefines_1.default.INDEX_TYPE_MASK, renderDrawEncodeDefines_1.default.INDEX_TYPE_SHIFT) |
    renderDrawEncodeDefines_1.default.WRITE_SET(wgfx.EnumCullMode.BACK, renderDrawEncodeDefines_1.default.CULL_MODE_MASK, renderDrawEncodeDefines_1.default.CULL_MODE_SHIFT) |
    renderDrawEncodeDefines_1.default.WRITE_SET(wgfx.EnumPrimitiveType.TRIANGLES, renderDrawEncodeDefines_1.default.PRIMITIVE_TYPE_MASK, renderDrawEncodeDefines_1.default.PRIMITIVE_TYPE_SHIFT) |
    renderDrawEncodeDefines_1.default.WRITE_SET(wgfx.EnumFaceWinding.CW, renderDrawEncodeDefines_1.default.FACE_WINDING_MASK, renderDrawEncodeDefines_1.default.FACE_WINDING_SHIFT);
;
var DEFAULT_DEPTH = renderDrawEncodeDefines_1.default.WRITE_SET(1, renderDrawEncodeDefines_1.default.DEPTH_WRITE_ENABLE_FUNC_MASK, renderDrawEncodeDefines_1.default.DEPTH_WRITE_ENABLE_FUNC_SHIFT) |
    renderDrawEncodeDefines_1.default.WRITE_SET(wgfx.EnumCompareFunc.LESS_EQUAL, renderDrawEncodeDefines_1.default.DEPTH_COMPARE_FUNC_MASK, renderDrawEncodeDefines_1.default.DEPTH_COMPARE_FUNC_SHIFT);
var DefalutRDArrayBuffer = new ArrayBuffer(RENDERDRAW_SIZE);
var DefalutRDU32View = new Uint32Array(DefalutRDArrayBuffer);
DefalutRDU32View[OFFSET_RASTER] = DEFAULT_RASTER;
DefalutRDU32View[OFFSET_DEPTH] = DEFAULT_DEPTH;
var RenderDraw = /** @class */ (function () {
    function RenderDraw(native) {
        this._native = native;
        exports.renderDraw2Native.set(this, native);
        this._u8view = new Uint8Array(this._native.data);
        this._u32View = new Uint32Array(this._native.data);
        this.clear();
    }
    Object.defineProperty(RenderDraw.prototype, "renderView", {
        set: function (val) {
            this._u32View[OFFSET_VIEW_ID] = renderView_1.renderView2Native.get(val).id;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "shader", {
        set: function (val) {
            this._u32View[OFFSET_SHADER_ID] = val.id;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "vertexLayout", {
        set: function (val) {
            this._u32View[OFFSET_VERTEX_LAYOUT_ID] = vertexLayout_1.vertexLayout2Native.get(val).id;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "indexBuffer", {
        set: function (val) {
            this._u32View[OFFSET_INDEX_BUFFER] = val.id;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "vertexBuffers", {
        set: function (val) {
            this._u32View.fill(0, OFFSET_VERTEX_BUFFERS, OFFSET_VERTEX_BUFFERS + 4);
            for (var i = 0; i < val.length; i++) {
                this._u32View[OFFSET_VERTEX_BUFFERS + i] = val[i].id;
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "nativeValues", {
        set: function (val) {
            this._u32View.fill(0, OFFSET_NATIVE_VALUES, OFFSET_NATIVE_VALUES + 16);
            for (var i = 0; i < val.length; i++) {
                this._u32View[OFFSET_NATIVE_VALUES + i] = nativeValue_1.nativeValue2Native.get(val[i]).id;
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "images", {
        set: function (val) {
            this._u32View.fill(0, OFFSET_IMAGES, OFFSET_IMAGES + 16);
            for (var i = 0; i < val.length; i++) {
                this._u32View[OFFSET_IMAGES + i] = val[i].id;
            }
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "baseElement", {
        set: function (val) {
            this._u32View[OFFSET_BASE_ELEMENT] = val;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(RenderDraw.prototype, "numElements", {
        set: function (val) {
            this._u32View[OFFSET_NUM_ELEMENTS] = val;
        },
        enumerable: false,
        configurable: true
    });
    RenderDraw.prototype.applyUpdate = function () { };
    RenderDraw.prototype.clear = function () {
        this._u32View.set(DefalutRDU32View);
    };
    // blend
    RenderDraw.prototype.setBlendOn = function (on) {
        this._u32View[OFFSET_BLEND] &= ~renderDrawEncodeDefines_1.default.BLEND_ENABLE_MASK;
        if (on) {
            this._u32View[OFFSET_BLEND] |= renderDrawEncodeDefines_1.default.WRITE_SET(1, renderDrawEncodeDefines_1.default.BLEND_ENABLE_MASK, renderDrawEncodeDefines_1.default.BLEND_ENABLE_SHIFT);
        }
    };
    RenderDraw.prototype.setBlendMode = function (src, dst, func) {
        this.setBlendModeSeparate(src, src, dst, dst, func, func);
    };
    RenderDraw.prototype.setBlendModeSeparate = function (srcRGB, srcAlpha, dstRGB, dstAlpha, funcRGB, funcAlpha) {
        // clear
        this._u32View[OFFSET_BLEND] &= ~(renderDrawEncodeDefines_1.default.BLEND_OP_RGB_MASK |
            renderDrawEncodeDefines_1.default.BLEND_OP_ALPHA_MASK |
            renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_RGB_MASK |
            renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_ALPHA_MASK |
            renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_RGB_MASK |
            renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_ALPHA_MASK);
        // set
        this._u32View[OFFSET_BLEND] |=
            renderDrawEncodeDefines_1.default.WRITE_SET(funcRGB, renderDrawEncodeDefines_1.default.BLEND_OP_RGB_MASK, renderDrawEncodeDefines_1.default.BLEND_OP_RGB_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(funcAlpha, renderDrawEncodeDefines_1.default.BLEND_OP_ALPHA_MASK, renderDrawEncodeDefines_1.default.BLEND_OP_ALPHA_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(srcRGB, renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_RGB_MASK, renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_RGB_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(srcAlpha, renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_ALPHA_MASK, renderDrawEncodeDefines_1.default.BLEND_SRC_FACTOR_ALPHA_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(dstRGB, renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_RGB_MASK, renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_RGB_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(dstAlpha, renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_ALPHA_MASK, renderDrawEncodeDefines_1.default.BLEND_DST_FACTOR_ALPHA_SHIFT);
    };
    RenderDraw.prototype.setColorMask = function (colorMask) {
        // clear
        this._u32View[OFFSET_BLEND] &= ~(renderDrawEncodeDefines_1.default.COLOR_WRITE_MASK);
        // set
        this._u32View[OFFSET_BLEND] |=
            renderDrawEncodeDefines_1.default.WRITE_SET(colorMask, renderDrawEncodeDefines_1.default.COLOR_WRITE_MASK, renderDrawEncodeDefines_1.default.COLOR_WRITE_SHIFT);
    };
    RenderDraw.prototype.setDepthWriteOn = function (on) {
        // clear
        this._u32View[OFFSET_DEPTH] &= ~renderDrawEncodeDefines_1.default.DEPTH_WRITE_ENABLE_FUNC_MASK;
        // set
        if (on) {
            this._u32View[OFFSET_DEPTH] |= renderDrawEncodeDefines_1.default.WRITE_SET(1, renderDrawEncodeDefines_1.default.DEPTH_WRITE_ENABLE_FUNC_MASK, renderDrawEncodeDefines_1.default.DEPTH_WRITE_ENABLE_FUNC_SHIFT);
        }
    };
    RenderDraw.prototype.setDepthTest = function (func) {
        // clear
        this._u32View[OFFSET_DEPTH] &= ~renderDrawEncodeDefines_1.default.DEPTH_COMPARE_FUNC_MASK;
        // set
        this._u32View[OFFSET_DEPTH] |= renderDrawEncodeDefines_1.default.WRITE_SET(func, renderDrawEncodeDefines_1.default.DEPTH_COMPARE_FUNC_MASK, renderDrawEncodeDefines_1.default.DEPTH_COMPARE_FUNC_SHIFT);
    };
    RenderDraw.prototype.setStencilTestOn = function (on) {
        // clear
        this._u32View[OFFSET_DEPTH] &= ~renderDrawEncodeDefines_1.default.STENCIL_ENABLE_FUNC_MASK;
        // set
        if (on) {
            this._u32View[OFFSET_DEPTH] |= renderDrawEncodeDefines_1.default.WRITE_SET(1, renderDrawEncodeDefines_1.default.STENCIL_ENABLE_FUNC_MASK, renderDrawEncodeDefines_1.default.STENCIL_ENABLE_FUNC_SHIFT);
        }
    };
    RenderDraw.prototype.setStencilWriteMask = function (mask) {
        // clear
        this._u32View[OFFSET_DEPTH] &= ~renderDrawEncodeDefines_1.default.STENCIL_WRITE_MASK;
        // set
        this._u32View[OFFSET_DEPTH] |= renderDrawEncodeDefines_1.default.WRITE_SET(mask, renderDrawEncodeDefines_1.default.STENCIL_WRITE_MASK, renderDrawEncodeDefines_1.default.STENCIL_WRITE_SHIFT);
    };
    RenderDraw.prototype.setStencilReadMask = function (mask) {
        // clear
        this._u32View[OFFSET_DEPTH] &= ~renderDrawEncodeDefines_1.default.STENCIL_READ_MASK;
        // set
        this._u32View[OFFSET_DEPTH] |= renderDrawEncodeDefines_1.default.WRITE_SET(mask, renderDrawEncodeDefines_1.default.STENCIL_READ_MASK, renderDrawEncodeDefines_1.default.STENCIL_READ_SHIFT);
    };
    RenderDraw.prototype.setStencilRef = function (ref) {
        // clear
        this._u32View[OFFSET_DEPTH] &= ~renderDrawEncodeDefines_1.default.STENCIL_REF_MASK;
        // set
        this._u32View[OFFSET_DEPTH] |= renderDrawEncodeDefines_1.default.WRITE_SET(ref, renderDrawEncodeDefines_1.default.STENCIL_REF_MASK, renderDrawEncodeDefines_1.default.STENCIL_REF_SHIFT);
    };
    RenderDraw.prototype.setStencilTestMode = function (func, fail, zfail, pass) {
        this.setStencilTestModeSeparate(func, fail, zfail, pass, func, fail, zfail, pass);
    };
    RenderDraw.prototype.setStencilTestModeSeparate = function (funcFront, failFront, zfailFront, passFront, funcBack, failBack, zfailBack, passBack) {
        // clear
        this._u32View[OFFSET_STENCIL_OP_TEST] = 0;
        // set
        this._u32View[OFFSET_STENCIL_OP_TEST] =
            renderDrawEncodeDefines_1.default.WRITE_SET(funcFront, renderDrawEncodeDefines_1.default.STENCIL_FRONT_COMPARE_FUN_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_COMPARE_FUN_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(failFront, renderDrawEncodeDefines_1.default.STENCIL_FRONT_FAIL_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_FAIL_OP_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(zfailFront, renderDrawEncodeDefines_1.default.STENCIL_FRONT_DEPTH_FAIL_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_DEPTH_FAIL_OP_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(passFront, renderDrawEncodeDefines_1.default.STENCIL_FRONT_PASS_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_FRONT_PASS_OP_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(funcBack, renderDrawEncodeDefines_1.default.STENCIL_BACK_COMPARE_FUN_MASK, renderDrawEncodeDefines_1.default.STENCIL_BACK_COMPARE_FUN_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(failBack, renderDrawEncodeDefines_1.default.STENCIL_BACK_FAIL_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_BACK_FAIL_OP_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(zfailBack, renderDrawEncodeDefines_1.default.STENCIL_BACK_DEPTH_FAIL_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_BACK_DEPTH_FAIL_OP_SHIFT) |
                renderDrawEncodeDefines_1.default.WRITE_SET(passBack, renderDrawEncodeDefines_1.default.STENCIL_BACK_PASS_OP_MASK, renderDrawEncodeDefines_1.default.STENCIL_BACK_PASS_OP_SHIFT);
    };
    RenderDraw.prototype.setCullMode = function (mode) {
        // clear
        this._u32View[OFFSET_RASTER] &= ~renderDrawEncodeDefines_1.default.CULL_MODE_MASK;
        // set
        this._u32View[OFFSET_RASTER] |= renderDrawEncodeDefines_1.default.WRITE_SET(mode, renderDrawEncodeDefines_1.default.CULL_MODE_MASK, renderDrawEncodeDefines_1.default.CULL_MODE_SHIFT);
    };
    RenderDraw.prototype.setFaceWinding = function (type) {
        // clear
        this._u32View[OFFSET_RASTER] &= ~renderDrawEncodeDefines_1.default.FACE_WINDING_MASK;
        // set
        this._u32View[OFFSET_RASTER] |= renderDrawEncodeDefines_1.default.WRITE_SET(type, renderDrawEncodeDefines_1.default.FACE_WINDING_MASK, renderDrawEncodeDefines_1.default.FACE_WINDING_SHIFT);
    };
    RenderDraw.prototype.setPrimitiveType = function (type) {
        // clear
        this._u32View[OFFSET_RASTER] &= ~renderDrawEncodeDefines_1.default.PRIMITIVE_TYPE_MASK;
        // set
        this._u32View[OFFSET_RASTER] |= renderDrawEncodeDefines_1.default.WRITE_SET(type, renderDrawEncodeDefines_1.default.PRIMITIVE_TYPE_MASK, renderDrawEncodeDefines_1.default.PRIMITIVE_TYPE_SHIFT);
    };
    RenderDraw.prototype.setIndexType = function (type) {
        // clear
        this._u32View[OFFSET_RASTER] &= ~renderDrawEncodeDefines_1.default.INDEX_TYPE_MASK;
        // set
        this._u32View[OFFSET_RASTER] |= renderDrawEncodeDefines_1.default.WRITE_SET(type, renderDrawEncodeDefines_1.default.INDEX_TYPE_MASK, renderDrawEncodeDefines_1.default.INDEX_TYPE_SHIFT);
    };
    RenderDraw.prototype.setPassDepthFormat = function (pixelFormat) {
        // clear
        this._u32View[OFFSET_RASTER] &= ~renderDrawEncodeDefines_1.default.DEPTH_FORMAT_MASK;
        // set
        this._u32View[OFFSET_RASTER] |= renderDrawEncodeDefines_1.default.WRITE_SET(pixelFormat, renderDrawEncodeDefines_1.default.DEPTH_FORMAT_MASK, renderDrawEncodeDefines_1.default.DEPTH_FORMAT_SHIFT);
    };
    RenderDraw.prototype.setPassColorFormat = function (pixelFormat, attachmentCount) {
        // clear
        this._u32View[OFFSET_RASTER] &= ~(renderDrawEncodeDefines_1.default.COLOR_ATTACHMENT_COUNT_MASK | renderDrawEncodeDefines_1.default.COLOR_FORMAT_MASK);
        // set
        this._u32View[OFFSET_RASTER] |= renderDrawEncodeDefines_1.default.WRITE_SET(pixelFormat, renderDrawEncodeDefines_1.default.COLOR_FORMAT_MASK, renderDrawEncodeDefines_1.default.COLOR_FORMAT_SHIFT) |
            renderDrawEncodeDefines_1.default.WRITE_SET(attachmentCount, renderDrawEncodeDefines_1.default.COLOR_ATTACHMENT_COUNT_MASK, renderDrawEncodeDefines_1.default.COLOR_ATTACHMENT_COUNT_SHIFT);
    };
    RenderDraw.prototype.setUnBatchable = function () {
        this._u8view[OFFSET_BATCHABLE] = 0;
        this._u8view[OFFSET_DATA_DIRTY] = 0;
    };
    // batchable
    RenderDraw.prototype.setBatchable = function (vertexBuffer, indexBuffer, worldTransform) {
        this._u8view[OFFSET_BATCHABLE] = 1;
        this._u8view[OFFSET_DATA_DIRTY] = 1;
        this._u32View[OFFSET_VERTEX_BUFFERS] = batchableVertexBuffer_1.batchableVertexBuffer2Native.get(vertexBuffer).id;
        this._u32View[OFFSET_VERTEX_BUFFERS + 1] = 0;
        this._u32View[OFFSET_INDEX_BUFFER] = batchableIndexBuffer_1.batchableIndexBuffer2Native.get(indexBuffer).id;
        this._u32View[OFFSET_WORLD_TRANSFROM] = nativeValue_1.nativeValue2Native.get(worldTransform).id;
    };
    // set dirty
    RenderDraw.prototype.setBatchableRenderDataDirty = function () {
        this._u8view[OFFSET_DATA_DIRTY] = 1;
    };
    return RenderDraw;
}());
exports.default = RenderDraw;


/***/ }),
/* 89 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
exports.rect2Native = void 0;
exports.rect2Native = new WeakMap();
var Rect = /** @class */ (function () {
    function Rect(native) {
        this._native = native;
        exports.rect2Native.set(this, native);
    }
    return Rect;
}());
exports.default = Rect;


/***/ })
/******/ ])["default"];
null

})(); /* LIBRARY_CLOSURE_END () */


} catch(err) {
      console.error('catch sdkSubPackage: wxGA error: ', err)
    }
