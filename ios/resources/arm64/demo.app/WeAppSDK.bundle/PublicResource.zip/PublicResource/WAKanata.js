
;try {

;(function () { /* LIBRARY_CLOSURE_START () */


            let getGlobalVar = "getKanataGlobalVar"
            let sdkSubpakcageGlobalVarGetter
            if(globalThis[getGlobalVar]) {
              sdkSubpakcageGlobalVarGetter = globalThis[getGlobalVar]
            } else if(typeof globalThis.WeixinJSBridge !== "undefined" && globalThis.WeixinJSBridge[getGlobalVar]){
              sdkSubpakcageGlobalVarGetter = globalThis.WeixinJSBridge[getGlobalVar]
            }
            var {wxConsole} = sdkSubpakcageGlobalVarGetter();
          


(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
  typeof define === 'function' && define.amd ? define(['exports'], factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global.Kanata = {}));
}(this, (function (topExports) { 'use strict';
  topExports.Puppet = typeof NativeGlobal !== 'undefined' ? NativeGlobal.Puppet : undefined;
  topExports.CREATE_INSTANCE = (MAIN_CANVAS, ENGINE_SETTINGS, ENGINE_MODE, IS_SUB_CONTEXT, HOST, FIX_INSTANCE) => {
      var K_INS = globalThis.KANATA_INSTANCES = globalThis.KANATA_INSTANCES || new Map();
      if (K_INS.get(MAIN_CANVAS)) {
        return K_INS.get(MAIN_CANVAS);
      }
      var module = {exports: {}};
      var exports = module.exports;

      (function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) :
  typeof define === 'function' && define.amd ? define(['exports'], factory) :
  (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory(global.KanataClass = {}));
})(this, (function (exports) { 'use strict';

  /*---------------- Enums ----------------*/
  /**
   * 顶点数据格式枚举。
   */
  exports.EVertexFormat = void 0;
  (function (EVertexFormat) {
      EVertexFormat[EVertexFormat["FLOAT"] = 0] = "FLOAT";
      EVertexFormat[EVertexFormat["FLOAT2"] = 1] = "FLOAT2";
      EVertexFormat[EVertexFormat["FLOAT3"] = 2] = "FLOAT3";
      EVertexFormat[EVertexFormat["FLOAT4"] = 3] = "FLOAT4";
      EVertexFormat[EVertexFormat["BYTE4"] = 4] = "BYTE4";
      EVertexFormat[EVertexFormat["BYTE4N"] = 5] = "BYTE4N";
      EVertexFormat[EVertexFormat["UBYTE4"] = 6] = "UBYTE4";
      EVertexFormat[EVertexFormat["UBYTE4N"] = 7] = "UBYTE4N";
      EVertexFormat[EVertexFormat["SHORT2"] = 8] = "SHORT2";
      EVertexFormat[EVertexFormat["SHORT2N"] = 9] = "SHORT2N";
      EVertexFormat[EVertexFormat["SHORT4"] = 10] = "SHORT4";
      EVertexFormat[EVertexFormat["SHORT4N"] = 11] = "SHORT4N";
      EVertexFormat[EVertexFormat["UINT10_N2"] = 12] = "UINT10_N2";
  })(exports.EVertexFormat || (exports.EVertexFormat = {}));
  /**
   * 顶点数据步进类型枚举。
   */
  exports.EVertexStep = void 0;
  (function (EVertexStep) {
      /**
       * 逐顶点。
       */
      EVertexStep[EVertexStep["PER_VERTEX"] = 0] = "PER_VERTEX";
      /**
       * 在使用Instance的情况下，逐实例。
       */
      EVertexStep[EVertexStep["PER_INSTANCE"] = 1] = "PER_INSTANCE";
  })(exports.EVertexStep || (exports.EVertexStep = {}));
  /**
   * 索引数据类型。
   */
  exports.EIndexType = void 0;
  (function (EIndexType) {
      /**
       * 无效值。
       */
      EIndexType[EIndexType["NONE"] = 1] = "NONE";
      /**
       * 16位索引。
       */
      EIndexType[EIndexType["UINT16"] = 2] = "UINT16";
      /**
       * 32位索引，注意在某些设备上不支持。
       */
      EIndexType[EIndexType["UINT32"] = 3] = "UINT32";
  })(exports.EIndexType || (exports.EIndexType = {}));
  /**
   * 纹理类型雷剧。
   */
  exports.ETextureType = void 0;
  (function (ETextureType) {
      /**
       * 2D纹理。
       */
      ETextureType[ETextureType["D2"] = 0] = "D2";
      /**
       * 立方体纹理。
       */
      ETextureType[ETextureType["Cube"] = 1] = "Cube";
      /**
       * 2D纹理数组。
       */
      ETextureType[ETextureType["D2Array"] = 2] = "D2Array";
      /**
       * 3D纹理。
       */
      ETextureType[ETextureType["D3"] = 3] = "D3";
      // CubeArray
  })(exports.ETextureType || (exports.ETextureType = {}));
  /**
   * 纹理格式枚举。
   */
  exports.ETextureFormat = void 0;
  (function (ETextureFormat) {
      /** Inputs or Render Target Formats. */
      ETextureFormat[ETextureFormat["RGBA8"] = 0] = "RGBA8";
      ETextureFormat[ETextureFormat["SRGBA8"] = 1] = "SRGBA8";
      ETextureFormat[ETextureFormat["RGB10A2"] = 2] = "RGB10A2";
      ETextureFormat[ETextureFormat["RG8"] = 3] = "RG8";
      ETextureFormat[ETextureFormat["R8"] = 4] = "R8";
      ETextureFormat[ETextureFormat["RGBA32F"] = 5] = "RGBA32F";
      ETextureFormat[ETextureFormat["RGBA16F"] = 6] = "RGBA16F";
      ETextureFormat[ETextureFormat["RG11B10F"] = 7] = "RG11B10F";
      ETextureFormat[ETextureFormat["RGB8"] = 8] = "RGB8";
      ETextureFormat[ETextureFormat["RGB16F"] = 9] = "RGB16F";
      ETextureFormat[ETextureFormat["RGB32F"] = 10] = "RGB32F";
      /** Render Target Only. */
      ETextureFormat[ETextureFormat["Depth_Low"] = 20] = "Depth_Low";
      ETextureFormat[ETextureFormat["Depth_High"] = 21] = "Depth_High";
      ETextureFormat[ETextureFormat["Depth_Stencil"] = 22] = "Depth_Stencil";
      ETextureFormat[ETextureFormat["RGBA4"] = 23] = "RGBA4";
      ETextureFormat[ETextureFormat["RGB565"] = 24] = "RGB565";
      ETextureFormat[ETextureFormat["RGB5A1"] = 25] = "RGB5A1";
      /** Compresseds */
      // ETC1.
      ETextureFormat[ETextureFormat["ETC1RGB8"] = 100] = "ETC1RGB8";
      // ETC2.
      ETextureFormat[ETextureFormat["ETC2RGB8"] = 110] = "ETC2RGB8";
      ETextureFormat[ETextureFormat["ETC2RGBA8"] = 111] = "ETC2RGBA8";
      // PVRTC1.
      ETextureFormat[ETextureFormat["PVRTC2RGBV1"] = 120] = "PVRTC2RGBV1";
      ETextureFormat[ETextureFormat["PVRTC4RGBV1"] = 121] = "PVRTC4RGBV1";
      ETextureFormat[ETextureFormat["PVRTC2RGBAV1"] = 122] = "PVRTC2RGBAV1";
      ETextureFormat[ETextureFormat["PVRTC4RGBAV1"] = 123] = "PVRTC4RGBAV1";
      // PVRTC V2, reserved.
      // ASTC
      ETextureFormat[ETextureFormat["ASTC4x4"] = 140] = "ASTC4x4";
      ETextureFormat[ETextureFormat["ASTC5x5"] = 141] = "ASTC5x5";
      ETextureFormat[ETextureFormat["ASTC6x6"] = 142] = "ASTC6x6";
      ETextureFormat[ETextureFormat["ASTC8x6"] = 143] = "ASTC8x6";
      ETextureFormat[ETextureFormat["ASTC8x8"] = 144] = "ASTC8x8";
      // DXT
      ETextureFormat[ETextureFormat["DXT1"] = 150] = "DXT1";
      ETextureFormat[ETextureFormat["DXT3"] = 151] = "DXT3";
      ETextureFormat[ETextureFormat["DXT5"] = 152] = "DXT5";
  })(exports.ETextureFormat || (exports.ETextureFormat = {}));
  /**
   * 纹理寻址模式枚举。
   */
  exports.EWrapMode = void 0;
  (function (EWrapMode) {
      EWrapMode[EWrapMode["REPEAT"] = 1] = "REPEAT";
      EWrapMode[EWrapMode["CLAMP_TO_EDGE"] = 2] = "CLAMP_TO_EDGE";
      EWrapMode[EWrapMode["MIRRORED_REPEAT"] = 3] = "MIRRORED_REPEAT";
  })(exports.EWrapMode || (exports.EWrapMode = {}));
  /**
   * 纹理过滤模式枚举。
   */
  exports.EFilterMode = void 0;
  (function (EFilterMode) {
      EFilterMode[EFilterMode["NEAREST"] = 1] = "NEAREST";
      EFilterMode[EFilterMode["LINEAR"] = 2] = "LINEAR";
      EFilterMode[EFilterMode["NEAREST_MIPMAP_NEAREST"] = 3] = "NEAREST_MIPMAP_NEAREST";
      EFilterMode[EFilterMode["NEAREST_MIPMAP_LINEAR"] = 4] = "NEAREST_MIPMAP_LINEAR";
      EFilterMode[EFilterMode["LINEAR_MIPMAP_NEAREST"] = 5] = "LINEAR_MIPMAP_NEAREST";
      EFilterMode[EFilterMode["LINEAR_MIPMAP_LINEAR"] = 6] = "LINEAR_MIPMAP_LINEAR";
  })(exports.EFilterMode || (exports.EFilterMode = {}));
  /**
   * Uniform值得类型枚举。
   */
  exports.EUniformType = void 0;
  (function (EUniformType) {
      EUniformType[EUniformType["FLOAT"] = 0] = "FLOAT";
      EUniformType[EUniformType["FLOAT2"] = 1] = "FLOAT2";
      EUniformType[EUniformType["FLOAT3"] = 2] = "FLOAT3";
      EUniformType[EUniformType["FLOAT4"] = 3] = "FLOAT4";
      EUniformType[EUniformType["MAT2"] = 4] = "MAT2";
      EUniformType[EUniformType["MAT3"] = 5] = "MAT3";
      EUniformType[EUniformType["MAT4"] = 6] = "MAT4";
      EUniformType[EUniformType["SAMPLER"] = 7] = "SAMPLER";
  })(exports.EUniformType || (exports.EUniformType = {}));
  /**
   * 背面剔除类型枚举。
   */
  exports.ECullMode = void 0;
  (function (ECullMode) {
      ECullMode[ECullMode["NONE"] = 0] = "NONE";
      ECullMode[ECullMode["FRONT"] = 1] = "FRONT";
      ECullMode[ECullMode["BACK"] = 2] = "BACK";
  })(exports.ECullMode || (exports.ECullMode = {}));
  /**
   * 正面顶点绕序枚举。
   */
  exports.EFaceWinding = void 0;
  (function (EFaceWinding) {
      EFaceWinding[EFaceWinding["CCW"] = 1] = "CCW";
      EFaceWinding[EFaceWinding["CW"] = 2] = "CW";
  })(exports.EFaceWinding || (exports.EFaceWinding = {}));
  /**
   * 各种测试的比较函数枚举。
   */
  exports.ECompareFunc = void 0;
  (function (ECompareFunc) {
      ECompareFunc[ECompareFunc["LESS"] = 1] = "LESS";
      ECompareFunc[ECompareFunc["LEQUAL"] = 2] = "LEQUAL";
      ECompareFunc[ECompareFunc["EQUAL"] = 3] = "EQUAL";
      ECompareFunc[ECompareFunc["GEQUAL"] = 4] = "GEQUAL";
      ECompareFunc[ECompareFunc["GREATER"] = 5] = "GREATER";
      ECompareFunc[ECompareFunc["NOTEQUAL"] = 6] = "NOTEQUAL";
      ECompareFunc[ECompareFunc["NEVER"] = 7] = "NEVER";
      ECompareFunc[ECompareFunc["ALWAYS"] = 8] = "ALWAYS";
  })(exports.ECompareFunc || (exports.ECompareFunc = {}));
  /**
   * 模板测试操作枚举。
   */
  exports.EStencilOp = void 0;
  (function (EStencilOp) {
      EStencilOp[EStencilOp["ZERO"] = 0] = "ZERO";
      EStencilOp[EStencilOp["KEEP"] = 1] = "KEEP";
      EStencilOp[EStencilOp["REPLACE"] = 2] = "REPLACE";
      EStencilOp[EStencilOp["INCR_WRAP"] = 3] = "INCR_WRAP";
      EStencilOp[EStencilOp["INCR"] = 4] = "INCR";
      EStencilOp[EStencilOp["DECR_WRAP"] = 5] = "DECR_WRAP";
      EStencilOp[EStencilOp["DECR"] = 6] = "DECR";
      EStencilOp[EStencilOp["INVERT"] = 7] = "INVERT";
  })(exports.EStencilOp || (exports.EStencilOp = {}));
  /**
   * 混合因子枚举。
   */
  exports.EBlendFactor = void 0;
  (function (EBlendFactor) {
      EBlendFactor[EBlendFactor["ZERO"] = 0] = "ZERO";
      EBlendFactor[EBlendFactor["ONE"] = 1] = "ONE";
      EBlendFactor[EBlendFactor["SRC_COLOR"] = 2] = "SRC_COLOR";
      EBlendFactor[EBlendFactor["ONE_MINUS_SRC_COLOR"] = 3] = "ONE_MINUS_SRC_COLOR";
      EBlendFactor[EBlendFactor["SRC_ALPHA"] = 4] = "SRC_ALPHA";
      EBlendFactor[EBlendFactor["ONE_MINUS_SRC_ALPHA"] = 5] = "ONE_MINUS_SRC_ALPHA";
      EBlendFactor[EBlendFactor["DST_ALPHA"] = 6] = "DST_ALPHA";
      EBlendFactor[EBlendFactor["ONE_MINUS_DST_ALPHA"] = 7] = "ONE_MINUS_DST_ALPHA";
      EBlendFactor[EBlendFactor["DST_COLOR"] = 8] = "DST_COLOR";
      EBlendFactor[EBlendFactor["ONE_MINUS_DST_COLOR"] = 9] = "ONE_MINUS_DST_COLOR";
      EBlendFactor[EBlendFactor["SRC_ALPHA_SATURATE"] = 10] = "SRC_ALPHA_SATURATE";
      EBlendFactor[EBlendFactor["CONSTANT_COLOR"] = 11] = "CONSTANT_COLOR";
      EBlendFactor[EBlendFactor["ONE_MINUS_CONSTANT_COLOR"] = 12] = "ONE_MINUS_CONSTANT_COLOR";
  })(exports.EBlendFactor || (exports.EBlendFactor = {}));
  /**
   * 混合方式枚举。
   */
  exports.EBlendEquation = void 0;
  (function (EBlendEquation) {
      EBlendEquation[EBlendEquation["FUNC_ADD"] = 0] = "FUNC_ADD";
      EBlendEquation[EBlendEquation["FUNC_SUBTRACT"] = 1] = "FUNC_SUBTRACT";
      EBlendEquation[EBlendEquation["FUNC_REVERSE_SUBTRACT"] = 2] = "FUNC_REVERSE_SUBTRACT";
      EBlendEquation[EBlendEquation["MIN"] = 3] = "MIN";
      EBlendEquation[EBlendEquation["MAX"] = 4] = "MAX";
  })(exports.EBlendEquation || (exports.EBlendEquation = {}));
  /**
   * 颜色通道掩码枚举。
   */
  exports.EColorMask = void 0;
  (function (EColorMask) {
      /**
       * 将会禁掉所有通道的输出。
       */
      EColorMask[EColorMask["NONE"] = 16] = "NONE";
      EColorMask[EColorMask["R"] = 1] = "R";
      EColorMask[EColorMask["G"] = 2] = "G";
      EColorMask[EColorMask["B"] = 4] = "B";
      EColorMask[EColorMask["A"] = 8] = "A";
      EColorMask[EColorMask["RGB"] = 7] = "RGB";
      EColorMask[EColorMask["RGBA"] = 15] = "RGBA";
  })(exports.EColorMask || (exports.EColorMask = {}));
  /**
   * 像素数据类型枚举。
   */
  exports.EPixelType = void 0;
  (function (EPixelType) {
      EPixelType[EPixelType["UNSIGNED_BYTE"] = 5121] = "UNSIGNED_BYTE";
      EPixelType[EPixelType["FLOAT"] = 5126] = "FLOAT";
      EPixelType[EPixelType["UNSIGNED_SHORT_5_6_5"] = 33635] = "UNSIGNED_SHORT_5_6_5";
      EPixelType[EPixelType["UNSIGNED_SHORT_4_4_4_4"] = 32819] = "UNSIGNED_SHORT_4_4_4_4";
      EPixelType[EPixelType["UNSIGNED_SHORT_5_5_5_1"] = 32820] = "UNSIGNED_SHORT_5_5_5_1";
  })(exports.EPixelType || (exports.EPixelType = {}));
  /**
   * 清屏操作枚举。
   */
  exports.ELoadAction = void 0;
  (function (ELoadAction) {
      /**
       * 清除屏幕颜色。
       */
      ELoadAction[ELoadAction["CLEAR"] = 0] = "CLEAR";
      /**
       * 不清屏，但依赖前面渲染的结果。
       */
      ELoadAction[ELoadAction["LOAD"] = 1] = "LOAD";
      /**
       * 完全不关心是否清屏。
       */
      ELoadAction[ELoadAction["DONTCARE"] = 2] = "DONTCARE";
  })(exports.ELoadAction || (exports.ELoadAction = {}));
  exports.EDataModelType = void 0;
  (function (EDataModelType) {
      EDataModelType[EDataModelType["AnimationClip"] = 1] = "AnimationClip";
      EDataModelType[EDataModelType["SkeletonBoneInverse"] = 2] = "SkeletonBoneInverse";
  })(exports.EDataModelType || (exports.EDataModelType = {}));
  /**
   * 渲染组件类型枚举。
   */
  exports.EMeshRenderType = void 0;
  (function (EMeshRenderType) {
      /**
       * 未知类型。
       */
      EMeshRenderType[EMeshRenderType["UnKnown"] = 0] = "UnKnown";
      /**
       * 静态3D类型。
       */
      EMeshRenderType[EMeshRenderType["Static3D"] = 1] = "Static3D";
      /**
       * 蒙皮3D类型。
       */
      EMeshRenderType[EMeshRenderType["Skinned3D"] = 2] = "Skinned3D";
      /**
       * UI类型。
       */
      EMeshRenderType[EMeshRenderType["UI"] = 3] = "UI";
  })(exports.EMeshRenderType || (exports.EMeshRenderType = {}));
  /**
   * 图元渲染类型枚举。
   */
  exports.EPrimitiveType = void 0;
  (function (EPrimitiveType) {
      EPrimitiveType[EPrimitiveType["TRIANGLES"] = 0] = "TRIANGLES";
      EPrimitiveType[EPrimitiveType["TRIANGLE_STRIP"] = 1] = "TRIANGLE_STRIP";
      EPrimitiveType[EPrimitiveType["LINES"] = 2] = "LINES";
      EPrimitiveType[EPrimitiveType["LINE_STRIP"] = 3] = "LINE_STRIP";
      EPrimitiveType[EPrimitiveType["POINTS"] = 4] = "POINTS";
      EPrimitiveType[EPrimitiveType["ZERO"] = 5] = "ZERO";
  })(exports.EPrimitiveType || (exports.EPrimitiveType = {}));
  /**
   * 阴影类型枚举。
   */
  exports.EShadowMode = void 0;
  (function (EShadowMode) {
      /**
       * 关闭阴影。
       */
      EShadowMode[EShadowMode["None"] = 0] = "None";
      /**
       * 开启单级联阴影，并开启PCF。
       */
      EShadowMode[EShadowMode["OneCascade_PCF"] = 1] = "OneCascade_PCF";
      /**
       * 开启二级联阴影，并开启PCF。
       */
      EShadowMode[EShadowMode["TwoCascade_PCF"] = 2] = "TwoCascade_PCF";
      /**
       * 开启四级联阴影，并开启PCF。
       */
      EShadowMode[EShadowMode["FourCascade_PCF"] = 4] = "FourCascade_PCF";
      /**
       * 开启单级联阴影，并开启PCSS。
       */
      EShadowMode[EShadowMode["PCSS"] = 5] = "PCSS";
  })(exports.EShadowMode || (exports.EShadowMode = {}));
  /**
   * 阴影匹配类型枚举。
   */
  exports.EShadowFitMode = void 0;
  (function (EShadowFitMode) {
      /**
       * 阴影范围适配视锥体。
       * 更稳定，可能降低阴影精度。
       */
      EShadowFitMode[EShadowFitMode["FitFrustum"] = 0] = "FitFrustum";
      /**
       * 阴影范围适配物体。
       * 能提高阴影精度，但可能会导致阴影不稳定。
       */
      EShadowFitMode[EShadowFitMode["FitObjects"] = 1] = "FitObjects";
  })(exports.EShadowFitMode || (exports.EShadowFitMode = {}));
  /**
   * 顶点数据布局用途枚举。
   */
  exports.EVertexLayoutUsage = void 0;
  (function (EVertexLayoutUsage) {
      EVertexLayoutUsage[EVertexLayoutUsage["CUSTOM"] = 0] = "CUSTOM";
      EVertexLayoutUsage[EVertexLayoutUsage["POSITION"] = 1] = "POSITION";
      EVertexLayoutUsage[EVertexLayoutUsage["NORMAL"] = 2] = "NORMAL";
      EVertexLayoutUsage[EVertexLayoutUsage["TANGENT"] = 3] = "TANGENT";
      EVertexLayoutUsage[EVertexLayoutUsage["UV0"] = 4] = "UV0";
      EVertexLayoutUsage[EVertexLayoutUsage["UV1"] = 5] = "UV1";
      EVertexLayoutUsage[EVertexLayoutUsage["UV2"] = 6] = "UV2";
      EVertexLayoutUsage[EVertexLayoutUsage["UV3"] = 7] = "UV3";
      EVertexLayoutUsage[EVertexLayoutUsage["COLOR"] = 8] = "COLOR";
      EVertexLayoutUsage[EVertexLayoutUsage["BONEINDEX"] = 9] = "BONEINDEX";
      EVertexLayoutUsage[EVertexLayoutUsage["BONEWEIGHT"] = 10] = "BONEWEIGHT"; // 骨骼蒙皮权重
  })(exports.EVertexLayoutUsage || (exports.EVertexLayoutUsage = {}));
  /**
   * 动态合批操作符枚举。
   */
  exports.EVertexBatchOperator = void 0;
  (function (EVertexBatchOperator) {
      /**
       * 矩阵乘法。
       */
      EVertexBatchOperator[EVertexBatchOperator["MatrixMultiple"] = 0] = "MatrixMultiple";
      /**
       * Scale offset。
       */
      EVertexBatchOperator[EVertexBatchOperator["UVST"] = 1] = "UVST";
  })(exports.EVertexBatchOperator || (exports.EVertexBatchOperator = {}));
  exports.EAnimationBlendType = void 0;
  (function (EAnimationBlendType) {
      EAnimationBlendType[EAnimationBlendType["Override"] = 0] = "Override";
      EAnimationBlendType[EAnimationBlendType["Additive"] = 1] = "Additive";
  })(exports.EAnimationBlendType || (exports.EAnimationBlendType = {}));
  exports.EUseDefaultAddedAction = void 0;
  (function (EUseDefaultAddedAction) {
      EUseDefaultAddedAction[EUseDefaultAddedAction["Ignore"] = 0] = "Ignore";
      EUseDefaultAddedAction[EUseDefaultAddedAction["Refresh"] = 1] = "Refresh";
  })(exports.EUseDefaultAddedAction || (exports.EUseDefaultAddedAction = {}));
  exports.EUseDefaultRetainedAction = void 0;
  (function (EUseDefaultRetainedAction) {
      EUseDefaultRetainedAction[EUseDefaultRetainedAction["Keep"] = 0] = "Keep";
      EUseDefaultRetainedAction[EUseDefaultRetainedAction["Refresh"] = 1] = "Refresh";
      EUseDefaultRetainedAction[EUseDefaultRetainedAction["WriteBack"] = 2] = "WriteBack";
  })(exports.EUseDefaultRetainedAction || (exports.EUseDefaultRetainedAction = {}));
  exports.EUseDefaultRemovedAction = void 0;
  (function (EUseDefaultRemovedAction) {
      EUseDefaultRemovedAction[EUseDefaultRemovedAction["Keep"] = 0] = "Keep";
      EUseDefaultRemovedAction[EUseDefaultRemovedAction["Clear"] = 1] = "Clear";
      EUseDefaultRemovedAction[EUseDefaultRemovedAction["WriteBack"] = 2] = "WriteBack";
  })(exports.EUseDefaultRemovedAction || (exports.EUseDefaultRemovedAction = {}));
  exports.ESkinnedSkeletonFlag = void 0;
  (function (ESkinnedSkeletonFlag) {
      ESkinnedSkeletonFlag[ESkinnedSkeletonFlag["Use3x4Matrix"] = 1] = "Use3x4Matrix";
      ESkinnedSkeletonFlag[ESkinnedSkeletonFlag["UseTextureMatrix"] = 2] = "UseTextureMatrix";
  })(exports.ESkinnedSkeletonFlag || (exports.ESkinnedSkeletonFlag = {}));
  /*---------------- Constants ----------------*/
  var RENDER_ENV_OFFSETS = {
      size: 21,
      resetFlag: 0,
      renderPass: 1,
      canvasWidth: 2,
      canvasHeight: 3,
      uniforms: 4,
      // bit0: useInstance, bit1: NeverTranspose
      useInstanceOrNeverTranspose: 20
  };
  var POOL_SUB_ID_MASK = 0xFFC0;
  var POOL_SUB_ID_SHIT = 6;
  var ENTITY2D_OFFSETS = {
      size: 14,
      rotation: 0,
      position: 1,
      scale: 3,
      worldMatrix: 5
  };
  var ENTITY3D_OFFSETS = {
      size: 27,
      // bool
      dfRotationType: 1,
      rotationType: 0,
      rotation: 1,
      position: 5,
      scale: 8,
      worldOffset: 11,
      worldMatrix: 11
  };
  var ENTITY3D_EXT_OFFSETS = {
      size: 2,
      layer: 0,
      mixedLayerMask: 1
  };
  var CULLING_OFFSETS = {
      size: 7,
      active: 0,
      // bool
      dfActive: 1,
      layer: 1,
      boundingBallCenter: 2,
      boundingBallRadius: 5,
      entityId: 6
  };
  var CAMERA_OFFSETS = {
      size: 147,
      view: 0,
      depth: 1,
      // bool
      active: 2,
      fov: 3,
      aspect: 4,
      near: 5,
      far: 6,
      up: 7,
      eye: 10,
      orthoSize: 13,
      // bool
      isProjection: 14,
      cullingMask: 15,
      canvasSizeY: 16,
      targetTransform: 17,
      // matrix
      viewMatrix: 18,
      projectionMatrix: 34,
      viewMatrixInverse: 50,
      viewMatrix2D: 66,
      projectionMatrix2D: 82,
      viewMatrixInverse2D: 98,
      // bit0 is projection, bit1 is view
      manualMatrix: 114,
      layerCullDistances: 115
  };
  var LIGHT_OFFSETS = {
      size: 78,
      view: 0,
      depth: 1,
      // bool
      active: 2,
      shadowDistance: 3,
      shadowMode: 4,
      shadowFilterMode: 5,
      lightDir: 6,
      bounds: 9,
      lightSpaceMatrices: 14
  };
  var MESH_OFFSETS = {
      dynamicBatch: 0,
      skinHandle: 1,
      castShadow: 2,
      bindTarget: 3,
      // per sub mesh
      start: 4,
      size: 5,
      materialId: 0,
      vertexBufferId: 1,
      indexBufferId: 2,
      startIndex: 3,
      numIndices: 4
  };
  var EFFECT_OFFSETS = {
      // per pass
      size: 6,
      useMaterialStates: 0,
      fstencil: 1,
      bstencil: 2,
      blendRGBA: 3,
      colorDepth: 4,
      state: 5
  };
  var MATERIAL_OFFSETS = {
      size: 14,
      renderQueue: 0,
      effect: 1,
      uniformBlock: 2,
      fstencilMask: 3,
      bstencilMask: 4,
      blendRGBAMask: 5,
      colorDepthMask: 6,
      stateMask: 7,
      fstencil: 8,
      bstencil: 9,
      blendRGBA: 10,
      colorDepth: 11,
      state: 12,
      useInstance: 13
  };
  var SKINNED_SKELETON_OFFSETS = {
      boneInverseModelId: 0,
      boneIndices: 1,
      perBoneIndices: 1,
      perBoneEntityId: 1,
      perBoneMatrixOld: 16,
      perBoneMatrixNew: 12
  };
  var DYNAMIC_BONES_OFFSETS = {
      stiffness: 0,
      elasticity: 1,
      damping: 2
  };
  /*---------------- Event Bridge ----------------*/
  exports.EEventType = void 0;
  (function (EEventType) {
      EEventType[EEventType["SetRootEntity"] = 1] = "SetRootEntity";
      EEventType[EEventType["AddChild"] = 2] = "AddChild";
      EEventType[EEventType["AddChildAtIndex"] = 3] = "AddChildAtIndex";
      EEventType[EEventType["RemoveFromParent"] = 4] = "RemoveFromParent";
      EEventType[EEventType["DisperseSubTree"] = 5] = "DisperseSubTree";
      EEventType[EEventType["BindToBone"] = 6] = "BindToBone";
      EEventType[EEventType["BindToBones"] = 7] = "BindToBones";
      EEventType[EEventType["UnBindFromBone"] = 8] = "UnBindFromBone";
      EEventType[EEventType["UnBindFromBones"] = 9] = "UnBindFromBones";
      EEventType[EEventType["EntityCommandActive"] = 10] = "EntityCommandActive";
      EEventType[EEventType["EntityCommandInActive"] = 11] = "EntityCommandInActive";
  })(exports.EEventType || (exports.EEventType = {}));
  /*---------------- Draco ----------------*/
  exports.EDracoErrorCode = void 0;
  (function (EDracoErrorCode) {
      EDracoErrorCode[EDracoErrorCode["kDecodeErrorNone"] = 0] = "kDecodeErrorNone";
      EDracoErrorCode[EDracoErrorCode["kDecodeErrorDecodeGeometryType"] = 1] = "kDecodeErrorDecodeGeometryType";
      EDracoErrorCode[EDracoErrorCode["kDecodeErrorDracoDecode"] = 2] = "kDecodeErrorDracoDecode";
      EDracoErrorCode[EDracoErrorCode["kDecodeErrorAttributeEmpty"] = 3] = "kDecodeErrorAttributeEmpty";
      EDracoErrorCode[EDracoErrorCode["kDecodeErrorAttributeSizeNotEqual"] = 4] = "kDecodeErrorAttributeSizeNotEqual";
      EDracoErrorCode[EDracoErrorCode["kDecodeErrorDecodeTypeError"] = 5] = "kDecodeErrorDecodeTypeError";
  })(exports.EDracoErrorCode || (exports.EDracoErrorCode = {}));
  exports.EDracoGeometryType = void 0;
  (function (EDracoGeometryType) {
      EDracoGeometryType[EDracoGeometryType["kGeometryTypeInvalid"] = -1] = "kGeometryTypeInvalid";
      EDracoGeometryType[EDracoGeometryType["kGeometryTypeTriangleMesh"] = 0] = "kGeometryTypeTriangleMesh";
      EDracoGeometryType[EDracoGeometryType["kGeometryTypePointCloud"] = 1] = "kGeometryTypePointCloud";
  })(exports.EDracoGeometryType || (exports.EDracoGeometryType = {}));
  exports.EDracoDecodeType = void 0;
  (function (EDracoDecodeType) {
      EDracoDecodeType[EDracoDecodeType["kDecodeTypeCross"] = 0] = "kDecodeTypeCross";
      // kDecodeTypeSegment, // unimplemented
  })(exports.EDracoDecodeType || (exports.EDracoDecodeType = {}));
  exports.EDracoDataType = void 0;
  (function (EDracoDataType) {
      EDracoDataType[EDracoDataType["DT_INVALID"] = 0] = "DT_INVALID";
      EDracoDataType[EDracoDataType["DT_INT8"] = 1] = "DT_INT8";
      EDracoDataType[EDracoDataType["DT_UINT8"] = 2] = "DT_UINT8";
      EDracoDataType[EDracoDataType["DT_INT16"] = 3] = "DT_INT16";
      EDracoDataType[EDracoDataType["DT_UINT16"] = 4] = "DT_UINT16";
      EDracoDataType[EDracoDataType["DT_INT32"] = 5] = "DT_INT32";
      EDracoDataType[EDracoDataType["DT_UINT32"] = 6] = "DT_UINT32";
      EDracoDataType[EDracoDataType["DT_INT64"] = 7] = "DT_INT64";
      EDracoDataType[EDracoDataType["DT_UINT64"] = 8] = "DT_UINT64";
      EDracoDataType[EDracoDataType["DT_FLOAT32"] = 9] = "DT_FLOAT32";
      EDracoDataType[EDracoDataType["DT_FLOAT64"] = 10] = "DT_FLOAT64";
      EDracoDataType[EDracoDataType["DT_BOOL"] = 11] = "DT_BOOL";
      EDracoDataType[EDracoDataType["DT_TYPES_COUNT"] = 12] = "DT_TYPES_COUNT";
  })(exports.EDracoDataType || (exports.EDracoDataType = {}));

  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation.

  Permission to use, copy, modify, and/or distribute this software for any
  purpose with or without fee is hereby granted.

  THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
  REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
  INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
  LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
  OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
  PERFORMANCE OF THIS SOFTWARE.
  ***************************************************************************** */
  /* global Reflect, Promise */

  var extendStatics = function(d, b) {
      extendStatics = Object.setPrototypeOf ||
          ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
          function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
      return extendStatics(d, b);
  };

  function __extends(d, b) {
      extendStatics(d, b);
      function __() { this.constructor = d; }
      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  }

  function __spreadArrays() {
      for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
      for (var r = Array(s), k = 0, i = 0; i < il; i++)
          for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
              r[k] = a[j];
      return r;
  }

  var hasNativeConsole = typeof wxNativeConsole !== 'undefined';
  // 开放数据域没有Reporter
  var hasReporter = typeof Reporter !== 'undefined';
  var libVersion = 
  // @ts-ignore
  typeof __libVersionInfo__ !== 'undefined' && __libVersionInfo__ ? __libVersionInfo__.version : 'unknown';
  var libUpdateTime = 
  // @ts-ignore
  typeof __libVersionInfo__ !== 'undefined' && __libVersionInfo__ ? __libVersionInfo__.updateTime : 'unknown';
  if (typeof libVersion === 'string') {
      libVersion = libVersion.replace(' ', '');
  }
  if (typeof libUpdateTime === 'string') {
      libUpdateTime = libUpdateTime.replace(' ', '-');
  }
  var libStr = libVersion + "," + libUpdateTime;
  var EEReportScope;
  (function (EEReportScope) {
      EEReportScope[EEReportScope["Default"] = 1000] = "Default";
  })(EEReportScope || (EEReportScope = {}));
  function escapeMsg(s) {
      return s.replace(/,/g, '，');
  }
  var logger = {
      backendVersion: 0,
      backendCommit: 'BeforeInit',
      // 同一设备同一小程序周期，必然一致
      init: function (backendVersion, backendCommit) {
          this.backendVersion = backendVersion[0] << 16 + backendVersion[1];
          this.backendCommit = backendCommit;
      },
      info: function () {
          var args = [];
          for (var _i = 0; _i < arguments.length; _i++) {
              args[_i] = arguments[_i];
          }
          hasNativeConsole && (wxNativeConsole === null || wxNativeConsole === void 0 ? void 0 : wxNativeConsole.log.apply(wxNativeConsole, __spreadArrays(['[kanata]'], args)));
          console.log.apply(console, __spreadArrays(['[kanata]'], args));
      },
      warn: function () {
          var args = [];
          for (var _i = 0; _i < arguments.length; _i++) {
              args[_i] = arguments[_i];
          }
          hasNativeConsole && (wxNativeConsole === null || wxNativeConsole === void 0 ? void 0 : wxNativeConsole.warn.apply(wxNativeConsole, __spreadArrays(['[kanata]'], args)));
          console.warn.apply(console, __spreadArrays(['[kanata]'], args));
      },
      error: function (error) {
          var args = [];
          for (var _i = 1; _i < arguments.length; _i++) {
              args[_i - 1] = arguments[_i];
          }
          if (typeof error === 'string') {
              error = new Error(error);
          }
          hasNativeConsole && (wxNativeConsole === null || wxNativeConsole === void 0 ? void 0 : wxNativeConsole.error.apply(wxNativeConsole, __spreadArrays(['[kanata]', error], args)));
          console.error.apply(console, __spreadArrays(['[kanata]', error], args));
          // #if defined(NATIVE)
          if (hasReporter) {
              var msg = this.backendVersion + "," + escapeMsg(this.backendCommit) + "," + EEReportScope.Default + ",1," + escapeMsg(error.message) + "," + escapeMsg(error.stack);
              Reporter.reportKeyValue({ key: 'XR_FRAME', value: msg + ",1," + libStr });
          }
          // #endif
      }
  };

  /**
   * INativeWorker.ts
   *
   * @Author  : hikaridai(hikaridai@tencent.com)
   * @Date    : 12/3/2020, 4:31:17 PM
  */
  var ctx = MAIN_CANVAS.getContext('wgfx', {
      bufferPoolSize: 40960,
      shaderPoolSize: 5120,
      imagePoolSize: 40960,
      pipelinePoolSize: 1024,
      passPoolSize: 1024,
      stencil: true,
      alpha: ENGINE_MODE === 'Editor' || ENGINE_SETTINGS.alpha === true,
      antialias: ENGINE_SETTINGS.mainScreenMSAA || false,
      preserveDrawingBuffer: true,
      ignore_assert: !!ENGINE_SETTINGS.gfxIgnoreAssert,
      disable_log: ENGINE_MODE !== 'Editor'
  });
  // 工具的engine在引擎域名运行，所以在调试模式下（knanta/engine打包在一起的情况下）
  // NativeGlobal是不存在的，要向上找一个window.top
  var Puppet$1;
  var Phys3D$1;
  //@ts-ignore
  if (typeof window !== 'undefined' && window.top) {
      //@ts-ignore
      Puppet$1 = (window.top.NativeGlobal || {}).Puppet;
      //@ts-ignore
      Phys3D$1 = (window.top.NativeGlobal || {}).Phys3D;
  }
  else if (typeof NativeGlobal !== 'undefined') {
      Puppet$1 = NativeGlobal.Puppet;
      Phys3D$1 = NativeGlobal.Phys3D;
  }
  else {
      Puppet$1 = ((wx === null || wx === void 0 ? void 0 : wx.NativeGlobal) || {}).Puppet;
      Phys3D$1 = ((wx === null || wx === void 0 ? void 0 : wx.NativeGlobal) || {}).Phys3D;
  }
  if (!Puppet$1) {
      logger.error("Puppet is not exist !");
  }
  if (!Phys3D$1) {
      logger.error("Phys3D is not exist !");
  }
  if (!(ctx === null || ctx === void 0 ? void 0 : ctx.gfx)) {
      logger.error("Get gfx context error: hasCTX(" + !!ctx + "), hasGFX(" + !!(ctx === null || ctx === void 0 ? void 0 : ctx.gfx) + ")!");
  }
  var w = undefined;
  // 子域不需要Context，直接复用主域的
  if (Puppet$1 && ((ctx && ctx.gfx) || IS_SUB_CONTEXT)) {
      w = new Puppet$1(ctx === null || ctx === void 0 ? void 0 : ctx.gfx, HOST, IS_SUB_CONTEXT);
      if (!w) {
          logger.error("puppet instance create failed !");
      }
      else {
          logger.init(w.getRenderEnv().version.split('.').map(function (s) { return parseInt(s, 10); }), w.getRenderEnv().commit_version);
      }
  }
  var worker$u = w || {};
  var native = { worker: worker$u };
  function destroy$1() {
      var _a, _b;
      native.worker.submit();
      (_b = (_a = native.worker).destroy) === null || _b === void 0 ? void 0 : _b.call(_a);
      native.worker = undefined;
  }
  function GET_MAIN_CANVAS$1() {
      return MAIN_CANVAS;
  }
  function IS_VALID$1() {
      return !!w;
  }

  /**
   * bufferManager.ts
   *
   * @Author  : hikaridai(hikaridai@tencent.com)
   * @Date    : 12/3/2020, 5:23:28 PM
   */
  var BufferManager = /** @class */ (function () {
      function BufferManager(delay) {
          this._queues = [];
          this._end = 0;
          this._end = delay;
          for (var index = 0; index <= delay; index += 1) {
              this._queues.push([]);
          }
      }
      BufferManager.prototype.add = function (res) {
          this._queues[0].push(res);
      };
      BufferManager.prototype.step = function () {
          var lastQueue = this._queues[this._end];
          lastQueue.splice(0, lastQueue.length);
          for (var index = this._end; index > 0; index -= 1) {
              this._queues[index] = this._queues[index - 1];
          }
          this._queues[0] = lastQueue;
      };
      BufferManager.prototype.clear = function () {
          this._queues.length = 0;
      };
      return BufferManager;
  }());
  var bufferManager = new BufferManager(5);

  var downloader$1 = {
      // #if defined(NATIVE)
      inWX: true,
      // #endif
      REAL_DOWNLOADER: null,
      LOAD: function (options) {
          return downloader$1.REAL_DOWNLOADER.load(options);
      }
  };

  /**
   * EventBase.ts
   *
   * @Author  : hikaridai(hikaridai@tencent.com)
   * @Date    : 9/4/2020, 1:23:32 PM
   */
  var SIZE_UINT32$1 = 4;
  var OFFSET_COMMAND_LENGTH = 0;
  var EventBase = /** @class */ (function () {
      function EventBase(buffer) {
          this._bufferSize = 0;
          if (buffer) {
              this.buffer = buffer;
              this._u32view = new Uint32Array(this.buffer, 0, this.buffer.byteLength / 4);
              this._bufferSize = this.buffer.byteLength;
          }
      }
      Object.defineProperty(EventBase.prototype, "commandOffset", {
          get: function () {
              return this._u32view[OFFSET_COMMAND_LENGTH];
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(EventBase.prototype, "commandOffsetUint32", {
          get: function () {
              return this._u32view[OFFSET_COMMAND_LENGTH] / SIZE_UINT32$1;
          },
          enumerable: false,
          configurable: true
      });
      EventBase.prototype._checkBufferSize = function (size) {
          if (this._u32view[OFFSET_COMMAND_LENGTH] + size + 1 > this._u32view.length) {
              native === null || native === void 0 ? void 0 : native.worker.refreshNodesWorldTransform();
          }
      };
      EventBase.prototype.setCommandSize = function (val) {
          this._u32view[OFFSET_COMMAND_LENGTH] = val;
      };
      return EventBase;
  }());

  var MainEventBridge = /** @class */ (function (_super) {
      __extends(MainEventBridge, _super);
      function MainEventBridge() {
          return _super.call(this, native === null || native === void 0 ? void 0 : native.worker.eventBusSM) || this;
      }
      MainEventBridge.prototype.setRootEntity = function (entityId) {
          var size = 2 * SIZE_UINT32$1;
          this._checkBufferSize(size);
          var offset = this._u32view[OFFSET_COMMAND_LENGTH] / SIZE_UINT32$1 + 1;
          this._u32view[offset] = exports.EEventType.SetRootEntity;
          this._u32view[offset + 1] = entityId;
          this.setCommandSize(this._u32view[OFFSET_COMMAND_LENGTH] + size);
      };
      MainEventBridge.prototype.addChild = function (entityId, childEntityId) {
          var size = 3 * SIZE_UINT32$1;
          this._checkBufferSize(size);
          var offset = this._u32view[OFFSET_COMMAND_LENGTH] / SIZE_UINT32$1 + 1;
          this._u32view[offset] = exports.EEventType.AddChild;
          this._u32view[offset + 1] = entityId;
          this._u32view[offset + 2] = childEntityId;
          this.setCommandSize(this._u32view[OFFSET_COMMAND_LENGTH] + size);
      };
      MainEventBridge.prototype.addChildAtIndex = function (entityId, childEntityId, index) {
          var size = 4 * SIZE_UINT32$1;
          this._checkBufferSize(size);
          var offset = this._u32view[OFFSET_COMMAND_LENGTH] / SIZE_UINT32$1 + 1;
          this._u32view[offset] = exports.EEventType.AddChildAtIndex;
          this._u32view[offset + 1] = entityId;
          this._u32view[offset + 2] = childEntityId;
          this._u32view[offset + 3] = index;
          this.setCommandSize(this._u32view[OFFSET_COMMAND_LENGTH] + size);
      };
      MainEventBridge.prototype.removeFromParent = function (entityId) {
          var size = 2 * SIZE_UINT32$1;
          this._checkBufferSize(size);
          var offset = this._u32view[OFFSET_COMMAND_LENGTH] / SIZE_UINT32$1 + 1;
          this._u32view[offset] = exports.EEventType.RemoveFromParent;
          this._u32view[offset + 1] = entityId;
          this.setCommandSize(this._u32view[OFFSET_COMMAND_LENGTH] + size);
      };
      MainEventBridge.prototype.disperseSubTree = function (entityId) {
          var size = 2 * SIZE_UINT32$1;
          this._checkBufferSize(size);
          var offset = this._u32view[OFFSET_COMMAND_LENGTH] / SIZE_UINT32$1 + 1;
          this._u32view[offset] = exports.EEventType.DisperseSubTree;
          this._u32view[offset + 1] = entityId;
          this.setCommandSize(this._u32view[OFFSET_COMMAND_LENGTH] + size);
      };
      MainEventBridge.prototype.bindToBone = function (entityId, boneId) {
          var size = 3 * SIZE_UINT32$1;
          this._checkBufferSize(size);
          var offset = this._u32view[OFFSET_COMMAND_LENGTH] / SIZE_UINT32$1 + 1;
          this._u32view[offset] = exports.EEventType.BindToBone;
          this._u32view[offset + 1] = entityId;
          this._u32view[offset + 2] = boneId;
          this.setCommandSize(this._u32view[OFFSET_COMMAND_LENGTH] + size);
      };
      MainEventBridge.prototype.unbindFromBone = function (entityId) {
          var size = 2 * SIZE_UINT32$1;
          this._checkBufferSize(size);
          var offset = this._u32view[OFFSET_COMMAND_LENGTH] / SIZE_UINT32$1 + 1;
          this._u32view[offset] = exports.EEventType.UnBindFromBone;
          this._u32view[offset + 1] = entityId;
          this.setCommandSize(this._u32view[OFFSET_COMMAND_LENGTH] + size);
      };
      MainEventBridge.prototype.entityCommandActive = function (entityId) {
          var size = 2 * SIZE_UINT32$1;
          this._checkBufferSize(size);
          var offset = this._u32view[OFFSET_COMMAND_LENGTH] / SIZE_UINT32$1 + 1;
          this._u32view[offset] = exports.EEventType.EntityCommandActive;
          this._u32view[offset + 1] = entityId;
          this.setCommandSize(this._u32view[OFFSET_COMMAND_LENGTH] + size);
      };
      MainEventBridge.prototype.entityCommandInActive = function (entityId) {
          var size = 2 * SIZE_UINT32$1;
          this._checkBufferSize(size);
          var offset = this._u32view[OFFSET_COMMAND_LENGTH] / SIZE_UINT32$1 + 1;
          this._u32view[offset] = exports.EEventType.EntityCommandInActive;
          this._u32view[offset + 1] = entityId;
          this.setCommandSize(this._u32view[OFFSET_COMMAND_LENGTH] + size);
      };
      // 兼容旧版接口
      MainEventBridge.prototype.bindToBones = function (entities, bones) {
          var entitiesLength = entities.length;
          var size = (2 + entitiesLength * 2) * SIZE_UINT32$1;
          this._checkBufferSize(size);
          var offset = this._u32view[OFFSET_COMMAND_LENGTH] / SIZE_UINT32$1 + 1;
          this._u32view[offset] = exports.EEventType.BindToBones;
          this._u32view[offset + 1] = entitiesLength;
          for (var i = 0; i < entitiesLength; i++) {
              var entity = entities[i];
              var bone = bones[i];
              this._u32view[offset + 2 + i] = entity.id;
              this._u32view[offset + 2 + entitiesLength + i] = bone.id;
          }
          this.setCommandSize(this._u32view[OFFSET_COMMAND_LENGTH] + size);
      };
      MainEventBridge.prototype.unBindFromBones = function (entities) {
          var entitiesLength = entities.length;
          var size = (2 + entitiesLength) * SIZE_UINT32$1;
          this._checkBufferSize(size);
          var offset = this._u32view[OFFSET_COMMAND_LENGTH] / SIZE_UINT32$1 + 1;
          this._u32view[offset] = exports.EEventType.UnBindFromBones;
          this._u32view[offset + 1] = entitiesLength;
          for (var i = 0; i < entitiesLength; i++) {
              var entity = entities[i];
              this._u32view[offset + 2 + i] = entity.id;
          }
          this.setCommandSize(this._u32view[OFFSET_COMMAND_LENGTH] + size);
      };
      return MainEventBridge;
  }(EventBase));

  var DirtyEntitiesEventBridge = /** @class */ (function (_super) {
      __extends(DirtyEntitiesEventBridge, _super);
      function DirtyEntitiesEventBridge() {
          return _super.call(this, native === null || native === void 0 ? void 0 : native.worker.dirtyNodesSM) || this;
      }
      DirtyEntitiesEventBridge.prototype.addDirtyEntity = function (entity) {
          this._checkBufferSize(1);
          this._u32view[this._u32view[OFFSET_COMMAND_LENGTH] + 1] = entity;
          this.setCommandSize(this._u32view[OFFSET_COMMAND_LENGTH] + 1);
      };
      DirtyEntitiesEventBridge.prototype.addDirtyEntityId = function (entityId) {
          this._checkBufferSize(1);
          this._u32view[this._u32view[OFFSET_COMMAND_LENGTH] + 1] = entityId;
          this.setCommandSize(this._u32view[OFFSET_COMMAND_LENGTH] + 1);
      };
      DirtyEntitiesEventBridge.prototype.addDirtyEntities = function (entities, entitiesLength) {
          this._checkBufferSize(entitiesLength);
          if (entitiesLength > this._u32view.length) {
              var startIndex = this._u32view[OFFSET_COMMAND_LENGTH] + 1;
              var len = entitiesLength - (this._u32view.length - 1);
              for (var i = 0; i < len; i++) {
                  this._u32view[startIndex + i] = entities[i];
              }
              var resetLen = entitiesLength - len;
              for (var i = len; i < resetLen; i++) {
                  this.addDirtyEntityId(entities[i]);
              }
          }
          else {
              var len = entitiesLength;
              var startIndex = this._u32view[OFFSET_COMMAND_LENGTH] + 1;
              for (var i = 0; i < len; i++) {
                  this._u32view[startIndex + i] = entities[i];
              }
              this.setCommandSize(this._u32view[OFFSET_COMMAND_LENGTH] + len);
          }
      };
      DirtyEntitiesEventBridge.prototype.addDirtyEntitiesById = function (entityIds, entitiesLength) {
          this._checkBufferSize(entitiesLength);
          if (entitiesLength > this._u32view.length) {
              var startIndex = this._u32view[OFFSET_COMMAND_LENGTH] + 1;
              var len = entitiesLength - (this._u32view.length - 1);
              for (var i = 0; i < len; i++) {
                  this._u32view[startIndex + i] = entityIds[i];
              }
              var resetLen = entitiesLength - len;
              for (var i = len; i < resetLen; i++) {
                  this.addDirtyEntityId(entityIds[i]);
              }
          }
          else {
              var len = entitiesLength;
              var startIndex = this._u32view[OFFSET_COMMAND_LENGTH] + 1;
              for (var i = 0; i < len; i++) {
                  this._u32view[startIndex + i] = entityIds[i];
              }
              this.setCommandSize(this._u32view[OFFSET_COMMAND_LENGTH] + len);
          }
      };
      return DirtyEntitiesEventBridge;
  }(EventBase));

  var mainBridge = new MainEventBridge();
  var dirtyEntitiesBridge = new DirtyEntitiesEventBridge();
  var EventBridge = /** @class */ (function () {
      function EventBridge() {
      }
      /*
      * 节点相关方法
      */
      EventBridge.prototype.entityAddChild = function (entity, child) {
          mainBridge.addChild(entity, child);
      };
      EventBridge.prototype.entityAddChildAtIndex = function (entity, child, index) {
          mainBridge.addChildAtIndex(entity, child, index);
      };
      EventBridge.prototype.entityRemoveFromParent = function (entity) {
          mainBridge.removeFromParent(entity);
      };
      EventBridge.prototype.entityClear = function (entity) {
          mainBridge.disperseSubTree(entity);
      };
      EventBridge.prototype.entitySetActive = function (entity, active) {
          if (active) {
              mainBridge.entityCommandActive(entity);
          }
          else {
              mainBridge.entityCommandInActive(entity);
          }
      };
      EventBridge.prototype.entitySetLocalMatrixDirty = function (entity) {
          dirtyEntitiesBridge.addDirtyEntity(entity);
      };
      EventBridge.prototype.setRootEntity = function (entity) {
          mainBridge.setRootEntity(entity);
      };
      EventBridge.prototype.refreshWorldTransform = function () {
          native === null || native === void 0 ? void 0 : native.worker.refreshNodesWorldTransform();
      };
      EventBridge.prototype.bindEntityToBone = function (entity, boneEntity) {
          mainBridge.bindToBone(entity.id, boneEntity.id);
      };
      EventBridge.prototype.unbindEntityFromBone = function (entity) {
          mainBridge.unbindFromBone(entity.id);
      };
      EventBridge.prototype.bindEntitiesToBones = function (entities, boneEntities) {
          mainBridge.bindToBones(entities, boneEntities);
      };
      EventBridge.prototype.unbindEntitiesFromBones = function (entities) {
          mainBridge.unBindFromBones(entities);
      };
      return EventBridge;
  }());
  var eventBridge$1 = new EventBridge();

  function isArrayBuffer(ab) {
      var _a, _b;
      return ((_a = ab) === null || _a === void 0 ? void 0 : _a.byteLength) !== undefined && !!((_b = ab) === null || _b === void 0 ? void 0 : _b.slice);
  }
  var Image$1 = /** @class */ (function () {
      function Image() {
          this._srcSet = false;
          this.isKanataImage = true;
          this.premultiplyAlpha = false;
          this.autoRelease = false;
      }
      Image.IS = function (obj) {
          return obj && obj.isKanataImage;
      };
      Object.defineProperty(Image.prototype, "data", {
          get: function () {
              var b = this._buffer;
              if (this.autoRelease) {
                  delete this._buffer;
              }
              return b;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Image.prototype, "localPath", {
          get: function () {
              return this._localPath;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Image.prototype, "src", {
          get: function () { return this._src; },
          set: function (v) {
              if (this._srcSet) {
                  logger.error("cannot set Image.src twice.");
                  return;
              }
              if (typeof v === "string") {
                  this._src = v;
                  this.createHttpImage(v);
                  this._srcSet = true;
              }
              else if (isArrayBuffer(v) || isArrayBuffer(v.buffer)) {
                  this._src = v;
                  this.createBufferImage(v, "buffer image");
                  this._srcSet = true;
              }
              else {
                  logger.error("Image.src can only be string or ArrayBuffer.");
              }
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Image.prototype, "width", {
          get: function () {
              return this._width;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Image.prototype, "height", {
          get: function () {
              return this._height;
          },
          enumerable: false,
          configurable: true
      });
      Image.prototype.createHttpImage = function (src) {
          var _this = this;
          downloader$1.LOAD({
              src: src,
              encoding: undefined,
              onLoad: function (res) {
                  _this._localPath = res.filePath;
                  _this.createBufferImage(res.data, src);
              },
              onError: function (error) {
                  _this.onerror && _this.onerror(error);
              }
          });
      };
      Image.prototype.createBufferImage = function (src, msg) {
          var _this = this;
          native === null || native === void 0 ? void 0 : native.worker.decodeImage(src, function (data, width, height) {
              if (!data) {
                  _this.onerror && _this.onerror(new Error("Decode Image error: '" + msg + "'"));
                  return;
              }
              _this._buffer = data;
              _this._width = width;
              _this._height = height;
              if (isArrayBuffer(_this._src)) {
                  _this._src = null;
              }
              _this.onload && _this.onload();
          }, this.premultiplyAlpha);
          bufferManager.add(src);
      };
      return Image;
  }());

  /**
   * commandArrays.ts
   *
   * @Author  : hikaridai(hikaridai@tencent.com)
   * @Date    : 1/6/2021, 4:26:46 PM
   */
  var DEAFAULT_BUFFER_SIZE = 1024;
  var SIZE_UINT32 = 4;
  var OFFSET_COMMANDLENGTH = 0;
  var CommandArray = /** @class */ (function () {
      function CommandArray(buffer) {
          this._bufferSize = 0;
          if (buffer) {
              this.buffer = buffer;
              this._u32view = new Uint32Array(this.buffer, 0, this.buffer.byteLength / 4);
              this._bufferSize = this.buffer.byteLength;
          }
          else {
              this.buffer = new ArrayBuffer(DEAFAULT_BUFFER_SIZE);
              this._u32view = new Uint32Array(this.buffer, 0, this.buffer.byteLength / 4);
              this._bufferSize = DEAFAULT_BUFFER_SIZE;
          }
      }
      Object.defineProperty(CommandArray.prototype, "commandOffset", {
          get: function () {
              return this._u32view[OFFSET_COMMANDLENGTH];
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(CommandArray.prototype, "commandOffsetUint32", {
          get: function () {
              return this._u32view[OFFSET_COMMANDLENGTH] / SIZE_UINT32;
          },
          enumerable: false,
          configurable: true
      });
      CommandArray.prototype._checkBufferSize = function (size) { };
      CommandArray.prototype.setCommandSize = function (val) {
          this._u32view[OFFSET_COMMANDLENGTH] = val;
      };
      return CommandArray;
  }());
  var SKIN_SCALE_SIZE = 2;
  var SKIN_SIZE_UINT32 = 4;
  var SkinningMatrixCommand = /** @class */ (function (_super) {
      __extends(SkinningMatrixCommand, _super);
      function SkinningMatrixCommand() {
          return _super !== null && _super.apply(this, arguments) || this;
      }
      SkinningMatrixCommand.prototype._checkBufferSize = function (size) {
          if (SKIN_SIZE_UINT32 + size > this._bufferSize) {
              var scaleSize = (SKIN_SIZE_UINT32 + size) * SKIN_SCALE_SIZE;
              this.buffer = new ArrayBuffer(scaleSize);
              this._u32view = new Uint32Array(this.buffer, 0, scaleSize / 4);
              this._bufferSize = scaleSize;
          }
      };
      SkinningMatrixCommand.prototype.updateSkinningMatrices = function (feObjects, length) {
          this._checkBufferSize(length * SKIN_SIZE_UINT32);
          var offset = 1;
          for (var i = 0; i < length; i++) {
              this._u32view[offset + i] = feObjects[i].id;
          }
          this.setCommandSize(length);
          return this._u32view;
      };
      return SkinningMatrixCommand;
  }(CommandArray));
  var ANIMATOR_SCALE_SIZE = 2;
  var ANIMATOR_SIZE_UINT32 = 4;
  var AnimatorCommand = /** @class */ (function (_super) {
      __extends(AnimatorCommand, _super);
      function AnimatorCommand() {
          return _super !== null && _super.apply(this, arguments) || this;
      }
      AnimatorCommand.prototype._checkBufferSize = function (size) {
          if (ANIMATOR_SIZE_UINT32 + size > this._bufferSize) {
              var scaleSize = (ANIMATOR_SIZE_UINT32 + size) * ANIMATOR_SCALE_SIZE;
              this.buffer = new ArrayBuffer(scaleSize);
              this._u32view = new Uint32Array(this.buffer, 0, scaleSize / 4);
              this._bufferSize = scaleSize;
          }
      };
      AnimatorCommand.prototype.updateAnimators = function (feObjects, length) {
          this._checkBufferSize(length * ANIMATOR_SIZE_UINT32);
          var offset = 1;
          for (var i = 0; i < length; i++) {
              this._u32view[offset + i] = feObjects[i].id;
          }
          this.setCommandSize(length);
          return this._u32view;
      };
      return AnimatorCommand;
  }(CommandArray));
  var ANIMATOR_CONTROLLER_SCALE_SIZE = 2;
  var ANIMATOR_CONTROLLER_SIZE_UINT32 = 4;
  var AnimatorControllerCommand = /** @class */ (function (_super) {
      __extends(AnimatorControllerCommand, _super);
      function AnimatorControllerCommand() {
          return _super !== null && _super.apply(this, arguments) || this;
      }
      AnimatorControllerCommand.prototype._checkBufferSize = function (size) {
          if (ANIMATOR_CONTROLLER_SIZE_UINT32 + size > this._bufferSize) {
              var scaleSize = (ANIMATOR_CONTROLLER_SIZE_UINT32 + size) * ANIMATOR_CONTROLLER_SCALE_SIZE;
              this.buffer = new ArrayBuffer(scaleSize);
              this._u32view = new Uint32Array(this.buffer, 0, scaleSize / 4);
              this._bufferSize = scaleSize;
          }
      };
      AnimatorControllerCommand.prototype.updateAnimatorControllers = function (feObjects, length) {
          this._checkBufferSize(length * ANIMATOR_CONTROLLER_SIZE_UINT32);
          var offset = 1;
          for (var i = 0; i < length; i++) {
              this._u32view[offset + i] = feObjects[i].id;
          }
          this.setCommandSize(length);
          return this._u32view;
      };
      return AnimatorControllerCommand;
  }(CommandArray));
  var skeletonCommand = new SkinningMatrixCommand();
  var animatorCommand = new AnimatorCommand();
  var animatorControllerCommand = new AnimatorControllerCommand();

  /**
   * index.ts
   *
   * @Author  : hikaridai(hikaridai@tencent.com)
   * @Date    : 2020/8/18 下午4:48:36
  */
  var hasWeakRef = typeof WeakRef !== 'undefined';
  var worker$t = {
      downloader: downloader$1,
      eventBridge: eventBridge$1,
      update: function (delta) {
          bufferManager.step();
      },
      destroy: function () {
          destroy$1();
          worker$t.downloader = undefined;
          worker$t.eventBridge = undefined;
          bufferManager.clear();
      },
      clearView: function (view) {
          return native === null || native === void 0 ? void 0 : native.worker.clearView(view.id);
      },
      cullCamera: function (camera, cullResult, lightMode) {
          return native === null || native === void 0 ? void 0 : native.worker.cullCamera(camera.id, cullResult.id, lightMode);
      },
      drawCamera: function (camera, renderList, lightMode) {
          return native === null || native === void 0 ? void 0 : native.worker.drawCamera(camera.id, renderList.id, lightMode);
      },
      drawLight: function (light, camera, renderList, lightMode) {
          return native === null || native === void 0 ? void 0 : native.worker.drawLight(light.id, camera.id, renderList.id, lightMode);
      },
      submit: function () {
          return native === null || native === void 0 ? void 0 : native.worker.submit();
      },
      createScalableList: function (initSize, onBackendEnlarge) {
          return native === null || native === void 0 ? void 0 : native.worker.createScalableList(initSize, onBackendEnlarge);
      },
      createNodePool: function (count, is3d) {
          return native === null || native === void 0 ? void 0 : native.worker.createNodePool(count, is3d);
      },
      createNodeTree: function (length, ids, buffer, calculateWordMatrix, is3d) {
          return native === null || native === void 0 ? void 0 : native.worker.createNodeTree(length, ids, buffer, calculateWordMatrix, is3d);
      },
      createVertexLayout: function (options) {
          return native === null || native === void 0 ? void 0 : native.worker.createVertexLayout(JSON.stringify(options));
      },
      createVertexDataDescriptor: function (options) {
          return native === null || native === void 0 ? void 0 : native.worker.createVertexDataDescriptor(JSON.stringify(options));
      },
      createVertexBuffer: function (buffer, layout) {
          bufferManager.add(buffer);
          return native === null || native === void 0 ? void 0 : native.worker.createVertexBuffer(buffer, layout.id);
      },
      updateVertexBuffer: function (bufferHandle, buffer, offset) {
          bufferManager.add(buffer);
          return native === null || native === void 0 ? void 0 : native.worker.updateVertexBuffer(bufferHandle.id, buffer, offset);
      },
      createIndexBuffer: function (buffer, is32bits) {
          bufferManager.add(buffer);
          return native === null || native === void 0 ? void 0 : native.worker.createIndexBuffer(buffer, is32bits);
      },
      updateIndexBuffer: function (bufferHandle, buffer, offset) {
          bufferManager.add(buffer);
          return native === null || native === void 0 ? void 0 : native.worker.updateIndexBuffer(bufferHandle.id, buffer, offset);
      },
      createVertexData: function (layout, size, batchDesc) {
          return native === null || native === void 0 ? void 0 : native.worker.createVertexData(layout.id, size, batchDesc.id);
      },
      createIndexData: function (size) {
          return native === null || native === void 0 ? void 0 : native.worker.createIndexData(size);
      },
      createTexture: function (type, width, height, slice, mips, format, flags, source, offsets) {
          source && source.forEach(function (ele, i) {
              ele = Image$1.IS(ele) ? ele.data : ele;
              source[i] = ele;
              bufferManager.add(ele);
          });
          return native === null || native === void 0 ? void 0 : native.worker.createTexture(type, width, height, slice, mips, format, flags, source, offsets);
      },
      createAutoUpdateTextureFromCanvas: function (canvas) {
          return native === null || native === void 0 ? void 0 : native.worker.createTexture(canvas);
      },
      updateTexture: function (handle, level, slice, xoffset, yoffset, zoffset, width, height, buffer) {
          bufferManager.add(buffer);
          return native === null || native === void 0 ? void 0 : native.worker.updateTexture(handle.id, level, slice, xoffset, yoffset, zoffset, width, height, buffer);
      },
      updateTextureFlags: function (texture, flags) {
          return native === null || native === void 0 ? void 0 : native.worker.updateTextureFlags(texture.id, flags);
      },
      createUniformBlockDescriptor: function (descriptor) {
          return native === null || native === void 0 ? void 0 : native.worker.createUniformBlockDescriptor(JSON.stringify(descriptor));
      },
      createUniformBlock: function (descriptor) {
          return native === null || native === void 0 ? void 0 : native.worker.createUniformBlock(descriptor.id);
      },
      createEffect: function (name, passCount, keyIndexMap, passes, shaders, variants, useRuntimeMacros) {
          return native === null || native === void 0 ? void 0 : native.worker.createEffect(name, passCount, JSON.stringify(keyIndexMap), JSON.stringify(passes), shaders, JSON.stringify(variants), useRuntimeMacros ? 0x2 : 0);
      },
      createMaterial: function (macros) {
          return native === null || native === void 0 ? void 0 : native.worker.createMaterial(JSON.stringify(macros || {}));
      },
      changeMaterialMacros: function (material, macros) {
          return native === null || native === void 0 ? void 0 : native.worker.changeMaterialMacros(material.id, JSON.stringify(macros));
      },
      createView: function (view) {
          var opts = {
              passAction: view.passAction,
              viewport: view.viewport,
              scissor: view.scissor
          };
          return native === null || native === void 0 ? void 0 : native.worker.createView(JSON.stringify(opts));
      },
      updateViewRect: function (view, rect) {
          return native === null || native === void 0 ? void 0 : native.worker.updateViewRect(view.id, rect);
      },
      updateViewScissor: function (view, rect) {
          return native === null || native === void 0 ? void 0 : native.worker.updateViewScissor(view.id, rect);
      },
      createRenderPass: function (descriptor) {
          var opts = descriptor;
          opts.colors.forEach(function (c) {
              c.texture = c.texture.id;
          });
          opts.depth.texture = opts.depth.texture.id;
          opts.stencil.texture = opts.stencil.texture.id;
          return native === null || native === void 0 ? void 0 : native.worker.createRenderPass(JSON.stringify(descriptor));
      },
      createCullingComponentPool: function (count) {
          return native === null || native === void 0 ? void 0 : native.worker.createCullingComponentPool(count);
      },
      createRenderComponent: function (meshCount, 
      // per object, like 'lightMapOffset'
      uniformBlock, attachedNodeId, cullingCompId, meshRenderType, macros) {
          return native === null || native === void 0 ? void 0 : native.worker.createRenderComponent(meshCount, uniformBlock.id, attachedNodeId, cullingCompId, meshRenderType, JSON.stringify(macros || {}));
      },
      changeMeshMacros: function (mesh, macros) {
          return native === null || native === void 0 ? void 0 : native.worker.changeMeshMacros(mesh.id, JSON.stringify(macros));
      },
      createAnimator: function (clipCount, nodeCount) {
          return native === null || native === void 0 ? void 0 : native.worker.createAnimator(clipCount, nodeCount);
      },
      updateAnimators: function (feObjects, size) {
          var data = animatorCommand.updateAnimators(feObjects, size);
          bufferManager.add(data);
          return native === null || native === void 0 ? void 0 : native.worker.updateAnimators(data);
      },
      createAnimationClipBinding: function (clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, useDefaultAddedNodesAction, rootEntity) {
          var eLen = Math.min(entityArray.length - entityArrayOffset, entityArrayLength);
          var cLen = Math.min(clipArray.length - clipArrayOffset, clipArrayLength);
          var buffer = new ArrayBuffer(4 * (eLen + cLen));
          var view = new Uint32Array(buffer);
          var cursor = 0;
          for (var i = clipArrayOffset; i < cLen; i++) {
              view[cursor++] = clipArray[i] ? clipArray[i].id : 0;
          }
          for (var i = entityArrayOffset; i < eLen; i++) {
              view[cursor++] = entityArray[i] === null ? 0 : (typeof entityArray[i] === "number" ? entityArray[i] : entityArray[i].id);
          }
          bufferManager.add(buffer);
          return native === null || native === void 0 ? void 0 : native.worker.createAnimationClipBinding(buffer, 0, cLen, eLen, useDefaultAddedNodesAction, rootEntity.id);
      },
      rebindAnimationClipBinding: function (binding, clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, removeAction, retainedAction, addedAction, rootEntity) {
          var eLen = Math.min(entityArray.length - entityArrayOffset, entityArrayLength);
          var cLen = Math.min(clipArray.length - clipArrayOffset, clipArrayLength);
          var buffer = new ArrayBuffer(4 * (eLen + cLen));
          var view = new Uint32Array(buffer);
          var cursor = 0;
          for (var i = clipArrayOffset; i < cLen; i++) {
              view[cursor++] = clipArray[i] ? clipArray[i].id : 0;
          }
          for (var i = entityArrayOffset; i < eLen; i++) {
              view[cursor++] = entityArray[i] === null ? 0 : (typeof entityArray[i] === "number" ? entityArray[i] : entityArray[i].id);
          }
          bufferManager.add(buffer);
          return binding.rebind(buffer, 0, cLen, eLen, removeAction, retainedAction, addedAction, rootEntity.id);
      },
      updateAnimationClipBinding: function (binding, clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, removeAction, retainedAction, addedAction) {
          var eLen = Math.min(entityArray.length - entityArrayOffset, entityArrayLength);
          var cLen = Math.min(clipArray.length - clipArrayOffset, clipArrayLength);
          var buffer = new ArrayBuffer(4 * (eLen + cLen));
          var view = new Uint32Array(buffer);
          var cursor = 0;
          for (var i = clipArrayOffset; i < cLen; i++) {
              view[cursor++] = clipArray[i] ? clipArray[i].id : 0;
          }
          for (var i = entityArrayOffset; i < eLen; i++) {
              view[cursor++] = entityArray[i] === null ? 0 : (typeof entityArray[i] === "number" ? entityArray[i] : entityArray[i].id);
          }
          bufferManager.add(buffer);
          return binding.update(buffer, 0, cLen, eLen, removeAction, retainedAction, addedAction);
      },
      writeAnimationClipBindingDefaultValues: function (binding) {
          binding.writeDefaultValues();
      },
      createAnimatorControllerModel: function (layerCount) {
          return native === null || native === void 0 ? void 0 : native.worker.createAnimatorControllerModel(layerCount);
      },
      setAnimatorControllerModelMaskAtIndex: function (model, index, mask) {
          var nativeHandle = model;
          nativeHandle.setMaskAtIndex(index, mask.buffer, mask.offset, mask.length);
      },
      updateAnimatorControllerModel: function (model) {
          var nativeHandle = model;
          nativeHandle.update();
      },
      createAnimatorControllerStateModel: function (clipCount) {
          return native === null || native === void 0 ? void 0 : native.worker.createAnimatorControllerStateModel(clipCount);
      },
      updateAnimatorControllers: function (feObjects, size) {
          var data = animatorControllerCommand.updateAnimatorControllers(feObjects, size);
          bufferManager.add(data);
          native === null || native === void 0 ? void 0 : native.worker.updateAnimatorControllers(data);
      },
      createSkinning: function (boneCount, flag) {
          return native === null || native === void 0 ? void 0 : native.worker.createSkinning(boneCount, flag);
      },
      updateSkinnings: function (feObjects, size) {
          var data = skeletonCommand.updateSkinningMatrices(feObjects, size);
          bufferManager.add(data);
          return native === null || native === void 0 ? void 0 : native.worker.updateSkinnings(data);
      },
      createRenderCamera: function (attachedNodeId, isUI) {
          return native === null || native === void 0 ? void 0 : native.worker.createRenderCamera(attachedNodeId, isUI);
      },
      createLightCamera: function () {
          return native === null || native === void 0 ? void 0 : native.worker.createLightCamera();
      },
      createAnimationClipModel: function (buffer) {
          bufferManager.add(buffer);
          return native === null || native === void 0 ? void 0 : native.worker.createAnimationClipModel(buffer);
      },
      createBoneInverseModel: function (buffer) {
          bufferManager.add(buffer);
          return native === null || native === void 0 ? void 0 : native.worker.createBoneInverseModel(buffer);
      },
      createDynamicBones: function (rootNodeId) {
          return native === null || native === void 0 ? void 0 : native.worker.createDynamicBones(rootNodeId);
      },
      loadTTFFont: function (url, callback) {
          downloader$1.LOAD({
              src: url,
              encoding: undefined,
              onLoad: function (_a) {
                  var data = _a.data, filePath = _a.filePath;
                  bufferManager.add(data);
                  var fontFamily = native === null || native === void 0 ? void 0 : native.worker.loadTTFFont(data, filePath);
                  callback(fontFamily);
              },
              onError: function () {
                  callback('Arial');
              }
          });
      },
      getGlyphInfo: function (fontSetting, charCode) {
          var _italic = fontSetting.italic ? "italic " : " ";
          var _bold = fontSetting.bold ? "bold " : " ";
          return native === null || native === void 0 ? void 0 : native.worker.getGlyphInfo(("" + _italic + _bold + Math.floor(fontSetting.size) + "px " + fontSetting.fontFamily).trim(), charCode);
      },
      refreshNodesWorldTransform: function () {
          return native === null || native === void 0 ? void 0 : native.worker.refreshNodesWorldTransform();
      },
      getRenderEnv: function () {
          var re = native === null || native === void 0 ? void 0 : native.worker.getRenderEnv();
          var registerFallbackEffect = re.registerFallbackEffect.bind(re);
          re.registerFallbackEffect = function (lightMode, handle) {
              registerFallbackEffect(lightMode, (handle === null || handle === void 0 ? void 0 : handle.id) || 0);
          };
          if (re.changeMacros) {
              var changeMacros_1 = re.changeMacros.bind(re);
              re.changeMacros = function (macros) {
                  changeMacros_1(JSON.stringify(macros));
              };
          }
          else {
              re.changeMacros = function () { };
          }
          if (re.changeVirtualMacros) {
              var changeVirtualMacros_1 = re.changeVirtualMacros.bind(re);
              re.changeVirtualMacros = function (macros) {
                  changeVirtualMacros_1(JSON.stringify(macros));
              };
          }
          else {
              re.changeVirtualMacros = function () { };
          }
          if (re.setInternalInstanceInfo) {
              var setInternalInstanceInfo_1 = re.setInternalInstanceInfo.bind(re);
              re.setInternalInstanceInfo = function (type, info, ignored) {
                  setInternalInstanceInfo_1(type, JSON.stringify(info), JSON.stringify(ignored));
              };
          }
          else {
              re.setInternalInstanceInfo = function () { };
          }
          return re;
      },
      createWeakRef: function (wrapper) {
          return hasWeakRef ? new WeakRef(wrapper) : (native === null || native === void 0 ? void 0 : native.worker.createWeakRef) ? native === null || native === void 0 ? void 0 : native.worker.createWeakRef(wrapper) : { deref: function () { return wrapper; } };
      },
      createWeakRefSentry: function () {
          return (native === null || native === void 0 ? void 0 : native.worker.createWeakRefSentry) ? native === null || native === void 0 ? void 0 : native.worker.createWeakRefSentry() : {};
      },
      createNativeUUMap: function () {
          return native === null || native === void 0 ? void 0 : native.worker.createNativeUUMap();
      },
      createNativeSUMap: function () {
          return native === null || native === void 0 ? void 0 : native.worker.createNativeSUMap();
      },
      createNativeULUMap: function () {
          return native === null || native === void 0 ? void 0 : native.worker.createNativeULUMap();
      },
      decodeBase64: function (base64) {
          return native === null || native === void 0 ? void 0 : native.worker.decodeBase64(base64);
      },
      // debug
      setNodeName: function (id, name) {
          return native === null || native === void 0 ? void 0 : native.worker.setNodeName(id, name);
      },
      setRenderComponentName: function (handle, name) {
          return native === null || native === void 0 ? void 0 : native.worker.setRenderComponentName(handle.id, name);
      },
      debugPrint: function (msg) {
          return native === null || native === void 0 ? void 0 : native.worker.debugPrint(msg);
      },
      setGlobalPhysicSystem: function (system) { },
      bindRigidBodyToNode: function (rigidBody, nodeId) { },
      unbindRigidBody: function (rigidBody) { },
      bindCCTToNode: function (cc, nodeId) { },
      unbindCCT: function (cc) { },
      decodeDraco: function (buffer, decodeType) {
          return native === null || native === void 0 ? void 0 : native.worker.decodeDraco(buffer, decodeType);
      }
  };

  /**
   * index.ts
   *
   * @Author  : hikaridai(hikaridai@tencent.com)
   * @Date    : 9/3/2020, 8:45:18 PM
   */
  var backend = {};
  backend.IS_VALID = IS_VALID$1;
  backend.GET_MAIN_CANVAS = GET_MAIN_CANVAS$1;
  backend.worker = worker$t;
  backend.Image = Image$1;
  backend.Phys3D = Phys3D$1;

  /**
   * renderEnv.ts
   *
   * @Author  : hikaridai(hikaridai@tencent.com)
   * @Date    : 1/18/2021, 3:53:26 PM
   */
  var worker$s = backend.worker;
  var RenderEnv = /** @class */ (function () {
      function RenderEnv() {
          this._macros = {};
          this._virtualMacros = {};
          this._isWrongWrapMapping = false;
          this._isNotWrongEffectSort = false;
          this._isGoodInstance = false;
          this._isGoodPhysAndScalableList = false;
          this._isSizeDirty = false;
          this.useExtendedMemory = false;
          this._handle = this.__handle = worker$s.getRenderEnv();
          this.id = this._handle.id;
          this._uniformBlocks = [];
          this._u32View = new Uint32Array(this._handle.data);
          this._f32View = new Float32Array(this._handle.data);
          if (typeof this._handle.version === 'string') {
              this._version = this._handle.version.split('.').map(function (s) { return parseInt(s, 10); });
          }
          else if (this.backendType !== 'WEBGL') {
              this._version = [0, 0];
          }
          if (this._version) {
              this._isWrongWrapMapping = this._version[0] === 0;
              /* 1.2之后，不再需要乱排Effect */
              this._isNotWrongEffectSort = !((this._version[0] <= 1) && (this._version[1] < 2));
              /* 1.3之后，修复了Instance */
              this._isGoodInstance = !((this._version[0] <= 1) && (this._version[1] < 3));
              /* 1.6之后，修复了Phys3D和ScalableList */
              this._isGoodPhysAndScalableList = !((this._version[0] <= 1) && (this._version[1] < 6));
          }
          else {
              this._isNotWrongEffectSort = true;
              this._isGoodInstance = true;
              this._isGoodPhysAndScalableList = true;
          }
          /* 1.2之后，开启neverTranspose */
          if (this._isNotWrongEffectSort) {
              this.neverTranspose = true;
          }
      }
      Object.defineProperty(RenderEnv.prototype, "version", {
          get: function () {
              return this._version.slice();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(RenderEnv.prototype, "backendType", {
          get: function () {
              return this._handle.backendType;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(RenderEnv.prototype, "canvasWidth", {
          get: function () {
              return this._f32View[RENDER_ENV_OFFSETS.canvasWidth];
          },
          set: function (value) {
              this._isSizeDirty = false;
              this._f32View[RENDER_ENV_OFFSETS.canvasWidth] = value;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(RenderEnv.prototype, "canvasHeight", {
          get: function () {
              return this._f32View[RENDER_ENV_OFFSETS.canvasHeight];
          },
          set: function (value) {
              this._isSizeDirty = true;
              this._f32View[RENDER_ENV_OFFSETS.canvasHeight] = value;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(RenderEnv.prototype, "supportCompressTextures", {
          get: function () {
              return this._handle.supportCompressTextures;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(RenderEnv.prototype, "features", {
          get: function () {
              return this._handle.features || {};
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(RenderEnv.prototype, "commitVersion", {
          get: function () {
              return this._handle.commit_version;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(RenderEnv.prototype, "usePuppetSokol", {
          get: function () {
              return this._handle.use_puppet_sokol;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(RenderEnv.prototype, "useInstance", {
          get: function () {
              return !!(this._u32View[RENDER_ENV_OFFSETS.useInstanceOrNeverTranspose] & 1);
          },
          set: function (value) {
              var v = this._u32View[RENDER_ENV_OFFSETS.useInstanceOrNeverTranspose];
              this._u32View[RENDER_ENV_OFFSETS.useInstanceOrNeverTranspose] = value ? (v | 1) : (v & ~1);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(RenderEnv.prototype, "neverTranspose", {
          get: function () {
              return !!(this._u32View[RENDER_ENV_OFFSETS.useInstanceOrNeverTranspose] & 2);
          },
          set: function (value) {
              var v = this._u32View[RENDER_ENV_OFFSETS.useInstanceOrNeverTranspose];
              this._u32View[RENDER_ENV_OFFSETS.useInstanceOrNeverTranspose] = value ? (v | 2) : (v & ~2);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(RenderEnv.prototype, "isWrongWrapMapping", {
          get: function () {
              return this._isWrongWrapMapping;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(RenderEnv.prototype, "isNotWrongEffectSort", {
          get: function () {
              return this._isNotWrongEffectSort;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(RenderEnv.prototype, "isGoodInstance", {
          get: function () {
              return this._isGoodInstance;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(RenderEnv.prototype, "isGoodPhysAndScalableList", {
          get: function () {
              return this._isGoodPhysAndScalableList;
          },
          enumerable: false,
          configurable: true
      });
      RenderEnv.prototype.supportCompressTexture = function (type) {
          return this.supportCompressTextures.indexOf(type) >= 0;
      };
      RenderEnv.prototype.registerFallbackEffect = function (lightMode, effect) {
          this._handle.registerFallbackEffect(lightMode, effect === null || effect === void 0 ? void 0 : effect.__handle);
      };
      RenderEnv.prototype.beginFrame = function () {
          this._u32View[RENDER_ENV_OFFSETS.resetFlag] = 1;
      };
      RenderEnv.prototype.endFrame = function () {
          worker$s.submit();
      };
      RenderEnv.prototype.clearView = function (view) {
          // #if defined(NATIVE)
          // 子域不允许清主屏
          if (IS_SUB_CONTEXT && this._renderPass.id === 0) {
              return;
          }
          // hack 因为客户端只有drawCamera才会同步size
          this._isSizeDirty && worker$s.drawCamera({ id: 0 }, { id: 0 }, 'ForwardBase');
          this._isSizeDirty = false;
          // #endif
          worker$s.clearView(view.__handle);
      };
      RenderEnv.prototype.setEnvUniform = function (index, uniforms) {
          this._u32View[RENDER_ENV_OFFSETS.uniforms + index] = uniforms.id;
          this._uniformBlocks[index] = uniforms;
      };
      RenderEnv.prototype.setRenderPass = function (renderPass) {
          this._u32View[RENDER_ENV_OFFSETS.renderPass] = renderPass.id;
          this._renderPass = renderPass;
      };
      RenderEnv.prototype.changeMacros = function (macros) {
          Object.assign(this._macros, macros);
          this._handle.changeMacros(this._macros);
      };
      RenderEnv.prototype.getMacro = function (key) {
          var _a;
          return (_a = this._macros) === null || _a === void 0 ? void 0 : _a[key];
      };
      RenderEnv.prototype.changeVirtualMacros = function (macros) {
          Object.assign(this._virtualMacros, macros);
          this._handle.changeVirtualMacros(this._virtualMacros);
      };
      RenderEnv.prototype.getVirtualMacro = function (key) {
          return this._virtualMacros[key];
      };
      RenderEnv.prototype.setInternalInstanceInfo = function (type, info, ignored) {
          this._handle.setInternalInstanceInfo(type, info, ignored);
      };
      RenderEnv.prototype.getErrors = function () {
          var _a, _b;
          return (_b = (_a = this.__handle).getErrors) === null || _b === void 0 ? void 0 : _b.call(_a);
      };
      return RenderEnv;
  }());
  var renderEnv = new RenderEnv();

  var PureResource = /** @class */ (function () {
      function PureResource() {
      }
      Object.defineProperty(PureResource.prototype, "_handle", {
          get: function () {
              return this.__handle;
          },
          set: function (value) {
              this.__handle = value;
              this.id = value.id;
          },
          enumerable: false,
          configurable: true
      });
      PureResource.prototype.destroy = function () {
          if (this._handle.destroy) {
              this._handle.destroy();
          }
      };
      return PureResource;
  }());

  var worker$r = backend.worker;
  //@todo 由于客户端BUG，为了防止内存泄漏不能持有this
  var SL_MAP = new Set();
  function CHECK_SLS_RESIZE() {
      !renderEnv.isGoodPhysAndScalableList && SL_MAP.forEach(function (sl) { return sl._checkResize(); });
  }
  function CLEAR_SLS() {
      !renderEnv.isGoodPhysAndScalableList && SL_MAP.clear();
  }
  /**
   * 可扩容列表，用于存储Mesh的剔除结果以及绘制数据的id。
   */
  var ScalableList = /** @class */ (function (_super) {
      __extends(ScalableList, _super);
      function ScalableList(initSize) {
          var _this = _super.call(this) || this;
          _this._size = 0;
          _this._index = 0;
          _this._onBackendEnlarge = function () {
              _this._resized();
          };
          if (renderEnv.isGoodPhysAndScalableList) {
              _this._handle = worker$r.createScalableList(initSize, _this._onBackendEnlarge);
          }
          else {
              _this._handle = worker$r.createScalableList(initSize);
              SL_MAP.add(_this);
              _this._preData = _this._handle.data;
          }
          _this._resized();
          return _this;
      }
      Object.defineProperty(ScalableList.prototype, "size", {
          /**
           * 当前全部可用的大小。
           */
          get: function () {
              return this._size;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(ScalableList.prototype, "dataView", {
          /**
           * 存储的id集合。
           */
          get: function () {
              return this._u32View;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(ScalableList.prototype, "usedSize", {
          /**
           * 当前已用的大小，一般不需要自己设置。
           */
          get: function () {
              return this._sizeView[0] > this.size ? this.size : this._sizeView[0];
          },
          set: function (value) {
              this._sizeView[0] = value;
          },
          enumerable: false,
          configurable: true
      });
      /**
       * 扩容，将会扩大两倍，一般不需要自己调用。
       *
       * @param deprecatedSize will always be current size, don't use it!
       */
      ScalableList.prototype.enlarge = function (deprecatedSize) {
          this._handle.enlarge();
          this._resized();
      };
      /**
       * 初始化到准备`add`的阶段。
       */
      ScalableList.prototype.begin = function () {
          this._index = 0;
      };
      /**
       * 添加一个数据。
       *
       * @param deprecatedEnlargeSize will always be current size, don't use it!
       */
      ScalableList.prototype.add = function (id, deprecatedEnlargeSize) {
          if (this._index === this._size) {
              this.enlarge();
          }
          this._u32View[this._index++] = id;
      };
      /**
       * 结束此次所有`add`的流程。
       */
      ScalableList.prototype.end = function () {
          this._sizeView[0] = this._index;
      };
      /**
       * 清空整个列表。
       */
      ScalableList.prototype.reset = function () {
          this._sizeView[0] = 0;
      };
      ScalableList.prototype._checkResize = function () {
          if (this._preData.byteLength !== this._handle.data.byteLength) {
              this._resized();
              this._preData = this._handle.data;
          }
      };
      ScalableList.prototype._resized = function () {
          var size = this.__handle.data.byteLength / 4 - 1;
          this._u32View = new Uint32Array(this.__handle.data, 4);
          this._sizeView = new Uint32Array(this.__handle.data, 0, 1);
          this._size = size;
      };
      return ScalableList;
  }(PureResource));

  /**
   * 跨域信息通道，用于主域和子域之间的通信。
   */
  var CrossContext = /** @class */ (function () {
      function CrossContext() {
          var dataBuses = topExports['DATA_BUSES'] = topExports['DATA_BUSES'] || {};
          this._globalObj = dataBuses[HOST] = dataBuses[HOST] || [];
      }
      CrossContext.prototype.postMessage = function (data) {
          !IS_SUB_CONTEXT && this._globalObj.push(data);
      };
      CrossContext.prototype.onMessage = function (callback) {
          IS_SUB_CONTEXT && (this._callback = callback);
      };
      CrossContext.prototype.flush = function () {
          if (!IS_SUB_CONTEXT) {
              return;
          }
          for (var _i = 0, _a = this._globalObj; _i < _a.length; _i++) {
              var data = _a[_i];
              this._callback && this._callback(typeof data === 'string' ? JSON.parse(data) : data);
          }
          this._globalObj.length = 0;
      };
      return CrossContext;
  }());
  var crossContext;
  if (topExports) {
      crossContext = new CrossContext();
  }
  var crossContext$1 = crossContext;

  var NativeObject = /** @class */ (function () {
      function NativeObject() {
      }
      Object.defineProperty(NativeObject.prototype, "__handle", {
          get: function () {
              return this._handle;
          },
          enumerable: false,
          configurable: true
      });
      NativeObject.prototype._init = function (info) {
          this._fastInit(info);
      };
      NativeObject.prototype._fastInit = function (info) {
          this._handle = info;
          var id = info.id, buffer = info.data;
          var size = buffer.byteLength;
          var offset = 0;
          this._bufferLength = size;
          this._byteOffset = offset;
          this._buffer = buffer;
          this.id = id;
          this._f32view = new Float32Array(buffer, offset, size / 4);
      };
      NativeObject.prototype._initU32View = function () {
          this._u32view = new Uint32Array(this._buffer, this._byteOffset, this._bufferLength / 4);
      };
      /*
        给子类用的工具
      */
      NativeObject.prototype._initPropertyView = function (offset, length) {
          return new Float32Array(this._buffer, this._byteOffset + offset * 4, length);
      };
      NativeObject.prototype.setRawBuffer = function (data) {
          this._f32view.set(data);
      };
      NativeObject.prototype.destroy = function () {
          if (this._handle.destroy) {
              this._handle.destroy();
          }
      };
      return NativeObject;
  }());

  var worker$q = backend.worker;
  var AnimatorComponent = /** @class */ (function (_super) {
      __extends(AnimatorComponent, _super);
      function AnimatorComponent() {
          var _this = _super.call(this) || this;
          _this._offsetEntityIds = 0;
          _this._animationClipCount = 0;
          _this._nodeCount = 0;
          _this._handle = { id: 0 };
          return _this;
      }
      AnimatorComponent.UPDATE_ANIMATORS = function (animators, size) {
          worker$q.updateAnimators(animators, size);
      };
      AnimatorComponent.prototype.bindAnimations = function (animationClipModels, entities, rootEntity) {
          this.entities = entities;
          this.animationClipModels = animationClipModels;
          this.animationClipModels = animationClipModels;
          this._animationClipCount = animationClipModels.length;
          var nodesLength = entities.length;
          for (var i in entities) {
              nodesLength += entities[i].length;
          }
          this._nodeCount = nodesLength;
          var nativeObj = worker$q.createAnimator(animationClipModels.length, nodesLength);
          if (nativeObj.id < 0 || !nativeObj.data) {
              // 分配失败，返回避免报错
              return;
          }
          else {
              this._init(nativeObj);
              this._initU32View();
          }
          for (var i = 0; i < animationClipModels.length; i++) {
              this._u32view[i * 3] = animationClipModels[i].id;
          }
          this._offsetEntityIds = animationClipModels.length * 3;
          var nodeSum = 0;
          var existEntityId;
          for (var i = 0; i < entities.length; i++) {
              for (var j = 0; j < entities[i].length; j++) {
                  if (entities[i][j] !== null) {
                      this._u32view[this._offsetEntityIds + nodeSum + j] = entities[i][j].id;
                      if (!existEntityId) {
                          existEntityId = entities[i][j].id;
                      }
                  }
                  else {
                      this._u32view[this._offsetEntityIds + nodeSum + j] = 0;
                  }
                  this._u32view[this._offsetEntityIds + nodeSum + j] = (entities[i][j] !== null) ? entities[i][j].id : 0;
              }
              nodeSum += entities[i].length;
          }
          // 兼容第一位为空的情况
          if (this._u32view[this._offsetEntityIds] === 0) {
              if (rootEntity !== undefined && rootEntity.id) {
                  this._u32view[this._offsetEntityIds] = rootEntity.id;
              }
              else {
                  if (existEntityId) {
                      this._u32view[this._offsetEntityIds] = existEntityId;
                  }
              }
          }
      };
      AnimatorComponent.prototype.setClipParams = function (index, frameIndex, blendWeight) {
          if (!this._handle)
              return;
          var offsetBase = index * 3;
          this._f32view[offsetBase + 1] = Math.round(frameIndex);
          this._f32view[offsetBase + 2] = blendWeight;
      };
      AnimatorComponent.prototype.getAnimationClipCount = function () {
          return this._animationClipCount;
      };
      AnimatorComponent.prototype.getNodeCount = function () {
          return this._nodeCount;
      };
      AnimatorComponent.prototype.getAnimationParameter = function (index) {
          var offsetBase = index * 3;
          return {
              animationClipId: this._u32view[offsetBase],
              frameIndex: this._f32view[offsetBase + 1],
              percentage: this._f32view[offsetBase + 2]
          };
      };
      AnimatorComponent.prototype.getEntity = function (index) {
          return this._u32view[this._offsetEntityIds + index];
      };
      return AnimatorComponent;
  }(NativeObject));

  var worker$p = backend.worker;
  var CameraComponent = /** @class */ (function (_super) {
      __extends(CameraComponent, _super);
      function CameraComponent(entity, isUI) {
          var _this = _super.call(this) || this;
          var nativeObj = worker$p.createRenderCamera(entity.id, isUI || false);
          if (nativeObj.id < 0 || !nativeObj.data) {
              return _this;
          }
          else {
              _this._init(nativeObj);
              _this._initU32View();
              _this._layerCullDistances = new Float32Array(_this._buffer, CAMERA_OFFSETS.layerCullDistances * 4, 32);
              _this._f32view.set([0, 1, 0], CAMERA_OFFSETS.up);
              _this.fov = Math.PI * 0.33;
              _this.aspect = 16 / 9;
              _this.near = 0.1;
              _this.far = 100;
          }
          _this.isProjection = true;
          return _this;
      }
      Object.defineProperty(CameraComponent.prototype, "active", {
          get: function () {
              return !!this._u32view[CAMERA_OFFSETS.active];
          },
          set: function (value) {
              this._u32view[CAMERA_OFFSETS.active] = value ? 1 : 0;
              this._setDirty();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(CameraComponent.prototype, "depth", {
          get: function () {
              return this._u32view[CAMERA_OFFSETS.depth];
          },
          set: function (value) {
              this._u32view[CAMERA_OFFSETS.depth] = value < 0 ? 0 : value;
              this._setDirty();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(CameraComponent.prototype, "isProjection", {
          get: function () {
              return !!this._u32view[CAMERA_OFFSETS.isProjection];
          },
          set: function (value) {
              this._u32view[CAMERA_OFFSETS.isProjection] = value ? 1 : 0;
              this._setDirty();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(CameraComponent.prototype, "view", {
          get: function () {
              return this._view;
          },
          set: function (value) {
              this._view = value;
              this._u32view[CAMERA_OFFSETS.view] = value.id;
              this._setDirty();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(CameraComponent.prototype, "fov", {
          get: function () {
              return this._f32view[CAMERA_OFFSETS.fov];
          },
          set: function (value) {
              this._f32view[CAMERA_OFFSETS.fov] = value;
              this._setDirty();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(CameraComponent.prototype, "aspect", {
          get: function () {
              return this._f32view[CAMERA_OFFSETS.aspect];
          },
          set: function (value) {
              if (Math.abs(this._f32view[CAMERA_OFFSETS.aspect] - value) <= 0.0001) {
                  return;
              }
              this._f32view[CAMERA_OFFSETS.aspect] = value;
              this._setDirty();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(CameraComponent.prototype, "near", {
          get: function () {
              return this._f32view[CAMERA_OFFSETS.near];
          },
          set: function (value) {
              this._f32view[CAMERA_OFFSETS.near] = value;
              this._setDirty();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(CameraComponent.prototype, "far", {
          get: function () {
              return this._f32view[CAMERA_OFFSETS.far];
          },
          set: function (value) {
              this._f32view[CAMERA_OFFSETS.far] = value;
              this._setDirty();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(CameraComponent.prototype, "orthoSize", {
          get: function () {
              return this._f32view[CAMERA_OFFSETS.orthoSize];
          },
          set: function (value) {
              this._f32view[CAMERA_OFFSETS.orthoSize] = value;
              this._setDirty();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(CameraComponent.prototype, "cullingMask", {
          get: function () {
              return this._u32view[CAMERA_OFFSETS.cullingMask];
          },
          set: function (value) {
              this._u32view[CAMERA_OFFSETS.cullingMask] = value;
              this._setDirty();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(CameraComponent.prototype, "layerCullDistances", {
          get: function () {
              return this._layerCullDistances;
          },
          set: function (value) {
              this._layerCullDistances.set(value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(CameraComponent.prototype, "canvasSizeY", {
          // UI Camera Only
          get: function () {
              return this._f32view[CAMERA_OFFSETS.canvasSizeY];
          },
          set: function (value) {
              this._f32view[CAMERA_OFFSETS.canvasSizeY] = value;
              this._setDirty();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(CameraComponent.prototype, "targetTransform", {
          get: function () {
              return this._u32view[CAMERA_OFFSETS.targetTransform];
          },
          set: function (entityId) {
              this._u32view[CAMERA_OFFSETS.targetTransform] = entityId;
              this._setDirty();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(CameraComponent.prototype, "up", {
          set: function (vec3) {
              this._f32view.set(vec3, CAMERA_OFFSETS.up);
          },
          enumerable: false,
          configurable: true
      });
      CameraComponent.prototype.cull = function (cullResult, lightMode) {
          worker$p.cullCamera(this.__handle, cullResult.__handle, lightMode);
      };
      CameraComponent.prototype.draw = function (renderList, lightMode) {
          worker$p.drawCamera(this.__handle, renderList.__handle, lightMode);
      };
      CameraComponent.prototype.changeProjectionMatrix = function (manual, mat4) {
          if (manual) {
              this._f32view.set(mat4, CAMERA_OFFSETS.projectionMatrix);
              this._u32view[CAMERA_OFFSETS.manualMatrix] |= 1;
          }
          else {
              this._u32view[CAMERA_OFFSETS.manualMatrix] &= ~(1);
          }
          this._setDirty();
      };
      CameraComponent.prototype.changeViewMatrix = function (manual, mat4) {
          if (manual) {
              this._f32view.set(mat4, CAMERA_OFFSETS.viewMatrix);
              this._u32view[CAMERA_OFFSETS.manualMatrix] |= 2;
          }
          else {
              this._u32view[CAMERA_OFFSETS.manualMatrix] &= ~(2);
          }
          this._setDirty();
      };
      CameraComponent.prototype._setDirty = function () {
          this._handle.setSharedDirty();
      };
      CameraComponent.prototype.updateMatrix = function () {
          this._handle.updateMatrices();
      };
      // Buffer Offset in 4bytes
      CameraComponent.OFFSETS = CAMERA_OFFSETS;
      return CameraComponent;
  }(NativeObject));

  var worker$o = backend.worker;
  var LightCameraComponent = /** @class */ (function (_super) {
      __extends(LightCameraComponent, _super);
      function LightCameraComponent() {
          var _this = _super.call(this) || this;
          var nativeObj = worker$o.createLightCamera();
          if (nativeObj.id < 0 || !nativeObj.data) {
              return _this;
          }
          else {
              _this._init(nativeObj);
              _this._initU32View();
              _this._lightSpaceMatrices = new Float32Array(_this._buffer, LIGHT_OFFSETS.lightSpaceMatrices * 4, 64);
              _this._tilingOffsets = new Float32Array([1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0]);
              _this._cascadedSplits = new Float32Array(3);
              _this._farBounds = new Float32Array(_this._buffer, (LIGHT_OFFSETS.bounds + 1) * 4, 4);
              _this._bounds = new Float32Array(_this._buffer, LIGHT_OFFSETS.bounds * 4, 5);
          }
          return _this;
      }
      Object.defineProperty(LightCameraComponent.prototype, "view", {
          get: function () {
              return this._view;
          },
          set: function (value) {
              this._u32view[LIGHT_OFFSETS.view] = value.id;
              this._view = value;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(LightCameraComponent.prototype, "active", {
          get: function () {
              return !!this._u32view[LIGHT_OFFSETS.active];
          },
          set: function (value) {
              this._u32view[LIGHT_OFFSETS.active] = value ? 1 : 0;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(LightCameraComponent.prototype, "depth", {
          get: function () {
              return this._u32view[LIGHT_OFFSETS.depth];
          },
          set: function (value) {
              this._u32view[LIGHT_OFFSETS.depth] = value;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(LightCameraComponent.prototype, "shadowDistance", {
          get: function () {
              return this._f32view[LIGHT_OFFSETS.shadowDistance];
          },
          set: function (value) {
              this._f32view[LIGHT_OFFSETS.shadowDistance] = value;
              this._updateBounds(false);
              this._setDirty();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(LightCameraComponent.prototype, "shadowFilterMode", {
          get: function () {
              return this._u32view[LIGHT_OFFSETS.shadowFilterMode];
          },
          set: function (value) {
              this._u32view[LIGHT_OFFSETS.shadowFilterMode] = value;
              this._setDirty();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(LightCameraComponent.prototype, "shadowMode", {
          get: function () {
              return this._u32view[LIGHT_OFFSETS.shadowMode];
          },
          set: function (value) {
              this._u32view[LIGHT_OFFSETS.shadowMode] = value;
              this._tilingOffsets.set(value == exports.EShadowMode.TwoCascade_PCF || value == exports.EShadowMode.FourCascade_PCF
                  ? [0.5, 0.5, 0, 0, 0.5, 0.5, 0.5, 0, 0.5, 0.5, 0, 0.5, 0.5, 0.5, 0.5, 0.5]
                  : [1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0]);
              this._updateBounds(false);
              this._setDirty();
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(LightCameraComponent.prototype, "lightSpaceMatrices", {
          get: function () {
              return this._lightSpaceMatrices;
          },
          enumerable: false,
          configurable: true
      });
      LightCameraComponent.prototype.draw = function (camera, renderList, lightMode) {
          worker$o.drawLight(this.__handle, camera.__handle, renderList, lightMode);
      };
      LightCameraComponent.prototype.prepareUniforms = function (uniforms) {
          uniforms.setUniform('u_csmLightSpaceMatrices', this.lightSpaceMatrices);
          uniforms.setUniform('u_shadowTilingOffsets', this._tilingOffsets);
          uniforms.setUniform('u_csmFarBounds', this._farBounds);
      };
      LightCameraComponent.prototype.setLightDir = function (x, y, z) {
          if (Math.abs(x - this._f32view[LIGHT_OFFSETS.lightDir]) < 1e-6
              && Math.abs(y - this._f32view[LIGHT_OFFSETS.lightDir + 1]) < 1e-6
              && Math.abs(z - this._f32view[LIGHT_OFFSETS.lightDir + 2]) < 1e-6) {
              return;
          }
          this._f32view[LIGHT_OFFSETS.lightDir] = x;
          this._f32view[LIGHT_OFFSETS.lightDir + 1] = y;
          this._f32view[LIGHT_OFFSETS.lightDir + 2] = z;
          this._setDirty();
      };
      LightCameraComponent.prototype.setCascadedSplits = function (s0, s1, s2) {
          // @note: bug, disable now!
          // this._cascadedSplits[2] = this._adjustSplitPercents(2, s2);
          // this._cascadedSplits[1] = this._adjustSplitPercents(1, s1);
          // this._cascadedSplits[0] = this._adjustSplitPercents(0, s0);
          // this._updateBounds(false);
          // this._setDirty();
      };
      LightCameraComponent.prototype._updateBounds = function (auto) {
          var near = 0.3;
          var far = this.shadowDistance;
          var csmSplitsNum = this.shadowMode;
          if (auto) {
              var lambda = 0.75;
              var ratio = far / near;
              this._bounds[0] = near;
              for (var i = 1; i < csmSplitsNum; i += 1) {
                  var si = i / csmSplitsNum;
                  var tNear = lambda * (near * Math.pow(ratio, si)) + (1 - lambda) * (near + (far - near) * si);
                  this._bounds[i] = tNear;
                  this._setSplitPercents(i - 1, tNear / far);
              }
              this._bounds[csmSplitsNum] = far;
              this._setSplitPercents(csmSplitsNum - 1, 1.0);
          }
          else {
              for (var i = 1; i < csmSplitsNum; i += 1) {
                  var tNear = this._cascadedSplits[i - 1] * far;
                  this._bounds[i] = tNear;
              }
              this._bounds[csmSplitsNum] = far;
          }
      };
      LightCameraComponent.prototype._adjustSplitPercents = function (index, percent) {
          if (index < this.shadowMode / 2) {
              percent = Math.min(percent, this._cascadedSplits[index + 1]);
          }
          return this._setSplitPercents(index, percent);
      };
      LightCameraComponent.prototype._setSplitPercents = function (index, percent) {
          var splitsNum = this.shadowMode / 2;
          if (index >= splitsNum) {
              return 0;
          }
          if (index === splitsNum - 1) {
              return 1;
          }
          return percent;
      };
      LightCameraComponent.prototype._setDirty = function () {
          this._handle.setSharedDirty();
      };
      LightCameraComponent.OFFSETS = LIGHT_OFFSETS;
      return LightCameraComponent;
  }(NativeObject));

  /**
   * PoolObject.ts
   *
   * @Author  : hikaridai(hikaridai@tencent.com)
   * @Date    : 9/3/2020, 9:47:31 PM
   */
  var PoolObject = /** @class */ (function () {
      function PoolObject() {
      }
      Object.defineProperty(PoolObject.prototype, "float32View", {
          get: function () {
              return this._nativePool._f32view;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(PoolObject.prototype, "uint32View", {
          get: function () {
              return this._nativePool._u32view;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(PoolObject.prototype, "id", {
          get: function () {
              return this._nativeId;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(PoolObject.prototype, "poolId", {
          get: function () {
              return this._poolId;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(PoolObject.prototype, "poolIndex", {
          get: function () {
              return this._poolIndex;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(PoolObject.prototype, "poll", {
          /*@internal */
          get: function () {
              var handle = this._nativePool.__handle;
              //@ts-ignore
              if (handle._wasmPool) {
                  //@ts-ignore
                  return handle._wasmPool;
              }
              return handle;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(PoolObject.prototype, "isUsing", {
          get: function () {
              return this._using;
          },
          set: function (value) {
              this._using = value;
          },
          enumerable: false,
          configurable: true
      });
      PoolObject.prototype._init = function (nativeObjId, nativePools) {
          this._nativeId = nativeObjId;
          this._poolId = nativeObjId & (~POOL_SUB_ID_MASK);
          this._poolIndex = nativeObjId & POOL_SUB_ID_MASK;
          this._nativePool = nativePools[this._poolId];
          this._using = true;
      };
      PoolObject.prototype.setRawBuffer = function (data) {
          this._nativePool._f32view.set(data, this.entityOffset);
      };
      return PoolObject;
  }());

  /**
   * ScalableNumberArray.ts
   *
   * @Author  : hikaridai(hikaridai@tencent.com)
   * @Date    : 9/3/2020, 9:23:34 PM
   */
  var scaleNumberArray = /** @class */ (function () {
      function scaleNumberArray(len) {
          this._index = 0;
          this._size = (len !== undefined) ? len : 500;
          this._array = new Array(this._size);
      }
      scaleNumberArray.prototype.push = function (val) {
          if (this._index >= this._size) {
              this._size *= 2;
              this._array.length = this._size;
          }
          this._array[this._index] = val;
          this._index++;
      };
      scaleNumberArray.prototype.pop = function () {
          this._index--;
          return this._array[this._index];
      };
      scaleNumberArray.prototype.getByIndex = function (index) {
          if (index >= this._index) {
              return -1;
          }
          return this._array[index];
      };
      scaleNumberArray.prototype.size = function () {
          return this._index;
      };
      scaleNumberArray.prototype.clear = function () {
          this._index = 0;
      };
      return scaleNumberArray;
  }());

  var Pool = /** @class */ (function (_super) {
      __extends(Pool, _super);
      function Pool(nativeObj) {
          var _this = _super.call(this) || this;
          _this._init(nativeObj);
          //@ts-ignore
          if (nativeObj._byteOffset !== undefined && nativeObj._byteSize !== undefined) {
              //@ts-ignore
              _this._bufferLength = nativeObj._byteSize;
              //@ts-ignore
              _this._byteOffset = nativeObj._byteOffset;
              _this._f32view = new Float32Array(_this._buffer, _this._byteOffset, _this._bufferLength / 4);
          }
          _this._initU32View();
          return _this;
      }
      Pool.prototype.supplyExtendedMemory = function (buffer) {
          var _a, _b;
          if (renderEnv.useExtendedMemory) {
              (_b = (_a = this.__handle).setExtendedMemory) === null || _b === void 0 ? void 0 : _b.call(_a, buffer);
              this.u32viewExt = new Uint32Array(buffer);
          }
      };
      return Pool;
  }(NativeObject));

  /**
   * PoolManager.ts
   *
   * @Author  : hikaridai(hikaridai@tencent.com)
   * @Date    : 9/3/2020, 9:19:34 PM
   */
  var ENTITY_POOL_LENGTH = 1024;
  var PoolManager = /** @class */ (function () {
      function PoolManager(template, templateView, allocateFunc, extendedMemSize) {
          if (extendedMemSize === void 0) { extendedMemSize = 0; }
          this.pools = {};
          this._poolIndex = 0;
          this._poolUsedLength = 0;
          this._poolLength = 0;
          this._disposedIds = new scaleNumberArray();
          this._template = template;
          this._templateView = templateView;
          this._allocateFunc = allocateFunc;
          this._extendedMemSize = extendedMemSize;
      }
      /*
      * 内部方法
      */
      PoolManager.prototype._enlargePool = function (size) {
          var poolNative = this._allocateFunc(size);
          var pool = new Pool(poolNative);
          if (this._extendedMemSize > 0) {
              pool.supplyExtendedMemory(new ArrayBuffer(size * this._extendedMemSize));
          }
          this._poolIndex = pool.id;
          this.pools[pool.id] = pool;
          this._poolLength += size;
      };
      /*
      * 对外方法
      */
      // 申请
      PoolManager.prototype.allocateOne = function () {
          if (this._disposedIds.size() > 0) {
              this._poolUsedLength++;
              return this._disposedIds.pop();
          }
          if (this._poolUsedLength >= this._poolLength) {
              this._enlargePool(ENTITY_POOL_LENGTH);
          }
          var id = this._poolIndex;
          this._poolIndex += (1 << POOL_SUB_ID_SHIT);
          this._poolUsedLength++;
          return id;
      };
      // 回收
      PoolManager.prototype.dispose = function (obj) {
          if (obj.isUsing) {
              this._disposedIds.push(obj.id);
              this._poolUsedLength--;
              obj.setRawBuffer(this._templateView);
              obj.isUsing = false;
          }
      };
      return PoolManager;
  }());

  var worker$n = backend.worker;
  /*
  * CULLING_COMPONENT_TEMPLATE
  */
  var CullingComponentTemplate = new Uint32Array(new ArrayBuffer(4 * CULLING_OFFSETS.size));
  var CullingComponentTemplateF32View = new Float32Array(CullingComponentTemplate.buffer);
  var CullingComponent = /** @class */ (function (_super) {
      __extends(CullingComponent, _super);
      function CullingComponent(entity) {
          var _this = _super.call(this) || this;
          var nativeObjId = CullingComponent.POLL_MANAGER.allocateOne();
          _this._init(nativeObjId, CullingComponent.POLL_MANAGER.pools);
          _this.entityOffset = (_this._poolIndex >> POOL_SUB_ID_SHIT) * CULLING_OFFSETS.size;
          _this._activeOffset = _this.entityOffset + CULLING_OFFSETS.active;
          _this._layerOffset = _this.entityOffset + CULLING_OFFSETS.layer;
          _this._boundingBallCenterOffset = _this.entityOffset + CULLING_OFFSETS.boundingBallCenter;
          _this._boundingBallRadiusOffset = _this.entityOffset + CULLING_OFFSETS.boundingBallRadius;
          _this._entityIdOffset = _this.entityOffset + CULLING_OFFSETS.entityId;
          return _this;
          // console.log('culling', this._nativePool,this._poolId, this._poolIndex, this._entityOffset);
      }
      CullingComponent.prototype.getActive = function () {
          return (this._nativePool._u32view[this._activeOffset] & CULLING_OFFSETS.dfActive) !== 0 ? true : false;
      };
      CullingComponent.prototype.setActive = function (val) {
          if (val) {
              this._nativePool._u32view[this._activeOffset] |= CULLING_OFFSETS.dfActive;
          }
          else {
              this._nativePool._u32view[this._activeOffset] &= ~CULLING_OFFSETS.dfActive;
          }
      };
      CullingComponent.prototype.getLayer = function () {
          return this._nativePool._u32view[this._layerOffset];
      };
      CullingComponent.prototype.setLayer = function (val) {
          this._nativePool._u32view[this._layerOffset] = val;
      };
      CullingComponent.prototype.getBoundingBallCenter = function () {
          if (!this._boundingBallCenter) {
              this._boundingBallCenter = new Float32Array(this._nativePool._buffer, this._boundingBallCenterOffset * 4, 3);
          }
          return this._boundingBallCenter;
      };
      CullingComponent.prototype.setBoundingBallCenter = function (val, offset) {
          if (offset === void 0) { offset = 0; }
          if (val[offset] === this._nativePool._f32view[this._boundingBallCenterOffset] && val[offset + 1] === this._nativePool._f32view[this._boundingBallCenterOffset + 1] && val[offset + 2] === this._nativePool._f32view[this._boundingBallCenterOffset] + 3) {
              return;
          }
          if (val.length === 3) {
              this._nativePool._f32view.set(val, this._boundingBallCenterOffset);
          }
          else {
              this._nativePool._f32view[this._boundingBallCenterOffset] = val[offset];
              this._nativePool._f32view[this._boundingBallCenterOffset + 1] = val[offset + 1];
              this._nativePool._f32view[this._boundingBallCenterOffset + 2] = val[offset + 2];
          }
      };
      CullingComponent.prototype.getBoundingBallRadius = function () {
          return this._nativePool._f32view[this._boundingBallRadiusOffset];
      };
      CullingComponent.prototype.setBoundingBallRadius = function (val) {
          this._nativePool._f32view[this._boundingBallRadiusOffset] = val;
      };
      CullingComponent.prototype.bindEntity = function (entity) {
          this._bindEntityNative(entity);
      };
      CullingComponent.prototype.destroy = function () {
          this._unbindEntityNative();
          CullingComponent.POLL_MANAGER.dispose(this);
      };
      CullingComponent.prototype._bindEntityNative = function (entity) {
          this.uint32View[this._entityIdOffset] = entity.id;
      };
      CullingComponent.prototype._unbindEntityNative = function () {
          this.uint32View[this._entityIdOffset] = 0;
      };
      CullingComponent.POLL_MANAGER = new PoolManager(CullingComponentTemplate, CullingComponentTemplateF32View, function (size) { return worker$n.createCullingComponentPool(size); });
      return CullingComponent;
  }(PoolObject));

  var worker$m = backend.worker;
  var MeshRendererComponent = /** @class */ (function (_super) {
      __extends(MeshRendererComponent, _super);
      function MeshRendererComponent(entity, options) {
          var _this = _super.call(this) || this;
          var nativeObj = _this._createNativeObj(entity, options);
          if (nativeObj.id < 0 || !nativeObj.data) {
              return _this;
          }
          else {
              _this._init(nativeObj);
              _this._initU32View();
          }
          _this._macros = options.macros;
          _this._meshCount = options.meshCount;
          _this._uniforms = options.uniformBlock;
          return _this;
      }
      MeshRendererComponent.CREATE_FAKE = function (entity, options) {
          return new FakeMeshRenderComponent(entity, options);
      };
      Object.defineProperty(MeshRendererComponent.prototype, "uniforms", {
          get: function () {
              return this._uniforms;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(MeshRendererComponent.prototype, "meshCount", {
          get: function () {
              return this._meshCount;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(MeshRendererComponent.prototype, "castShadow", {
          get: function () {
              return !!this._u32view[MESH_OFFSETS.castShadow];
          },
          set: function (value) {
              this._u32view[MESH_OFFSETS.castShadow] = value ? 1 : 0;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(MeshRendererComponent.prototype, "dynamicBatch", {
          get: function () {
              return !!this._u32view[MESH_OFFSETS.dynamicBatch];
          },
          set: function (value) {
              this._u32view[MESH_OFFSETS.dynamicBatch] = value ? 1 : 0;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(MeshRendererComponent.prototype, "skinSkeleton", {
          set: function (sk) {
              this._u32view[MESH_OFFSETS.skinHandle] = sk.id;
              this._skinSkeleton = sk;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(MeshRendererComponent.prototype, "bindTarget", {
          set: function (target) {
              this._u32view[MESH_OFFSETS.bindTarget] = target ? target.id : 0;
              this._bindTarget = target;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(MeshRendererComponent.prototype, "macros", {
          get: function () {
              return this._macros;
          },
          enumerable: false,
          configurable: true
      });
      MeshRendererComponent.prototype._createNativeObj = function (entity, options) {
          return worker$m.createRenderComponent(options.meshCount, options.uniformBlock.__handle, entity.id, options.culling ? options.culling.id : 0, options.renderType, options.macros);
      };
      MeshRendererComponent.prototype.changeMacros = function (macros) {
          this._macros = this._macros || {};
          Object.assign(this._macros, macros);
          // worker.changeMeshMacros(this.__handle, macros);
          worker$m.changeMeshMacros(this.__handle, this._macros, true);
      };
      MeshRendererComponent.prototype.getStartIndex = function (index) {
          return this._u32view[MESH_OFFSETS.start + MESH_OFFSETS.size * index + MESH_OFFSETS.startIndex];
      };
      MeshRendererComponent.prototype.setStartIndex = function (index, value) {
          this._u32view[MESH_OFFSETS.start + MESH_OFFSETS.size * index + MESH_OFFSETS.startIndex] = value;
      };
      MeshRendererComponent.prototype.getNumIndices = function (index) {
          return this._u32view[MESH_OFFSETS.start + MESH_OFFSETS.size * index + MESH_OFFSETS.numIndices];
      };
      MeshRendererComponent.prototype.setNumIndices = function (index, value) {
          this._u32view[MESH_OFFSETS.start + MESH_OFFSETS.size * index + MESH_OFFSETS.numIndices] = value;
      };
      MeshRendererComponent.prototype.getVertexBuffer = function (index) {
          return this._vertexes[index];
      };
      MeshRendererComponent.prototype.setVertexBuffer = function (index, buffer) {
          if (!this._vertexes) {
              this._vertexes = new Array(this._meshCount);
          }
          this._u32view[MESH_OFFSETS.start + MESH_OFFSETS.size * index + MESH_OFFSETS.vertexBufferId] = buffer.id;
          this._vertexes[index] = buffer;
      };
      MeshRendererComponent.prototype.getIndexBuffer = function (index) {
          return this._indexes[index];
      };
      MeshRendererComponent.prototype.setIndexBuffer = function (index, buffer) {
          if (!this._indexes) {
              this._indexes = new Array(this._meshCount);
          }
          this._u32view[MESH_OFFSETS.start + MESH_OFFSETS.size * index + MESH_OFFSETS.indexBufferId] = buffer.id;
          this._indexes[index] = buffer;
      };
      MeshRendererComponent.prototype.getVertexData = function (index) {
          return this._vertexes && this._vertexes[index];
      };
      MeshRendererComponent.prototype.setVertexData = function (index, buffer) {
          if (!this._vertexes) {
              this._vertexes = new Array(this._meshCount);
          }
          this._u32view[MESH_OFFSETS.start + MESH_OFFSETS.size * index + MESH_OFFSETS.vertexBufferId] = buffer.id;
          this._vertexes[index] = buffer;
      };
      MeshRendererComponent.prototype.getIndexData = function (index) {
          return this._indexes && this._indexes[index];
      };
      MeshRendererComponent.prototype.setIndexData = function (index, buffer) {
          if (!this._indexes) {
              this._indexes = new Array(this._meshCount);
          }
          this._u32view[MESH_OFFSETS.start + MESH_OFFSETS.size * index + MESH_OFFSETS.indexBufferId] = buffer.id;
          this._indexes[index] = buffer;
      };
      MeshRendererComponent.prototype.getMaterial = function (index) {
          return this._materials && this._materials[index];
      };
      MeshRendererComponent.prototype.setMaterial = function (index, material) {
          if (!this._materials) {
              this._materials = new Array(this._meshCount);
          }
          this._u32view[MESH_OFFSETS.start + MESH_OFFSETS.size * index + MESH_OFFSETS.materialId] = material ? material.id : 0;
          this._materials[index] = material;
      };
      MeshRendererComponent.prototype.fastSet = function (vertexes, indexes, materials, startIndexes, numIndices) {
          this._vertexes = vertexes;
          this._indexes = indexes;
          this._materials = materials;
          for (var index = 0; index < this._meshCount; index += 1) {
              this.setVertexBuffer(index, vertexes[index]);
              this.setIndexBuffer(index, indexes[index]);
              this.setMaterial(index, materials[index]);
              this.setStartIndex(index, startIndexes[index]);
              this.setNumIndices(index, numIndices[index]);
          }
      };
      MeshRendererComponent.prototype.setDirty = function () {
          this._handle.setSharedDirty && this._handle.setSharedDirty();
      };
      MeshRendererComponent.prototype.copyStates = function (comp) {
          if (comp._u32view.length < this._u32view.length) {
              this._u32view.set(comp._u32view, 0);
          }
          else {
              this._u32view.set(new Uint32Array(comp._u32view.buffer, 0, this._u32view.length), 0);
          }
          this._materials = comp._materials;
          this._vertexes = comp._vertexes;
          this._indexes = comp._indexes;
      };
      MeshRendererComponent.OFFSETS = MESH_OFFSETS;
      return MeshRendererComponent;
  }(NativeObject));
  var FakeMeshRenderComponent = /** @class */ (function (_super) {
      __extends(FakeMeshRenderComponent, _super);
      function FakeMeshRenderComponent() {
          return _super !== null && _super.apply(this, arguments) || this;
      }
      FakeMeshRenderComponent.prototype._createNativeObj = function (entity, options) {
          var handle = {
              id: 0,
              data: new ArrayBuffer((MESH_OFFSETS.start + MESH_OFFSETS.size * options.meshCount) * 4),
              setSharedDirty: function () { }
          };
          return handle;
      };
      Object.defineProperty(FakeMeshRenderComponent.prototype, "uniforms", {
          get: function () {
              return this._uniforms;
          },
          set: function (uniforms) {
              this._uniforms = uniforms;
          },
          enumerable: false,
          configurable: true
      });
      return FakeMeshRenderComponent;
  }(MeshRendererComponent));

  var worker$l = backend.worker;
  var SkinnedSkeletonComponent = /** @class */ (function (_super) {
      __extends(SkinnedSkeletonComponent, _super);
      function SkinnedSkeletonComponent(boneNum, flag) {
          var _this = _super.call(this) || this;
          _this.flag = flag;
          _this._boneNum = 0;
          _this._boneNum = boneNum;
          var nativeObj = worker$l.createSkinning(boneNum, flag);
          if (nativeObj.id < 0 || !nativeObj.data) {
              return _this;
          }
          else {
              _this._init(nativeObj);
              _this._initU32View();
          }
          return _this;
      }
      SkinnedSkeletonComponent.UPDATE_MATS = function (comps, size) {
          worker$l.updateSkinnings(comps, size);
      };
      Object.defineProperty(SkinnedSkeletonComponent.prototype, "boneNum", {
          get: function () {
              return this._boneNum;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(SkinnedSkeletonComponent.prototype, "boneInverseModel", {
          get: function () {
              return this._boneInverseModel;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(SkinnedSkeletonComponent.prototype, "boneOffsetMatrices", {
          get: function () {
              return this._boneOffsetMatrices;
          },
          enumerable: false,
          configurable: true
      });
      SkinnedSkeletonComponent.prototype.setBoneMatrix = function (boneInverseModel, boneIndices, boneEntities) {
          var boneNum = this._boneNum;
          if (boneIndices.length !== boneNum || boneEntities.length !== boneNum) {
              console.warn('setBoneMatrix Error');
              return;
          }
          var boneEntityIds = [];
          for (var i = 0; i < boneNum; i++) {
              boneEntityIds.push(boneEntities[i].id);
          }
          this._u32view[SKINNED_SKELETON_OFFSETS.boneInverseModelId] = boneInverseModel.id;
          this._u32view.set(boneIndices, SKINNED_SKELETON_OFFSETS.boneIndices);
          var offset_boneEntityIds = SKINNED_SKELETON_OFFSETS.boneIndices + boneNum * SKINNED_SKELETON_OFFSETS.perBoneIndices;
          this._u32view.set(boneEntityIds, offset_boneEntityIds);
          this._boneOffsetMatrices = new Float32Array(this._buffer, this._byteOffset + (SKINNED_SKELETON_OFFSETS.boneIndices + boneNum * (SKINNED_SKELETON_OFFSETS.perBoneIndices + SKINNED_SKELETON_OFFSETS.perBoneEntityId)) * 4, boneNum * ((this.flag & 1) ? 12 : 16));
          this._boneInverseModel = boneInverseModel;
      };
      SkinnedSkeletonComponent.prototype.getBoneNum = function () {
          return this._boneNum;
      };
      SkinnedSkeletonComponent.prototype.getBoneOffsetMatrices = function () {
          return this._boneOffsetMatrices;
      };
      return SkinnedSkeletonComponent;
  }(NativeObject));

  var worker$k = backend.worker;
  var DynamicBonesComponent = /** @class */ (function (_super) {
      __extends(DynamicBonesComponent, _super);
      function DynamicBonesComponent(rootNode) {
          var _this = _super.call(this) || this;
          var nativeObj = worker$k.createDynamicBones(rootNode ? rootNode.id : 0);
          if (nativeObj.id < 0 || !nativeObj.data) {
              return _this;
          }
          else {
              _this._init(nativeObj);
              _this._initU32View();
          }
          return _this;
      }
      Object.defineProperty(DynamicBonesComponent.prototype, "stiffness", {
          get: function () {
              return this._f32view[DYNAMIC_BONES_OFFSETS.stiffness];
          },
          set: function (v) {
              this._f32view[DYNAMIC_BONES_OFFSETS.stiffness] = v;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(DynamicBonesComponent.prototype, "damping", {
          get: function () {
              return this._f32view[DYNAMIC_BONES_OFFSETS.damping];
          },
          set: function (v) {
              this._f32view[DYNAMIC_BONES_OFFSETS.damping] = v;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(DynamicBonesComponent.prototype, "elasticity", {
          get: function () {
              return this._f32view[DYNAMIC_BONES_OFFSETS.elasticity];
          },
          set: function (v) {
              this._f32view[DYNAMIC_BONES_OFFSETS.elasticity] = v;
          },
          enumerable: false,
          configurable: true
      });
      DynamicBonesComponent.prototype.preUpdate = function () {
          this._handle.preUpdate();
      };
      DynamicBonesComponent.prototype.update = function (dt, rootMotion) {
          if (rootMotion) {
              this._handle.update(dt, rootMotion.x, rootMotion.y, rootMotion.z);
          }
          else {
              this._handle.update(dt);
          }
      };
      DynamicBonesComponent.prototype.rebuild = function () {
          this._handle.rebuild();
      };
      DynamicBonesComponent.prototype.resetRoot = function (root) {
          this._handle.resetRoot(root ? root.id : 0);
      };
      // Buffer Offset in 4bytes
      DynamicBonesComponent.OFFSETS = DYNAMIC_BONES_OFFSETS;
      return DynamicBonesComponent;
  }(NativeObject));

  var worker$j = backend.worker;
  /*
  * ENTITY2D_TEMPLATE
  */
  var entity2DTemplateF32View = new Float32Array(new ArrayBuffer(4 * ENTITY2D_OFFSETS.size));
  // rotation/position/scale
  entity2DTemplateF32View.set([0, 0, 0, 1, 1], 0);
  var Entity2D = /** @class */ (function (_super) {
      __extends(Entity2D, _super);
      function Entity2D() {
          var _this = _super.call(this) || this;
          var nativeObjId = Entity2D.POLL_MANAGER.allocateOne();
          _this._init(nativeObjId, Entity2D.POLL_MANAGER.pools);
          _this.entityOffset = (_this._poolIndex >> POOL_SUB_ID_SHIT) * ENTITY2D_OFFSETS.size;
          _this.localRotationOffset = _this.entityOffset + ENTITY2D_OFFSETS.rotation;
          _this.localPositionOffset = _this.entityOffset + ENTITY2D_OFFSETS.position;
          _this.localScaleOffset = _this.entityOffset + ENTITY2D_OFFSETS.scale;
          _this.worldMatrixOffset = _this.entityOffset + ENTITY2D_OFFSETS.worldMatrix;
          _this.active = true;
          return _this;
          // console.log('2d', this._nativePool, this._poolId, this._poolIndex);
      }
      Entity2D.prototype.addChild = function (child) {
          worker$j.eventBridge.entityAddChild(this.id, child.id);
      };
      Entity2D.prototype.addChildAtIndex = function (child, index) {
          worker$j.eventBridge.entityAddChildAtIndex(this.id, child.id, index);
      };
      Entity2D.prototype.removeFromParent = function () {
          worker$j.eventBridge.entityRemoveFromParent(this.id);
      };
      Entity2D.prototype.setAsRoot = function () {
          worker$j.eventBridge.setRootEntity(this.id);
      };
      Entity2D.prototype.destroy = function () {
          this.removeFromParent();
          Entity2D.POLL_MANAGER.dispose(this);
      };
      Entity2D.prototype.clear = function () {
          worker$j.eventBridge.entityClear(this.id);
      };
      Entity2D.prototype.setLocalMatrixDirty = function () {
          worker$j.eventBridge.entitySetLocalMatrixDirty(this.id);
      };
      Object.defineProperty(Entity2D.prototype, "active", {
          set: function (val) {
              worker$j.eventBridge.entitySetActive(this.id, val);
          },
          enumerable: false,
          configurable: true
      });
      Entity2D.POLL_MANAGER = new PoolManager(entity2DTemplateF32View, entity2DTemplateF32View, function (size) { return worker$j.createNodePool(size, false); });
      Entity2D.OFFSETS = ENTITY2D_OFFSETS;
      return Entity2D;
  }(PoolObject));

  /**
   * ScalableTypedArray.ts
   *
   * @Author  : jasonjwang(jasonjwang@tencent.com)
   * @Date    : 5/8/2021, 16:14:34 PM
   */
  var ScalableTypedArray = /** @class */ (function () {
      function ScalableTypedArray(_ctor, len) {
          this._ctor = _ctor;
          this._index = 0;
          this._size = (len !== undefined) ? len : 500;
          this._array = new _ctor(this._size);
      }
      ScalableTypedArray.prototype.push = function (val) {
          if (this._index >= this._size) {
              var newArray = new this._ctor(this._size * 2);
              newArray.set(this._array);
              this._array = newArray;
              this._size *= 2;
          }
          this._array[this._index] = val;
          this._index++;
      };
      ScalableTypedArray.prototype.pop = function () {
          this._index--;
          return this._array[this._index];
      };
      ScalableTypedArray.prototype.getByIndex = function (index) {
          if (index >= this._index) {
              return -1;
          }
          return this._array[index];
      };
      ScalableTypedArray.prototype.size = function () {
          return this._index;
      };
      ScalableTypedArray.prototype.clear = function () {
          this._index = 0;
      };
      Object.defineProperty(ScalableTypedArray.prototype, "buffer", {
          get: function () {
              return this._array.buffer;
          },
          enumerable: false,
          configurable: true
      });
      return ScalableTypedArray;
  }());

  var worker$i = backend.worker;
  /*
  * ENTITY3D_TEMPLATE
  */
  var entity3DTemplate = new Uint32Array(new ArrayBuffer(4 * ENTITY3D_OFFSETS.size));
  var entity3DTemplateF32View = new Float32Array(entity3DTemplate.buffer);
  // use quaternion
  entity3DTemplate[0] = 1;
  // quaternion
  entity3DTemplateF32View.set([0, 0, 0, 1], 1 /* 1*4 */);
  // position
  entity3DTemplateF32View.set([0, 0, 0], 5 /* 5*4 */);
  // scale
  entity3DTemplateF32View.set([1, 1, 1], 8 /* 8*4 */);
  var Entity3D = /** @class */ (function (_super) {
      __extends(Entity3D, _super);
      function Entity3D() {
          var _this = _super.call(this) || this;
          var nativeObjId = Entity3D.POLL_MANAGER.allocateOne();
          _this._init(nativeObjId, Entity3D.POLL_MANAGER.pools);
          _this.entityOffset = (_this._poolIndex >> POOL_SUB_ID_SHIT) * ENTITY3D_OFFSETS.size;
          _this.localRotationTypeOffset = _this.entityOffset + ENTITY3D_OFFSETS.rotationType;
          _this.localQuaternionOffset = _this.entityOffset + ENTITY3D_OFFSETS.rotation;
          _this.localPositionOffset = _this.entityOffset + ENTITY3D_OFFSETS.position;
          _this.localScaleOffset = _this.entityOffset + ENTITY3D_OFFSETS.scale;
          _this.worldMatrixOffset = _this.entityOffset + ENTITY3D_OFFSETS.worldOffset;
          _this.extOffset = (_this._poolIndex >> POOL_SUB_ID_SHIT) * ENTITY3D_EXT_OFFSETS.size;
          _this.layerOffset = _this.extOffset + ENTITY3D_EXT_OFFSETS.layer;
          _this.mixedLayerMaskOffset = _this.extOffset + ENTITY3D_EXT_OFFSETS.mixedLayerMask;
          _this.active = true;
          return _this;
          // console.log('3d', this._nativePool,this._poolId, this._poolIndex, this._entityOffset);
      }
      Entity3D.CREATE_TREE = function (length, buffer, out, calculateWordMatrix) {
          if (calculateWordMatrix === void 0) { calculateWordMatrix = false; }
          Entity3D._CREATE_TREE_IDS.clear();
          for (var i = 0; i < length; i++) {
              out[i] = new Entity3D();
              Entity3D._CREATE_TREE_IDS.push(out[i].id);
          }
          var result = worker$i.createNodeTree(length, Entity3D._CREATE_TREE_IDS.buffer, buffer, calculateWordMatrix, true);
          if (!result) {
              for (var i = 0; i < length; i++) {
                  /**
                   * No need to call remove from parent, so no need to call destroy method.
                   */
                  Entity3D.POLL_MANAGER.dispose(out[i]);
              }
          }
          return result;
      };
      Entity3D.prototype.setUsingEuler = function (on) {
          if (on) {
              this._nativePool._u32view[this.localRotationTypeOffset] &= ~ENTITY3D_OFFSETS.dfRotationType;
          }
          else {
              this._nativePool._u32view[this.localRotationTypeOffset] |= ENTITY3D_OFFSETS.dfRotationType;
          }
      };
      Entity3D.prototype.isUsingEuler = function () {
          return (this._nativePool._u32view[this.localRotationTypeOffset] & ENTITY3D_OFFSETS.dfRotationType) !== 0 ? false : true;
      };
      Entity3D.prototype.setLayer = function (layer) {
          if (!this._nativePool.u32viewExt) {
              return;
          }
          if (layer !== this.getLayer()) {
              this._nativePool.u32viewExt[this.layerOffset] = layer;
              this.setLocalMatrixDirty();
          }
      };
      Entity3D.prototype.getLayer = function () {
          if (!this._nativePool.u32viewExt) {
              return 0;
          }
          return this._nativePool.u32viewExt[this.layerOffset];
      };
      Entity3D.prototype.getMixedLayerMask = function () {
          if (this._nativePool.u32viewExt) {
              return this._nativePool.u32viewExt[this.mixedLayerMaskOffset];
          }
          else {
              return 1;
          }
      };
      Entity3D.prototype.addChild = function (child) {
          worker$i.eventBridge.entityAddChild(this.id, child.id);
      };
      Entity3D.prototype.addChildAtIndex = function (child, index) {
          worker$i.eventBridge.entityAddChildAtIndex(this.id, child.id, index);
      };
      Entity3D.prototype.removeFromParent = function () {
          worker$i.eventBridge.entityRemoveFromParent(this.id);
      };
      Entity3D.prototype.setAsRoot = function () {
          worker$i.eventBridge.setRootEntity(this.id);
      };
      Entity3D.prototype.destroy = function () {
          this.removeFromParent();
          Entity3D.POLL_MANAGER.dispose(this);
      };
      /**
       * 如果只调用entityClear指令，那么Kanata就无法回收根节点下面的子节点了。
       * 目前Kanata的frontend没有父子关系信息只能这么做了。
       * 这个方法目前只能减少eventBridge的指令量，避免在大规模节点销毁的时候频繁触发eventBridge的溢出提交。
       * @param entities
       * @param length
       */
      Entity3D.prototype.clear = function (entities, length) {
          for (var i = 0; i < length; i++) {
              Entity3D.POLL_MANAGER.dispose(entities[i]);
          }
          worker$i.eventBridge.entityClear(this.id);
      };
      Entity3D.prototype.setLocalMatrixDirty = function () {
          worker$i.eventBridge.entitySetLocalMatrixDirty(this.id);
      };
      Object.defineProperty(Entity3D.prototype, "active", {
          set: function (val) {
              worker$i.eventBridge.entitySetActive(this.id, val);
          },
          enumerable: false,
          configurable: true
      });
      Entity3D.POLL_MANAGER = new PoolManager(entity3DTemplate, entity3DTemplateF32View, function (size) { return worker$i.createNodePool(size, true); }, ENTITY3D_EXT_OFFSETS.size * 4);
      // Static Offset
      Entity3D.OFFSETS = ENTITY3D_OFFSETS;
      Entity3D._CREATE_TREE_IDS = new ScalableTypedArray(Uint32Array);
      return Entity3D;
  }(PoolObject));

  var worker$h = backend.worker;
  var DataModel = /** @class */ (function (_super) {
      __extends(DataModel, _super);
      function DataModel() {
          return _super !== null && _super.apply(this, arguments) || this;
      }
      DataModel.prototype._createNativeModel = function (type, buffer) {
          var model;
          if (type === exports.EDataModelType.AnimationClip) {
              model = worker$h.createAnimationClipModel(buffer);
          }
          else if (type === exports.EDataModelType.SkeletonBoneInverse) {
              model = worker$h.createBoneInverseModel(buffer);
          }
          model = model || { id: 0 };
          this._handle = model;
      };
      return DataModel;
  }(PureResource));

  var AnimationClipModel = /** @class */ (function (_super) {
      __extends(AnimationClipModel, _super);
      function AnimationClipModel() {
          return _super !== null && _super.apply(this, arguments) || this;
      }
      AnimationClipModel.prototype.setAnimationClip = function (ab) {
          this._createNativeModel(exports.EDataModelType.AnimationClip, ab);
      };
      return AnimationClipModel;
  }(DataModel));

  var worker$g = backend.worker;
  var AnimationClipBinding = /** @class */ (function (_super) {
      __extends(AnimationClipBinding, _super);
      function AnimationClipBinding(clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, useDefaultAddedNodesAction, rootEntity) {
          var _this = _super.call(this) || this;
          _this._handle = worker$g.createAnimationClipBinding(clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, useDefaultAddedNodesAction, rootEntity);
          return _this;
      }
      AnimationClipBinding.prototype.rebind = function (clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, removeAction, retainedAction, addedAction, rootEntity) {
          return worker$g.rebindAnimationClipBinding(this.__handle, clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, removeAction, retainedAction, addedAction, rootEntity);
      };
      AnimationClipBinding.prototype.update = function (clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, removeAction, retainedAction, addedAction) {
          return worker$g.updateAnimationClipBinding(this.__handle, clipArray, clipArrayOffset, clipArrayLength, entityArray, entityArrayOffset, entityArrayLength, removeAction, retainedAction, addedAction);
      };
      AnimationClipBinding.prototype.writeDefaultValues = function () {
          worker$g.writeAnimationClipBindingDefaultValues(this.__handle);
      };
      return AnimationClipBinding;
  }(PureResource));

  var worker$f = backend.worker;
  var AnimatorControllerModel = /** @class */ (function (_super) {
      __extends(AnimatorControllerModel, _super);
      function AnimatorControllerModel(layerCount) {
          var _this = _super.call(this) || this;
          _this.layerCount = layerCount;
          _this._handle = worker$f.createAnimatorControllerModel(layerCount);
          _this._uint32View = new Uint32Array(_this._handle.data);
          _this._f32View = new Float32Array(_this._handle.data);
          _this._blendStates = new Array(layerCount);
          for (var layerIndex = 0; layerIndex < layerCount; layerIndex++) {
              _this._uint32View[1 + 3 * layerIndex] = 1;
              _this._f32View[1 + 3 * layerIndex + 1] = 0;
              _this._f32View[1 + 3 * layerIndex + 2] = 0;
          }
          return _this;
      }
      AnimatorControllerModel.UPDATE_ANIMATOR_CONTROLLERS = function (animatorControllers, size) {
          worker$f.updateAnimatorControllers(animatorControllers, size);
      };
      AnimatorControllerModel.prototype.setAnimationClipBinding = function (binding) {
          this._uint32View[0] = binding ? binding.id : 0;
          this._binding = binding;
      };
      // 0
      AnimatorControllerModel.prototype.setLayerBlendType = function (layerIndex, blendType) {
          this._uint32View[1 + 3 * layerIndex] = blendType;
      };
      // 1
      AnimatorControllerModel.prototype.setLayerWeight = function (layerIndex, weight) {
          this._f32View[1 + 3 * layerIndex + 1] = weight;
      };
      // 2
      AnimatorControllerModel.prototype.setLayerBlend = function (layerIndex, blend) {
          if (blend) {
              this._uint32View[1 + 3 * layerIndex + 2] = blend.id;
          }
          else {
              this._uint32View[1 + 3 * layerIndex + 2] = 0;
          }
          this._blendStates[layerIndex] = blend;
      };
      AnimatorControllerModel.prototype.setLayerMask = function (layerIndex, mask) {
          worker$f.setAnimatorControllerModelMaskAtIndex(this.__handle, layerIndex, mask);
      };
      AnimatorControllerModel.prototype.update = function () {
          worker$f.updateAnimatorControllerModel(this.__handle);
      };
      AnimatorControllerModel.prototype.destroy = function () {
          this._binding = null;
          this._blendStates = null;
      };
      return AnimatorControllerModel;
  }(PureResource));

  var worker$e = backend.worker;
  var AnimatorControllerStateModel = /** @class */ (function (_super) {
      __extends(AnimatorControllerStateModel, _super);
      function AnimatorControllerStateModel(count) {
          var _this = _super.call(this) || this;
          _this.count = count;
          _this._index = 0;
          _this._handle = worker$e.createAnimatorControllerStateModel(count);
          _this._f32View = new Float32Array(_this._handle.data);
          _this._uint32View = new Uint32Array(_this._handle.data);
          for (var i = 0; i < count; i++) {
              _this._uint32View[5 * i + 3] = 0;
              _this._f32View[5 * i + 3 + 1] = 0;
              _this._f32View[5 * i + 3 + 2] = 0;
              _this._uint32View[5 * i + 3 + 3] = 0;
              _this._f32View[5 * i + 3 + 4] = 0;
          }
          return _this;
      }
      Object.defineProperty(AnimatorControllerStateModel.prototype, "weight", {
          get: function () {
              return this._f32View[0];
          },
          set: function (weight) {
              this._f32View[0] = weight;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(AnimatorControllerStateModel.prototype, "useDefault", {
          get: function () {
              return this._f32View[1];
          },
          set: function (useDefault) {
              this._f32View[1] = useDefault;
          },
          enumerable: false,
          configurable: true
      });
      AnimatorControllerStateModel.prototype.resetBlendInfo = function () {
          for (var i = 0; i < this.count; i++) {
              this._f32View[5 * i + 3 + 1] = 0;
              this._f32View[5 * i + 3 + 2] = 0;
          }
          this._index = 0;
      };
      AnimatorControllerStateModel.prototype.setNextState = function (state) {
          this._uint32View[2] = state ? state.id : 0;
          this._nextState = state;
      };
      AnimatorControllerStateModel.prototype.setBlendInfo = function (clip, frameIndex, blendWeight, additiveReferenceClip, additiveFrameIndex) {
          if (this._index >= this.count) {
              return false;
          }
          this._uint32View[5 * this._index + 3] = clip.id;
          this._f32View[5 * this._index + 3 + 1] = frameIndex;
          this._f32View[5 * this._index + 3 + 2] = blendWeight;
          this._uint32View[5 * this._index + 3 + 3] = additiveReferenceClip ? additiveReferenceClip.id : this._uint32View[5 * this._index + 3];
          this._f32View[5 * this._index + 3 + 4] = additiveFrameIndex;
          this._index++;
          return true;
      };
      return AnimatorControllerStateModel;
  }(PureResource));

  var DataBuffer = /** @class */ (function (_super) {
      __extends(DataBuffer, _super);
      function DataBuffer(nativeObj) {
          var _this = _super.call(this) || this;
          _this._init(nativeObj);
          return _this;
      }
      Object.defineProperty(DataBuffer.prototype, "dataLength", {
          get: function () {
              return this._u32view[0];
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(DataBuffer.prototype, "byteOffset", {
          // 数据区起始
          get: function () {
              return this._byteOffset + 4;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(DataBuffer.prototype, "arrayBuffer", {
          get: function () {
              return this._buffer;
          },
          enumerable: false,
          configurable: true
      });
      return DataBuffer;
  }(NativeObject));

  /**
   * stateBuilder.ts
   *
   * @Author  : hikaridai(hikaridai@tencent.com)
   * @Date    : 9/9/2020, 8:27:23 PM
   */
  var PT_SAMPLER_WRAP_S_SHIFT = 0;
  var PT_SAMPLER_WRAP_S_MASK = 0x00000007;
  var PT_SAMPLER_WRAP_T_SHIFT = 3;
  var PT_SAMPLER_WRAP_T_MASK = 0x00000038;
  var PT_SAMPLER_WRAP_R_SHIFT = 6;
  var PT_SAMPLER_WRAP_R_MASK = 0x000001C0;
  var PT_SAMPLER_FILTER_MIN_SHIFT = 9;
  var PT_SAMPLER_FILTER_MIN_MASK = 0x00000E00;
  var PT_SAMPLER_FILTER_MAG_SHIFT = 12;
  var PT_SAMPLER_FILTER_MAG_MASK = 0x00003000;
  var PT_TEXTURE_GENERATE_MIPMAP = 0x00004000; //!< Generate mipmap.
  var PT_TEXTURE_RT = 0x00008000; //!< Render target no MSAA.
  var PT_TEXTURE_RT_WRITE_ONLY = 0x00010000; //!< Render target write only.
  var PT_TEXTURE_RT_MSAA_SHIFT = 17;
  var PT_TEXTURE_RT_MSAA_MASK = 0x00060000;
  var PT_TEXTURE_ANISOTROPY_SHIFT = 20;
  var PT_TEXTURE_ANISOTROPY_MASK = 0x00F00000;
  function PACK_SAMPLER_WRAP_S_INDEX(value, v) {
      return (value & ~PT_SAMPLER_WRAP_S_MASK) | (v << PT_SAMPLER_WRAP_S_SHIFT);
  }
  function PACK_SAMPLER_WRAP_T_INDEX(value, v) {
      return (value & ~PT_SAMPLER_WRAP_T_MASK) | (v << PT_SAMPLER_WRAP_T_SHIFT);
  }
  function PACK_SAMPLER_WRAP_R_INDEX(value, v) {
      return (value & ~PT_SAMPLER_WRAP_R_MASK) | (v << PT_SAMPLER_WRAP_R_SHIFT);
  }
  function PACK_SAMPLER_FILTER_MIN_INDEX(value, v) {
      return (value & ~PT_SAMPLER_FILTER_MIN_MASK) | (v << PT_SAMPLER_FILTER_MIN_SHIFT);
  }
  function PACK_SAMPLER_FILTER_MAG_INDEX(value, v) {
      return (value & ~PT_SAMPLER_FILTER_MAG_MASK) | (v << PT_SAMPLER_FILTER_MAG_SHIFT);
  }
  function PACK_TEXTURE_GENERATE_MIPMAP(value, v) {
      return v ? (value | PT_TEXTURE_GENERATE_MIPMAP) : (value & ~PT_TEXTURE_GENERATE_MIPMAP);
  }
  function PACK_TEXTURE_SAMPLE_COUNT(value, v) {
      return (value & ~PT_TEXTURE_RT_MSAA_MASK) | (v === 1 ? 0 : v << PT_TEXTURE_RT_MSAA_SHIFT);
  }
  function PACK_TEXTURE_ANISO(value, v) {
      return (value & ~PT_TEXTURE_ANISOTROPY_MASK) | ((v - 1) << PT_TEXTURE_ANISOTROPY_SHIFT);
  }
  function PACK_TEXTURE_IS_RT(value, v) {
      return v ? (value | PT_TEXTURE_RT) : (value & ~PT_TEXTURE_RT);
  }
  function PACK_TEXTURE_IS_RT_WRITE_ONLY(value, v) {
      return v ? (value | PT_TEXTURE_RT_WRITE_ONLY) : (value & ~PT_TEXTURE_RT_WRITE_ONLY);
  }
  function EXTRACT_SAMPLER_WRAP_S_INDEX(value) {
      return (value & PT_SAMPLER_WRAP_S_MASK) >> PT_SAMPLER_WRAP_S_SHIFT;
  }
  function EXTRACT_SAMPLER_WRAP_T_INDEX(value) {
      return (value & PT_SAMPLER_WRAP_T_MASK) >> PT_SAMPLER_WRAP_T_SHIFT;
  }
  function EXTRACT_SAMPLER_WRAP_R_INDEX(value) {
      return (value & PT_SAMPLER_WRAP_R_MASK) >> PT_SAMPLER_WRAP_R_SHIFT;
  }
  function EXTRACT_SAMPLER_FILTER_MIN_INDEX(value) {
      return (value & PT_SAMPLER_FILTER_MIN_MASK) >> PT_SAMPLER_FILTER_MIN_SHIFT;
  }
  function EXTRACT_SAMPLER_FILTER_MAG_INDEX(value) {
      return (value & PT_SAMPLER_FILTER_MAG_MASK) >> PT_SAMPLER_FILTER_MAG_SHIFT;
  }
  function EXTRACT_TEXTURE_GENERATE_MIPMAP(value) {
      return !!(value & PT_TEXTURE_GENERATE_MIPMAP);
  }
  function EXTRACT_TEXTURE_SAMPLE_COUNT(value) {
      return (value & PT_TEXTURE_RT_MSAA_MASK) >> PT_TEXTURE_RT_MSAA_SHIFT;
  }
  function EXTRACT_TEXTURE_IS_RT(value) {
      return !!(value & PT_TEXTURE_RT);
  }
  function EXTRACT_TEXTURE_ANISO(value) {
      return ((value & PT_TEXTURE_ANISOTROPY_MASK) >> PT_TEXTURE_ANISOTROPY_SHIFT) + 1;
  }
  var PT_WRITE_RGBA = 0x0000000f; //!< Enable alpha write.
  var PT_WRITE_RGBA_MASK = 0x0000000f;
  var PT_WRITE_Z = 0x80000000; //!< Enable depth write.
  function PACK_ENABLE_WRITE_Z(value, v) {
      return v ? (value | PT_WRITE_Z) : (value & ~PT_WRITE_Z);
  }
  function PACK_WRITE_RGBA_MASK(value, v) {
      return (value & ~PT_WRITE_RGBA) | (v & PT_WRITE_RGBA);
  }
  function PACK_ENABLE_WRITE_RGBA(value, v) {
      return v ? (value | PT_WRITE_RGBA) : (value & ~PT_WRITE_RGBA);
  }
  function EXTRACT_WRITE_RGBA_MASK(value) {
      return value & PT_WRITE_RGBA;
  }
  function EXTRACT_ENABLE_WRITE_Z(value) {
      return !!(value & PT_WRITE_Z);
  }
  /**
   * Blend test state.
   */
  var PT_BLEND_ENABLE = 0x40000000; //!< Eanble blend test.
  function PACK_ENABLE_BLEND(value, v) {
      return v ? (value | PT_BLEND_ENABLE) : (value & ~PT_BLEND_ENABLE);
  }
  function EXTRACT_ENABLE_BLEND(value) {
      return !!(value & PT_BLEND_ENABLE);
  }
  var PT_BLEND_FACTOR_SHIFT = 8; //!< Blend state bit shift
  var PT_BLEND_FACTOR_MASK = 0x00ffff00; //!< Blend state bit mask
  function PACK_BLEND_SRC_RGB(value, v) {
      return (value & 0xfffff0ff) | (v << PT_BLEND_FACTOR_SHIFT);
  }
  function PACK_BLEND_DST_RGB(value, v) {
      return (value & 0xffff0fff) | (v << PT_BLEND_FACTOR_SHIFT << 4);
  }
  function PACK_BLEND_SRC_A(value, v) {
      return (value & 0xfff0ffff) | (v << PT_BLEND_FACTOR_SHIFT << 8);
  }
  function PACK_BLEND_DST_A(value, v) {
      return (value & 0xff0fffff) | (v << PT_BLEND_FACTOR_SHIFT << 12);
  }
  function EXTRACT_BLEND_FACTOR_SRC_RGB_INDEX(value) {
      return ((value & PT_BLEND_FACTOR_MASK) >> PT_BLEND_FACTOR_SHIFT) & 0xf;
  }
  function EXTRACT_BLEND_FACTOR_DST_RGB_INDEX(value) {
      return (((value & PT_BLEND_FACTOR_MASK) >> PT_BLEND_FACTOR_SHIFT) >> 4) & 0xf;
  }
  function EXTRACT_BLEND_FACTOR_SRC_A_INDEX(value) {
      return (((value & PT_BLEND_FACTOR_MASK) >> PT_BLEND_FACTOR_SHIFT) >> 8) & 0xf;
  }
  function EXTRACT_BLEND_FACTOR_DST_A_INDEX(value) {
      return (((value & PT_BLEND_FACTOR_MASK) >> PT_BLEND_FACTOR_SHIFT) >> 12) & 0xf;
  }
  var PT_BLEND_EQUATION_SHIFT = 24; //!< Blend equation bit shift
  var PT_BLEND_EQUATION_MASK = 0x3f000000; //!< Blend equation bit mask
  function PACK_BLEND_EQUATION_RGB(value, v) {
      return (value & 0xf0ffffff) | (v << PT_BLEND_EQUATION_SHIFT);
  }
  function PACK_BLEND_EQUATION_A(value, v) {
      return (value & 0xcfffffff) | (v << PT_BLEND_EQUATION_SHIFT << 3);
  }
  function EXTRACT_BLEND_EQUATION_RGB_INDEX(value) {
      return ((value & PT_BLEND_EQUATION_MASK) >> PT_BLEND_EQUATION_SHIFT) & 0x7;
  }
  /**
   * Depth test state. When `PT_DEPTH_` is not specified depth test will be disabled.
   *
   */
  var PT_DEPTH_TEST_DISABLE = 0x00000000; //!< Diable depth test.
  var PT_DEPTH_TEST_SHIFT = 4; //!< Depth test state bit shift
  var PT_DEPTH_TEST_MASK = 0x000000f0; //!< Depth test state bit mask
  function PACK_DEPTH_FUNC(value, v) {
      return (value & ~PT_DEPTH_TEST_MASK) | (v << PT_DEPTH_TEST_SHIFT);
  }
  function EXTRACT_ENABLE_DEPTH_TEST(value) {
      return ((value & PT_DEPTH_TEST_MASK) !== PT_DEPTH_TEST_DISABLE);
  }
  function EXTRACT_DEPTH_TEST_FUNC_INDEX(value) {
      return (value & PT_DEPTH_TEST_MASK) >> PT_DEPTH_TEST_SHIFT;
  }
  /// Stencil read mask.
  var PT_STENCIL_RMASK_SHIFT = 0;
  var PT_STENCIL_RMASK_MASK = 0x000000ff;
  function PACK_STENCIL_RMASK(value, v) {
      return (value & ~PT_STENCIL_RMASK_MASK) | ((v & 0xff) << PT_STENCIL_RMASK_SHIFT);
  }
  function EXTRACT_STENCIL_RMASK(value) {
      return (value & PT_STENCIL_RMASK_MASK) >> PT_STENCIL_RMASK_SHIFT;
  }
  /// Stencil ref.
  var PT_STENCIL_REF_SHIFT = 8;
  var PT_STENCIL_REF_MASK = 0x0000ff00;
  function PACK_STENCIL_REF(value, v) {
      return (value & ~PT_STENCIL_REF_MASK) | (v << PT_STENCIL_REF_SHIFT);
  }
  function EXTRACT_STENCIL_REF(value) {
      return (value & PT_STENCIL_REF_MASK) >> PT_STENCIL_REF_SHIFT;
  }
  /// If fstencil and bstencil stencil test both are diable, disable stencil test.
  var PT_STENCIL_TEST_DISABLE = 0x00000000; //!< Diable stencil test.
  var PT_STENCIL_TEST_SHIFT = 16; //!< Stencil test bit shift
  var PT_STENCIL_TEST_MASK = 0x000f0000; //!< Stencil test bit mask
  function PACK_STENCIL_TEST(value, v) {
      return (value & ~PT_STENCIL_TEST_MASK) | (v << PT_STENCIL_TEST_SHIFT);
  }
  function EXTRACT_ENABLE_STENCIL_TEST(value) {
      return ((value & PT_STENCIL_TEST_MASK) !== PT_STENCIL_TEST_DISABLE);
  }
  function EXTRACT_STENCIL_TEST_INDEX(value) {
      return (value & PT_STENCIL_TEST_MASK) >> PT_STENCIL_TEST_SHIFT;
  }
  var PT_STENCIL_OP_SHIFT = 20; //!< Stencil operation fail bit shift
  var PT_STENCIL_OP_MASK = 0xfff00000; //!< Stencil operation fail bit mask
  function PACK_STENCIL_OP_SFAILURE(value, v) {
      return (value & 0xff0fffff) | (v << PT_STENCIL_OP_SHIFT);
  }
  function PACK_STENCIL_OP_DFAILURE(value, v) {
      return (value & 0xf0ffffff) | (v << PT_STENCIL_OP_SHIFT << 4);
  }
  function PACK_STENCIL_OP_PASS(value, v) {
      return (value & 0x0fffffff) | (v << PT_STENCIL_OP_SHIFT << 8);
  }
  function EXTRACT_STENCIL_OP_SFAILURE_INDEX(value) {
      return ((value & PT_STENCIL_OP_MASK) >> PT_STENCIL_OP_SHIFT) & 0xf;
  }
  function EXTRACT_STENCIL_OP_DFAILURE_INDEX(value) {
      return (((value & PT_STENCIL_OP_MASK) >> PT_STENCIL_OP_SHIFT) >> 4) & 0xf;
  }
  function EXTRACT_STENCIL_OP_PASS_INDEX(value) {
      return (((value & PT_STENCIL_OP_MASK) >> PT_STENCIL_OP_SHIFT) >> 8) & 0xf;
  }
  /**
   * Set Other States.
   *
   */
  /**
   * Set Stencil Write Mask.
   */
  var PT_STATE_STENCIL_WMASK_SHIFT = 0;
  var PT_STATE_STENCIL_WMASK_MASK = 0x000000ff;
  function PACK_STENCIL_WMASK(value, v) {
      return (value & ~PT_STATE_STENCIL_WMASK_MASK) | ((v & 0xff) << PT_STATE_STENCIL_WMASK_SHIFT);
  }
  function EXTRACT_STENCIL_WMASK(value) {
      return (value & PT_STATE_STENCIL_WMASK_MASK);
  }
  var PT_STATE_CULL_SHIFT = 8; //!< Culling mode bit shift
  var PT_STATE_CULL_MASK = 0x00000300; //!< Culling mode bit mask
  function PACK_CULL(value, v) {
      return (value & ~PT_STATE_CULL_MASK) | (v << PT_STATE_CULL_SHIFT);
  }
  function EXTRACT_CULL(value) {
      return (value & PT_STATE_CULL_MASK) >> PT_STATE_CULL_SHIFT;
  }
  function EXTRACT_ENABLE_CULL(value) {
      return !!(value & PT_STATE_CULL_MASK);
  }
  var PT_STATE_PT_SHIFT = 11; //!< Primitive type bit shift
  var PT_STATE_PT_MASK = 0x00003800; //!< Primitive type bit mask
  function PACK_PRIMITIVE_TYPE(value, v) {
      return (value & ~PT_STATE_PT_MASK) | (v << PT_STATE_PT_SHIFT);
  }
  function EXTRACT_PRIMITIVE_TYPE_INDEX(value) {
      return (value & PT_STATE_PT_MASK) >> PT_STATE_PT_SHIFT;
  }
  // bit: [1 ~ 31]
  function PACK_USE_MATERIAL_STATE(value, maskFromBit1, v) {
      return v ? (value | maskFromBit1) : (value & ~maskFromBit1);
  }
  function EXTRACT_USE_MATERIAL_STATE(value, maskFromBit1) {
      return !!(value & (1 << maskFromBit1));
  }

  var worker$d = backend.worker;
  var Effect = /** @class */ (function (_super) {
      __extends(Effect, _super);
      function Effect(name, passCount, 
      // if useRuntimeMacros is true, give empty array
      keyIndexMap, passes, shaders, 
      // if useRuntimeMacros is true, give empty array
      variants, useRuntimeMacros) {
          if (useRuntimeMacros === void 0) { useRuntimeMacros = false; }
          var _this = _super.call(this) || this;
          var handle = worker$d.createEffect(name, passCount, keyIndexMap, passes, shaders, variants, useRuntimeMacros);
          if (handle.id < 0 || !handle.data) {
              return _this;
          }
          else {
              _this._handle = handle;
              _this._init(handle);
              _this._initU32View();
          }
          for (var pass = 0; pass < passCount; pass += 1) {
              var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth;
              _this._u32view[offset] = PACK_ENABLE_WRITE_RGBA(_this._u32view[offset], true);
              _this._u32view[offset] = PACK_BLEND_SRC_A(_this._u32view[offset], exports.EBlendFactor.ZERO);
              _this._u32view[offset] = PACK_BLEND_DST_A(_this._u32view[offset], exports.EBlendFactor.ONE);
          }
          _this._passCount = passCount;
          return _this;
      }
      Object.defineProperty(Effect.prototype, "passCount", {
          get: function () {
              return this._passCount;
          },
          enumerable: false,
          configurable: true
      });
      Effect.prototype.warmUp = function () {
          return this._handle.warmUp();
      };
      Effect.prototype.getBlendOn = function (pass) {
          return EXTRACT_ENABLE_BLEND(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth]);
      };
      Effect.prototype.setBlendOn = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth;
          this._u32view[offset] = PACK_ENABLE_BLEND(this._u32view[offset], value);
      };
      Effect.prototype.getBlendSrc = function (pass) {
          return EXTRACT_BLEND_FACTOR_SRC_RGB_INDEX(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth]);
      };
      Effect.prototype.setBlendSrc = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth;
          this._u32view[offset] = PACK_BLEND_SRC_RGB(this._u32view[offset], value);
          this._u32view[offset] = PACK_BLEND_SRC_A(this._u32view[offset], value);
      };
      Effect.prototype.getBlendDst = function (pass) {
          return EXTRACT_BLEND_FACTOR_DST_RGB_INDEX(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth]);
      };
      Effect.prototype.setBlendDst = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth;
          this._u32view[offset] = PACK_BLEND_DST_RGB(this._u32view[offset], value);
          this._u32view[offset] = PACK_BLEND_DST_A(this._u32view[offset], value);
      };
      Effect.prototype.getBlendSrcRGB = function (pass) {
          return EXTRACT_BLEND_FACTOR_SRC_RGB_INDEX(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth]);
      };
      Effect.prototype.setBlendSrcRGB = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth;
          this._u32view[offset] = PACK_BLEND_SRC_RGB(this._u32view[offset], value);
      };
      Effect.prototype.getBlendSrcAlpha = function (pass) {
          return EXTRACT_BLEND_FACTOR_SRC_A_INDEX(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth]);
      };
      Effect.prototype.setBlendSrcAlpha = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth;
          this._u32view[offset] = PACK_BLEND_SRC_A(this._u32view[offset], value);
      };
      Effect.prototype.getBlendDstRGB = function (pass) {
          return EXTRACT_BLEND_FACTOR_DST_RGB_INDEX(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth]);
      };
      Effect.prototype.setBlendDstRGB = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth;
          this._u32view[offset] = PACK_BLEND_DST_RGB(this._u32view[offset], value);
      };
      Effect.prototype.getBlendDstAlpha = function (pass) {
          return EXTRACT_BLEND_FACTOR_DST_A_INDEX(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth]);
      };
      Effect.prototype.setBlendDstAlpha = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth;
          this._u32view[offset] = PACK_BLEND_DST_A(this._u32view[offset], value);
      };
      Effect.prototype.getBlendFunc = function (pass) {
          return EXTRACT_BLEND_EQUATION_RGB_INDEX(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth]);
      };
      Effect.prototype.setBlendFunc = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth;
          this._u32view[offset] = PACK_BLEND_EQUATION_RGB(this._u32view[offset], value);
          this._u32view[offset] = PACK_BLEND_EQUATION_A(this._u32view[offset], value);
      };
      Effect.prototype.getDepthTestOn = function (pass) {
          return EXTRACT_ENABLE_DEPTH_TEST(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth]);
      };
      Effect.prototype.setDepthTestOn = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth;
          this._u32view[offset] = PACK_DEPTH_FUNC(this._u32view[offset], value ? exports.ECompareFunc.LEQUAL : 0);
      };
      Effect.prototype.getDepthTestComp = function (pass) {
          return EXTRACT_DEPTH_TEST_FUNC_INDEX(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth]);
      };
      Effect.prototype.setDepthTestComp = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth;
          this._u32view[offset] = PACK_DEPTH_FUNC(this._u32view[offset], value);
      };
      Effect.prototype.getDepthWrite = function (pass) {
          return EXTRACT_ENABLE_WRITE_Z(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth]);
      };
      Effect.prototype.setDepthWrite = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth;
          this._u32view[offset] = PACK_ENABLE_WRITE_Z(this._u32view[offset], value);
      };
      Effect.prototype.getColorWrite = function (pass) {
          return EXTRACT_WRITE_RGBA_MASK(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth]);
      };
      Effect.prototype.setColorWrite = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.colorDepth;
          this._u32view[offset] = PACK_WRITE_RGBA_MASK(this._u32view[offset], value);
      };
      Effect.prototype.getCullFace = function (pass) {
          return EXTRACT_CULL(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.state]);
      };
      Effect.prototype.setCullFace = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.state;
          this._u32view[offset] = PACK_CULL(this._u32view[offset], value);
      };
      Effect.prototype.getCullOn = function (pass) {
          return EXTRACT_ENABLE_CULL(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.state]);
      };
      Effect.prototype.setCullOn = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.state;
          this._u32view[offset] = PACK_CULL(this._u32view[offset], value ? exports.ECullMode.BACK : exports.ECullMode.NONE);
      };
      Effect.prototype.getPrimitiveType = function (pass) {
          return EXTRACT_PRIMITIVE_TYPE_INDEX(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.state]);
      };
      Effect.prototype.setPrimitiveType = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.state;
          this._u32view[offset] = PACK_PRIMITIVE_TYPE(this._u32view[offset], value);
      };
      Effect.prototype.getStencilTestOn = function (pass) {
          return EXTRACT_ENABLE_STENCIL_TEST(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil]);
      };
      Effect.prototype.setStencilTestOn = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.bstencil;
          var v = PACK_STENCIL_TEST(this._u32view[offset], value ? exports.ECompareFunc.LEQUAL : 0);
          this._u32view[offset] = v;
          offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil;
          this._u32view[offset] = v;
      };
      Effect.prototype.getStencilComp = function (pass) {
          return EXTRACT_STENCIL_TEST_INDEX(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil]);
      };
      Effect.prototype.setStencilComp = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.bstencil;
          var v = PACK_STENCIL_TEST(this._u32view[offset], value);
          this._u32view[offset] = v;
          offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil;
          this._u32view[offset] = v;
      };
      Effect.prototype.getStencilPass = function (pass) {
          return EXTRACT_STENCIL_OP_PASS_INDEX(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil]);
      };
      Effect.prototype.setStencilPass = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.bstencil;
          var v = PACK_STENCIL_OP_PASS(this._u32view[offset], value);
          this._u32view[offset] = v;
          offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil;
          this._u32view[offset] = v;
      };
      Effect.prototype.getStencilFail = function (pass) {
          return EXTRACT_STENCIL_OP_SFAILURE_INDEX(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil]);
      };
      Effect.prototype.setStencilFail = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.bstencil;
          var v = PACK_STENCIL_OP_SFAILURE(this._u32view[offset], value);
          this._u32view[offset] = v;
          offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil;
          this._u32view[offset] = v;
      };
      Effect.prototype.getStencilZFail = function (pass) {
          return EXTRACT_STENCIL_OP_DFAILURE_INDEX(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil]);
      };
      Effect.prototype.setStencilZFail = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.bstencil;
          var v = PACK_STENCIL_OP_DFAILURE(this._u32view[offset], value);
          this._u32view[offset] = v;
          offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil;
          this._u32view[offset] = v;
      };
      Effect.prototype.getStencilWriteMask = function (pass) {
          return EXTRACT_STENCIL_WMASK(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil]);
      };
      Effect.prototype.setStencilWriteMask = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.bstencil;
          var v = PACK_STENCIL_WMASK(this._u32view[offset], value);
          this._u32view[offset] = v;
          offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil;
          this._u32view[offset] = v;
      };
      Effect.prototype.getStencilReadMask = function (pass) {
          return EXTRACT_STENCIL_RMASK(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil]);
      };
      Effect.prototype.setStencilReadMask = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.bstencil;
          var v = PACK_STENCIL_RMASK(this._u32view[offset], value);
          this._u32view[offset] = v;
          offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil;
          this._u32view[offset] = v;
      };
      Effect.prototype.getStencilRef = function (pass) {
          return EXTRACT_STENCIL_REF(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil]);
      };
      Effect.prototype.setStencilRef = function (pass, value) {
          var offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.bstencil;
          var v = PACK_STENCIL_REF(this._u32view[offset], value);
          this._u32view[offset] = v;
          offset = pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.fstencil;
          this._u32view[offset] = v;
      };
      /*-------- use state mask --------*/
      Effect.prototype.getUseMaterialStates = function (pass) {
          return !!(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.useMaterialStates] & 1);
      };
      // 必须先于别的use state mask调用！
      Effect.prototype.setUseMaterialStates = function (pass, value) {
          this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.useMaterialStates] = value ? 0xffffffff : 0;
      };
      Effect.prototype._getUseMaterialStateMask = function (pass, maskFromBit1) {
          return EXTRACT_USE_MATERIAL_STATE(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.useMaterialStates], maskFromBit1);
      };
      Effect.prototype._setUseMaterialStateMask = function (pass, maskFromBit1, value) {
          this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.useMaterialStates] =
              PACK_USE_MATERIAL_STATE(this._u32view[pass * EFFECT_OFFSETS.size + EFFECT_OFFSETS.useMaterialStates], maskFromBit1, value);
      };
      Effect.prototype.getUseMaterialStateBlendOn = function (pass) {
          return this._getUseMaterialStateMask(pass, 1);
      };
      Effect.prototype.setUseMaterialStateBlendOn = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 1, value);
      };
      Effect.prototype.getUseMaterialStateBlendSrcRGB = function (pass) {
          return this._getUseMaterialStateMask(pass, 2);
      };
      Effect.prototype.setUseMaterialStateBlendSrcRGB = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 2, value);
      };
      Effect.prototype.getUseMaterialStateBlendSrcAlpha = function (pass) {
          return this._getUseMaterialStateMask(pass, 3);
      };
      Effect.prototype.setUseMaterialStateBlendSrcAlpha = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 3, value);
      };
      Effect.prototype.getUseMaterialStateBlendDstRGB = function (pass) {
          return this._getUseMaterialStateMask(pass, 4);
      };
      Effect.prototype.setUseMaterialStateBlendDstRGB = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 4, value);
      };
      Effect.prototype.getUseMaterialStateBlendDstAlpha = function (pass) {
          return this._getUseMaterialStateMask(pass, 5);
      };
      Effect.prototype.setUseMaterialStateBlendDstAlpha = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 5, value);
      };
      Effect.prototype.getUseMaterialStateBlendFunc = function (pass) {
          return this._getUseMaterialStateMask(pass, 6);
      };
      Effect.prototype.setUseMaterialStateBlendFunc = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 6, value);
      };
      Effect.prototype.getUseMaterialStateDepthTestOn = function (pass) {
          return this._getUseMaterialStateMask(pass, 7);
      };
      Effect.prototype.setUseMaterialStateDepthTestOn = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 7, value);
      };
      Effect.prototype.getUseMaterialStateDepthTestComp = function (pass) {
          return this._getUseMaterialStateMask(pass, 8);
      };
      Effect.prototype.setUseMaterialStateDepthTestComp = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 8, value);
      };
      Effect.prototype.getUseMaterialStateDepthWrite = function (pass) {
          return this._getUseMaterialStateMask(pass, 9);
      };
      Effect.prototype.setUseMaterialStateDepthWrite = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 9, value);
      };
      Effect.prototype.getUseMaterialStateCullOn = function (pass) {
          return this._getUseMaterialStateMask(pass, 10);
      };
      Effect.prototype.setUseMaterialStateCullOn = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 10, value);
      };
      Effect.prototype.getUseMaterialStateCullFace = function (pass) {
          return this._getUseMaterialStateMask(pass, 11);
      };
      Effect.prototype.setUseMaterialStateCullFace = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 11, value);
      };
      Effect.prototype.getUseMaterialStatePrimitiveType = function (pass) {
          return this._getUseMaterialStateMask(pass, 12);
      };
      Effect.prototype.setUseMaterialStatePrimitiveType = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 12, value);
      };
      Effect.prototype.getUseMaterialStateStencilTestOn = function (pass) {
          return this._getUseMaterialStateMask(pass, 13);
      };
      Effect.prototype.setUseMaterialStateStencilTestOn = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 13, value);
      };
      Effect.prototype.getUseMaterialStateStencilTestComp = function (pass) {
          return this._getUseMaterialStateMask(pass, 14);
      };
      Effect.prototype.setUseMaterialStateStencilTestComp = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 14, value);
      };
      Effect.prototype.getUseMaterialStateStencilTestPass = function (pass) {
          return this._getUseMaterialStateMask(pass, 15);
      };
      Effect.prototype.setUseMaterialStateStencilTestPass = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 15, value);
      };
      Effect.prototype.getUseMaterialStateStencilTestFail = function (pass) {
          return this._getUseMaterialStateMask(pass, 16);
      };
      Effect.prototype.setUseMaterialStateStencilTestFail = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 16, value);
      };
      Effect.prototype.getUseMaterialStateStencilTestZFail = function (pass) {
          return this._getUseMaterialStateMask(pass, 17);
      };
      Effect.prototype.setUseMaterialStateStencilTestZFail = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 17, value);
      };
      Effect.prototype.getUseMaterialStateColorWrite = function (pass) {
          return this._getUseMaterialStateMask(pass, 18);
      };
      Effect.prototype.setUseMaterialStateColorWrite = function (pass, value) {
          return this._setUseMaterialStateMask(pass, 18, value);
      };
      /*-------- end use state mask --------*/
      Effect.prototype.showDebugInfo = function () {
          var info = '';
          for (var pass = 0; pass < this._passCount; pass += 1) {
              info += "Pass: " + pass + ":\nPrimitiveType(" + exports.EPrimitiveType[this.getPrimitiveType(pass)] + "),\nBlendOn(" + this.getBlendOn(pass) + "), BlendSrc(" + exports.EBlendFactor[this.getBlendSrcRGB(pass)] + "," + exports.EBlendFactor[this.getBlendSrcAlpha(pass)] + "), BlendDst(" + exports.EBlendFactor[this.getBlendDstRGB(pass)] + "," + exports.EBlendFactor[this.getBlendDstAlpha(pass)] + "), BlendFunc(" + exports.EBlendEquation[this.getBlendFunc(pass)] + "),\nDepthTestOn(" + this.getDepthTestOn(pass) + "), DepthTestComp(" + exports.ECompareFunc[this.getDepthTestComp(pass)] + "), DepthWrite(" + this.getDepthWrite(pass) + "),\nCullOn(" + this.getCullOn(pass) + "), CullFace(" + exports.ECullMode[this.getCullFace(pass)] + "),\nStencilTestOn(" + this.getStencilTestOn(pass) + "), StencilComp(" + exports.ECompareFunc[this.getStencilComp(pass)] + "), StencilPass(" + exports.EStencilOp[this.getStencilPass(pass)] + "), StencilFail(" + exports.EStencilOp[this.getStencilFail(pass)] + "), StencilZFail(" + exports.EStencilOp[this.getStencilZFail(pass)] + "),\nStencilWriteMask(" + this.getStencilWriteMask(pass) + "), StencilReadMask(" + this.getStencilReadMask(pass) + "), StencilRef(" + this.getStencilRef(pass) + ")\n      ";
          }
          return info;
      };
      Effect.OFFSETS = EFFECT_OFFSETS;
      return Effect;
  }(NativeObject));

  var worker$c = backend.worker;
  var Material = /** @class */ (function (_super) {
      __extends(Material, _super);
      /*-------- Masks end --------*/
      function Material(macros, effect, uniformBlock) {
          var _this = _super.call(this) || this;
          _this._createNativeMat(macros, effect, uniformBlock);
          _this.renderQueue = 2000;
          _this._macros = macros;
          if (effect) {
              _this.effect = effect;
          }
          if (uniformBlock) {
              _this.uniforms = uniformBlock;
          }
          return _this;
      }
      Object.defineProperty(Material.prototype, "effect", {
          get: function () {
              return this._effect;
          },
          set: function (value) {
              this._u32view[MATERIAL_OFFSETS.effect] = value.id;
              this._effect = value;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "uniforms", {
          get: function () {
              return this._uniforms;
          },
          set: function (value) {
              this._u32view[MATERIAL_OFFSETS.uniformBlock] = value.id;
              this._uniforms = value;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "renderQueue", {
          get: function () {
              return this._u32view[MATERIAL_OFFSETS.renderQueue];
          },
          set: function (value) {
              this._u32view[MATERIAL_OFFSETS.renderQueue] = value;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "useInstance", {
          get: function () {
              return !!this._u32view[MATERIAL_OFFSETS.useInstance];
          },
          set: function (value) {
              this._u32view[MATERIAL_OFFSETS.useInstance] = value ? 1 : 0;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendOn", {
          get: function () {
              return EXTRACT_ENABLE_BLEND(this._u32view[MATERIAL_OFFSETS.colorDepth]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.colorDepth;
              this._u32view[offset] = PACK_ENABLE_BLEND(this._u32view[offset], value);
              this._u32view[MATERIAL_OFFSETS.colorDepthMask] |= PT_BLEND_ENABLE;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendSrcRGB", {
          get: function () {
              return EXTRACT_BLEND_FACTOR_SRC_RGB_INDEX(this._u32view[MATERIAL_OFFSETS.colorDepth]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.colorDepth;
              this._u32view[offset] = PACK_BLEND_SRC_RGB(this._u32view[offset], value);
              this._u32view[MATERIAL_OFFSETS.colorDepthMask] |= 0x00000f00;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendSrcRGBChanged", {
          get: function () {
              return !!(this._u32view[MATERIAL_OFFSETS.colorDepthMask] & 0x00000f00);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendSrcAlpha", {
          get: function () {
              return EXTRACT_BLEND_FACTOR_SRC_A_INDEX(this._u32view[MATERIAL_OFFSETS.colorDepth]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.colorDepth;
              this._u32view[offset] = PACK_BLEND_SRC_A(this._u32view[offset], value);
              this._u32view[MATERIAL_OFFSETS.colorDepthMask] |= 0x000f0000;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendSrc", {
          set: function (value) {
              this.blendSrcRGB = value;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendDstRGB", {
          get: function () {
              return EXTRACT_BLEND_FACTOR_DST_RGB_INDEX(this._u32view[MATERIAL_OFFSETS.colorDepth]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.colorDepth;
              this._u32view[offset] = PACK_BLEND_DST_RGB(this._u32view[offset], value);
              this._u32view[MATERIAL_OFFSETS.colorDepthMask] |= 0x0000f000;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendDstRGBChanged", {
          get: function () {
              return !!(this._u32view[MATERIAL_OFFSETS.colorDepthMask] & 0x0000f000);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendDstAlpha", {
          get: function () {
              return EXTRACT_BLEND_FACTOR_DST_A_INDEX(this._u32view[MATERIAL_OFFSETS.colorDepth]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.colorDepth;
              this._u32view[offset] = PACK_BLEND_DST_A(this._u32view[offset], value);
              this._u32view[MATERIAL_OFFSETS.colorDepthMask] |= 0x00f00000;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendDst", {
          set: function (value) {
              this.blendDstRGB = value;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendFunc", {
          get: function () {
              return EXTRACT_BLEND_EQUATION_RGB_INDEX(this._u32view[MATERIAL_OFFSETS.colorDepth]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.colorDepth;
              this._u32view[offset] = PACK_BLEND_EQUATION_RGB(this._u32view[offset], value);
              this._u32view[offset] = PACK_BLEND_EQUATION_A(this._u32view[offset], value);
              this._u32view[MATERIAL_OFFSETS.colorDepthMask] |= PT_BLEND_EQUATION_MASK;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "depthTestOn", {
          get: function () {
              return EXTRACT_ENABLE_DEPTH_TEST(this._u32view[MATERIAL_OFFSETS.colorDepth]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.colorDepth;
              this._u32view[offset] = PACK_DEPTH_FUNC(this._u32view[offset], value ? exports.ECompareFunc.LEQUAL : 0);
              this._u32view[MATERIAL_OFFSETS.colorDepthMask] |= PT_DEPTH_TEST_MASK;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "depthTestComp", {
          get: function () {
              return EXTRACT_DEPTH_TEST_FUNC_INDEX(this._u32view[MATERIAL_OFFSETS.colorDepth]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.colorDepth;
              this._u32view[offset] = PACK_DEPTH_FUNC(this._u32view[offset], value);
              this._u32view[MATERIAL_OFFSETS.colorDepthMask] |= PT_DEPTH_TEST_MASK;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "depthWrite", {
          get: function () {
              return EXTRACT_ENABLE_WRITE_Z(this._u32view[MATERIAL_OFFSETS.colorDepth]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.colorDepth;
              this._u32view[offset] = PACK_ENABLE_WRITE_Z(this._u32view[offset], value);
              this._u32view[MATERIAL_OFFSETS.colorDepthMask] |= PT_WRITE_Z;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "colorWrite", {
          get: function () {
              return EXTRACT_WRITE_RGBA_MASK(this._u32view[MATERIAL_OFFSETS.colorDepth]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.colorDepth;
              this._u32view[offset] = PACK_WRITE_RGBA_MASK(this._u32view[offset], value);
              this._u32view[MATERIAL_OFFSETS.colorDepthMask] |= PT_WRITE_RGBA_MASK;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "cullFace", {
          get: function () {
              return EXTRACT_CULL(this._u32view[MATERIAL_OFFSETS.state]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.state;
              this._u32view[offset] = PACK_CULL(this._u32view[offset], value);
              this._u32view[MATERIAL_OFFSETS.stateMask] |= PT_STATE_CULL_MASK;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "cullOn", {
          get: function () {
              return EXTRACT_ENABLE_CULL(this._u32view[MATERIAL_OFFSETS.state]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.state;
              this._u32view[offset] = PACK_CULL(this._u32view[offset], value ? exports.ECullMode.BACK : exports.ECullMode.NONE);
              this._u32view[MATERIAL_OFFSETS.stateMask] |= PT_STATE_CULL_MASK;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "primitiveType", {
          get: function () {
              return EXTRACT_PRIMITIVE_TYPE_INDEX(this._u32view[MATERIAL_OFFSETS.state]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.state;
              this._u32view[offset] = PACK_PRIMITIVE_TYPE(this._u32view[offset], value);
              this._u32view[MATERIAL_OFFSETS.stateMask] |= PT_STATE_PT_MASK;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilTestOn", {
          get: function () {
              return EXTRACT_ENABLE_STENCIL_TEST(this._u32view[MATERIAL_OFFSETS.fstencil]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.bstencil;
              var v = PACK_STENCIL_TEST(this._u32view[offset], value ? exports.ECompareFunc.LEQUAL : 0);
              this._u32view[offset] = v;
              offset = MATERIAL_OFFSETS.fstencil;
              this._u32view[offset] = v;
              this._u32view[MATERIAL_OFFSETS.bstencilMask] |= PT_STENCIL_TEST_MASK;
              this._u32view[MATERIAL_OFFSETS.fstencilMask] |= PT_STENCIL_TEST_MASK;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilComp", {
          get: function () {
              return EXTRACT_STENCIL_TEST_INDEX(this._u32view[MATERIAL_OFFSETS.fstencil]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.bstencil;
              var v = PACK_STENCIL_TEST(this._u32view[offset], value);
              this._u32view[offset] = v;
              offset = MATERIAL_OFFSETS.fstencil;
              this._u32view[offset] = v;
              this._u32view[MATERIAL_OFFSETS.bstencilMask] |= PT_STENCIL_TEST_MASK;
              this._u32view[MATERIAL_OFFSETS.fstencilMask] |= PT_STENCIL_TEST_MASK;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilPass", {
          get: function () {
              return EXTRACT_STENCIL_OP_PASS_INDEX(this._u32view[MATERIAL_OFFSETS.fstencil]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.bstencil;
              var v = PACK_STENCIL_OP_PASS(this._u32view[offset], value);
              this._u32view[offset] = v;
              offset = MATERIAL_OFFSETS.fstencil;
              this._u32view[offset] = v;
              this._u32view[MATERIAL_OFFSETS.bstencilMask] |= 0xf0000000;
              this._u32view[MATERIAL_OFFSETS.fstencilMask] |= 0xf0000000;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilFail", {
          get: function () {
              return EXTRACT_STENCIL_OP_SFAILURE_INDEX(this._u32view[MATERIAL_OFFSETS.fstencil]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.bstencil;
              var v = PACK_STENCIL_OP_SFAILURE(this._u32view[offset], value);
              this._u32view[offset] = v;
              offset = MATERIAL_OFFSETS.fstencil;
              this._u32view[offset] = v;
              this._u32view[MATERIAL_OFFSETS.bstencilMask] |= 0x00f00000;
              this._u32view[MATERIAL_OFFSETS.fstencilMask] |= 0x00f00000;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilZFail", {
          get: function () {
              return EXTRACT_STENCIL_OP_DFAILURE_INDEX(this._u32view[MATERIAL_OFFSETS.fstencil]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.bstencil;
              var v = PACK_STENCIL_OP_DFAILURE(this._u32view[offset], value);
              this._u32view[offset] = v;
              offset = MATERIAL_OFFSETS.fstencil;
              this._u32view[offset] = v;
              this._u32view[MATERIAL_OFFSETS.bstencilMask] |= 0x0f000000;
              this._u32view[MATERIAL_OFFSETS.fstencilMask] |= 0x0f000000;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilWriteMask", {
          get: function () {
              return EXTRACT_STENCIL_WMASK(this._u32view[MATERIAL_OFFSETS.state]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.state;
              var v = PACK_STENCIL_WMASK(this._u32view[offset], value);
              this._u32view[offset] = v;
              this._u32view[MATERIAL_OFFSETS.stateMask] |= PT_STATE_STENCIL_WMASK_MASK;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilReadMask", {
          get: function () {
              return EXTRACT_STENCIL_RMASK(this._u32view[MATERIAL_OFFSETS.fstencil]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.bstencil;
              var v = PACK_STENCIL_RMASK(this._u32view[offset], value);
              this._u32view[offset] = v;
              offset = MATERIAL_OFFSETS.fstencil;
              this._u32view[offset] = v;
              this._u32view[MATERIAL_OFFSETS.bstencilMask] |= PT_STENCIL_RMASK_MASK;
              this._u32view[MATERIAL_OFFSETS.fstencilMask] |= PT_STENCIL_RMASK_MASK;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilRef", {
          get: function () {
              return EXTRACT_STENCIL_REF(this._u32view[MATERIAL_OFFSETS.fstencil]);
          },
          set: function (value) {
              var offset = MATERIAL_OFFSETS.bstencil;
              var v = PACK_STENCIL_REF(this._u32view[offset], value);
              this._u32view[offset] = v;
              offset = MATERIAL_OFFSETS.fstencil;
              this._u32view[offset] = v;
              this._u32view[MATERIAL_OFFSETS.bstencilMask] |= PT_STENCIL_REF_MASK;
              this._u32view[MATERIAL_OFFSETS.fstencilMask] |= PT_STENCIL_REF_MASK;
          },
          enumerable: false,
          configurable: true
      });
      /*-------- Masks, only for editor --------*/
      Material.prototype._setMask = function (offset, maskBits, value) {
          this._u32view[offset] = value ? (this._u32view[offset] | maskBits) : (this._u32view[offset] & ~maskBits);
      };
      Material.prototype._getMask = function (offset, maskBits) {
          return !!(this._u32view[offset] & maskBits);
      };
      Object.defineProperty(Material.prototype, "blendOnMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.colorDepthMask, PT_BLEND_ENABLE);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.colorDepthMask, PT_BLEND_ENABLE, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendSrcRGBMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.colorDepthMask, 0x00000f00);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.colorDepthMask, 0x00000f00, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendSrcAlphaMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.colorDepthMask, 0x000f0000);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.colorDepthMask, 0x000f0000, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendSrcMask", {
          set: function (value) {
              this.blendSrcRGBMask = value;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendDstRGBMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.colorDepthMask, 0x0000f000);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.colorDepthMask, 0x0000f000, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendDstAlphaMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.colorDepthMask, 0x00f00000);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.colorDepthMask, 0x00f00000, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendDstMask", {
          set: function (value) {
              this.blendDstRGBMask = value;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "blendFuncMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.colorDepthMask, PT_BLEND_EQUATION_MASK);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.colorDepthMask, PT_BLEND_EQUATION_MASK, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "depthTestOnMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.colorDepthMask, PT_DEPTH_TEST_MASK);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.colorDepthMask, PT_DEPTH_TEST_MASK, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "depthTestCompMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.colorDepthMask, PT_DEPTH_TEST_MASK);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.colorDepthMask, PT_DEPTH_TEST_MASK, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "depthWriteMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.colorDepthMask, PT_WRITE_Z);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.colorDepthMask, PT_WRITE_Z, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "colorWriteMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.colorDepthMask, PT_WRITE_RGBA_MASK);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.colorDepthMask, PT_WRITE_RGBA_MASK, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "cullFaceMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.stateMask, PT_STATE_CULL_MASK);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.stateMask, PT_STATE_CULL_MASK, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "cullOnMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.stateMask, PT_STATE_CULL_MASK);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.stateMask, PT_STATE_CULL_MASK, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "primitiveTypeMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.stateMask, PT_STATE_PT_MASK);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.stateMask, PT_STATE_PT_MASK, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilTestOnMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.bstencilMask, PT_STENCIL_TEST_MASK);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.bstencilMask, PT_STENCIL_TEST_MASK, value);
              this._setMask(MATERIAL_OFFSETS.fstencilMask, PT_STENCIL_TEST_MASK, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilCompMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.bstencilMask, PT_STENCIL_TEST_MASK);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.bstencilMask, PT_STENCIL_TEST_MASK, value);
              this._setMask(MATERIAL_OFFSETS.fstencilMask, PT_STENCIL_TEST_MASK, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilPassMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.bstencilMask, 0xf0000000);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.bstencilMask, 0xf0000000, value);
              this._setMask(MATERIAL_OFFSETS.fstencilMask, 0xf0000000, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilFailMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.bstencilMask, 0x00f00000);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.bstencilMask, 0x00f00000, value);
              this._setMask(MATERIAL_OFFSETS.fstencilMask, 0x00f00000, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilZFailMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.bstencilMask, 0x0f000000);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.bstencilMask, 0x0f000000, value);
              this._setMask(MATERIAL_OFFSETS.fstencilMask, 0x0f000000, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilWriteMaskMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.stateMask, PT_STATE_STENCIL_WMASK_MASK);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.stateMask, PT_STATE_STENCIL_WMASK_MASK, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilReadMaskMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.bstencilMask, PT_STENCIL_RMASK_MASK);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.bstencilMask, PT_STENCIL_RMASK_MASK, value);
              this._setMask(MATERIAL_OFFSETS.fstencilMask, PT_STENCIL_RMASK_MASK, value);
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Material.prototype, "stencilRefMask", {
          get: function () {
              return this._getMask(MATERIAL_OFFSETS.bstencilMask, PT_STENCIL_REF_MASK);
          },
          set: function (value) {
              this._setMask(MATERIAL_OFFSETS.bstencilMask, PT_STENCIL_REF_MASK, value);
              this._setMask(MATERIAL_OFFSETS.fstencilMask, PT_STENCIL_REF_MASK, value);
          },
          enumerable: false,
          configurable: true
      });
      Material.prototype._createNativeMat = function (macros, effect, uniformBlock) {
          var handle = worker$c.createMaterial(macros, uniformBlock);
          if (handle.id < 0 || !handle.data) {
              // 分配失败，返回避免报错
              return;
          }
          else {
              this._handle = handle;
              this._init(handle);
              this._initU32View();
          }
      };
      Material.prototype.changeMacros = function (macros) {
          this._macros = this._macros || {};
          Object.assign(this._macros, macros);
          // worker.changeMaterialMacros(this.__handle, macros);
          worker$c.changeMaterialMacros(this.__handle, this._macros, true);
      };
      Material.prototype.getMacro = function (key) {
          var _a;
          return (_a = this._macros) === null || _a === void 0 ? void 0 : _a[key];
      };
      Material.prototype.clone = function (uniforms) {
          var res = new Material(Object.assign({}, this._macros), this._effect);
          res._f32view.set(this._f32view);
          res.uniforms = uniforms || this._uniforms.clone();
          return res;
      };
      Material.prototype.showDebugInfo = function () {
          var info = '';
          info += "RenderQueue(" + this.renderQueue + "), PrimitiveType(" + exports.EPrimitiveType[this.primitiveType] + "),\nOverwrite(" + this._u32view[MATERIAL_OFFSETS.fstencilMask].toString(16) + ", " + this._u32view[MATERIAL_OFFSETS.bstencilMask].toString(16) + ", " + this._u32view[MATERIAL_OFFSETS.blendRGBAMask].toString(16) + ", " + this._u32view[MATERIAL_OFFSETS.colorDepthMask].toString(16) + ", " + this._u32view[MATERIAL_OFFSETS.stateMask].toString(16) + "),\nBlendOn(" + this.blendOn + "), BlendSrc(" + exports.EBlendFactor[this.blendSrcRGB] + "," + exports.EBlendFactor[this.blendSrcAlpha] + "), BlendDst(" + exports.EBlendFactor[this.blendDstRGB] + "," + exports.EBlendFactor[this.blendDstAlpha] + "), BlendFunc(" + exports.EBlendEquation[this.blendFunc] + "),\nDepthTestOn(" + this.depthTestOn + "), DepthTestComp(" + exports.ECompareFunc[this.depthTestComp] + "), DepthWrite(" + this.depthWrite + "),\nCullOn(" + this.cullOn + "), CullFace(" + exports.ECullMode[this.cullFace] + "),\nStencilTestOn(" + this.stencilTestOn + "), StencilComp(" + exports.ECompareFunc[this.stencilComp] + "), StencilComp(" + exports.EStencilOp[this.stencilPass] + "), StencilFail(" + exports.EStencilOp[this.stencilFail] + "), StencilZFail(" + exports.EStencilOp[this.stencilZFail] + "),\nStencilWriteMask(" + this.stencilWriteMask + "), StencilReadMask(" + this.stencilReadMask + "), StencilRef(" + this.stencilRef + ")\n      ";
          return info;
      };
      Material.OFFSETS = MATERIAL_OFFSETS;
      return Material;
  }(NativeObject));

  var worker$b = backend.worker;
  var RenderPass = /** @class */ (function (_super) {
      __extends(RenderPass, _super);
      function RenderPass(options) {
          var _this = _super.call(this) || this;
          var opts = options;
          opts.colors.forEach(function (c, index) {
              c.texture = c.texture.__handle;
          });
          opts.depth.texture = opts.depth.texture.__handle;
          if (!options.stencil) {
              opts.stencil = { texture: { id: 0 } };
          }
          else {
              opts.stencil.texture = opts.stencil.texture.__handle;
          }
          _this._handle = worker$b.createRenderPass(opts);
          return _this;
      }
      RenderPass.SCREEN_RENDER_PASS = { id: 0, __handle: { id: 0 } };
      return RenderPass;
  }(PureResource));

  var SkeletonBoneInverseModel = /** @class */ (function (_super) {
      __extends(SkeletonBoneInverseModel, _super);
      function SkeletonBoneInverseModel() {
          return _super !== null && _super.apply(this, arguments) || this;
      }
      SkeletonBoneInverseModel.prototype.setBoneInverseMatrix = function (matrices) {
          var view = new Float32Array(matrices.length);
          view.set(matrices);
          this._createNativeModel(exports.EDataModelType.SkeletonBoneInverse, view.buffer);
      };
      return SkeletonBoneInverseModel;
  }(DataModel));

  var worker$a = backend.worker;
  /**
   * 纹理资源。
   */
  var Texture = /** @class */ (function (_super) {
      __extends(Texture, _super);
      function Texture(options) {
          var _this = _super.call(this) || this;
          var canvas = options.canvas;
          if (canvas) {
              _this._width = canvas.width;
              _this._height = canvas.height;
          }
          else {
              _this._width = options.width;
              _this._height = options.height;
          }
          _this._type = options.type || exports.ETextureType.D2;
          _this._slice = options.slices || 0;
          _this._mips = options.mips || 0;
          _this._pixelFormat = options.pixelFormat || exports.ETextureFormat.RGBA8;
          if (Math.log2(_this.width) % 1 !== 0 || Math.log2(_this.height) % 1 !== 0) {
              // not a pot texture
              _this.fixNonPOT(options);
          }
          _this._flags = _this._buildFlags(options);
          var handle = canvas
              ? worker$a.createAutoUpdateTextureFromCanvas(canvas)
              : worker$a.createTexture(_this._type, _this._width, _this._height, _this._slice, _this._mips, _this._pixelFormat, _this._flags, options.source, options.offsets);
          if (!handle) {
              // hack!!!!!!!!!!!!!!!!!!!!
              _this._handle = { id: 0 };
          }
          else {
              _this._handle = handle;
          }
          return _this;
      }
      Object.defineProperty(Texture.prototype, "type", {
          get: function () {
              return this._type;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Texture.prototype, "width", {
          get: function () {
              return this._width;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Texture.prototype, "height", {
          get: function () {
              return this._height;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Texture.prototype, "slice", {
          get: function () {
              return this._slice;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Texture.prototype, "mips", {
          get: function () {
              return this._mips;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Texture.prototype, "pixelFormat", {
          get: function () {
              return this._pixelFormat;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Texture.prototype, "wrapU", {
          get: function () {
              return renderEnv.isWrongWrapMapping ? EXTRACT_SAMPLER_WRAP_R_INDEX(this._flags) : EXTRACT_SAMPLER_WRAP_S_INDEX(this._flags);
          },
          set: function (value) {
              worker$a.updateTextureFlags(this.__handle, this._flags = renderEnv.isWrongWrapMapping ? PACK_SAMPLER_WRAP_R_INDEX(this._flags, value) : PACK_SAMPLER_WRAP_S_INDEX(this._flags, value));
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Texture.prototype, "wrapV", {
          get: function () {
              return renderEnv.isWrongWrapMapping ? EXTRACT_SAMPLER_WRAP_S_INDEX(this._flags) : EXTRACT_SAMPLER_WRAP_T_INDEX(this._flags);
          },
          set: function (value) {
              worker$a.updateTextureFlags(this.__handle, this._flags = renderEnv.isWrongWrapMapping ? PACK_SAMPLER_WRAP_S_INDEX(this._flags, value) : PACK_SAMPLER_WRAP_T_INDEX(this._flags, value));
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Texture.prototype, "wrapW", {
          get: function () {
              return renderEnv.isWrongWrapMapping ? EXTRACT_SAMPLER_WRAP_T_INDEX(this._flags) : EXTRACT_SAMPLER_WRAP_R_INDEX(this._flags);
          },
          set: function (value) {
              worker$a.updateTextureFlags(this.__handle, this._flags = renderEnv.isWrongWrapMapping ? PACK_SAMPLER_WRAP_T_INDEX(this._flags, value) : PACK_SAMPLER_WRAP_R_INDEX(this._flags, value));
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Texture.prototype, "magFilter", {
          get: function () {
              return EXTRACT_SAMPLER_FILTER_MAG_INDEX(this._flags);
          },
          set: function (value) {
              worker$a.updateTextureFlags(this.__handle, this._flags = PACK_SAMPLER_FILTER_MAG_INDEX(this._flags, value));
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Texture.prototype, "minFilter", {
          get: function () {
              return EXTRACT_SAMPLER_FILTER_MIN_INDEX(this._flags);
          },
          set: function (value) {
              worker$a.updateTextureFlags(this.__handle, this._flags = PACK_SAMPLER_FILTER_MIN_INDEX(this._flags, value));
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Texture.prototype, "anisoLevel", {
          get: function () {
              return EXTRACT_TEXTURE_ANISO(this._flags);
          },
          set: function (value) {
              worker$a.updateTextureFlags(this.__handle, this._flags = PACK_TEXTURE_ANISO(this._flags, value));
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Texture.prototype, "sampleCount", {
          get: function () {
              return EXTRACT_TEXTURE_SAMPLE_COUNT(this._flags);
          },
          set: function (value) {
              worker$a.updateTextureFlags(this.__handle, this._flags = PACK_TEXTURE_SAMPLE_COUNT(this._flags, value));
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Texture.prototype, "generateMipmaps", {
          get: function () {
              return EXTRACT_TEXTURE_GENERATE_MIPMAP(this._flags);
          },
          set: function (value) {
              worker$a.updateTextureFlags(this.__handle, this._flags = PACK_TEXTURE_GENERATE_MIPMAP(this._flags, value));
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(Texture.prototype, "isRenderTarget", {
          get: function () {
              return EXTRACT_TEXTURE_IS_RT(this._flags);
          },
          set: function (value) {
              worker$a.updateTextureFlags(this.__handle, this._flags = PACK_TEXTURE_IS_RT(this._flags, value));
          },
          enumerable: false,
          configurable: true
      });
      /**
       * 在创建了纹理后，可以用此方法来更新。
       */
      Texture.prototype.update = function (options) {
          var level = options.level || 0;
          worker$a.updateTexture(this.__handle, level, options.slice || 0, options.xoffset || 0, options.yoffset || 0, options.zoffset || 0, options.width || (this.width >> level) || 1, options.height || (this.height >> level) || 1, options.buffer);
      };
      Texture.prototype._buildFlags = function (options) {
          this._flags = 0;
          if (renderEnv.isWrongWrapMapping) {
              options.wrapU && (this._flags = PACK_SAMPLER_WRAP_R_INDEX(this._flags, options.wrapU));
              options.wrapV && (this._flags = PACK_SAMPLER_WRAP_S_INDEX(this._flags, options.wrapV));
              options.wrapW && (this._flags = PACK_SAMPLER_WRAP_T_INDEX(this._flags, options.wrapW));
          }
          else {
              options.wrapU && (this._flags = PACK_SAMPLER_WRAP_S_INDEX(this._flags, options.wrapU));
              options.wrapV && (this._flags = PACK_SAMPLER_WRAP_T_INDEX(this._flags, options.wrapV));
              options.wrapW && (this._flags = PACK_SAMPLER_WRAP_R_INDEX(this._flags, options.wrapW));
          }
          options.magFilter && (this._flags = PACK_SAMPLER_FILTER_MAG_INDEX(this._flags, options.magFilter));
          options.minFilter && (this._flags = PACK_SAMPLER_FILTER_MIN_INDEX(this._flags, options.minFilter));
          options.anisoLevel && (this._flags = PACK_TEXTURE_ANISO(this._flags, options.anisoLevel));
          options.sampleCount && (this._flags = PACK_TEXTURE_SAMPLE_COUNT(this._flags, options.sampleCount));
          options.generateMipmaps && (this._flags = PACK_TEXTURE_GENERATE_MIPMAP(this._flags, options.generateMipmaps));
          options.isRenderTarget && (this._flags = PACK_TEXTURE_IS_RT(this._flags, options.isRenderTarget));
          options.isWriteOnly && (this._flags = PACK_TEXTURE_IS_RT_WRITE_ONLY(this._flags, options.isWriteOnly));
          return this._flags;
      };
      Texture.prototype.fixNonPOT = function (options) {
          options.wrapU = exports.EWrapMode.CLAMP_TO_EDGE;
          options.wrapV = exports.EWrapMode.CLAMP_TO_EDGE;
          options.wrapW = exports.EWrapMode.CLAMP_TO_EDGE;
          options.minFilter = NonPOTFilterFixMap.get(options.minFilter); // possibly undefined
          options.magFilter = NonPOTFilterFixMap.get(options.magFilter);
          options.anisoLevel = 0;
          options.mips = 0;
          options.generateMipmaps = false;
      };
      Texture.prototype.showDebugInfo = function () {
          var info = '';
          info += "type(" + exports.ETextureType[this.type] + "), format(" + exports.ETextureFormat[this.pixelFormat] + "),\nwidth(" + this.width + "), height(" + this.height + "), slice(" + this.slice + "), mips(" + this.mips + "),\nwrapU(" + exports.EWrapMode[this.wrapU] + "), wrapV(" + exports.EWrapMode[this.wrapV] + "), wrapW(" + exports.EWrapMode[this.wrapW] + "),\nmagFilter(" + exports.EFilterMode[this.magFilter] + "), minFilter(" + exports.EFilterMode[this.minFilter] + "),\nanisoLevel(" + this.anisoLevel + "), sampleCount(" + this.sampleCount + "), generateMipmaps(" + this.generateMipmaps + ")\n    ";
          return info;
      };
      return Texture;
  }(PureResource));
  var NonPOTFilterFixMap = new Map([
      [exports.EFilterMode.LINEAR, exports.EFilterMode.LINEAR],
      [exports.EFilterMode.LINEAR_MIPMAP_LINEAR, exports.EFilterMode.LINEAR],
      [exports.EFilterMode.LINEAR_MIPMAP_NEAREST, exports.EFilterMode.LINEAR],
      [exports.EFilterMode.NEAREST, exports.EFilterMode.NEAREST],
      [exports.EFilterMode.NEAREST_MIPMAP_LINEAR, exports.EFilterMode.NEAREST],
      [exports.EFilterMode.NEAREST_MIPMAP_NEAREST, exports.EFilterMode.NEAREST]
  ]);

  var worker$9 = backend.worker;
  /**
   * 存储Uniform的一个区块。
   */
  var UniformBlock = /** @class */ (function (_super) {
      __extends(UniformBlock, _super);
      /**
       * @param descriptor 描述符。
       */
      function UniformBlock(descriptor) {
          var _this = _super.call(this) || this;
          _this._handle = _this._createNativeObj(descriptor);
          if (_this._handle.data) {
              _this._f32View = new Float32Array(_this._handle.data);
              _this._u32View = new Uint32Array(_this._handle.data);
          }
          _this._descriptor = descriptor;
          return _this;
      }
      /**
       * @internal
       */
      UniformBlock.CREATE_FAKE = function (descriptor) {
          return new FakeUniformBlock(descriptor);
      };
      Object.defineProperty(UniformBlock.prototype, "_dataView", {
          /**
           * @internal
           */
          get: function () {
              return this._f32View;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(UniformBlock.prototype, "descriptor", {
          /**
           * 描述符。
           */
          get: function () {
              return this._descriptor;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(UniformBlock.prototype, "textures", {
          /**
           * @internal
           */
          get: function () {
              return this._textures;
          },
          enumerable: false,
          configurable: true
      });
      UniformBlock.prototype._createNativeObj = function (descriptor) {
          return worker$9.createUniformBlock(descriptor.__handle) || { id: 0 };
      };
      /**
       * 是否包含某个成员uniform。
       */
      UniformBlock.prototype.hasKey = function (key) {
          return this._descriptor.hasKey(key);
      };
      /**
       * 设置某个成员uniform。
       */
      UniformBlock.prototype.setUniform = function (key, value) {
          var pair = this._descriptor.layout[key];
          if (!pair) {
              return false;
          }
          if (pair[0] === exports.EUniformType.SAMPLER) {
              if (value instanceof Texture) {
                  this._textures = this._textures || {};
                  this._textures[key] = value;
                  value = value.id;
              }
              else if (this._textures) {
                  this._textures[key] = undefined;
              }
          }
          this._descriptor.setUniform(key, value, this._f32View, this._u32View);
          return true;
      };
      /**
       * 获取某个成员uniform。
       * 如果是返回`number`，则是纹理的id。
       */
      UniformBlock.prototype.getUniform = function (key) {
          return this._descriptor.getUniform(key, this._f32View, this._u32View);
      };
      /**
       * 获取某个成员uniform的texture实例。
       */
      UniformBlock.prototype.getTexture = function (key) {
          return this._textures[key];
      };
      /**
       * @internal
       */
      UniformBlock.prototype._getFloatOffset = function (key) {
          return this._descriptor._getFloatOffset(key);
      };
      /**
       * @internal
       */
      UniformBlock.prototype.setAllData = function (data) {
          this._f32View.set(data, 0);
      };
      /**
       * 科隆某个uniform。
       */
      UniformBlock.prototype.clone = function () {
          var res = new UniformBlock(this._descriptor);
          // 如果没有Uniform，为空
          if (!res._f32View) {
              return res;
          }
          if (this._textures) {
              res._textures = Object.assign({}, this._textures);
          }
          res._f32View.set(this._f32View);
          return res;
      };
      /**
       * 复制某个uniform。
       */
      UniformBlock.prototype.copy = function (ub) {
          if (this._descriptor.id === ub._descriptor.id) {
              this._f32View.set(ub._f32View);
              this._textures = ub.textures;
              return;
          }
          var layout = ub.descriptor.layout;
          for (var key in layout) {
              if (this.hasKey(key)) {
                  var value = ub.getUniform(key);
                  this.setUniform(key, value);
                  if (ub._textures && ub._textures[key]) {
                      this._textures = this._textures || {};
                      this._textures[key] = ub._textures[key];
                  }
              }
          }
      };
      UniformBlock.prototype.showDebugInfo = function () {
          var _this = this;
          var info = '';
          Object.keys(this._descriptor.layout).forEach(function (key) {
              var value = _this._descriptor.getUniform(key, _this._f32View, _this._u32View);
              info += key + ": [" + (typeof value === 'number' ? [value] : value).join(',') + "]\n";
          });
          return info;
      };
      return UniformBlock;
  }(PureResource));
  var FakeUniformBlock = /** @class */ (function (_super) {
      __extends(FakeUniformBlock, _super);
      function FakeUniformBlock() {
          return _super !== null && _super.apply(this, arguments) || this;
      }
      FakeUniformBlock.prototype._createNativeObj = function (descriptor) {
          return {
              id: 0,
              data: new ArrayBuffer(descriptor.size * 4)
          };
      };
      return FakeUniformBlock;
  }(UniformBlock));

  var worker$8 = backend.worker;
  /**
   * UniformBlock描述符。
   */
  var UniformDescriptor = /** @class */ (function (_super) {
      __extends(UniformDescriptor, _super);
      function UniformDescriptor(options) {
          var _this = _super.call(this) || this;
          // key: [type, offset, size, length, realType, needTranspose]
          // when using glsl2, matX will be converted to X x vectorX
          // but matX need to be transposed, so we need this fucking realType
          _this._layout = {};
          var preOffset = 0;
          options.uniforms.forEach(function (pair) {
              var realType = pair.type;
              if (!renderEnv.neverTranspose) {
                  // hack for es2
                  if (pair.type === exports.EUniformType.MAT4) {
                      pair.type = exports.EUniformType.FLOAT4;
                      pair.num = (pair.num || 1) * 4;
                  }
              }
              var size = pair.num !== undefined ? pair.num : 1;
              var len = _this._getLength(pair.type);
              var offset = preOffset + len * size;
              _this._layout[pair.name] = [pair.type, preOffset, size, len, realType, !!pair.needTranspose];
              preOffset = offset;
          });
          _this._size = preOffset;
          _this._handle = worker$8.createUniformBlockDescriptor(options) || { id: 0 };
          return _this;
      }
      Object.defineProperty(UniformDescriptor.prototype, "layout", {
          /**
           * @internal
           */
          get: function () {
              return this._layout;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(UniformDescriptor.prototype, "size", {
          /**
           * 以Float计的长度。
           */
          get: function () {
              return this._size;
          },
          enumerable: false,
          configurable: true
      });
      UniformDescriptor.prototype._getLength = function (type) {
          var len = 0;
          switch (type) {
              case exports.EUniformType.FLOAT:
                  len = 1;
                  break;
              case exports.EUniformType.FLOAT2:
                  len = 2;
                  break;
              case exports.EUniformType.FLOAT3:
                  len = 3;
                  break;
              case exports.EUniformType.FLOAT4:
                  len = 4;
              case exports.EUniformType.MAT2:
                  len = 4;
                  break;
              case exports.EUniformType.MAT3:
                  len = 9;
                  break;
              case exports.EUniformType.MAT4:
                  len = 16;
                  break;
              case exports.EUniformType.SAMPLER:
                  len = 1;
                  break;
          }
          return len;
      };
      /**
       * @internal
       */
      UniformDescriptor.prototype.hasKey = function (key) {
          return this._layout[key] !== undefined;
      };
      /**
       * @internal
       */
      UniformDescriptor.prototype.setUniform = function (key, value, f32, u32) {
          var pair = this._layout[key];
          if (!pair) {
              return;
          }
          var t = pair[0], offset = pair[1];
          switch (t) {
              case exports.EUniformType.FLOAT:
              case exports.EUniformType.FLOAT2:
              case exports.EUniformType.FLOAT3:
              case exports.EUniformType.FLOAT4:
              case exports.EUniformType.MAT2:
              case exports.EUniformType.MAT3:
              case exports.EUniformType.MAT4:
                  this._setFloatArray(offset, value, f32);
                  break;
              case exports.EUniformType.SAMPLER:
                  this._setTexture(offset, value, u32);
                  break;
          }
      };
      UniformDescriptor.prototype._setFloatArray = function (offset, value, buffer) {
          buffer.set(value, offset);
      };
      UniformDescriptor.prototype._setTexture = function (offset, texture, buffer) {
          buffer[offset] = texture;
      };
      /**
       * @internal
       */
      UniformDescriptor.prototype.getUniform = function (key, f32, u32) {
          var pair = this._layout[key];
          if (!pair) {
              return null;
          }
          var t = pair[0], offset = pair[1], size = pair[2], length = pair[3];
          switch (t) {
              case exports.EUniformType.FLOAT:
              case exports.EUniformType.FLOAT2:
              case exports.EUniformType.FLOAT3:
              case exports.EUniformType.FLOAT4:
              case exports.EUniformType.MAT2:
              case exports.EUniformType.MAT3:
              case exports.EUniformType.MAT4:
                  return new Float32Array(f32.buffer, offset * 4, size * length);
              case exports.EUniformType.SAMPLER:
                  return u32[offset];
          }
      };
      /**
       * @internal
       */
      UniformDescriptor.prototype._getFloatOffset = function (key) {
          var tmp = this._layout[key];
          return tmp ? tmp[1] : -1;
      };
      return UniformDescriptor;
  }(PureResource));

  var worker$7 = backend.worker;
  var IndexBuffer = /** @class */ (function (_super) {
      __extends(IndexBuffer, _super);
      function IndexBuffer(buffer, is32bits) {
          if (is32bits === void 0) { is32bits = false; }
          var _this = _super.call(this) || this;
          _this._handle = worker$7.createIndexBuffer(buffer, is32bits) || { id: 0 };
          _this._byteSize = buffer.byteLength;
          return _this;
      }
      Object.defineProperty(IndexBuffer.prototype, "byteSize", {
          get: function () {
              return this._byteSize;
          },
          enumerable: false,
          configurable: true
      });
      IndexBuffer.prototype.update = function (buffer, offset) {
          worker$7.updateIndexBuffer(this.__handle, buffer, offset);
      };
      return IndexBuffer;
  }(PureResource));

  var worker$6 = backend.worker;
  var IndexData = /** @class */ (function (_super) {
      __extends(IndexData, _super);
      function IndexData(size) {
          var _this = _super.call(this) || this;
          _this._handle = worker$6.createIndexData(size);
          return _this;
      }
      Object.defineProperty(IndexData.prototype, "data", {
          get: function () {
              return this._handle.data;
          },
          enumerable: false,
          configurable: true
      });
      return IndexData;
  }(PureResource));

  var worker$5 = backend.worker;
  /**
   * 顶点数据。
   */
  var VertexBuffer = /** @class */ (function (_super) {
      __extends(VertexBuffer, _super);
      function VertexBuffer(buffer, layout) {
          var _this = _super.call(this) || this;
          _this._handle = worker$5.createVertexBuffer(buffer, layout.__handle) || { id: 0 };
          _this._layout = layout;
          _this._byteSize = buffer.byteLength;
          return _this;
      }
      Object.defineProperty(VertexBuffer.prototype, "byteSize", {
          get: function () {
              return this._byteSize;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(VertexBuffer.prototype, "layout", {
          get: function () {
              return this._layout;
          },
          enumerable: false,
          configurable: true
      });
      VertexBuffer.prototype.update = function (buffer, offset) {
          worker$5.updateVertexBuffer(this.__handle, buffer, offset);
      };
      return VertexBuffer;
  }(PureResource));

  var worker$4 = backend.worker;
  /**
   * 用于合批的顶点数据。
   */
  var VertexData = /** @class */ (function (_super) {
      __extends(VertexData, _super);
      function VertexData(layout, size, batchDesc) {
          var _this = _super.call(this) || this;
          _this._handle = worker$4.createVertexData(layout.__handle, size, batchDesc.__handle);
          _this._layout = layout;
          return _this;
      }
      Object.defineProperty(VertexData.prototype, "layout", {
          get: function () {
              return this._layout;
          },
          enumerable: false,
          configurable: true
      });
      Object.defineProperty(VertexData.prototype, "data", {
          get: function () {
              return this._handle.data;
          },
          enumerable: false,
          configurable: true
      });
      return VertexData;
  }(PureResource));

  var worker$3 = backend.worker;
  /**
   * 顶点布局描述。
   */
  var VertexLayout = /** @class */ (function (_super) {
      __extends(VertexLayout, _super);
      function VertexLayout(options) {
          var _this = _super.call(this) || this;
          _this._attributes = {};
          _this._usages = {};
          _this._options = options;
          options.attributes.forEach(function (opt) {
              _this._attributes[opt.name] = opt;
              _this._usages[opt.usage] = opt;
          });
          _this._handle = worker$3.createVertexLayout(options);
          return _this;
      }
      Object.defineProperty(VertexLayout.prototype, "stride", {
          /**
           * 顶点数据单位步长。
           */
          get: function () {
              return this._options.stride;
          },
          enumerable: false,
          configurable: true
      });
      /**
       * 获取某个属性的配置。
       */
      VertexLayout.prototype.getConfigByName = function (name) {
          return this._attributes[name];
      };
      /**
       * 获取某个用途的属性的配置。
       */
      VertexLayout.prototype.getConfigByUsage = function (usage) {
          return this._usages[usage];
      };
      return VertexLayout;
  }(PureResource));

  var worker$2 = backend.worker;
  /**
   * 用于合批的顶点数据的描述符。
   */
  var VertexDataDescriptor = /** @class */ (function (_super) {
      __extends(VertexDataDescriptor, _super);
      function VertexDataDescriptor(options) {
          var _this = _super.call(this) || this;
          _this._options = options;
          _this._handle = worker$2.createVertexDataDescriptor(options);
          return _this;
      }
      return VertexDataDescriptor;
  }(PureResource));

  var worker$1 = backend.worker;
  /**
   * 视图，用于控制清屏、视图区域等配置。
   */
  var View = /** @class */ (function (_super) {
      __extends(View, _super);
      function View(options) {
          var _this = _super.call(this) || this;
          _this._handle = worker$1.createView(options);
          return _this;
      }
      return View;
  }(PureResource));

  /**
   * index.ts
   *
   * @Author  : hikaridai(hikaridai@tencent.com)
   * @Date    : 2020/8/18 下午4:58:50
   */
  // #endif
  var worker = backend.worker, IS_VALID = backend.IS_VALID, GET_MAIN_CANVAS = backend.GET_MAIN_CANVAS, Image = backend.Image, Phys3D = backend.Phys3D;
  var downloader = worker.downloader;
  var createWeakRef = worker.createWeakRef;
  var createWeakRefSentry = worker.createWeakRefSentry;
  var createNativeUUMap = worker.createNativeUUMap;
  var createNativeSUMap = worker.createNativeSUMap;
  var createNativeULUMap = worker.createNativeULUMap;
  var loadTTFFont = worker.loadTTFFont;
  var getGlyphInfo = worker.getGlyphInfo;
  var refreshNodesWorldTransform = worker.refreshNodesWorldTransform;
  var setGlobalPhysicSystem = worker.setGlobalPhysicSystem;
  var bindRigidBodyToNode = worker.bindRigidBodyToNode;
  var bindCCTToNode = worker.bindCCTToNode;
  var unbindRigidBody = worker.unbindRigidBody;
  var unbindCCT = worker.unbindCCT;
  var decodeBase64 = worker.decodeBase64;
  var initDraco = worker.initDraco;
  var decodeDraco = worker.decodeDraco;
  function destroy() {
      CLEAR_SLS();
      worker.destroy();
  }
  function update(delta) {
      // #if defined(NATIVE)
      crossContext$1.flush();
      // #endif
      CHECK_SLS_RESIZE();
      worker.update(delta);
  }
  var setNodeName = function (id, name) {
      {
          return;
      }
  };
  var setRenderComponentName = function (comp, name) {
      {
          return;
      }
  };
  var debugPrint = function (msg) {
      {
          return;
      }
  };
  var eb = worker.eventBridge;
  var eventBridge = {
      bindEntityToBone: eb.bindEntityToBone.bind(eb),
      unbindEntityFromBone: eb.unbindEntityFromBone.bind(eb),
      bindEntitiesToBones: eb.bindEntitiesToBones.bind(eb),
      unbindEntitiesFromBones: eb.unbindEntitiesFromBones.bind(eb)
  };

  /**
   * index.ts
   *
   * @Author  : hikaridai(hikaridai@tencent.com)
   * @Date    : 2020/8/18 下午4:48:36
   */
  var VERSION = '1.0.4';
  var NG = undefined;
  if (typeof window !== 'undefined' && window.top) {
      //@ts-ignore
      NG = window.top.NativeGlobal;
  }
  else if (typeof NativeGlobal !== 'undefined') {
      NG = NativeGlobal;
  }
  else {
      NG = wx === null || wx === void 0 ? void 0 : wx.NativeGlobal;
  }
  // 跟着公共库的版本才暴露
  var Puppet = typeof NG !== 'undefined' && NG.Puppet;
  // #endif
  /**
   * 根据数据，返回二维节点对应结构的Float32array
   */
  function composeRawBufferEntity2D(rotation, position, scale) {
      var rawBuffer = new ArrayBuffer(4 * ENTITY2D_OFFSETS.size);
      var f32View = new Float32Array(rawBuffer);
      f32View[ENTITY2D_OFFSETS.rotation] = rotation;
      f32View[ENTITY2D_OFFSETS.position] = position[0];
      f32View[ENTITY2D_OFFSETS.position + 1] = position[1];
      f32View[ENTITY2D_OFFSETS.scale] = scale[0];
      f32View[ENTITY2D_OFFSETS.scale + 1] = scale[1];
      return f32View;
  }
  /**
   * 根据数据，返回三维节点对应结构的Float32array，除WorldMatrix。
   */
  function composeRawBufferEntity3D(useEuler, rotation, position, scale) {
      var rawBuffer = new ArrayBuffer(4 * (ENTITY3D_OFFSETS.size - 16));
      var u32View = new Uint32Array(rawBuffer);
      var f32View = new Float32Array(rawBuffer);
      // u32View[0] = 0xffffffff;
      u32View[ENTITY3D_OFFSETS.rotationType] = useEuler ? 0 : 1;
      f32View.set(rotation, ENTITY3D_OFFSETS.rotation /* 2*4 */);
      f32View.set(position, ENTITY3D_OFFSETS.position /* 6*4 */);
      f32View.set(scale, ENTITY3D_OFFSETS.scale /* 9*4 */);
      return f32View;
  }
  /**
   * 根据数据，返回三维节点对应结构的Float32array
   */
  function composeRawBufferEntity3DWhole(useEuler, rotation, position, scale) {
      var rawBuffer = new ArrayBuffer(4 * ENTITY3D_OFFSETS.size);
      var u32View = new Uint32Array(rawBuffer);
      var f32View = new Float32Array(rawBuffer);
      // u32View[0] = 0xffffffff;
      u32View[ENTITY3D_OFFSETS.rotationType] = useEuler ? 0 : 1;
      f32View.set(rotation, ENTITY3D_OFFSETS.rotation /* 2*4 */);
      f32View.set(position, ENTITY3D_OFFSETS.position /* 6*4 */);
      f32View.set(scale, ENTITY3D_OFFSETS.scale /* 9*4 */);
      return f32View;
  }

  exports.AnimationClipBinding = AnimationClipBinding;
  exports.AnimationClipModel = AnimationClipModel;
  exports.AnimatorComponent = AnimatorComponent;
  exports.AnimatorControllerModel = AnimatorControllerModel;
  exports.AnimatorControllerStateModel = AnimatorControllerStateModel;
  exports.CAMERA_OFFSETS = CAMERA_OFFSETS;
  exports.CULLING_OFFSETS = CULLING_OFFSETS;
  exports.CameraComponent = CameraComponent;
  exports.CullingComponent = CullingComponent;
  exports.DYNAMIC_BONES_OFFSETS = DYNAMIC_BONES_OFFSETS;
  exports.DataBuffer = DataBuffer;
  exports.DataModel = DataModel;
  exports.Downloader = downloader;
  exports.DynamicBonesComponent = DynamicBonesComponent;
  exports.EFFECT_OFFSETS = EFFECT_OFFSETS;
  exports.ENTITY2D_OFFSETS = ENTITY2D_OFFSETS;
  exports.ENTITY3D_EXT_OFFSETS = ENTITY3D_EXT_OFFSETS;
  exports.ENTITY3D_OFFSETS = ENTITY3D_OFFSETS;
  exports.Effect = Effect;
  exports.Entity2D = Entity2D;
  exports.Entity3D = Entity3D;
  exports.GET_MAIN_CANVAS = GET_MAIN_CANVAS;
  exports.IS_VALID = IS_VALID;
  exports.Image = Image;
  exports.IndexBuffer = IndexBuffer;
  exports.IndexData = IndexData;
  exports.LIGHT_OFFSETS = LIGHT_OFFSETS;
  exports.LightCameraComponent = LightCameraComponent;
  exports.MATERIAL_OFFSETS = MATERIAL_OFFSETS;
  exports.MESH_OFFSETS = MESH_OFFSETS;
  exports.Material = Material;
  exports.MeshRendererComponent = MeshRendererComponent;
  exports.POOL_SUB_ID_MASK = POOL_SUB_ID_MASK;
  exports.POOL_SUB_ID_SHIT = POOL_SUB_ID_SHIT;
  exports.Phys3D = Phys3D;
  exports.Puppet = Puppet;
  exports.RENDER_ENV_OFFSETS = RENDER_ENV_OFFSETS;
  exports.RenderEnv = RenderEnv;
  exports.RenderPass = RenderPass;
  exports.SKINNED_SKELETON_OFFSETS = SKINNED_SKELETON_OFFSETS;
  exports.ScalableList = ScalableList;
  exports.SkeletonBoneInverseModel = SkeletonBoneInverseModel;
  exports.SkinnedSkeletonComponent = SkinnedSkeletonComponent;
  exports.Texture = Texture;
  exports.UniformBlock = UniformBlock;
  exports.UniformDescriptor = UniformDescriptor;
  exports.VERSION = VERSION;
  exports.VertexBuffer = VertexBuffer;
  exports.VertexData = VertexData;
  exports.VertexDataDescriptor = VertexDataDescriptor;
  exports.VertexLayout = VertexLayout;
  exports.View = View;
  exports.bindCCTToNode = bindCCTToNode;
  exports.bindRigidBodyToNode = bindRigidBodyToNode;
  exports.composeRawBufferEntity2D = composeRawBufferEntity2D;
  exports.composeRawBufferEntity3D = composeRawBufferEntity3D;
  exports.composeRawBufferEntity3DWhole = composeRawBufferEntity3DWhole;
  exports.createNativeSUMap = createNativeSUMap;
  exports.createNativeULUMap = createNativeULUMap;
  exports.createNativeUUMap = createNativeUUMap;
  exports.createWeakRef = createWeakRef;
  exports.createWeakRefSentry = createWeakRefSentry;
  exports.crossContext = crossContext$1;
  exports.debugPrint = debugPrint;
  exports.decodeBase64 = decodeBase64;
  exports.decodeDraco = decodeDraco;
  exports.destroy = destroy;
  exports.eventBridge = eventBridge;
  exports.getGlyphInfo = getGlyphInfo;
  exports.initDraco = initDraco;
  exports.loadTTFFont = loadTTFFont;
  exports.refreshNodesWorldTransform = refreshNodesWorldTransform;
  exports.renderEnv = renderEnv;
  exports.setGlobalPhysicSystem = setGlobalPhysicSystem;
  exports.setNodeName = setNodeName;
  exports.setRenderComponentName = setRenderComponentName;
  exports.unbindCCT = unbindCCT;
  exports.unbindRigidBody = unbindRigidBody;
  exports.update = update;

  Object.defineProperty(exports, '__esModule', { value: true });

}));


      topExports.EVertexFormat = exports.EVertexFormat;
topExports.EVertexStep = exports.EVertexStep;
topExports.EIndexType = exports.EIndexType;
topExports.ETextureType = exports.ETextureType;
topExports.ETextureFormat = exports.ETextureFormat;
topExports.EWrapMode = exports.EWrapMode;
topExports.EFilterMode = exports.EFilterMode;
topExports.EUniformType = exports.EUniformType;
topExports.ECullMode = exports.ECullMode;
topExports.EFaceWinding = exports.EFaceWinding;
topExports.ECompareFunc = exports.ECompareFunc;
topExports.EStencilOp = exports.EStencilOp;
topExports.EBlendFactor = exports.EBlendFactor;
topExports.EBlendEquation = exports.EBlendEquation;
topExports.EColorMask = exports.EColorMask;
topExports.EPixelType = exports.EPixelType;
topExports.ELoadAction = exports.ELoadAction;
topExports.EDataModelType = exports.EDataModelType;
topExports.EMeshRenderType = exports.EMeshRenderType;
topExports.EPrimitiveType = exports.EPrimitiveType;
topExports.EShadowMode = exports.EShadowMode;
topExports.EShadowFitMode = exports.EShadowFitMode;
topExports.EVertexLayoutUsage = exports.EVertexLayoutUsage;
topExports.EVertexBatchOperator = exports.EVertexBatchOperator;
topExports.EAnimationBlendType = exports.EAnimationBlendType;
topExports.EUseDefaultAddedAction = exports.EUseDefaultAddedAction;
topExports.EUseDefaultRetainedAction = exports.EUseDefaultRetainedAction;
topExports.EUseDefaultRemovedAction = exports.EUseDefaultRemovedAction;
topExports.ESkinnedSkeletonFlag = exports.ESkinnedSkeletonFlag;
topExports.RENDER_ENV_OFFSETS = exports.RENDER_ENV_OFFSETS;
topExports.POOL_SUB_ID_MASK = exports.POOL_SUB_ID_MASK;
topExports.POOL_SUB_ID_SHIT = exports.POOL_SUB_ID_SHIT;
topExports.ENTITY2D_OFFSETS = exports.ENTITY2D_OFFSETS;
topExports.ENTITY3D_OFFSETS = exports.ENTITY3D_OFFSETS;
topExports.ENTITY3D_EXT_OFFSETS = exports.ENTITY3D_EXT_OFFSETS;
topExports.CULLING_OFFSETS = exports.CULLING_OFFSETS;
topExports.CAMERA_OFFSETS = exports.CAMERA_OFFSETS;
topExports.LIGHT_OFFSETS = exports.LIGHT_OFFSETS;
topExports.MESH_OFFSETS = exports.MESH_OFFSETS;
topExports.EFFECT_OFFSETS = exports.EFFECT_OFFSETS;
topExports.MATERIAL_OFFSETS = exports.MATERIAL_OFFSETS;
topExports.SKINNED_SKELETON_OFFSETS = exports.SKINNED_SKELETON_OFFSETS;
topExports.DYNAMIC_BONES_OFFSETS = exports.DYNAMIC_BONES_OFFSETS;
topExports.EEventType = exports.EEventType;
topExports.EDracoErrorCode = exports.EDracoErrorCode;
topExports.EDracoGeometryType = exports.EDracoGeometryType;
topExports.EDracoDecodeType = exports.EDracoDecodeType;
topExports.EDracoDataType = exports.EDracoDataType;

      K_INS.set(MAIN_CANVAS, exports);
      return exports;
  };
  topExports.RELEASE_INSTANCE = (MAIN_CANVAS) => {
    var K_INS = globalThis.KANATA_INSTANCES = globalThis.KANATA_INSTANCES || new Map();
    if (K_INS.has(MAIN_CANVAS)) {
      K_INS.delete(MAIN_CANVAS);
    }
  };
})));

null

})(); /* LIBRARY_CLOSURE_END () */


} catch(err) {
      console.error('catch sdkSubPackage: kanata error: ', err)
    }
